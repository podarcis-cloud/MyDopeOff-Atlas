/* MyDope Off — page-femmes.js
   Dossier femmes. Seul besoin : MDCore.init() (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'femmes', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
