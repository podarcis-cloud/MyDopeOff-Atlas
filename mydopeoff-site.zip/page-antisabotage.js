/* MyDope Off — page-antisabotage.js
   Logique de antisabotage, extraite du script inline de antisabotage.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var body = document.getElementById('as-body');
  var STEPS = 5;
  var state = { pattern:'', trigger_situation:'', wish:'', outcome:'', obstacle:'', action:'' };

  var PATTERN_SUGG = [
    'Je repousse un rendez-vous ou une d\u00e9marche alors que je sais que \u00e7a va empirer',
    'Je coupe le contact avec quelqu\u2019un qui m\u2019aide, sans trop savoir pourquoi',
    'Je m\u2019arr\u00eate juste avant que quelque chose commence \u00e0 marcher pour moi',
    'Je replonge d\u00e8s que \u00e7a commence \u00e0 aller mieux'
  ];
  var OBSTACLE_SUGG = [
    'Je me dis qu\u2019une fois, \u00e7a ne changera rien',
    'Je me sens seul\u00b7e, d\u2019un coup',
    'Je veux juste que \u00e7a s\u2019arr\u00eate maintenant',
    'J\u2019ai l\u2019impression de ne pas m\u00e9riter que \u00e7a marche'
  ];

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function personalValues(){ try{ return window.MDData ? MDData.getValeurs() : []; }catch(e){ return []; } }

  function dots(i){
    var h=''; for(var k=0;k<STEPS;k++) h+='<div class="as-dot'+(k<=i?' on':'')+'"></div>';
    return '<div class="as-dots">'+h+'</div>';
  }
  function hero(text){
    var av = window.MDCompagnon && window.MDCompagnon.avatarHTML ? MDCompagnon.avatarHTML('bienveillance',{size:40}) : '';
    return '<div class="as-hero">'+av+'<div class="as-bub"><p>'+text+'</p></div></div>';
  }
  /* Rappelle visuellement ce que l'utilisateur a écrit à l'étape 1 — jamais de pronom
     vague (« ça », « cette fois ») sans le texte réel affiché juste au-dessus. */
  function recap(label, text){
    return '<div class="as-recap"><span class="as-recap-lbl">'+esc(label)+'</span><p>\u00ab '+esc(text)+' \u00bb</p></div>';
  }
  function chips(list){
    return '<div class="as-chips">'+list.map(function(s){
      return '<button type="button" class="as-chip" data-v="'+s.replace(/"/g,'&quot;')+'">'+s+'</button>';
    }).join('')+'</div>';
  }
  function wireChips(taId){
    body.querySelectorAll('.as-chip').forEach(function(b){
      b.addEventListener('click', function(){
        var ta = document.getElementById(taId);
        ta.value = b.getAttribute('data-v');
        body.querySelectorAll('.as-chip').forEach(function(x){ x.classList.remove('sel'); });
        b.classList.add('sel');
        ta.focus();
      });
    });
  }

  function step1(){
    body.innerHTML = dots(0) + hero('Pas besoin de tout lister. Une seule situation r\u00e9cente, pr\u00e9cise, sur laquelle revenir aujourd\u2019hui \u2014 \u00e7a suffit largement pour commencer.') +
      '<p class="game-step">1 \u00b7 Repérer une situation</p>' +
      '<p class="game-q">Il y a s\u00fbrement une situation o\u00f9 tu fais souvent l\u2019inverse de ce qui t\u2019aide. D\u00e9cris-la en une phrase.</p>' +
      chips(PATTERN_SUGG) +
      '<textarea class="as-ta" id="as-ta1" placeholder="ex : quand je me sens jug\u00e9\u00b7e, je coupe le contact avec les gens qui pourraient m\u2019aider">'+state.pattern+'</textarea>' +
      '<button class="game-cta" id="as-next1">Continuer</button>';
    wireChips('as-ta1');
    document.getElementById('as-next1').addEventListener('click', function(){
      state.pattern = document.getElementById('as-ta1').value.trim();
      if (!state.pattern) { document.getElementById('as-ta1').focus(); return; }
      step2();
    });
  }

  function step2(){
    var vals = personalValues();
    body.innerHTML = dots(1) + hero('Derri\u00e8re \u00e7a, il y a souvent quelque chose qui compte vraiment pour toi \u2014 pas juste \u00ab\u00a0arr\u00eater de\u2026\u00a0\u00bb.') +
      '<p class="game-step">2 \u00b7 Ce qui compte vraiment</p>' +
      recap('Tu as d\u00e9crit', state.pattern) +
      '<p class="game-q">Cette situation-l\u00e0 abîme quelque chose d\u2019important pour toi. Quoi, au juste ?</p>' +
      (vals.length ? chips(vals) : '') +
      '<textarea class="as-ta" id="as-ta2" placeholder="ex : garder un lien avec les gens qui comptent">'+state.wish+'</textarea>' +
      '<button class="game-cta" id="as-next2">Continuer</button>';
    wireChips('as-ta2');
    document.getElementById('as-next2').addEventListener('click', function(){
      state.wish = document.getElementById('as-ta2').value.trim();
      if (!state.wish) { document.getElementById('as-ta2').focus(); return; }
      step3();
    });
  }

  function step3(){
    body.innerHTML = dots(2) + hero('Ferme presque les yeux, quelques secondes. Vois la version o\u00f9 \u00e7a se passe bien \u2014 pas dans l\u2019abstrait, une sc\u00e8ne pr\u00e9cise.') +
      '<div class="as-breathe" id="as-breathe"><span id="as-breathe-n">3</span></div>' +
      '<p class="game-step">3 \u00b7 Le résultat que tu veux</p>' +
      recap('La situation', state.pattern) +
      '<div id="as-step3-rest" style="opacity:0;pointer-events:none;transition:opacity .5s">' +
      '<p class="game-q">Imagine que la prochaine fois, \u00e7a se passe bien. Concr\u00e8tement, \u00e0 quoi \u00e7a ressemble ?</p>' +
      '<textarea class="as-ta" id="as-ta3" placeholder="ex : je r\u00e9ponds au message au lieu de le laisser en attente">'+state.outcome+'</textarea>' +
      '<button class="game-cta" id="as-next3">Continuer</button>' +
      '</div>';
    var n = 3, nEl = document.getElementById('as-breathe-n');
    var iv = setInterval(function(){
      n--;
      if (n <= 0) {
        clearInterval(iv);
        nEl.textContent = '';
        var rest = document.getElementById('as-step3-rest');
        rest.style.opacity = '1'; rest.style.pointerEvents = 'auto';
        document.getElementById('as-next3').addEventListener('click', function(){
          state.outcome = document.getElementById('as-ta3').value.trim();
          if (!state.outcome) { document.getElementById('as-ta3').focus(); return; }
          step4();
        });
      } else { nEl.textContent = n; }
    }, 1000);
  }

  function step4(){
    body.innerHTML = dots(3) + hero('C\u2019est l\u2019\u00e9tape la plus honn\u00eate : pas l\u2019excuse qu\u2019on se donne d\u2019habitude, mais ce qui se passe juste avant elle, dans la t\u00eate.') +
      '<p class="game-step">4 \u00b7 Le déclencheur intérieur</p>' +
      recap('La situation', state.pattern) +
      '<p class="game-q">Juste avant ce moment-l\u00e0, qu\u2019est-ce qui se passe dans ta t\u00eate ?</p>' +
      chips(OBSTACLE_SUGG) +
      '<textarea class="as-ta" id="as-ta4" placeholder="ex : je me dis que je ne m\u00e9rite pas que \u00e7a marche">'+state.obstacle+'</textarea>' +
      '<button class="game-cta" id="as-next4">Continuer</button>';
    wireChips('as-ta4');
    document.getElementById('as-next4').addEventListener('click', function(){
      state.obstacle = document.getElementById('as-ta4').value.trim();
      if (!state.obstacle) { document.getElementById('as-ta4').focus(); return; }
      step5();
    });
  }

  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

  function step5(){
    body.innerHTML = dots(4) + hero('Une r\u00e9ponse simple, assez pr\u00e9cise pour se d\u00e9clencher toute seule, sans avoir \u00e0 y r\u00e9fl\u00e9chir sur le moment.') +
      '<p class="game-step">5 \u00b7 Ta réponse toute prête</p>' +
      recap('Le signal à repérer', state.obstacle) +
      '<p class="game-q">Quand ce signal arrive, qu\u2019est-ce que tu fais \u00e0 la place ?</p>' +
      '<textarea class="as-ta" id="as-ta5" placeholder="ex : je pose mon t\u00e9l\u00e9phone 2 minutes avant de r\u00e9pondre \u00e0 quoi que ce soit"></textarea>' +
      '<button class="game-cta" id="as-next5">Voir mon plan</button>';
    document.getElementById('as-next5').addEventListener('click', function(){
      state.action = document.getElementById('as-ta5').value.trim();
      if (!state.action) { document.getElementById('as-ta5').focus(); return; }
      finish();
    });
  }

  function finish(){
    try{
      var d = store();
      d.parcours = d.parcours || {};
      d.parcours.antiSabotage = state;
      save(d);
    }catch(e){}
    body.innerHTML = dots(4) +
      '<p class="game-step">Ton plan</p>' +
      '<div class="as-plan"><span class="as-plan-lbl">Le signal</span>'+esc(state.obstacle)+
      '<span class="as-plan-lbl" style="margin-top:10px">Ce que je fais à la place</span>'+esc(state.action)+'</div>' +
      '<p class="game-sub">Ce que \u00e7a protège pour toi : '+esc(state.wish)+'.</p>';
    if (window.MDExercise){
      MDExercise.after('antisabotage', { meta:{ a_un_plan:true },
        title:'Plan anti-sabotage',
        nav:{ primary:{label:'Refaire un plan'} },
        onClose:function(){ state={pattern:'',trigger_situation:'',wish:'',outcome:'',obstacle:'',action:''}; step1(); } });
    } else if (window.MDData && MDData.logSession) { MDData.logSession('antisabotage', { meta:{ a_un_plan:true } }); }
  }

  function showExisting(existing){
    body.innerHTML = hero('Tu as d\u00e9j\u00e0 un plan enregistr\u00e9. Tu peux le relire, ou en construire un nouveau si ta situation a chang\u00e9.') +
      '<p class="game-step">Ton plan</p>' +
      '<div class="as-plan"><span class="as-plan-lbl">Le signal</span>'+esc(existing.obstacle)+
      '<span class="as-plan-lbl" style="margin-top:10px">Ce que je fais à la place</span>'+esc(existing.action)+'</div>' +
      '<p class="game-sub">Ce que \u00e7a protège pour toi : '+esc(existing.wish)+'.</p>' +
      '<button class="game-cta" id="as-new">Construire un nouveau plan</button>' +
      '<button class="game-cta-link" id="as-end2">Fermer</button>';
    document.getElementById('as-new').addEventListener('click', function(){ state={pattern:'',trigger_situation:'',wish:'',outcome:'',obstacle:'',action:''}; step1(); });
    document.getElementById('as-end2').addEventListener('click', function(){ location.href='fiches.html'; });
  }

  function begin(){
    var existing = null;
    try{ var d=store(); existing = d.parcours && d.parcours.antiSabotage && d.parcours.antiSabotage.action ? d.parcours.antiSabotage : null; }catch(e){}
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'reflexion', title:'Plan anti-sabotage',
        lines:['Des fois, on sait très bien ce qui compte pour nous \u2014 et on fait quand m\u00eame l\u2019inverse, sans trop savoir pourquoi sur le moment.',
               'En 5 petites \u00e9tapes, on va nommer ce qui se passe, puis pr\u00e9parer \u00e0 l\u2019avance une r\u00e9ponse simple pour la prochaine fois.',
               'Des phrases courtes, \u00e0 ton rythme \u2014 rien de compliqu\u00e9.'],
        why:'Pr\u00e9parer sa r\u00e9ponse \u00e0 l\u2019avance, plut\u00f4t que de compter sur un sursaut de volont\u00e9 au moment m\u00eame, est l\u2019un des leviers les mieux documentés pour changer une habitude \u2014 surtout que ce moment-l\u00e0 est justement celui o\u00f9 la volont\u00e9 est la moins disponible.',
        hideGauge:true,
        onStart:function(){ if (existing) showExisting(existing); else step1(); } });
    } else { if (existing) showExisting(existing); else step1(); }
  }
  document.getElementById('as-start').addEventListener('click', begin);
  document.getElementById('as-skip').addEventListener('click', begin);
  try{ MDCore.init({page:'antisabotage',section:'equilibre'}); }catch(e){}
  begin();
})();
