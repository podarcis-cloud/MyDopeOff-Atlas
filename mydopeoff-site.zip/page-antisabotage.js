/* MyDope Off — page-antisabotage.js
   Logique de antisabotage, extraite du script inline de antisabotage.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var body = document.getElementById('as-body');
  var STEPS = 5;
  var state = { pattern:'', trigger_situation:'', wish:'', outcome:'', obstacle:'', action:'' };

  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var T = {
    pattern1:{ fr:'Je repousse un rendez-vous ou une démarche alors que je sais que ça va empirer', en:'I put off an appointment or a step even though I know it will make things worse' },
    pattern2:{ fr:'Je coupe le contact avec quelqu\u2019un qui m\u2019aide, sans trop savoir pourquoi', en:'I cut contact with someone who helps me, without really knowing why' },
    pattern3:{ fr:'Je m\u2019arrête juste avant que quelque chose commence à marcher pour moi', en:'I stop right before something starts working for me' },
    pattern4:{ fr:'Je replonge dès que ça commence à aller mieux', en:'I relapse as soon as things start getting better' },
    obstacle1:{ fr:'Je me dis qu\u2019une fois, ça ne changera rien', en:'I tell myself that just once won\u2019t change anything' },
    obstacle2:{ fr:'Je me sens seul\u00b7e, d\u2019un coup', en:'I suddenly feel alone' },
    obstacle3:{ fr:'Je veux juste que ça s\u2019arrête maintenant', en:'I just want it to stop right now' },
    obstacle4:{ fr:'J\u2019ai l\u2019impression de ne pas mériter que ça marche', en:'I feel like I don\u2019t deserve for it to work' },
    hero1:{ fr:'Pas besoin de tout lister. Une seule situation récente, précise, sur laquelle revenir aujourd\u2019hui \u2014 ça suffit largement pour commencer.', en:'No need to list everything. Just one recent, specific situation to revisit today \u2014 that\u2019s more than enough to start.' },
    step1_label:{ fr:'1 \u00b7 Repérer une situation', en:'1 \u00b7 Spot a situation' },
    step1_q:{ fr:'Il y a sûrement une situation où tu fais souvent l\u2019inverse de ce qui t\u2019aide. Décris-la en une phrase.', en:'There\u2019s probably a situation where you often do the opposite of what helps you. Describe it in one sentence.' },
    step1_ph:{ fr:'ex\u00a0: quand je me sens jugé\u00b7e, je coupe le contact avec les gens qui pourraient m\u2019aider', en:'e.g.: when I feel judged, I cut contact with the people who could help me' },
    continue:{ fr:'Continuer', en:'Continue' },
    hero2:{ fr:'Derrière ça, il y a souvent quelque chose qui compte vraiment pour toi \u2014 pas juste \u00ab\u00a0arrêter de\u2026\u00a0\u00bb.', en:'Behind that, there\u2019s often something that really matters to you \u2014 not just \u201cstop doing\u2026\u201d.' },
    step2_label:{ fr:'2 \u00b7 Ce qui compte vraiment', en:'2 \u00b7 What really matters' },
    recap_described:{ fr:'Tu as décrit', en:'You described' },
    step2_q:{ fr:'Cette situation-là abîme quelque chose d\u2019important pour toi. Quoi, au juste\u00a0?', en:'That situation damages something important to you. What, exactly?' },
    step2_ph:{ fr:'ex\u00a0: garder un lien avec les gens qui comptent', en:'e.g.: keeping a connection with the people who matter' },
    hero3:{ fr:'Ferme presque les yeux, quelques secondes. Vois la version où ça se passe bien \u2014 pas dans l\u2019abstrait, une scène précise.', en:'Almost close your eyes, for a few seconds. Picture the version where it goes well \u2014 not in the abstract, a specific scene.' },
    step3_label:{ fr:'3 \u00b7 Le résultat que tu veux', en:'3 \u00b7 The outcome you want' },
    recap_situation:{ fr:'La situation', en:'The situation' },
    step3_q:{ fr:'Imagine que la prochaine fois, ça se passe bien. Concrètement, à quoi ça ressemble\u00a0?', en:'Imagine that next time, it goes well. Concretely, what does that look like?' },
    step3_ph:{ fr:'ex\u00a0: je réponds au message au lieu de le laisser en attente', en:'e.g.: I reply to the message instead of leaving it unanswered' },
    hero4:{ fr:'C\u2019est l\u2019étape la plus honnête\u00a0: pas l\u2019excuse qu\u2019on se donne d\u2019habitude, mais ce qui se passe juste avant elle, dans la tête.', en:'This is the most honest step: not the excuse you usually give yourself, but what happens right before it, in your head.' },
    step4_label:{ fr:'4 \u00b7 Le déclencheur intérieur', en:'4 \u00b7 The inner trigger' },
    step4_q:{ fr:'Juste avant ce moment-là, qu\u2019est-ce qui se passe dans ta tête\u00a0?', en:'Right before that moment, what\u2019s going on in your head?' },
    step4_ph:{ fr:'ex\u00a0: je me dis que je ne mérite pas que ça marche', en:'e.g.: I tell myself I don\u2019t deserve for it to work' },
    hero5:{ fr:'Une réponse simple, assez précise pour se déclencher toute seule, sans avoir à y réfléchir sur le moment.', en:'A simple response, precise enough to trigger on its own, without having to think it through in the moment.' },
    step5_label:{ fr:'5 \u00b7 Ta réponse toute prête', en:'5 \u00b7 Your ready-made response' },
    recap_signal:{ fr:'Le signal à repérer', en:'The signal to watch for' },
    step5_q:{ fr:'Quand ce signal arrive, qu\u2019est-ce que tu fais à la place\u00a0?', en:'When that signal shows up, what do you do instead?' },
    step5_ph:{ fr:'ex\u00a0: je pose mon téléphone 2 minutes avant de répondre à quoi que ce soit', en:'e.g.: I put my phone down for 2 minutes before responding to anything' },
    see_plan:{ fr:'Voir mon plan', en:'See my plan' },
    plan_title:{ fr:'Ton plan', en:'Your plan' },
    plan_signal:{ fr:'Le signal', en:'The signal' },
    plan_instead:{ fr:'Ce que je fais à la place', en:'What I do instead' },
    plan_protects:{ fr:'Ce que ça protège pour toi\u00a0:', en:'What this protects for you:' },
    exercise_title:{ fr:'Plan anti-sabotage', en:'Anti-sabotage plan' },
    redo_plan:{ fr:'Refaire un plan', en:'Make a new plan' },
    existing_hero:{ fr:'Tu as déjà un plan enregistré. Tu peux le relire, ou en construire un nouveau si ta situation a changé.', en:'You already have a saved plan. You can re-read it, or build a new one if your situation has changed.' },
    new_plan:{ fr:'Construire un nouveau plan', en:'Build a new plan' },
    close:{ fr:'Fermer', en:'Close' },
    rules_line1:{ fr:'Des fois, on sait très bien ce qui compte pour nous \u2014 et on fait quand même l\u2019inverse, sans trop savoir pourquoi sur le moment.', en:'Sometimes you know very well what matters to you \u2014 and you do the opposite anyway, without quite knowing why in the moment.' },
    rules_line2:{ fr:'En 5 petites étapes, on va nommer ce qui se passe, puis préparer à l\u2019avance une réponse simple pour la prochaine fois.', en:'In 5 small steps, we\u2019ll name what\u2019s happening, then prepare a simple response in advance for next time.' },
    rules_line3:{ fr:'Des phrases courtes, à ton rythme \u2014 rien de compliqué.', en:'Short sentences, at your own pace \u2014 nothing complicated.' },
    rules_why:{ fr:'Préparer sa réponse à l\u2019avance, plutôt que de compter sur un sursaut de volonté au moment même, est l\u2019un des leviers les mieux documentés pour changer une habitude \u2014 surtout que ce moment-là est justement celui où la volonté est la moins disponible.', en:'Preparing your response in advance, rather than counting on a surge of willpower in the moment itself, is one of the best-documented levers for changing a habit \u2014 especially since that moment is exactly when willpower is least available.' }
  };
  function t(key){ var e = T[key]; return e ? (lang()==='en' ? e.en : e.fr) : key; }

  var PATTERN_SUGG = [t('pattern1'), t('pattern2'), t('pattern3'), t('pattern4')];
  var OBSTACLE_SUGG = [t('obstacle1'), t('obstacle2'), t('obstacle3'), t('obstacle4')];

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function personalValues(){ try{ return window.MDData ? MDData.getValeurs() : []; }catch(e){ return []; } }

  function dots(i){
    var h=''; for(var k=0;k<STEPS;k++) h+='<div class="as-dot'+(k<=i?' on':'')+'"></div>';
    return '<div class="as-dots">'+h+'</div>';
  }
  function hero(text){
    var av = window.MDCompagnon && window.MDCompagnon.avatarHTML ? MDCompagnon.avatarHTML('bienveillance',{size:40}) : '';
    return '<div class="as-hero">'+av+'<div class="as-bub"><p>'+text+'</p></div></div>';
  }
  /* Rappelle visuellement ce que l'utilisateur a écrit à l'étape 1 — jamais de pronom
     vague (« ça », « cette fois ») sans le texte réel affiché juste au-dessus. */
  function recap(label, text){
    return '<div class="as-recap"><span class="as-recap-lbl">'+esc(label)+'</span><p>\u00ab '+esc(text)+' \u00bb</p></div>';
  }
  function chips(list){
    return '<div class="as-chips">'+list.map(function(s){
      return '<button type="button" class="as-chip" data-v="'+s.replace(/"/g,'&quot;')+'">'+s+'</button>';
    }).join('')+'</div>';
  }
  function wireChips(taId){
    body.querySelectorAll('.as-chip').forEach(function(b){
      b.addEventListener('click', function(){
        var ta = document.getElementById(taId);
        ta.value = b.getAttribute('data-v');
        body.querySelectorAll('.as-chip').forEach(function(x){ x.classList.remove('sel'); });
        b.classList.add('sel');
        ta.focus();
      });
    });
  }

  function step1(){
    body.innerHTML = dots(0) + hero(t('hero1')) +
      '<p class="game-step">'+t('step1_label')+'</p>' +
      '<p class="game-q">'+t('step1_q')+'</p>' +
      chips(PATTERN_SUGG) +
      '<textarea class="as-ta" id="as-ta1" placeholder="'+t('step1_ph')+'">'+state.pattern+'</textarea>' +
      '<button class="game-cta" id="as-next1">'+t('continue')+'</button>';
    wireChips('as-ta1');
    document.getElementById('as-next1').addEventListener('click', function(){
      state.pattern = document.getElementById('as-ta1').value.trim();
      if (!state.pattern) { document.getElementById('as-ta1').focus(); return; }
      step2();
    });
  }

  function step2(){
    var vals = personalValues();
    body.innerHTML = dots(1) + hero(t('hero2')) +
      '<p class="game-step">'+t('step2_label')+'</p>' +
      recap(t('recap_described'), state.pattern) +
      '<p class="game-q">'+t('step2_q')+'</p>' +
      (vals.length ? chips(vals) : '') +
      '<textarea class="as-ta" id="as-ta2" placeholder="'+t('step2_ph')+'">'+state.wish+'</textarea>' +
      '<button class="game-cta" id="as-next2">'+t('continue')+'</button>';
    wireChips('as-ta2');
    document.getElementById('as-next2').addEventListener('click', function(){
      state.wish = document.getElementById('as-ta2').value.trim();
      if (!state.wish) { document.getElementById('as-ta2').focus(); return; }
      step3();
    });
  }

  function step3(){
    body.innerHTML = dots(2) + hero(t('hero3')) +
      '<div class="as-breathe" id="as-breathe"><span id="as-breathe-n">3</span></div>' +
      '<p class="game-step">'+t('step3_label')+'</p>' +
      recap(t('recap_situation'), state.pattern) +
      '<div id="as-step3-rest" style="opacity:0;pointer-events:none;transition:opacity .5s">' +
      '<p class="game-q">'+t('step3_q')+'</p>' +
      '<textarea class="as-ta" id="as-ta3" placeholder="'+t('step3_ph')+'">'+state.outcome+'</textarea>' +
      '<button class="game-cta" id="as-next3">'+t('continue')+'</button>' +
      '</div>';
    var n = 3, nEl = document.getElementById('as-breathe-n');
    var iv = setInterval(function(){
      n--;
      if (n <= 0) {
        clearInterval(iv);
        nEl.textContent = '';
        var rest = document.getElementById('as-step3-rest');
        rest.style.opacity = '1'; rest.style.pointerEvents = 'auto';
        document.getElementById('as-next3').addEventListener('click', function(){
          state.outcome = document.getElementById('as-ta3').value.trim();
          if (!state.outcome) { document.getElementById('as-ta3').focus(); return; }
          step4();
        });
      } else { nEl.textContent = n; }
    }, 1000);
  }

  function step4(){
    body.innerHTML = dots(3) + hero(t('hero4')) +
      '<p class="game-step">'+t('step4_label')+'</p>' +
      recap(t('recap_situation'), state.pattern) +
      '<p class="game-q">'+t('step4_q')+'</p>' +
      chips(OBSTACLE_SUGG) +
      '<textarea class="as-ta" id="as-ta4" placeholder="'+t('step4_ph')+'">'+state.obstacle+'</textarea>' +
      '<button class="game-cta" id="as-next4">'+t('continue')+'</button>';
    wireChips('as-ta4');
    document.getElementById('as-next4').addEventListener('click', function(){
      state.obstacle = document.getElementById('as-ta4').value.trim();
      if (!state.obstacle) { document.getElementById('as-ta4').focus(); return; }
      step5();
    });
  }

  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

  function step5(){
    body.innerHTML = dots(4) + hero(t('hero5')) +
      '<p class="game-step">'+t('step5_label')+'</p>' +
      recap(t('recap_signal'), state.obstacle) +
      '<p class="game-q">'+t('step5_q')+'</p>' +
      '<textarea class="as-ta" id="as-ta5" placeholder="'+t('step5_ph')+'"></textarea>' +
      '<button class="game-cta" id="as-next5">'+t('see_plan')+'</button>';
    document.getElementById('as-next5').addEventListener('click', function(){
      state.action = document.getElementById('as-ta5').value.trim();
      if (!state.action) { document.getElementById('as-ta5').focus(); return; }
      finish();
    });
  }

  function finish(){
    try{
      var d = store();
      d.parcours = d.parcours || {};
      d.parcours.antiSabotage = state;
      save(d);
    }catch(e){}
    body.innerHTML = dots(4) +
      '<p class="game-step">'+t('plan_title')+'</p>' +
      '<div class="as-plan"><span class="as-plan-lbl">'+t('plan_signal')+'</span>'+esc(state.obstacle)+
      '<span class="as-plan-lbl" style="margin-top:10px">'+t('plan_instead')+'</span>'+esc(state.action)+'</div>' +
      '<p class="game-sub">'+t('plan_protects')+' '+esc(state.wish)+'.</p>';
    if (window.MDExercise){
      MDExercise.after('antisabotage', { meta:{ a_un_plan:true },
        title:t('exercise_title'),
        nav:{ primary:{label:t('redo_plan')} },
        onClose:function(){ state={pattern:'',trigger_situation:'',wish:'',outcome:'',obstacle:'',action:''}; step1(); } });
    } else if (window.MDData && MDData.logSession) { MDData.logSession('antisabotage', { meta:{ a_un_plan:true } }); }
  }

  function showExisting(existing){
    body.innerHTML = hero(t('existing_hero')) +
      '<p class="game-step">'+t('plan_title')+'</p>' +
      '<div class="as-plan"><span class="as-plan-lbl">'+t('plan_signal')+'</span>'+esc(existing.obstacle)+
      '<span class="as-plan-lbl" style="margin-top:10px">'+t('plan_instead')+'</span>'+esc(existing.action)+'</div>' +
      '<p class="game-sub">'+t('plan_protects')+' '+esc(existing.wish)+'.</p>' +
      '<button class="game-cta" id="as-new">'+t('new_plan')+'</button>' +
      '<button class="game-cta-link" id="as-end2">'+t('close')+'</button>';
    document.getElementById('as-new').addEventListener('click', function(){ state={pattern:'',trigger_situation:'',wish:'',outcome:'',obstacle:'',action:''}; step1(); });
    document.getElementById('as-end2').addEventListener('click', function(){ location.href='fiches.html'; });
  }

  function begin(){
    var existing = null;
    try{ var d=store(); existing = d.parcours && d.parcours.antiSabotage && d.parcours.antiSabotage.action ? d.parcours.antiSabotage : null; }catch(e){}
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'reflexion', title:t('exercise_title'),
        lines:[t('rules_line1'), t('rules_line2'), t('rules_line3')],
        why:t('rules_why'),
        hideGauge:true,
        onStart:function(){ if (existing) showExisting(existing); else step1(); } });
    } else { if (existing) showExisting(existing); else step1(); }
  }
  try{ MDCore.init({page:'antisabotage',section:'equilibre'}); }catch(e){}
  begin();
})();
