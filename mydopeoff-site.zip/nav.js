/* MyDope Off — nav.js
   SOURCE UNIQUE de la barre de navigation, partagée par TOUTES les pages.
   Usage : placer <div data-nav="CLE"></div> à l'endroit voulu et charger ce fichier.
   CLE = index | suivi | psychochecker | fiches | rdr  (vide = aucun onglet actif).
   Aucune dépendance : ne touche QUE l'élément [data-nav]. */
(function () {
  'use strict';
  var ITEMS = [
    { k:'index',         href:'index.html',         label:'Accueil',     icon:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>' },
    { k:'suivi',         href:'suivi.html',         label:'Suivi', icon:'<path d="M3 18 L9 11 l4 4 L21 6"/>' },
    { k:'psychochecker', href:'psychochecker.html', label:'Substances',  icon:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>' },
    { k:'fiches',        href:'fiches.html',        label:'Parcours',   icon:'<path d="M3 12h4l2 5 4-12 2 7h6"/>' },
    { k:'rdr',           href:'rdr.html',           label:'Sécurité',    icon:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>' }
  ];

  function render(active) {
    return '<nav class="bn show" aria-label="Navigation principale">' +
      ITEMS.map(function (n) {
        var on = (n.k === active);
        return '<a class="' + (on ? 'on' : '') + '" href="' + n.href + '"' + (on ? ' aria-current="page"' : '') + '>' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + n.icon + '</svg>' +
          '<span>' + n.label + '</span></a>';
      }).join('') + '</nav>';
  }

  function mountFooter(host){
    try{
      if(document.querySelector('.priv-foot')) return;
      if(/aucune inscription/i.test((document.body&&document.body.textContent)||'')) return;
      var f=document.createElement('footer');
      f.className='priv-foot';
      var api=window.MDCore||window.LUCIDE;
      var cur=(function(){try{return localStorage.getItem('mydopeoff_lang')||'fr';}catch(e){return 'fr';}})();
      var lw=document.createElement('div'); lw.className='foot-lang';
      ['fr','en'].forEach(function(l){ var b=document.createElement('button'); b.type='button'; b.textContent=l.toUpperCase(); if(l===cur)b.className='on';
        b.addEventListener('click',function(){ try{ localStorage.setItem('mydopeoff_lang',l); }catch(e){} var a=window.MDCore||window.LUCIDE; if(a&&a.setLang){ a.setLang(l); } else if(window.MDTranslateDOM){ window.MDTranslateDOM(l==='en'); } lw.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b);}); });
        lw.appendChild(b); });
      var note=document.createElement('div'); note.textContent='Aucun compte \u00b7 aucune inscription en ligne \u00b7 100 % local';
      f.appendChild(lw); f.appendChild(note);
      host.parentNode.insertBefore(f, host);
      try{ var _ll=localStorage.getItem('mydopeoff_lang')||'fr'; if(_ll==='en' && window.MDTranslateDOM) setTimeout(function(){ window.MDTranslateDOM(true); },0); }catch(e){}
    }catch(e){}
  }
  function mount() {
    var host = document.querySelector('[data-nav]');
    if (!host) return;
    mountFooter(host);
    var active = host.getAttribute('data-nav') || (document.body && document.body.getAttribute('data-page')) || '';
    host.outerHTML = render(active);
  }

  if (document.readyState !== 'loading') mount();
  else document.addEventListener('DOMContentLoaded', mount);

  window.MDNav = { render: render, items: ITEMS, mount: mount };
})();
