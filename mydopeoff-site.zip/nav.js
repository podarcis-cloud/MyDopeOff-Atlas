/* MyDope Off — nav.js
   SOURCE UNIQUE de la barre de navigation, partagée par TOUTES les pages.
   Usage : placer <div data-nav="CLE"></div> à l'endroit voulu et charger ce fichier.
   CLE = index | suivi | psychochecker | fiches | rdr  (vide = aucun onglet actif).
   Aucune dépendance : ne touche QUE l'élément [data-nav]. */
(function () {
  'use strict';
  var ITEMS = [
    { k:'index',         href:'index.html',         label:'Accueil',     icon:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>' },
    { k:'suivi',         href:'suivi.html',         label:'Progression', icon:'<path d="M3 18 L9 11 l4 4 L21 6"/>' },
    { k:'psychochecker', href:'psychochecker.html', label:'Substances',  icon:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>' },
    { k:'fiches',        href:'fiches.html',        label:'Équilibre',   icon:'<path d="M3 12h4l2 5 4-12 2 7h6"/>' },
    { k:'rdr',           href:'rdr.html',           label:'Sécurité',    icon:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>' }
  ];

  function render(active) {
    return '<nav class="bn show" aria-label="Navigation principale">' +
      ITEMS.map(function (n) {
        var on = (n.k === active);
        return '<a class="' + (on ? 'on' : '') + '" href="' + n.href + '"' + (on ? ' aria-current="page"' : '') + '>' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + n.icon + '</svg>' +
          '<span>' + n.label + '</span></a>';
      }).join('') + '</nav>';
  }

  function mount() {
    var host = document.querySelector('[data-nav]');
    if (!host) return;
    var active = host.getAttribute('data-nav') || (document.body && document.body.getAttribute('data-page')) || '';
    host.outerHTML = render(active);
  }

  if (document.readyState !== 'loading') mount();
  else document.addEventListener('DOMContentLoaded', mount);

  window.MDNav = { render: render, items: ITEMS, mount: mount };
})();
