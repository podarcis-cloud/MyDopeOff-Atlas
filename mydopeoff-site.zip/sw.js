/* MyDope Off — service worker (à plat). Bump CACHE à chaque déploiement. */
const CACHE='mydopeoff-v319';
const CORE=[
  './','index.html','tokens.css','components.css',
  'core.js','data.js','decor.js','compagnon.js','exercise.js','jeu-hero.js','parcours.js','urgence.js','scanner.js','inhib.js','identite.js','dossier-guide.js','page-dossier.js','page-intro.js','page-echo.js','page-braise.js','page-filtre.js','page-patience.js','page-surf.js','page-virage.js','page-elan.js','page-antisabotage.js','page-dualtask.js','page-breathe.js','page-lettre.js','page-guide.js','page-tetris.js','page-soutenir.js','page-maze.js','page-fiches.js','progression-recit.js','memoire-mascotte.js','i18n.js','dossiers-i18n.js',"i18n-phrases.js",'regions.js','manifest.json',
  'icon-192.png','icon-512.png','apple-touch-icon.png','logo-atlas.svg','logo-mark.png','craving-sos.png','surf-hero.png','surfer.svg'
];
const OPTIONAL=[
  'suivi.html','detection.html','page-index.js','theme-toggle.js','theme-early.js','page-suivi.js','historique.js','page-detection.js','nav.js','backup.js','page-rdr.js','page-controles.js','page-inscription.js',
  'psychochecker.html','fiches.html','rdr.html','crack.html','ketamine.html','nitreux.html','opioides-synthese.html','alcool.html','cannabis.html','cocaine.html','benzodiazepines.html','mdma.html','tabac-vapotage.html','polyconsommation.html','rechute.html','psychedeliques.html','rdr-vs-abstinence.html','autosabotage.html','antisabotage.html','memoire-autosabotage.pdf','controles.html','guide.html','breathe.html',"lettre.html","souffle.png","tetris.png","maze.png",'soutenir.html','inscription.html',
  'maze.html','tetris.html','surf.html','echo.html','braise.html','patience.html','filtre.html','virage.html','dualtask.html','elan.html','antisabotage.html','bilan-hero.js','anecdotes.js','debriefs.js',
  'profil.html','page-profil.js','trophies.js',
  'detection-data.js','substances-index.js','custom-substances.js','page-admin.js','admin.html','interactions-fix.js','interactions-data.js','substance-classes.js','psychochecker-data.js','new-substances.js','page-psychochecker.js',
  'fiches-i18n.js','controles-i18n.js','guide-i18n.js','protocols-i18n.js','rdr-i18n.js','icon-512-maskable.png','hero-atlas.jpg','tabs/suivi.png','tabs/substance.png','tabs/parcours.png','tabs/rdr.png','tabs/bilan.png','art-waves.jpg','art-topo.jpg','art-bloom.jpg','art-progression.jpg','art-substances.jpg','art-equilibre.jpg','art-securite.jpg','art-bilan.jpg',
  'avatars/serenite.png','avatars/respiration.png','avatars/reflexion.png','avatars/explication.png','avatars/motivation.png','avatars/bienveillance.png','avatars/ecoute.png','avatars/action.png','avatars/projection.png','avatars/encouragement.png','avatars/pause.png','avatars/celebration.png',
  'avatars/curiosite.png','avatars/concentration.png','avatars/doute.png','avatars/depassement.png','avatars/changement.png','avatars/prise-de-recul.png','avatars/gratitude.png','avatars/lacher-prise.png','avatars/decision.png','avatars/energie.png','avatars/introspection.png','avatars/espoir.png',
  'avatars/inspiration.png','avatars/clarification.png','avatars/vigilance.png','avatars/adaptation.png','avatars/acceptation.png','avatars/ancrage.png','avatars/curiosite-active.png','avatars/choix-eclaire.png','avatars/ressource.png','avatars/transmission.png','avatars/resilience.png','avatars/horizon.png',
  'avatars/tristesse.png','avatars/colere.png','avatars/fatigue.png','avatars/solitude.png','avatars/vulnerabilite.png','avatars/fierte.png','avatars/soulagement.png','avatars/confiance.png','avatars/complicite.png','avatars/emerveillement.png','avatars/tendresse.png','avatars/impatience.png','avatars/craving.png',
  'ill-cards/1-tristesse.png','ill-cards/2-colere.png','ill-cards/3-fatigue.png','ill-cards/4-solitude.png','ill-cards/5-vulnerabilite.png','ill-cards/6-fierte.png','ill-cards/7-soulagement.png','ill-cards/8-confiance.png','ill-cards/9-complicite.png','ill-cards/10-emerveillement.png','ill-cards/11-tendresse.png','ill-cards/12-impatience.png',
  'ill-cards/13-curiosite.png','ill-cards/14-concentration.png','ill-cards/15-doute.png','ill-cards/16-depassement.png','ill-cards/17-changement.png','ill-cards/18-prise-de-recul.png','ill-cards/19-gratitude.png','ill-cards/20-craving.png','ill-cards/21-decision.png','ill-cards/22-energie.png','ill-cards/23-introspection.png','ill-cards/24-espoir.png','ill-cards/25-accueil.png','ill-cards/26-questionnement.png','ill-cards/27-decouverte.png','ill-cards/28-comprehension.png','ill-cards/29-patience.png','ill-cards/30-connexion.png','ill-cards/31-equilibre.png','ill-cards/32-protection.png','ill-cards/33-exploration.png','ill-cards/34-partage.png','ill-cards/35-perseverance.png','ill-cards/36-accomplissement.png'
];
self.addEventListener('install', e=>{
  e.waitUntil((async()=>{
    const c=await caches.open(CACHE);
    await c.addAll(CORE);                 // doit réussir
    await Promise.allSettled(OPTIONAL.map(u=>c.add(u))); // best-effort
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e=>{
  e.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
    self.clients.claim();
  })());
});
self.addEventListener('fetch', e=>{
  const r=e.request; if(r.method!=='GET') return;
  const url=new URL(r.url);
  // Fonts Google & externes : cache-first (immuables)
  if(url.origin!==location.origin){
    e.respondWith((async()=>{ const c=await caches.match(r); if(c) return c;
      try{ const net=await fetch(r); return net; }catch(err){ return c; } })());
    return;
  }
  // Même origine (HTML/CSS/JS/images du site) : NETWORK-FIRST -> toujours la dernière version,
  // cache mis à jour à chaque fois, et servi en secours si hors-ligne.
  e.respondWith((async()=>{
    try{
      const net=await fetch(r, {cache:'no-store'});
      if(net && net.status===200){ const c=await caches.open(CACHE); c.put(r, net.clone()); }
      return net;
    }catch(err){
      const cached=await caches.match(r);
      return cached || caches.match('index.html');
    }
  })());
});
