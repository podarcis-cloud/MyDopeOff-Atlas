/* MyDope Off — service worker (à plat). Bump CACHE à chaque déploiement. */
const CACHE='mydopeoff-v83-atlas';
const CORE=[
  './','index.html','tokens.css','components.css',
  'core.js','i18n.js',"i18n-phrases.js",'regions.js','manifest.json',
  'icon-192.png','icon-512.png','apple-touch-icon.png'
];
const OPTIONAL=[
  'suivi.html','detection.html','page-index.js','page-suivi.js','page-detection.js','nav.js','page-rdr.js','page-controles.js','page-inscription.js',
  'psychochecker.html','fiches.html','rdr.html','controles.html','guide.html','breathe.html',"lettre.html","souffle.png","tetris.png","maze.png",'soutenir.html','inscription.html',
  'maze.html','tetris.html','bilans.html','page-bilans.js','lucide.js',
  'detection-data.js','substances-index.js','custom-substances.js','page-admin.js','admin.html','interactions-fix.js','interactions-data.js','substance-classes.js','new-substances.js',
  'brand.html','page-brand.js','brand/board-1-elements.jpg','brand/board-2-master.jpg','brand/board-3-concepts.jpg','fiches-i18n.js','controles-i18n.js','guide-i18n.js','protocols-i18n.js','rdr-i18n.js','icon-512-maskable.png','art-waves.jpg','art-topo.jpg','art-bloom.jpg','art-progression.jpg','art-substances.jpg','art-equilibre.jpg','art-securite.jpg','art-bilan.jpg'
];
self.addEventListener('install', e=>{
  e.waitUntil((async()=>{
    const c=await caches.open(CACHE);
    await c.addAll(CORE);                 // doit réussir
    await Promise.allSettled(OPTIONAL.map(u=>c.add(u))); // best-effort
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e=>{
  e.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
    self.clients.claim();
  })());
});
self.addEventListener('fetch', e=>{
  const r=e.request; if(r.method!=='GET') return;
  const url=new URL(r.url);
  const fresh = r.mode==='navigate' || /\.(html|css|js)(\?|$)/.test(url.pathname);
  if(fresh){
    /* network-first : le code à jour l'emporte toujours, cache = secours hors-ligne */
    e.respondWith((async()=>{
      try{
        const net=await fetch(r, {cache:'no-store'});
        if(net && net.status===200 && url.origin===location.origin){ const c=await caches.open(CACHE); c.put(r, net.clone()); }
        return net;
      }catch(err){
        const cached=await caches.match(r); return cached || caches.match('index.html');
      }
    })());
  } else {
    /* cache-first : images, polices, médias (rapides, stables) */
    e.respondWith((async()=>{
      const cached=await caches.match(r); if(cached) return cached;
      try{
        const net=await fetch(r);
        if(net && net.status===200 && url.origin===location.origin){ const c=await caches.open(CACHE); c.put(r, net.clone()); }
        return net;
      }catch(err){ return cached; }
    })());
  }
});
