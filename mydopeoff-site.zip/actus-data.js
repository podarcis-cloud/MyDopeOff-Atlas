/* MyDope Off — actus-data.js
   ============================================================================
   Actualités de fond du champ. Distinct de `alertes-data.js` : autre tempo, autre durée
   de vie, autre usage. Une alerte parle d'un produit qui circule cette semaine ; une
   actualité parle de ce qui change dans le paysage — souvent pour longtemps.

   SEUIL D'ENTRÉE
   Une actualité entre quand elle **change ce que la personne trouvera sur le terrain**.
   Pas quand elle est indignante : quand elle est opérante. Le champ `change` est aussi
   obligatoire ici que `geste` l'est pour une alerte.

   POSITION — décision de Simon, 11 août 2026
   Le produit prend position sur les politiques publiques qui touchent son objet.
   Ce n'est pas une entorse à « ni cautionner ni condamner » : ce principe protège la
   personne du jugement porté sur SON usage. Il n'a jamais engagé le produit à la
   neutralité envers ce qui lui nuit. Le champ lui-même le montre — notre répertoire
   contient une famille `plaidoyer`, où figurent INPUD, HRI et IDPC.

   Mieux : la prise de position sert le principe fondateur. Quand quelqu'un ne trouve
   pas de service ouvert, il conclut spontanément qu'il n'a pas assez cherché, ou qu'il
   ne mérite pas mieux. Dire « ce n'est pas toi, c'est une ligne budgétaire supprimée
   en juillet » désamorce un jugement que la personne s'inflige. C'est le geste G19 du
   chapitre 40 appliqué à sa cause réelle.

   DEUX LIMITES, qui viennent d'ASUD (registres défaillants, ch. 40)
   1. Pas de pathos. On nomme l'injustice, on ne met pas en scène la détresse.
      Quelqu'un qui ouvre ça à 3 h du matin n'est pas une cause : c'est quelqu'un qui
      cherche une adresse.
   2. La position ne remplace jamais l'information pratique. Le champ `change` passe
      avant le champ `position` à l'écran, toujours.

   TROIS SOURCES MINIMUM par actualité politique — une de plus que le protocole 38.
   Une erreur factuelle dans une prise de position discrédite tout le reste du produit.
   ============================================================================ */
window.MD_ACTUS = [

  {
    id: 'actu-2026-07-pgsp-bruxelles',
    date: '2026-08-04', perime_le: '2027-03-31',
    regions: ['BE'],
    titre_fr: 'Bruxelles coupe le drug checking et les maraudes',
    titre_en: 'Brussels cuts drug checking and street outreach',

    corps_fr: "Le gouvernement bruxellois n’a pas reconduit 14 des 39 projets du Plan global de sécurité et de prévention pour 2026. Modus Vivendi perd ses deux programmes subsidiés : l’analyse de produits (126 500 €) et la centrale d’achat de matériel stérile qui approvisionnait tout le secteur (85 500 €). Dune passe de 116 875 à 59 375 €, notamment sur les maraudes. Transit, qui gère les deux salles de consommation à moindre risque, conserve finalement l’intégralité de son financement.",
    corps_en: "The Brussels government did not renew 14 of the 39 projects in its 2026 security and prevention plan. Modus Vivendi loses both its funded programmes: substance analysis (€126,500) and the sterile equipment purchasing hub that supplied the whole sector (€85,500). Dune drops from €116,875 to €59,375, hitting street outreach in particular. Transit, which runs the two supervised consumption rooms, ultimately keeps its full funding.",

    change_fr: "Si tu comptes sur l’analyse de produits ou sur une maraude à Bruxelles, appelle avant de te déplacer : les permanences et les horaires vont bouger dans les mois qui viennent. La salle de consommation de Transit, elle, reste ouverte.",
    change_en: "If you rely on substance testing or street outreach in Brussels, call before travelling: opening hours and sessions will shift over the coming months. Transit’s consumption room stays open.",

    position_fr: "Et si un service que tu cherchais n’est plus là, ce n’est pas que tu as mal cherché. C’est une ligne budgétaire supprimée en juillet, par des gens qui n’ont jamais eu à en dépendre. L’analyse de produits sauve des vies pour le prix d’un rond-point ; la faire disparaître est un choix, pas une fatalité.",
    position_en: "And if a service you were counting on isn’t there any more, it isn’t that you looked badly. It’s a budget line cut in July, by people who never had to depend on it. Drug checking saves lives for the price of a roundabout; making it disappear is a choice, not a fact of nature.",

    sources: [
      { nom: 'BX1', url: 'https://bx1.be/categories/news/prevention-a-bruxelles-les-coupes-budgetaires-sont-confirmees-14-projets-ne-seront-pas-reconduits-en-2026/' },
      { nom: 'La DH', url: 'https://www.dhnet.be/regions/bruxelles/2026/08/04/un-recul-de-25-ans-une-explosion-des-maladies-infectieuses-le-couperet-est-tombe-pour-les-associations-du-secteur-de-la-prevention-a-bruxelles-NCQ4CD5IRZCSZJOHZAIUW4R5CI/' },
      { nom: 'féda bxl', url: 'https://fedabxl.be/en/2026/07/securite-et-prevention-le-brugov-fait-passer-a-la-trappe-14-projets-sur-39-et-les-asbl-transit-et-dune-perdent-des-financements-dh/' }
    ]
  },

  {
    id: 'actu-2026-07-brussels-deal',
    date: '2026-08-07', perime_le: '2026-12-31',
    regions: ['BE'],
    titre_fr: 'Mille places d’hébergement supprimées à Bruxelles',
    titre_en: 'A thousand shelter places cut in Brussels',

    corps_fr: "La ministre fédérale de l’Asile et de la Migration a annoncé la fermeture de 1 000 des 2 000 places financées par le Brussels Deal — 300 début juillet, 700 confirmées ensuite. Près de 40 % des places d’accueil d’urgence du Samusocial dépendent de ce dispositif. Les fermetures interviennent juste avant l’hiver.",
    corps_en: "The federal Minister for Asylum and Migration has announced the closure of 1,000 of the 2,000 places funded through the Brussels Deal — 300 in early July, 700 confirmed shortly after. Around 40% of Samusocial’s emergency shelter places depend on this scheme. The closures land just before winter.",

    change_fr: "Trouver un lit d’urgence à Bruxelles va devenir plus difficile cet hiver. Si tu es concerné·e, appelle le 0800 99 340 (Samusocial, gratuit, 24 h/24) plutôt que de te présenter sur place : ils orientent vers ce qui reste ouvert.",
    change_en: "Finding an emergency bed in Brussels will get harder this winter. If this affects you, call 0800 99 340 (Samusocial, free, 24/7) rather than turning up in person: they’ll point you to what’s still open.",

    position_fr: "Dormir dehors multiplie tous les risques dont parle ce site — consommer seul, dans l’urgence, sans pouvoir tester quoi que ce soit. Retirer mille lits avant l’hiver est une décision dont les conséquences se compteront en personnes. Rien de neutre dans une ligne budgétaire de cette nature. Une mobilisation est prévue le 18 août à 17h30, place de l’Albertine.",
    position_en: "Sleeping rough multiplies every risk this site talks about — using alone, in a hurry, with no way to test anything. Removing a thousand beds before winter isn’t a neutral accounting measure: its consequences will be counted in people. A public rally is planned for 18 August at 5.30pm, place de l’Albertine.",

    sources: [
      { nom: 'Samusocial', url: 'https://samusocial.be/suppression-de-1000-places-daccueil-le-risque-dune-crise-humanitaire-au-coeur-de-la-capitale-europeenne/' },
      { nom: 'RTBF', url: 'https://www.rtbf.be/article/asile-manifestation-annoncee-contre-la-suppression-de-1000-places-d-accueil-a-bruxelles-11767680' },
      { nom: 'BX1', url: 'https://bx1.be/categories/news/brussels-deal-le-samusocial-redoute-une-crise-humanitaire-apres-la-suppression-de-1-000-places-daccueil/' }
    ]
  },

  {
    id: 'actu-2026-hsa-france',
    date: '2026-06-19', perime_le: '2027-06-30',
    regions: ['FR'],
    titre_fr: 'Salles de consommation : deux ans de plus, et de nouveaux formats',
    titre_en: 'Consumption rooms: two more years, and new formats',

    corps_fr: "Le Parlement a prolongé jusqu’au 31 décembre 2027 l’expérimentation des haltes soins addictions — les deux seules de France, à Paris et Strasbourg, devaient fermer fin 2025. Un arrêté du 19 mai 2026 va plus loin : il approuve deux nouveaux cadres, l’un pour des haltes avec hébergement, l’autre pour des haltes mobiles, avec un hébergement explicitement ouvert « sans exigence préalable d’arrêt » de la consommation.",
    corps_en: "Parliament extended the supervised consumption room trial to 31 December 2027 — France’s only two, in Paris and Strasbourg, were due to close at the end of 2025. A ministerial order of 19 May 2026 goes further, approving two new formats: rooms with accommodation, and mobile units, with housing explicitly open “with no prior requirement to stop” using.",

    change_fr: "Les deux structures existantes restent ouvertes. Et le cadre mobile ouvre la possibilité de dispositifs ailleurs qu’à Paris et Strasbourg dans les mois qui viennent — sans garantie que des projets se montent.",
    change_en: "Both existing sites stay open. And the mobile framework makes services possible outside Paris and Strasbourg in the coming months — with no guarantee that projects will actually launch.",

    position_fr: "Dix ans d’évaluations convergentes — l’INSERM a mesuré moins de passages aux urgences, moins de contaminations, des économies de santé — et on en est encore à prolonger une expérimentation de deux ans en deux ans. Ce qui est bon pour la santé publique n’a jamais eu besoin d’être réévalué aussi souvent quand ça ne concernait pas des usagers de drogues.",
    position_en: "Ten years of converging evaluations — France’s national health research institute measured fewer emergency admissions, fewer infections, healthcare savings — and still the scheme is renewed two years at a time. Things that are good for public health rarely need this much re-evaluating when the people involved aren’t drug users.",

    sources: [
      { nom: 'Légifrance — arrêté du 19 mai 2026', url: 'https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000054152101' },
      { nom: 'AIDES / Remaides', url: 'https://www.aides.org/actualite/lactu-remaides-plfss-2026-hsa-prolongees-2027' },
      { nom: 'La Gazette des communes', url: 'https://www.lagazettedescommunes.com/1016545/haltes-soins-addictions-deux-ans-de-prolongation/' }
    ]
  },

  {
    id: 'actu-2026-marche-opioides-europe',
    date: '2026-06-09', perime_le: '2027-06-30',
    regions: null,
    titre_fr: 'Le marché des opioïdes se déplace plus vite que les lois',
    titre_en: 'The opioid market moves faster than the law',

    corps_fr: "L’interdiction chinoise des nitazènes, en juillet 2025, n’a pas fait disparaître le problème : elle l’a déplacé. Une nouvelle famille, les orphines, a pris le relais en quelques mois. Depuis 2009, 95 nouveaux opioïdes de synthèse ont été détectés en Europe, dont sept pour la seule année 2025.",
    corps_en: "China’s July 2025 nitazene ban didn’t make the problem go away: it moved it. A new family, the orphines, took over within months. Since 2009, 95 new synthetic opioids have been detected in Europe, seven of them in 2025 alone.",

    change_fr: "Concrètement : ce que tu achetais il y a six mois n’est pas forcément ce que tu achètes aujourd’hui, même chez la même personne. Une dose test réduite après chaque changement de source reste la seule information fiable dont tu disposes.",
    change_en: "In practice: what you bought six months ago isn’t necessarily what you’re buying now, even from the same person. A reduced test dose after every change of source isn’t excessive caution — it’s the only reliable information you have.",

    position_fr: "Chaque interdiction produit une molécule moins connue, moins dosable, plus dangereuse. L’agence européenne elle-même le décrit ainsi depuis 2009. Aucune opinion là-dedans. Interdire plus vite ne rattrapera jamais un laboratoire — analyser ce qui circule, oui.",
    position_en: "Every ban produces a molecule that is less known, harder to dose, more dangerous. That isn’t an opinion: it’s a description of what has happened since 2009, written by the European agency itself. Banning faster will never outrun a laboratory — testing what actually circulates will.",

    sources: [
      { nom: 'EUDA — Rapport européen 2026', url: 'https://www.euda.europa.eu/publications/european-drug-report/2026/drug-situation-in-europe-up-to-2026_en' },
      { nom: 'EUDA — Nouveaux risques sanitaires', url: 'https://www.euda.europa.eu/news/2026/new-health-risks-europeans-fast-moving-drug-market_en' },
      { nom: 'EUDA — Nouvelles substances psychoactives', url: 'https://www.euda.europa.eu/publications/european-drug-report/2025/new-psychoactive-substances_en' }
    ]
  },

  {
    id: 'actu-2026-nitazenes-deces',
    date: '2026-06-09', perime_le: '2027-06-30',
    regions: null,
    titre_fr: 'Ce que les nitazènes ont déjà coûté',
    titre_en: 'What nitazenes have already cost',

    corps_fr: "En Angleterre, 458 décès liés aux nitazènes ont été recensés entre juin 2023 et janvier 2025, dans toutes les régions du pays. En Estonie, ces molécules étaient impliquées dans 62 des 119 décès par overdose de 2023 ; en Lettonie, dans 101 sur 154. Leur puissance dépasse celle du fentanyl, et elles échappent souvent aux analyses toxicologiques de routine.",
    corps_en: "In England, 458 nitazene-linked deaths were recorded between June 2023 and January 2025, across every region. In Estonia these molecules were involved in 62 of 119 overdose deaths in 2023; in Latvia, 101 of 154. They outmatch fentanyl in potency and often escape routine post-mortem toxicology.",

    change_fr: "La naloxone fonctionne sur les nitazènes, mais il faut souvent plusieurs doses avant que la respiration reparte. Si tu en as, garde-en plus d’une. Si tu n’en as pas, plusieurs structures en donnent gratuitement — elles sont dans la section réseau plus bas.",
    change_en: "Naloxone does work on nitazenes, but several doses are often needed before breathing restarts. If you carry it, carry more than one. If you don’t, several services hand it out free — they’re in the network section below.",

    position_fr: "Ces chiffres viennent de pays qui comptent. Ailleurs, on ne cherche pas ces molécules dans les analyses post-mortem, donc on ne les trouve pas, donc elles n’existent pas dans les statistiques. Une overdose non identifiée ne devient pas une overdose évitée.",
    position_en: "These figures come from countries that count. Elsewhere nobody looks for these molecules in post-mortem toxicology, so nobody finds them, so they don’t exist in the statistics. An unidentified overdose does not become a prevented one.",

    sources: [
      { nom: 'RTS', url: 'https://www.rts.ch/info/monde/2025/article/alerte-en-europe-les-nitazenes-opioides-50-fois-plus-forts-que-le-fentanyl-28964892.html' },
      { nom: 'EUDA — Nouvelles substances psychoactives', url: 'https://www.euda.europa.eu/publications/european-drug-report/2025/new-psychoactive-substances_en' },
      { nom: 'EUDA — Rapport européen 2026', url: 'https://www.euda.europa.eu/publications/european-drug-report/2026/drug-situation-in-europe-up-to-2026_en' }
    ]
  },

  {
    id: 'actu-2026-naloxone-suisse',
    date: '2026-01-15', perime_le: '2027-06-30',
    regions: ['CH'],
    titre_fr: 'Naloxone à emporter : la Suisse s’équipe',
    titre_en: 'Take-home naloxone: Switzerland gears up',

    corps_fr: "Face à l’arrivée des opioïdes de synthèse, la Suisse déploie la naloxone à emporter et des bandelettes de test rapide. Une première journée d’action a eu lieu en octobre 2025 dans un centre d’accueil ; une pharmacie a commandé un millier de doses. Un système de recueil systématique des épisodes de consommation a démarré à la mi-janvier 2026.",
    corps_en: "Faced with synthetic opioids arriving, Switzerland is rolling out take-home naloxone and rapid test strips. A first action day took place in October 2025 at a drop-in centre; one pharmacy ordered a thousand doses. A systematic system for recording use episodes started in mid-January 2026.",

    change_fr: "Si tu consommes des opioïdes en Suisse, la naloxone à emporter devient réellement accessible — demande-la en pharmacie ou dans un centre d’accueil. Elle ne coûte rien à porter et ne sert qu’une fois, pour quelqu’un d’autre le plus souvent.",
    change_en: "If you use opioids in Switzerland, take-home naloxone is becoming genuinely available — ask at a pharmacy or a drop-in centre. It costs nothing to carry and gets used once, most often for someone else.",

    position_fr: "C’est ce que devrait faire n’importe quel pays qui voit arriver ces molécules : équiper les gens avant, pas compter les morts après. Que ce soit remarquable en dit long sur ce qui se fait ailleurs.",
    position_en: "This is what any country seeing these molecules arrive ought to do: equip people beforehand, rather than count the dead afterwards. That it stands out says a lot about what happens elsewhere.",

    sources: [
      { nom: 'Infodrog — Rapport NPS Suisse', url: 'https://www.infodrog.ch/files/content/schadensminderung_fr/Nouvelles-substances-psychoactives-en-Suisse_Rapport-2025_infodrog.pdf' },
      { nom: 'EUDA — Rapport européen 2026', url: 'https://www.euda.europa.eu/publications/european-drug-report/2026/drug-situation-in-europe-up-to-2026_en' },
      { nom: 'RTS', url: 'https://www.rts.ch/info/monde/2025/article/alerte-en-europe-les-nitazenes-opioides-50-fois-plus-forts-que-le-fentanyl-28964892.html' }
    ]
  }

];
