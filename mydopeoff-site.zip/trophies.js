/* trophies.js — Collection de cartes « arcanes » (tarot thématique RDR), à paliers.
   100 % dérivé des signaux déjà journalisés (MDData.getSessions() + entries() du Journal) :
   AUCUN jeu n'a besoin de connaître ce module pour la détection. Un jeu futur qui appelle
   MDData.logSession(type,…) alimente automatiquement check() — zéro couplage.

   Chaque carte a 1 à 3 paliers (étoiles). Un palier = { star, cond(ctx), phrase, mission }.
   - phrase : texte tarot (poétique, évocateur) affiché une fois le palier atteint.
   - mission : texte précis de ce qu'il reste à faire pour l'atteindre (pas de « continue tes
     séances » vague — la condition exacte, en clair).
   Les cartes à un seul palier restent des jalons ponctuels (ex. premier usage du mode urgence) ;
   les cartes à plusieurs paliers (liées à un jeu précis) continuent d'évoluer après déblocage.

   Ton des phrases : voix tarot — courte, évocatrice, present tense, jamais mièvre — distincte
   de la voix conversationnelle de la mascotte (qui vit dans debriefs.js).

   Expose window.MDTrophies : { CARTES, MAX_N, check(), getUnlocked(), isUnlocked(), getTier(),
   stats(), celebrate() }. */
window.MDTrophies = (function () {

  function lang() { try { return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; } catch (e) { return 'fr'; } }

  function nbType(ss, t) { return ss.filter(function (s) { return s.type === t; }).length; }
  function activeDays(ss) { var d = {}; ss.forEach(function (s) { d[Math.floor((s.date || 0) / 86400000)] = 1; }); return Object.keys(d); }
  function currentStreak(ss) {
    var set = {}; activeDays(ss).forEach(function (k) { set[k] = 1; });
    var day = Math.floor(Date.now() / 86400000), n = 0;
    while (set[day]) { n++; day--; }
    return n;
  }
  function deltas(ss) { return ss.filter(function (s) { return s.envieAvant != null && s.envieApres != null; }); }
  function distinctTypes(ss) { var s = {}; ss.forEach(function (x) { s[x.type] = 1; }); return Object.keys(s); }

  /* Conditions de déblocage : identiques dans les deux langues (logique pure, jamais traduite).
     Séparées ici du texte pour ne les écrire qu'une fois — CARTES_FR/CARTES_EN les référencent. */
  var COND = {
    tristesse1: function(c){ return c.ss.length>=1 && c.bilan && ((c.bilan.craving && c.bilan.craving.daysAgo<=14 && c.bilan.craving.improving===false) || (c.bilan.wellbeing && c.bilan.wellbeing.daysAgo<=14 && c.bilan.wellbeing.improving===false)); },
    colere1: function(c){ return c.ss.some(function(s){ return s.envieAvant>=8; }); },
    fatigue1: function(c){ return nbType(c.ss,'filtre')>=1; },
    solitude1: function(c){ return c.ss.some(function(s){ var h=new Date(s.date||0).getHours(); return h>=23 || h<5; }); },
    vulnerabilite1: function(c){ return nbType(c.ss,'antisabotage')>=1; },
    fierte1: function(c){ return nbType(c.ss,'echo')>=1; },
    soulagement1: function(c){ return nbType(c.ss,'braise')>=1; },
    confiance1: function(c){ return nbType(c.ss,'dualtask')>=1; },
    complicite1: function(c){ return nbType(c.ss,'virage')>=1; },
    emerveillement1: function(c){ return nbType(c.ss,'patience')>=1; },
    tendresse1: function(c){ return nbType(c.ss,'elan')>=1; },
    impatience1: function(c){ return nbType(c.ss,'inhib')>=1; },
    curiosite1: function(c){ return c.ss.length>=1; },
    curiosite2: function(c){ return c.types.length>=5; },
    curiosite3: function(c){ return c.types.length>=8; },
    concentration1: function(c){ return nbType(c.ss,'tetris')>=1; },
    concentration2: function(c){ return nbType(c.ss,'tetris')>=10; },
    concentration3: function(c){ return nbType(c.ss,'tetris')>=30; },
    doute1: function(c){ return c.deltas.some(function(s){ return s.envieApres>s.envieAvant; }); },
    depassement1: function(c){ return nbType(c.ss,'surf')>=1; },
    depassement2: function(c){ return nbType(c.ss,'surf')>=10; },
    depassement3: function(c){ return nbType(c.ss,'surf')>=30; },
    changement1: function(c){ return c.deltas.some(function(s){ return (s.envieAvant-s.envieApres)>=3; }); },
    prisederecul1: function(c){ return nbType(c.ss,'lettre')>=1; },
    prisederecul2: function(c){ return nbType(c.ss,'lettre')>=5; },
    prisederecul3: function(c){ return nbType(c.ss,'lettre')>=15; },
    gratitude1: function(c){ return c.ss.length>=5; },
    craving1: function(c){ return c.ss.some(function(s){ return s.envieAvant!=null; }); },
    craving2: function(c){ return c.ss.filter(function(s){ return s.envieAvant!=null; }).length>=10; },
    craving3: function(c){ return c.deltas.filter(function(s){ return (s.envieAvant-s.envieApres)>=2; }).length>=10; },
    decision1: function(c){ return nbType(c.ss,'maze')>=1; },
    decision2: function(c){ return nbType(c.ss,'maze')>=10; },
    decision3: function(c){ return nbType(c.ss,'maze')>=30; },
    energie1: function(c){ return c.byDay.some(function(n){ return n>=3; }); },
    introspection1: function(c){ return nbType(c.ss,'breathe')>=1; },
    introspection2: function(c){ return nbType(c.ss,'breathe')>=10; },
    introspection3: function(c){ return nbType(c.ss,'breathe')>=30; },
    espoir1: function(c){ return c.streak>=3; },
    accueil1: function(){ return true; },
    questionnement1: function(c){ return c.days.length>=2; },
    decouverte1: function(c){ return c.types.length>=3; },
    comprehension1: function(c){ return c.ss.length>=10; },
    patience1: function(c){ return c.streak>=7; },
    connexion1: function(c){ return ['breathe','tetris','maze','surf'].every(function(t){ return nbType(c.ss,t)>=1; }); },
    equilibre1: function(c){ return c.ss.length>=15; },
    protection1: function(c){ return nbType(c.ss,'urgence')>=1; },
    exploration1: function(c){ return c.ss.length>=20; },
    partage1: function(c){ return c.notes>=1; },
    perseverance1: function(c){ return c.streak>=14; },
    accomplissement1: function(c){ return c.streak>=30; },
    recadrage1: function(c){ return c.ss.some(function(s){ return s.type==='recadrage'; }); },
    autocompassion1: function(c){
      var days = c.ss.map(function(s){ return Math.floor((s.date||0)/86400000); }).sort(function(a,b){return a-b;});
      for (var i=1;i<days.length;i++){ if (days[i]-days[i-1]>=3) return true; }
      return false;
    }
  };
  var CARTES_FR = [
    { id:'tristesse', n:1, label:'Tristesse', img:'ill-cards/1-tristesse.png', tiers:[
      { star:1, cond:COND.tristesse1,
        phrase:'Rien n\u2019allait franchement mieux. Tu es venu\u00b7e quand m\u00eame.',
        mission:'Termine une s\u00e9ance apr\u00e8s un bilan qui montrait une tendance qui ne s\u2019am\u00e9liore pas encore.' }
    ]},
    { id:'colere', n:2, label:'Col\u00e8re', img:'ill-cards/2-colere.png', tiers:[
      { star:1, cond:COND.colere1,
        phrase:'\u00c7a montait fort. \u00c7a n\u2019a pas d\u00e9bord\u00e9.',
        mission:'Termine une s\u00e9ance commenc\u00e9e avec une envie \u00e0 8 ou plus.' }
    ]},
    { id:'fatigue', n:3, label:'Fatigue', img:'ill-cards/3-fatigue.png', tiers:[
      { star:1, cond:COND.fatigue1,
        phrase:'Vingt fois de suite, filtrer le r\u00e9flexe. \u00c7a fatigue, et \u00e7a marche.',
        mission:'Termine une session de Filtre.' }
    ]},
    { id:'solitude', n:4, label:'Solitude', img:'ill-cards/4-solitude.png', tiers:[
      { star:1, cond:COND.solitude1,
        phrase:'Une heure o\u00f9 presque personne n\u2019est \u00e9veill\u00e9. Toi, si.',
        mission:'Termine une s\u00e9ance tard le soir ou t\u00f4t le matin (23h\u20135h).' }
    ]},
    { id:'vulnerabilite', n:5, label:'Vuln\u00e9rabilit\u00e9', img:'ill-cards/5-vulnerabilite.png', tiers:[
      { star:1, cond:COND.vulnerabilite1,
        phrase:'Regarder en face la fa\u00e7on dont tu peux te freiner toi-m\u00eame \u2014 sans se juger.',
        mission:'Construis ton plan anti-sabotage.' }
    ]},
    { id:'fierte', n:6, label:'Fiert\u00e9', img:'ill-cards/6-fierte.png', tiers:[
      { star:1, cond:COND.fierte1,
        phrase:'La s\u00e9quence s\u2019allongeait. Ta m\u00e9moire a tenu.',
        mission:'Termine une session d\u2019\u00c9cho.' }
    ]},
    { id:'soulagement', n:7, label:'Soulagement', img:'ill-cards/7-soulagement.png', tiers:[
      { star:1, cond:COND.soulagement1,
        phrase:'Le plaisir pr\u00e9dit et le plaisir ressenti se sont enfin accord\u00e9s.',
        mission:'Termine une session de Braise.' }
    ]},
    { id:'confiance', n:8, label:'Confiance', img:'ill-cards/8-confiance.png', tiers:[
      { star:1, cond:COND.confiance1,
        phrase:'Deux attentions \u00e0 la fois, et aucune n\u2019est tomb\u00e9e.',
        mission:'Termine une session de Double t\u00e2che.' }
    ]},
    { id:'complicite', n:9, label:'Complicit\u00e9', img:'ill-cards/9-complicite.png', tiers:[
      { star:1, cond:COND.complicite1,
        phrase:'La r\u00e8gle a chang\u00e9 sans pr\u00e9venir. Tu as suivi quand m\u00eame.',
        mission:'Termine une session de Virage.' }
    ]},
    { id:'emerveillement', n:10, label:'\u00c9merveillement', img:'ill-cards/10-emerveillement.png', tiers:[
      { star:1, cond:COND.emerveillement1,
        phrase:'Une graine laiss\u00e9e \u00e0 pousser plut\u00f4t que cueillie tout de suite.',
        mission:'Termine une session de Patience.' }
    ]},
    { id:'tendresse', n:11, label:'Tendresse', img:'ill-cards/11-tendresse.png', tiers:[
      { star:1, cond:COND.tendresse1,
        phrase:'Repousser l\u2019impulsion, attirer ce qui compte vraiment pour toi.',
        mission:'Termine une session d\u2019\u00c9lan.' }
    ]},
    { id:'impatience', n:12, label:'Impatience', img:'ill-cards/12-impatience.png', tiers:[
      { star:1, cond:COND.impatience1,
        phrase:'Le rond appelait \u00e0 agir vite. Le carr\u00e9 demandait d\u2019attendre.',
        mission:'Termine une session de Contr\u00f4le du frein.' }
    ]},
    { id:'curiosite', n:13, label:'Curiosité', img:'ill-cards/13-curiosite.png', tiers:[
      { star:1, cond:COND.curiosite1,
        phrase:'La porte n\u2019était pas fermée à clé. Il suffisait de la pousser.',
        mission:'Termine ton premier exercice, n\u2019importe lequel.' },
      { star:2, cond:COND.curiosite2,
        phrase:'Cinq portes différentes, et tu es entré·e dans chacune.',
        mission:'Essaie 5 exercices différents.' },
      { star:3, cond:COND.curiosite3,
        phrase:'Il ne reste plus grand-chose que tu n\u2019as pas exploré ici.',
        mission:'Essaie 8 exercices différents.' }
    ]},
    { id:'concentration', n:14, label:'Concentration', img:'ill-cards/14-concentration.png', tiers:[
      { star:1, cond:COND.concentration1,
        phrase:'Les blocs tombent. L\u2019esprit, lui, reste.',
        mission:'Termine une partie de Tetris.' },
      { star:2, cond:COND.concentration2,
        phrase:'Dix parties. Le geste ne demande plus de réfléchir.',
        mission:'Termine 10 parties de Tetris.' },
      { star:3, cond:COND.concentration3,
        phrase:'Trente parties. Ce jeu t\u2019appartient autant que l\u2019inverse.',
        mission:'Termine 30 parties de Tetris.' }
    ]},
    { id:'doute', n:15, label:'Doute', img:'ill-cards/15-doute.png', tiers:[
      { star:1, cond:COND.doute1,
        phrase:'Toutes les vagues ne se laissent pas surfer. Celle-ci comptait quand même.',
        mission:'Une séance où l\u2019envie n\u2019a pas baissé — ça arrive, et ça compte aussi.' }
    ]},
    { id:'depassement', n:16, label:'Dépassement', img:'ill-cards/16-depassement.png', tiers:[
      { star:1, cond:COND.depassement1,
        phrase:'Elle est montée, elle est redescendue. Tu es resté·e.',
        mission:'Termine une session de Surf de l\u2019envie.' },
      { star:2, cond:COND.depassement2,
        phrase:'Dix vagues tenues. Ton corps sait maintenant ce que ton mental doutait.',
        mission:'Termine 10 sessions de Surf.' },
      { star:3, cond:COND.depassement3,
        phrase:'Trente vagues. Il n\u2019y a plus de vague qui te surprenne vraiment.',
        mission:'Termine 30 sessions de Surf.' }
    ]},
    { id:'changement', n:17, label:'Changement', img:'ill-cards/17-changement.png', tiers:[
      { star:1, cond:COND.changement1,
        phrase:'Entre l\u2019avant et l\u2019après, une ligne nette. Rien d\u2019invisible cette fois.',
        mission:'Une séance où l\u2019envie a baissé d\u2019au moins 3 points.' }
    ]},
    { id:'prise-de-recul', n:18, label:'Prise de recul', img:'ill-cards/18-prise-de-recul.png', tiers:[
      { star:1, cond:COND.prisederecul1,
        phrase:'Une lettre part aujourd\u2019hui. Elle arrivera au bon moment.',
        mission:'Écris une lettre à ton futur toi.' },
      { star:2, cond:COND.prisederecul2,
        phrase:'Cinq lettres. Une conversation s\u2019est installée avec qui tu deviens.',
        mission:'Écris 5 lettres à ton futur toi.' },
      { star:3, cond:COND.prisederecul3,
        phrase:'Quinze lettres. Un carnet entier adressé à personne d\u2019autre que toi.',
        mission:'Écris 15 lettres à ton futur toi.' }
    ]},
    { id:'gratitude', n:19, label:'Gratitude', img:'ill-cards/19-gratitude.png', tiers:[
      { star:1, cond:COND.gratitude1,
        phrase:'Cinq fois, tu es revenu·e. Ça ne doit rien au hasard.',
        mission:'Termine 5 séances, tous exercices confondus.' }
    ]},
    { id:'craving', n:20, label:'Craving', img:'ill-cards/20-craving.png', tiers:[
      { star:1, cond:COND.craving1,
        phrase:'Nommer l\u2019intensit\u00e9 avant de choisir quoi en faire \u2014 c\u2019est d\u00e9j\u00e0 ne plus la subir.',
        mission:'Mesure ton envie avant un exercice (bouton craving) au moins une fois.' },
      { star:2, cond:COND.craving2,
        phrase:'Dix fois, tu as pris sa mesure avant de la laisser d\u00e9cider \u00e0 ta place.',
        mission:'Mesure ton envie avant un exercice, 10 fois au total.' },
      { star:3, cond:COND.craving3,
        phrase:'Dix fois, elle est arriv\u00e9e forte et repartie plus l\u00e9g\u00e8re.',
        mission:'Dix séances où l\u2019envie a baissé d\u2019au moins 2 points entre le début et la fin.' }
    ]},
    { id:'decision', n:21, label:'Décision', img:'ill-cards/21-decision.png', tiers:[
      { star:1, cond:COND.decision1,
        phrase:'Chaque virage du labyrinthe posait la même question.',
        mission:'Termine un niveau du Labyrinthe.' },
      { star:2, cond:COND.decision2,
        phrase:'Dix labyrinthes. Tu choisis plus vite qu\u2019avant.',
        mission:'Termine 10 sessions du Labyrinthe.' },
      { star:3, cond:COND.decision3,
        phrase:'Trente labyrinthes. Plus aucun mur ne te surprend.',
        mission:'Termine 30 sessions du Labyrinthe.' }
    ]},
    { id:'energie', n:22, label:'Énergie', img:'ill-cards/22-energie.png', tiers:[
      { star:1, cond:COND.energie1,
        phrase:'Trois fois dans la même journée. Quelque chose s\u2019est allumé.',
        mission:'Termine 3 exercices dans la même journée.' }
    ]},
    { id:'introspection', n:23, label:'Introspection', img:'ill-cards/23-introspection.png', tiers:[
      { star:1, cond:COND.introspection1,
        phrase:'Le souffle ralentit. Le reste suit, toujours.',
        mission:'Termine une session de Souffle.' },
      { star:2, cond:COND.introspection2,
        phrase:'Dix fois, tu as ralenti volontairement. C\u2019est un vrai réflexe maintenant.',
        mission:'Termine 10 sessions de Souffle.' },
      { star:3, cond:COND.introspection3,
        phrase:'Trente fois. Ton souffle sait le chemin par cœur.',
        mission:'Termine 30 sessions de Souffle.' }
    ]},
    { id:'espoir', n:24, label:'Espoir', img:'ill-cards/24-espoir.png', tiers:[
      { star:1, cond:COND.espoir1,
        phrase:'Trois jours de suite, sans qu\u2019on te le demande.',
        mission:'Reviens 3 jours de suite.' }
    ]},
    { id:'accueil', n:25, label:'Accueil', img:'ill-cards/25-accueil.png', tiers:[
      { star:1, cond:COND.accueil1,
        phrase:'Le seuil est franchi. La porte reste ouverte.',
        mission:'Ouvre l\u2019application.' }
    ]},
    { id:'questionnement', n:26, label:'Questionnement', img:'ill-cards/26-questionnement.png', tiers:[
      { star:1, cond:COND.questionnement1,
        phrase:'Tu es revenu·e poser la question une seconde fois.',
        mission:'Reviens un autre jour.' }
    ]},
    { id:'decouverte', n:27, label:'Découverte', img:'ill-cards/27-decouverte.png', tiers:[
      { star:1, cond:COND.decouverte1,
        phrase:'Trois chemins différents, et tu as tous pris.',
        mission:'Essaie 3 exercices différents.' }
    ]},
    { id:'comprehension', n:28, label:'Compréhension', img:'ill-cards/28-comprehension.png', tiers:[
      { star:1, cond:COND.comprehension1,
        phrase:'Dix fois répété, ça commence à ressembler à un savoir.',
        mission:'Termine 10 séances, tous exercices confondus.' }
    ]},
    { id:'patience', n:29, label:'Patience', img:'ill-cards/29-patience.png', tiers:[
      { star:1, cond:COND.patience1,
        phrase:'Sept jours tenus, un par un, sans regarder trop loin devant.',
        mission:'Reviens 7 jours de suite.' }
    ]},
    { id:'connexion', n:30, label:'Connexion', img:'ill-cards/30-connexion.png', tiers:[
      { star:1, cond:COND.connexion1,
        phrase:'Le souffle, les blocs, le labyrinthe, la vague. Tu as touché à tout.',
        mission:'Essaie Souffle, Tetris, Labyrinthe et Surf, au moins une fois chacun.' }
    ]},
    { id:'equilibre', n:31, label:'Équilibre', img:'ill-cards/31-equilibre.png', tiers:[
      { star:1, cond:COND.equilibre1,
        phrase:'Quinze fois. Le geste ne demande plus de courage, juste de l\u2019habitude.',
        mission:'Termine 15 séances, tous exercices confondus.' }
    ]},
    { id:'protection', n:32, label:'Protection', img:'ill-cards/32-protection.png', tiers:[
      { star:1, cond:COND.protection1,
        phrase:'Le signal d\u2019alarme a servi. C\u2019est exactement pour ça qu\u2019il existe.',
        mission:'Utilise le mode urgence une fois.' }
    ]},
    { id:'exploration', n:33, label:'Exploration', img:'ill-cards/33-exploration.png', tiers:[
      { star:1, cond:COND.exploration1,
        phrase:'Vingt fois. L\u2019outil ne t\u2019appartient plus — tu l\u2019as fait tien.',
        mission:'Termine 20 séances, tous exercices confondus.' }
    ]},
    { id:'partage', n:34, label:'Partage', img:'ill-cards/34-partage.png', tiers:[
      { star:1, cond:COND.partage1,
        phrase:'Un mot posé quelque part rien que pour toi. Ça compte comme une confidence.',
        mission:'Ajoute une note à une entrée du Journal.' }
    ]},
    { id:'perseverance', n:35, label:'Persévérance', img:'ill-cards/35-perseverance.png', tiers:[
      { star:1, cond:COND.perseverance1,
        phrase:'Quatorze jours. Ce n\u2019est plus un effort, c\u2019est devenu un rythme.',
        mission:'Reviens 14 jours de suite.' }
    ]},
    { id:'accomplissement', n:36, label:'Accomplissement', img:'ill-cards/36-accomplissement.png', tiers:[
      { star:1, cond:COND.accomplissement1,
        phrase:'Trente jours de suite. Un mois entier tient dans cette carte.',
        mission:'Reviens 30 jours de suite.' }
    ]},
    { id:'recadrage', n:37, label:'Recadrage', img:'ill-cards/37-recadrage.png', tiers:[
      { star:1, cond:COND.recadrage1,
        phrase:'Une pens\u00e9e est arriv\u00e9e d\u00e9guis\u00e9e en v\u00e9rit\u00e9. Tu l\u2019as regard\u00e9e d\u2019un autre angle.',
        mission:'Termine une session de Recadrage.' }
    ]},
    { id:'autocompassion', n:38, label:'Auto-compassion', img:'ill-cards/38-auto-compassion.png', tiers:[
      { star:1, cond:COND.autocompassion1,
        phrase:'Une pause n\u2019a pas eu besoin d\u2019excuse. Tu es revenu\u00b7e, simplement.',
        mission:'Reviens apr\u00e8s une pause de 3 jours ou plus, et termine une s\u00e9ance.' }
    ]}
  ];

  var CARTES_EN = [
    { id:'tristesse', n:1, label:'Sadness', img:'ill-cards/1-tristesse.png', tiers:[
      { star:1, cond:COND.tristesse1,
        phrase:'Nothing was really getting better. You came anyway.',
        mission:'Finish a session after a check-in that showed a trend not improving yet.' }
    ]},
    { id:'colere', n:2, label:'Anger', img:'ill-cards/2-colere.png', tiers:[
      { star:1, cond:COND.colere1,
        phrase:'It was rising hard. It didn\u2019t spill over.',
        mission:'Finish a session started with an urge at 8 or above.' }
    ]},
    { id:'fatigue', n:3, label:'Fatigue', img:'ill-cards/3-fatigue.png', tiers:[
      { star:1, cond:COND.fatigue1,
        phrase:'Twenty times in a row, filtering the reflex. It\u2019s tiring, and it works.',
        mission:'Finish a Filter session.' }
    ]},
    { id:'solitude', n:4, label:'Solitude', img:'ill-cards/4-solitude.png', tiers:[
      { star:1, cond:COND.solitude1,
        phrase:'An hour when almost no one else is awake. You were.',
        mission:'Finish a session late at night or early morning (11pm\u20135am).' }
    ]},
    { id:'vulnerabilite', n:5, label:'Vulnerability', img:'ill-cards/5-vulnerabilite.png', tiers:[
      { star:1, cond:COND.vulnerabilite1,
        phrase:'Looking straight at how you can hold yourself back \u2014 without judging it.',
        mission:'Build your anti-sabotage plan.' }
    ]},
    { id:'fierte', n:6, label:'Pride', img:'ill-cards/6-fierte.png', tiers:[
      { star:1, cond:COND.fierte1,
        phrase:'The sequence kept growing. Your memory held.',
        mission:'Finish an Echo session.' }
    ]},
    { id:'soulagement', n:7, label:'Relief', img:'ill-cards/7-soulagement.png', tiers:[
      { star:1, cond:COND.soulagement1,
        phrase:'Predicted pleasure and felt pleasure finally matched.',
        mission:'Finish an Ember session.' }
    ]},
    { id:'confiance', n:8, label:'Trust', img:'ill-cards/8-confiance.png', tiers:[
      { star:1, cond:COND.confiance1,
        phrase:'Two attentions at once, and neither one dropped.',
        mission:'Finish a Dual task session.' }
    ]},
    { id:'complicite', n:9, label:'Complicity', img:'ill-cards/9-complicite.png', tiers:[
      { star:1, cond:COND.complicite1,
        phrase:'The rule changed without warning. You followed anyway.',
        mission:'Finish a Switch session.' }
    ]},
    { id:'emerveillement', n:10, label:'Wonder', img:'ill-cards/10-emerveillement.png', tiers:[
      { star:1, cond:COND.emerveillement1,
        phrase:'A seed left to grow rather than picked right away.',
        mission:'Finish a Patience session.' }
    ]},
    { id:'tendresse', n:11, label:'Tenderness', img:'ill-cards/11-tendresse.png', tiers:[
      { star:1, cond:COND.tendresse1,
        phrase:'Pushing the impulse away, pulling in what really matters to you.',
        mission:'Finish an Impulse session.' }
    ]},
    { id:'impatience', n:12, label:'Impatience', img:'ill-cards/12-impatience.png', tiers:[
      { star:1, cond:COND.impatience1,
        phrase:'The circle called for quick action. The square asked you to wait.',
        mission:'Finish a Brake control session.' }
    ]},
    { id:'curiosite', n:13, label:'Curiosity', img:'ill-cards/13-curiosite.png', tiers:[
      { star:1, cond:COND.curiosite1,
        phrase:'The door wasn\u2019t locked. It only needed a push.',
        mission:'Finish your first exercise, any one at all.' },
      { star:2, cond:COND.curiosite2,
        phrase:'Five different doors, and you walked through each one.',
        mission:'Try 5 different exercises.' },
      { star:3, cond:COND.curiosite3,
        phrase:'There\u2019s not much left here you haven\u2019t explored.',
        mission:'Try 8 different exercises.' }
    ]},
    { id:'concentration', n:14, label:'Focus', img:'ill-cards/14-concentration.png', tiers:[
      { star:1, cond:COND.concentration1,
        phrase:'The blocks fall. The mind, though, stays.',
        mission:'Finish a game of Tetris.' },
      { star:2, cond:COND.concentration2,
        phrase:'Ten games. The gesture no longer needs thinking about.',
        mission:'Finish 10 games of Tetris.' },
      { star:3, cond:COND.concentration3,
        phrase:'Thirty games. This game belongs to you as much as the reverse.',
        mission:'Finish 30 games of Tetris.' }
    ]},
    { id:'doute', n:15, label:'Doubt', img:'ill-cards/15-doute.png', tiers:[
      { star:1, cond:COND.doute1,
        phrase:'Not every wave lets itself be surfed. This one still counted.',
        mission:'A session where the urge didn\u2019t go down — it happens, and it counts too.' }
    ]},
    { id:'depassement', n:16, label:'Overcoming', img:'ill-cards/16-depassement.png', tiers:[
      { star:1, cond:COND.depassement1,
        phrase:'It rose, it fell again. You stayed.',
        mission:'Finish a Surfing the urge session.' },
      { star:2, cond:COND.depassement2,
        phrase:'Ten waves held. Your body now knows what your mind doubted.',
        mission:'Finish 10 Surf sessions.' },
      { star:3, cond:COND.depassement3,
        phrase:'Thirty waves. No wave really surprises you anymore.',
        mission:'Finish 30 Surf sessions.' }
    ]},
    { id:'changement', n:17, label:'Change', img:'ill-cards/17-changement.png', tiers:[
      { star:1, cond:COND.changement1,
        phrase:'Between before and after, a clean line. Nothing invisible this time.',
        mission:'A session where the urge dropped by at least 3 points.' }
    ]},
    { id:'prise-de-recul', n:18, label:'Stepping back', img:'ill-cards/18-prise-de-recul.png', tiers:[
      { star:1, cond:COND.prisederecul1,
        phrase:'A letter leaves today. It will arrive at the right time.',
        mission:'Write a letter to your future self.' },
      { star:2, cond:COND.prisederecul2,
        phrase:'Five letters. A conversation has begun with who you\u2019re becoming.',
        mission:'Write 5 letters to your future self.' },
      { star:3, cond:COND.prisederecul3,
        phrase:'Fifteen letters. A whole notebook addressed to no one but you.',
        mission:'Write 15 letters to your future self.' }
    ]},
    { id:'gratitude', n:19, label:'Gratitude', img:'ill-cards/19-gratitude.png', tiers:[
      { star:1, cond:COND.gratitude1,
        phrase:'Five times, you came back. That owes nothing to chance.',
        mission:'Finish 5 sessions, any exercises.' }
    ]},
    { id:'craving', n:20, label:'Craving', img:'ill-cards/20-craving.png', tiers:[
      { star:1, cond:COND.craving1,
        phrase:'Naming the intensity before deciding what to do with it \u2014 that\u2019s already not enduring it passively.',
        mission:'Measure your urge before an exercise (craving button) at least once.' },
      { star:2, cond:COND.craving2,
        phrase:'Ten times, you took its measure before letting it decide for you.',
        mission:'Measure your urge before an exercise, 10 times total.' },
      { star:3, cond:COND.craving3,
        phrase:'Ten times, it arrived strong and left lighter.',
        mission:'Ten sessions where the urge dropped by at least 2 points from start to finish.' }
    ]},
    { id:'decision', n:21, label:'Decision', img:'ill-cards/21-decision.png', tiers:[
      { star:1, cond:COND.decision1,
        phrase:'Every turn in the maze asked the same question.',
        mission:'Finish a Maze level.' },
      { star:2, cond:COND.decision2,
        phrase:'Ten mazes. You choose faster than before.',
        mission:'Finish 10 Maze sessions.' },
      { star:3, cond:COND.decision3,
        phrase:'Thirty mazes. No wall surprises you anymore.',
        mission:'Finish 30 Maze sessions.' }
    ]},
    { id:'energie', n:22, label:'Energy', img:'ill-cards/22-energie.png', tiers:[
      { star:1, cond:COND.energie1,
        phrase:'Three times in the same day. Something switched on.',
        mission:'Finish 3 exercises in the same day.' }
    ]},
    { id:'introspection', n:23, label:'Introspection', img:'ill-cards/23-introspection.png', tiers:[
      { star:1, cond:COND.introspection1,
        phrase:'The breath slows down. The rest follows, always.',
        mission:'Finish a Breath session.' },
      { star:2, cond:COND.introspection2,
        phrase:'Ten times, you slowed down on purpose. It\u2019s a real reflex now.',
        mission:'Finish 10 Breath sessions.' },
      { star:3, cond:COND.introspection3,
        phrase:'Thirty times. Your breath knows the way by heart.',
        mission:'Finish 30 Breath sessions.' }
    ]},
    { id:'espoir', n:24, label:'Hope', img:'ill-cards/24-espoir.png', tiers:[
      { star:1, cond:COND.espoir1,
        phrase:'Three days in a row, with no one asking you to.',
        mission:'Come back 3 days in a row.' }
    ]},
    { id:'accueil', n:25, label:'Welcome', img:'ill-cards/25-accueil.png', tiers:[
      { star:1, cond:COND.accueil1,
        phrase:'The threshold is crossed. The door stays open.',
        mission:'Open the app.' }
    ]},
    { id:'questionnement', n:26, label:'Questioning', img:'ill-cards/26-questionnement.png', tiers:[
      { star:1, cond:COND.questionnement1,
        phrase:'You came back to ask the question a second time.',
        mission:'Come back another day.' }
    ]},
    { id:'decouverte', n:27, label:'Discovery', img:'ill-cards/27-decouverte.png', tiers:[
      { star:1, cond:COND.decouverte1,
        phrase:'Three different paths, and you took them all.',
        mission:'Try 3 different exercises.' }
    ]},
    { id:'comprehension', n:28, label:'Understanding', img:'ill-cards/28-comprehension.png', tiers:[
      { star:1, cond:COND.comprehension1,
        phrase:'Repeated ten times, it starts to look like knowledge.',
        mission:'Finish 10 sessions, any exercises.' }
    ]},
    { id:'patience', n:29, label:'Patience', img:'ill-cards/29-patience.png', tiers:[
      { star:1, cond:COND.patience1,
        phrase:'Seven days held, one at a time, without looking too far ahead.',
        mission:'Come back 7 days in a row.' }
    ]},
    { id:'connexion', n:30, label:'Connection', img:'ill-cards/30-connexion.png', tiers:[
      { star:1, cond:COND.connexion1,
        phrase:'The breath, the blocks, the maze, the wave. You touched them all.',
        mission:'Try Breathe, Tetris, Maze and Surf, at least once each.' }
    ]},
    { id:'equilibre', n:31, label:'Balance', img:'ill-cards/31-equilibre.png', tiers:[
      { star:1, cond:COND.equilibre1,
        phrase:'Fifteen times. The gesture no longer needs courage, just habit.',
        mission:'Finish 15 sessions, any exercises.' }
    ]},
    { id:'protection', n:32, label:'Protection', img:'ill-cards/32-protection.png', tiers:[
      { star:1, cond:COND.protection1,
        phrase:'The alarm signal was used. That\u2019s exactly what it\u2019s there for.',
        mission:'Use urgent mode once.' }
    ]},
    { id:'exploration', n:33, label:'Exploration', img:'ill-cards/33-exploration.png', tiers:[
      { star:1, cond:COND.exploration1,
        phrase:'Twenty times. The tool no longer belongs to you \u2014 you\u2019ve made it yours.',
        mission:'Finish 20 sessions, any exercises.' }
    ]},
    { id:'partage', n:34, label:'Sharing', img:'ill-cards/34-partage.png', tiers:[
      { star:1, cond:COND.partage1,
        phrase:'A few words set down somewhere just for you. That counts as a confidence.',
        mission:'Add a note to a Journal entry.' }
    ]},
    { id:'perseverance', n:35, label:'Perseverance', img:'ill-cards/35-perseverance.png', tiers:[
      { star:1, cond:COND.perseverance1,
        phrase:'Fourteen days. It\u2019s no longer effort, it\u2019s become a rhythm.',
        mission:'Come back 14 days in a row.' }
    ]},
    { id:'accomplissement', n:36, label:'Accomplishment', img:'ill-cards/36-accomplissement.png', tiers:[
      { star:1, cond:COND.accomplissement1,
        phrase:'Thirty days in a row. A whole month fits in this card.',
        mission:'Come back 30 days in a row.' }
    ]},
    { id:'recadrage', n:37, label:'Reframe', img:'ill-cards/37-recadrage.png', tiers:[
      { star:1, cond:COND.recadrage1,
        phrase:'A thought arrived disguised as truth. You looked at it from another angle.',
        mission:'Finish a Reframe session.' }
    ]},
    { id:'autocompassion', n:38, label:'Self-compassion', img:'ill-cards/38-auto-compassion.png', tiers:[
      { star:1, cond:COND.autocompassion1,
        phrase:'A pause needed no excuse. You came back, simply.',
        mission:'Come back after a pause of 3 or more days, and finish a session.' }
    ]}
  ];

  function CARTES() { return lang() === 'en' ? CARTES_EN : CARTES_FR; }
  var MAX_N = 38; // borne actuelle de la galerie ; augmente d'elle-même si CARTES() grandit au-delà

  function buildCtx() {
    var ss = (window.MDData ? window.MDData.getSessions() : []);
    var o = (window.MDData ? window.MDData.getCtc() : {});
    var entries = Array.isArray(o.entries) ? o.entries : [];
    var byDayMap = {};
    ss.forEach(function (s) { var k = Math.floor((s.date || 0) / 86400000); byDayMap[k] = (byDayMap[k] || 0) + 1; });
    return {
      ss: ss,
      days: activeDays(ss),
      streak: currentStreak(ss),
      deltas: deltas(ss),
      types: distinctTypes(ss),
      byDay: Object.keys(byDayMap).map(function (k) { return byDayMap[k]; }),
      notes: entries.filter(function (e) { return e && e.note; }).length,
      bilan: (window.MDData.getBilanState ? window.MDData.getBilanState() : null)
    };
  }

  /* Évalue toutes les cartes, fait progresser les paliers atteints. Renvoie la liste des
     progressions RÉELLES de cette évaluation (nouvelles étoiles), pour déclencher une célébration. */
  function check() {
    if (!window.MDData) return [];
    var ctx = buildCtx();
    var priorTiers = window.MDData.getTrophyTiers();
    var gains = [];
    CARTES().forEach(function (c) {
      var reached = 0, reachedTier = null;
      c.tiers.forEach(function (t) { if (t.cond(ctx) && t.star > reached) { reached = t.star; reachedTier = t; } });
      if (reached > 0) {
        var before = priorTiers[c.id] || 0;
        var progressed = window.MDData.setTrophyTier(c.id, reached);
        if (progressed && reached > before) gains.push({ card: c, tier: reachedTier, star: reached });
      }
    });
    return gains;
  }

  function getUnlocked() { return window.MDData ? window.MDData.getTrophies() : []; }
  function isUnlocked(id) { return getUnlocked().indexOf(id) >= 0; }
  function getTier(id) { var t = window.MDData ? window.MDData.getTrophyTiers() : {}; return t[id] || 0; }
  function stats() { var c = buildCtx(); return { total: c.ss.length, streak: c.streak, days: c.days.length }; }

  /* ---- Popup de célébration : « au moment du succès », pas silencieusement en profil ---- */
  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdt-ov{z-index:var(--z-modal-top,5000);align-items:center;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.62);backdrop-filter:blur(3px)}' +
      '.mdt-card{max-width:340px;width:100%;background:var(--surface,#fff);border-radius:22px;overflow:hidden;' +
      'box-shadow:0 22px 60px rgba(31,43,37,.32);text-align:center;animation:mdt-in .35s var(--ease,ease) both}' +
      '@keyframes mdt-in{from{transform:scale(.88);opacity:0}to{transform:scale(1);opacity:1}}' +
      '.mdt-eyebrow{font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-caps,11px);font-weight:700;' +
      'letter-spacing:.08em;text-transform:uppercase;color:var(--terra,#C7765C);padding:16px 0 0}' +
      '.mdt-vis{width:78%;margin:10px auto 0;aspect-ratio:1288/868;border-radius:14px;overflow:hidden;background:var(--surface,#fff);box-shadow:0 8px 22px rgba(31,43,37,.22)}' +
      '.mdt-vis img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdt-stars{margin:12px 0 2px;font-size:18px;letter-spacing:3px;color:var(--ocre,#D5A84A)}' +
      '.mdt-meta{padding:4px 22px 22px}' +
      '.mdt-n{font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);margin-bottom:2px}' +
      '.mdt-name{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,21px);font-weight:500;color:var(--ink,#1F2B25);margin:2px 0 10px}' +
      '.mdt-phrase{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-ui,15px);' +
      'font-style:italic;color:var(--ink,#1F2B25);line-height:1.5;margin:0 0 20px}' +
      '.mdt-go{display:block;width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;' +
      'font-weight:700;font-size:var(--fs-ui,15px);padding:13px;cursor:pointer;margin-bottom:8px}' +
      '.mdt-close{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);' +
      'font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer}' +
      '@media (prefers-reduced-motion:reduce){.mdt-card{animation:none}}';
    var s = document.createElement('style'); s.textContent = css; document.head.appendChild(s);
  }

  var CELEB_T = {
    new_card:{fr:'Nouvelle carte', en:'New card'}, upgraded_card:{fr:'Carte améliorée', en:'Upgraded card'},
    see_collection:{fr:'Voir ma collection', en:'See my collection'}, continue_btn:{fr:'Continuer', en:'Continue'}
  };
  function ct(k){ var e=CELEB_T[k]; return e ? (lang()==='en'?e.en:e.fr) : k; }

  /* celebrate(gains) : affiche une popup par carte progressée (à la file si plusieurs). */
  function celebrate(gains, onDone) {
    if (!gains || !gains.length) { if (typeof onDone === 'function') onDone(); return; }
    inject();
    var queue = gains.slice();
    function showNext() {
      if (!queue.length) { if (typeof onDone === 'function') onDone(); return; }
      var g = queue.shift();
      var ov = document.createElement('div'); ov.className = 'mdt-ov md-ov';
      var stars = '\u2605'.repeat(g.star) + '\u2606'.repeat(Math.max(0, g.card.tiers.length - g.star));
      var isNew = g.card.tiers.length <= 1 || g.star === 1;
      ov.innerHTML = '<div class="mdt-card">' +
        '<div class="mdt-eyebrow">' + (isNew ? ct('new_card') : ct('upgraded_card')) + '</div>' +
        '<div class="mdt-vis"><img src="' + g.card.img + '" alt="' + g.card.label + '"></div>' +
        (g.card.tiers.length > 1 ? '<div class="mdt-stars">' + stars + '</div>' : '') +
        '<div class="mdt-meta"><div class="mdt-n">' + g.card.n + '</div><div class="mdt-name">' + g.card.label + '</div>' +
        '<p class="mdt-phrase">' + g.tier.phrase + '</p>' +
        '<button type="button" class="mdt-go">' + ct('see_collection') + '</button>' +
        '<button type="button" class="mdt-close">' + ct('continue_btn') + '</button></div></div>';
      document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: ct('new_card') });
      function close() { if (ov.parentNode) ov.parentNode.removeChild(ov); showNext(); }
      ov.querySelector('.mdt-go').addEventListener('click', function () { location.href = 'profil.html#collection'; });
      ov.querySelector('.mdt-close').addEventListener('click', close);
    }
    showNext();
  }

  /* checkAndCelebrate(onDone) : le point d'entrée pratique pour tout jeu — vérifie et célèbre en
     un appel. onDone (optionnel) n'est appelé qu'une fois la dernière carte de la file fermée
     par la personne (ou immédiatement s'il n'y a rien à célébrer) — sert à ne jamais naviguer
     ailleurs pendant qu'un popup trophée est encore visible. */
  function checkAndCelebrate(onDone) { var gains = check(); celebrate(gains, onDone); return gains; }

  return {
    CARTES: CARTES, MAX_N: MAX_N, check: check, getUnlocked: getUnlocked, isUnlocked: isUnlocked,
    getTier: getTier, stats: stats, celebrate: celebrate, checkAndCelebrate: checkAndCelebrate
  };
})();
