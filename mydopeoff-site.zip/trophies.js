/* trophies.js — Collection de cartes « arcanes » (tarot thématique RDR), à paliers.
   100 % dérivé des signaux déjà journalisés (MDData.getSessions() + entries() du Journal) :
   AUCUN jeu n'a besoin de connaître ce module pour la détection. Un jeu futur qui appelle
   MDData.logSession(type,…) alimente automatiquement check() — zéro couplage.

   Chaque carte a 1 à 3 paliers (étoiles). Un palier = { star, cond(ctx), phrase, mission }.
   - phrase : texte tarot (poétique, évocateur) affiché une fois le palier atteint.
   - mission : texte précis de ce qu'il reste à faire pour l'atteindre (pas de « continue tes
     séances » vague — la condition exacte, en clair).
   Les cartes à un seul palier restent des jalons ponctuels (ex. premier usage du mode urgence) ;
   les cartes à plusieurs paliers (liées à un jeu précis) continuent d'évoluer après déblocage.

   Ton des phrases : voix tarot — courte, évocatrice, present tense, jamais mièvre — distincte
   de la voix conversationnelle de la mascotte (qui vit dans debriefs.js).

   Expose window.MDTrophies : { CARTES, MAX_N, check(), getUnlocked(), isUnlocked(), getTier(),
   stats(), celebrate() }. */
window.MDTrophies = (function () {

  function nbType(ss, t) { return ss.filter(function (s) { return s.type === t; }).length; }
  function activeDays(ss) { var d = {}; ss.forEach(function (s) { d[Math.floor((s.date || 0) / 86400000)] = 1; }); return Object.keys(d); }
  function currentStreak(ss) {
    var set = {}; activeDays(ss).forEach(function (k) { set[k] = 1; });
    var day = Math.floor(Date.now() / 86400000), n = 0;
    while (set[day]) { n++; day--; }
    return n;
  }
  function deltas(ss) { return ss.filter(function (s) { return s.envieAvant != null && s.envieApres != null; }); }
  function distinctTypes(ss) { var s = {}; ss.forEach(function (x) { s[x.type] = 1; }); return Object.keys(s); }

  var CARTES = [
    { id:'tristesse', n:1, label:'Tristesse', img:'ill-cards/1-tristesse.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=1 && c.bilan && ((c.bilan.craving && c.bilan.craving.daysAgo<=14 && c.bilan.craving.improving===false) || (c.bilan.wellbeing && c.bilan.wellbeing.daysAgo<=14 && c.bilan.wellbeing.improving===false)); },
        phrase:'Rien n\u2019allait franchement mieux. Tu es venu\u00b7e quand m\u00eame.',
        mission:'Termine une s\u00e9ance apr\u00e8s un bilan qui montrait une tendance qui ne s\u2019am\u00e9liore pas encore.' }
    ]},
    { id:'colere', n:2, label:'Col\u00e8re', img:'ill-cards/2-colere.png', tiers:[
      { star:1, cond:function(c){ return c.ss.some(function(s){ return s.envieAvant>=8; }); },
        phrase:'\u00c7a montait fort. \u00c7a n\u2019a pas d\u00e9bord\u00e9.',
        mission:'Termine une s\u00e9ance commenc\u00e9e avec une envie \u00e0 8 ou plus.' }
    ]},
    { id:'fatigue', n:3, label:'Fatigue', img:'ill-cards/3-fatigue.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'filtre')>=1; },
        phrase:'Vingt fois de suite, filtrer le r\u00e9flexe. \u00c7a fatigue, et \u00e7a marche.',
        mission:'Termine une session de Filtre.' }
    ]},
    { id:'solitude', n:4, label:'Solitude', img:'ill-cards/4-solitude.png', tiers:[
      { star:1, cond:function(c){ return c.ss.some(function(s){ var h=new Date(s.date||0).getHours(); return h>=23 || h<5; }); },
        phrase:'Une heure o\u00f9 presque personne n\u2019est \u00e9veill\u00e9. Toi, si.',
        mission:'Termine une s\u00e9ance tard le soir ou t\u00f4t le matin (23h\u20135h).' }
    ]},
    { id:'vulnerabilite', n:5, label:'Vuln\u00e9rabilit\u00e9', img:'ill-cards/5-vulnerabilite.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'antisabotage')>=1; },
        phrase:'Regarder en face la fa\u00e7on dont tu peux te freiner toi-m\u00eame \u2014 sans se juger.',
        mission:'Construis ton plan anti-sabotage.' }
    ]},
    { id:'fierte', n:6, label:'Fiert\u00e9', img:'ill-cards/6-fierte.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'echo')>=1; },
        phrase:'La s\u00e9quence s\u2019allongeait. Ta m\u00e9moire a tenu.',
        mission:'Termine une session d\u2019\u00c9cho.' }
    ]},
    { id:'soulagement', n:7, label:'Soulagement', img:'ill-cards/7-soulagement.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'braise')>=1; },
        phrase:'Le plaisir pr\u00e9dit et le plaisir ressenti se sont enfin accord\u00e9s.',
        mission:'Termine une session de Braise.' }
    ]},
    { id:'confiance', n:8, label:'Confiance', img:'ill-cards/8-confiance.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'dualtask')>=1; },
        phrase:'Deux attentions \u00e0 la fois, et aucune n\u2019est tomb\u00e9e.',
        mission:'Termine une session de Double t\u00e2che.' }
    ]},
    { id:'complicite', n:9, label:'Complicit\u00e9', img:'ill-cards/9-complicite.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'virage')>=1; },
        phrase:'La r\u00e8gle a chang\u00e9 sans pr\u00e9venir. Tu as suivi quand m\u00eame.',
        mission:'Termine une session de Virage.' }
    ]},
    { id:'emerveillement', n:10, label:'\u00c9merveillement', img:'ill-cards/10-emerveillement.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'patience')>=1; },
        phrase:'Une graine laiss\u00e9e \u00e0 pousser plut\u00f4t que cueillie tout de suite.',
        mission:'Termine une session de Patience.' }
    ]},
    { id:'tendresse', n:11, label:'Tendresse', img:'ill-cards/11-tendresse.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'elan')>=1; },
        phrase:'Repousser l\u2019impulsion, attirer ce qui compte vraiment pour toi.',
        mission:'Termine une session d\u2019\u00c9lan.' }
    ]},
    { id:'impatience', n:12, label:'Impatience', img:'ill-cards/12-impatience.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'inhib')>=1; },
        phrase:'Le rond appelait \u00e0 agir vite. Le carr\u00e9 demandait d\u2019attendre.',
        mission:'Termine une session de Contr\u00f4le du frein.' }
    ]},
    { id:'curiosite', n:13, label:'Curiosité', img:'ill-cards/13-curiosite.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=1; },
        phrase:'La porte n\u2019était pas fermée à clé. Il suffisait de la pousser.',
        mission:'Termine ton premier exercice, n\u2019importe lequel.' },
      { star:2, cond:function(c){ return c.types.length>=5; },
        phrase:'Cinq portes différentes, et tu es entré·e dans chacune.',
        mission:'Essaie 5 exercices différents.' },
      { star:3, cond:function(c){ return c.types.length>=8; },
        phrase:'Il ne reste plus grand-chose que tu n\u2019as pas exploré ici.',
        mission:'Essaie 8 exercices différents.' }
    ]},
    { id:'concentration', n:14, label:'Concentration', img:'ill-cards/14-concentration.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'tetris')>=1; },
        phrase:'Les blocs tombent. L\u2019esprit, lui, reste.',
        mission:'Termine une partie de Tetris.' },
      { star:2, cond:function(c){ return nbType(c.ss,'tetris')>=10; },
        phrase:'Dix parties. Le geste ne demande plus de réfléchir.',
        mission:'Termine 10 parties de Tetris.' },
      { star:3, cond:function(c){ return nbType(c.ss,'tetris')>=30; },
        phrase:'Trente parties. Ce jeu t\u2019appartient autant que l\u2019inverse.',
        mission:'Termine 30 parties de Tetris.' }
    ]},
    { id:'doute', n:15, label:'Doute', img:'ill-cards/15-doute.png', tiers:[
      { star:1, cond:function(c){ return c.deltas.some(function(s){ return s.envieApres>s.envieAvant; }); },
        phrase:'Toutes les vagues ne se laissent pas surfer. Celle-ci comptait quand même.',
        mission:'Une séance où l\u2019envie n\u2019a pas baissé — ça arrive, et ça compte aussi.' }
    ]},
    { id:'depassement', n:16, label:'Dépassement', img:'ill-cards/16-depassement.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'surf')>=1; },
        phrase:'Elle est montée, elle est redescendue. Tu es resté·e.',
        mission:'Termine une session de Surf de l\u2019envie.' },
      { star:2, cond:function(c){ return nbType(c.ss,'surf')>=10; },
        phrase:'Dix vagues tenues. Ton corps sait maintenant ce que ton mental doutait.',
        mission:'Termine 10 sessions de Surf.' },
      { star:3, cond:function(c){ return nbType(c.ss,'surf')>=30; },
        phrase:'Trente vagues. Il n\u2019y a plus de vague qui te surprenne vraiment.',
        mission:'Termine 30 sessions de Surf.' }
    ]},
    { id:'changement', n:17, label:'Changement', img:'ill-cards/17-changement.png', tiers:[
      { star:1, cond:function(c){ return c.deltas.some(function(s){ return (s.envieAvant-s.envieApres)>=3; }); },
        phrase:'Entre l\u2019avant et l\u2019après, une ligne nette. Rien d\u2019invisible cette fois.',
        mission:'Une séance où l\u2019envie a baissé d\u2019au moins 3 points.' }
    ]},
    { id:'prise-de-recul', n:18, label:'Prise de recul', img:'ill-cards/18-prise-de-recul.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'lettre')>=1; },
        phrase:'Une lettre part aujourd\u2019hui. Elle arrivera au bon moment.',
        mission:'Écris une lettre à ton futur toi.' },
      { star:2, cond:function(c){ return nbType(c.ss,'lettre')>=5; },
        phrase:'Cinq lettres. Une conversation s\u2019est installée avec qui tu deviens.',
        mission:'Écris 5 lettres à ton futur toi.' },
      { star:3, cond:function(c){ return nbType(c.ss,'lettre')>=15; },
        phrase:'Quinze lettres. Un carnet entier adressé à personne d\u2019autre que toi.',
        mission:'Écris 15 lettres à ton futur toi.' }
    ]},
    { id:'gratitude', n:19, label:'Gratitude', img:'ill-cards/19-gratitude.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=5; },
        phrase:'Cinq fois, tu es revenu·e. Ça ne doit rien au hasard.',
        mission:'Termine 5 séances, tous exercices confondus.' }
    ]},
    { id:'craving', n:20, label:'Craving', img:'ill-cards/20-craving.png', tiers:[
      { star:1, cond:function(c){ return c.ss.some(function(s){ return s.envieAvant!=null; }); },
        phrase:'Nommer l\u2019intensit\u00e9 avant de choisir quoi en faire \u2014 c\u2019est d\u00e9j\u00e0 ne plus la subir.',
        mission:'Mesure ton envie avant un exercice (bouton craving) au moins une fois.' },
      { star:2, cond:function(c){ return c.ss.filter(function(s){ return s.envieAvant!=null; }).length>=10; },
        phrase:'Dix fois, tu as pris sa mesure avant de la laisser d\u00e9cider \u00e0 ta place.',
        mission:'Mesure ton envie avant un exercice, 10 fois au total.' },
      { star:3, cond:function(c){ return c.deltas.filter(function(s){ return (s.envieAvant-s.envieApres)>=2; }).length>=10; },
        phrase:'Dix fois, elle est arriv\u00e9e forte et repartie plus l\u00e9g\u00e8re.',
        mission:'Dix séances où l\u2019envie a baissé d\u2019au moins 2 points entre le début et la fin.' }
    ]},
    { id:'decision', n:21, label:'Décision', img:'ill-cards/21-decision.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'maze')>=1; },
        phrase:'Chaque virage du labyrinthe posait la même question.',
        mission:'Termine un niveau du Labyrinthe.' },
      { star:2, cond:function(c){ return nbType(c.ss,'maze')>=10; },
        phrase:'Dix labyrinthes. Tu choisis plus vite qu\u2019avant.',
        mission:'Termine 10 sessions du Labyrinthe.' },
      { star:3, cond:function(c){ return nbType(c.ss,'maze')>=30; },
        phrase:'Trente labyrinthes. Plus aucun mur ne te surprend.',
        mission:'Termine 30 sessions du Labyrinthe.' }
    ]},
    { id:'energie', n:22, label:'Énergie', img:'ill-cards/22-energie.png', tiers:[
      { star:1, cond:function(c){ return c.byDay.some(function(n){ return n>=3; }); },
        phrase:'Trois fois dans la même journée. Quelque chose s\u2019est allumé.',
        mission:'Termine 3 exercices dans la même journée.' }
    ]},
    { id:'introspection', n:23, label:'Introspection', img:'ill-cards/23-introspection.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'breathe')>=1; },
        phrase:'Le souffle ralentit. Le reste suit, toujours.',
        mission:'Termine une session de Souffle.' },
      { star:2, cond:function(c){ return nbType(c.ss,'breathe')>=10; },
        phrase:'Dix fois, tu as ralenti volontairement. C\u2019est un vrai réflexe maintenant.',
        mission:'Termine 10 sessions de Souffle.' },
      { star:3, cond:function(c){ return nbType(c.ss,'breathe')>=30; },
        phrase:'Trente fois. Ton souffle sait le chemin par cœur.',
        mission:'Termine 30 sessions de Souffle.' }
    ]},
    { id:'espoir', n:24, label:'Espoir', img:'ill-cards/24-espoir.png', tiers:[
      { star:1, cond:function(c){ return c.streak>=3; },
        phrase:'Trois jours de suite, sans qu\u2019on te le demande.',
        mission:'Reviens 3 jours de suite.' }
    ]},
    { id:'accueil', n:25, label:'Accueil', img:'ill-cards/25-accueil.png', tiers:[
      { star:1, cond:function(){ return true; },
        phrase:'Le seuil est franchi. La porte reste ouverte.',
        mission:'Ouvre l\u2019application.' }
    ]},
    { id:'questionnement', n:26, label:'Questionnement', img:'ill-cards/26-questionnement.png', tiers:[
      { star:1, cond:function(c){ return c.days.length>=2; },
        phrase:'Tu es revenu·e poser la question une seconde fois.',
        mission:'Reviens un autre jour.' }
    ]},
    { id:'decouverte', n:27, label:'Découverte', img:'ill-cards/27-decouverte.png', tiers:[
      { star:1, cond:function(c){ return c.types.length>=3; },
        phrase:'Trois chemins différents, et tu as tous pris.',
        mission:'Essaie 3 exercices différents.' }
    ]},
    { id:'comprehension', n:28, label:'Compréhension', img:'ill-cards/28-comprehension.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=10; },
        phrase:'Dix fois répété, ça commence à ressembler à un savoir.',
        mission:'Termine 10 séances, tous exercices confondus.' }
    ]},
    { id:'patience', n:29, label:'Patience', img:'ill-cards/29-patience.png', tiers:[
      { star:1, cond:function(c){ return c.streak>=7; },
        phrase:'Sept jours tenus, un par un, sans regarder trop loin devant.',
        mission:'Reviens 7 jours de suite.' }
    ]},
    { id:'connexion', n:30, label:'Connexion', img:'ill-cards/30-connexion.png', tiers:[
      { star:1, cond:function(c){ return ['breathe','tetris','maze','surf'].every(function(t){ return nbType(c.ss,t)>=1; }); },
        phrase:'Le souffle, les blocs, le labyrinthe, la vague. Tu as touché à tout.',
        mission:'Essaie Souffle, Tetris, Labyrinthe et Surf, au moins une fois chacun.' }
    ]},
    { id:'equilibre', n:31, label:'Équilibre', img:'ill-cards/31-equilibre.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=15; },
        phrase:'Quinze fois. Le geste ne demande plus de courage, juste de l\u2019habitude.',
        mission:'Termine 15 séances, tous exercices confondus.' }
    ]},
    { id:'protection', n:32, label:'Protection', img:'ill-cards/32-protection.png', tiers:[
      { star:1, cond:function(c){ return nbType(c.ss,'urgence')>=1; },
        phrase:'Le signal d\u2019alarme a servi. C\u2019est exactement pour ça qu\u2019il existe.',
        mission:'Utilise le mode urgence une fois.' }
    ]},
    { id:'exploration', n:33, label:'Exploration', img:'ill-cards/33-exploration.png', tiers:[
      { star:1, cond:function(c){ return c.ss.length>=20; },
        phrase:'Vingt fois. L\u2019outil ne t\u2019appartient plus — tu l\u2019as fait tien.',
        mission:'Termine 20 séances, tous exercices confondus.' }
    ]},
    { id:'partage', n:34, label:'Partage', img:'ill-cards/34-partage.png', tiers:[
      { star:1, cond:function(c){ return c.notes>=1; },
        phrase:'Un mot posé quelque part rien que pour toi. Ça compte comme une confidence.',
        mission:'Ajoute une note à une entrée du Journal.' }
    ]},
    { id:'perseverance', n:35, label:'Persévérance', img:'ill-cards/35-perseverance.png', tiers:[
      { star:1, cond:function(c){ return c.streak>=14; },
        phrase:'Quatorze jours. Ce n\u2019est plus un effort, c\u2019est devenu un rythme.',
        mission:'Reviens 14 jours de suite.' }
    ]},
    { id:'accomplissement', n:36, label:'Accomplissement', img:'ill-cards/36-accomplissement.png', tiers:[
      { star:1, cond:function(c){ return c.streak>=30; },
        phrase:'Trente jours de suite. Un mois entier tient dans cette carte.',
        mission:'Reviens 30 jours de suite.' }
    ]}
  ];

  var MAX_N = 36; // borne actuelle de la galerie ; augmente d'elle-même si CARTES grandit au-delà

  function buildCtx() {
    var ss = (window.MDData ? window.MDData.getSessions() : []);
    var o = (window.MDData ? window.MDData.getCtc() : {});
    var entries = Array.isArray(o.entries) ? o.entries : [];
    var byDayMap = {};
    ss.forEach(function (s) { var k = Math.floor((s.date || 0) / 86400000); byDayMap[k] = (byDayMap[k] || 0) + 1; });
    return {
      ss: ss,
      days: activeDays(ss),
      streak: currentStreak(ss),
      deltas: deltas(ss),
      types: distinctTypes(ss),
      byDay: Object.keys(byDayMap).map(function (k) { return byDayMap[k]; }),
      notes: entries.filter(function (e) { return e && e.note; }).length,
      bilan: (window.MDData.getBilanState ? window.MDData.getBilanState() : null)
    };
  }

  /* Évalue toutes les cartes, fait progresser les paliers atteints. Renvoie la liste des
     progressions RÉELLES de cette évaluation (nouvelles étoiles), pour déclencher une célébration. */
  function check() {
    if (!window.MDData) return [];
    var ctx = buildCtx();
    var priorTiers = window.MDData.getTrophyTiers();
    var gains = [];
    CARTES.forEach(function (c) {
      var reached = 0, reachedTier = null;
      c.tiers.forEach(function (t) { if (t.cond(ctx) && t.star > reached) { reached = t.star; reachedTier = t; } });
      if (reached > 0) {
        var before = priorTiers[c.id] || 0;
        var progressed = window.MDData.setTrophyTier(c.id, reached);
        if (progressed && reached > before) gains.push({ card: c, tier: reachedTier, star: reached });
      }
    });
    return gains;
  }

  function getUnlocked() { return window.MDData ? window.MDData.getTrophies() : []; }
  function isUnlocked(id) { return getUnlocked().indexOf(id) >= 0; }
  function getTier(id) { var t = window.MDData ? window.MDData.getTrophyTiers() : {}; return t[id] || 0; }
  function stats() { var c = buildCtx(); return { total: c.ss.length, streak: c.streak, days: c.days.length }; }

  /* ---- Popup de célébration : « au moment du succès », pas silencieusement en profil ---- */
  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdt-ov{z-index:var(--z-modal-top,5000);align-items:center;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.62);backdrop-filter:blur(3px)}' +
      '.mdt-card{max-width:340px;width:100%;background:var(--surface,#fff);border-radius:22px;overflow:hidden;' +
      'box-shadow:0 22px 60px rgba(31,43,37,.32);text-align:center;animation:mdt-in .35s var(--ease,ease) both}' +
      '@keyframes mdt-in{from{transform:scale(.88);opacity:0}to{transform:scale(1);opacity:1}}' +
      '.mdt-eyebrow{font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-caps,11px);font-weight:700;' +
      'letter-spacing:.08em;text-transform:uppercase;color:var(--terra,#C7765C);padding:16px 0 0}' +
      '.mdt-vis{width:78%;margin:10px auto 0;aspect-ratio:1288/868;border-radius:14px;overflow:hidden;background:var(--surface,#fff);box-shadow:0 8px 22px rgba(31,43,37,.22)}' +
      '.mdt-vis img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdt-stars{margin:12px 0 2px;font-size:18px;letter-spacing:3px;color:var(--ocre,#D5A84A)}' +
      '.mdt-meta{padding:4px 22px 22px}' +
      '.mdt-n{font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);margin-bottom:2px}' +
      '.mdt-name{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,21px);font-weight:500;color:var(--ink,#1F2B25);margin:2px 0 10px}' +
      '.mdt-phrase{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-ui,15px);' +
      'font-style:italic;color:var(--ink,#1F2B25);line-height:1.5;margin:0 0 20px}' +
      '.mdt-go{display:block;width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;' +
      'font-weight:700;font-size:var(--fs-ui,15px);padding:13px;cursor:pointer;margin-bottom:8px}' +
      '.mdt-close{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);' +
      'font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer}' +
      '@media (prefers-reduced-motion:reduce){.mdt-card{animation:none}}';
    var s = document.createElement('style'); s.textContent = css; document.head.appendChild(s);
  }

  /* celebrate(gains) : affiche une popup par carte progressée (à la file si plusieurs). */
  function celebrate(gains, onDone) {
    if (!gains || !gains.length) { if (typeof onDone === 'function') onDone(); return; }
    inject();
    var queue = gains.slice();
    function showNext() {
      if (!queue.length) { if (typeof onDone === 'function') onDone(); return; }
      var g = queue.shift();
      var ov = document.createElement('div'); ov.className = 'mdt-ov md-ov';
      var stars = '\u2605'.repeat(g.star) + '\u2606'.repeat(Math.max(0, g.card.tiers.length - g.star));
      var isNew = g.card.tiers.length <= 1 || g.star === 1;
      ov.innerHTML = '<div class="mdt-card">' +
        '<div class="mdt-eyebrow">' + (isNew ? 'Nouvelle carte' : 'Carte améliorée') + '</div>' +
        '<div class="mdt-vis"><img src="' + g.card.img + '" alt="' + g.card.label + '"></div>' +
        (g.card.tiers.length > 1 ? '<div class="mdt-stars">' + stars + '</div>' : '') +
        '<div class="mdt-meta"><div class="mdt-n">' + g.card.n + '</div><div class="mdt-name">' + g.card.label + '</div>' +
        '<p class="mdt-phrase">' + g.tier.phrase + '</p>' +
        '<button type="button" class="mdt-go">Voir ma collection</button>' +
        '<button type="button" class="mdt-close">Continuer</button></div></div>';
      document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Nouvelle carte' });
      function close() { if (ov.parentNode) ov.parentNode.removeChild(ov); showNext(); }
      ov.querySelector('.mdt-go').addEventListener('click', function () { location.href = 'profil.html#collection'; });
      ov.querySelector('.mdt-close').addEventListener('click', close);
    }
    showNext();
  }

  /* checkAndCelebrate(onDone) : le point d'entrée pratique pour tout jeu — vérifie et célèbre en
     un appel. onDone (optionnel) n'est appelé qu'une fois la dernière carte de la file fermée
     par la personne (ou immédiatement s'il n'y a rien à célébrer) — sert à ne jamais naviguer
     ailleurs pendant qu'un popup trophée est encore visible. */
  function checkAndCelebrate(onDone) { var gains = check(); celebrate(gains, onDone); return gains; }

  return {
    CARTES: CARTES, MAX_N: MAX_N, check: check, getUnlocked: getUnlocked, isUnlocked: isUnlocked,
    getTier: getTier, stats: stats, celebrate: celebrate, checkAndCelebrate: checkAndCelebrate
  };
})();
