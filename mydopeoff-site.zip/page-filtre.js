/* MyDope Off — page-filtre.js
   Logique de filtre, extraite du script inline de filtre.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var COLORS=[{n:'BLEU',c:'#69889A'},{n:'VERT',c:'#7A8F72'},{n:'JAUNE',c:'#D5A84A'},{n:'ROUGE',c:'#C7765C'}];
  var TRIALS=20;
  var body=document.getElementById('fl-body');
  var trial=0, correct=0, rts=[], tStart=0, ink=null, t0=0, locked=false;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;} return a; }

  function render(){
    var html='<p class="game-step">'+(trial+1)+' / '+TRIALS+'</p>'+
      '<div class="fl-stage"><span class="fl-word" id="fl-word"></span></div><div class="fl-pads">';
    COLORS.forEach(function(col,i){ html+='<button class="fl-pad" data-i="'+i+'" style="background:'+col.c+'"><small>'+col.n+'</small></button>'; });
    html+='</div><div class="game-hud"><span>Justes : <b id="fl-ok">'+correct+'</b></span><span id="fl-fb">&nbsp;</span></div>'+
      '<div class="game-bar"><span id="fl-fill"></span></div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-i]').forEach(function(b){ b.addEventListener('click',function(){ answer(parseInt(b.getAttribute('data-i'),10)); }); });
    next();
  }

  function next(){
    locked=false;
    var word=COLORS[Math.floor(Math.random()*4)];
    // 72% incongruent (conflit), 28% congruent
    if(Math.random()<0.72){ do{ ink=COLORS[Math.floor(Math.random()*4)]; }while(ink.n===word.n); }
    else ink=word;
    var w=document.getElementById('fl-word'); w.textContent=word.n; w.style.color=ink.c;
    document.getElementById('fl-fill').style.width=Math.round(trial/TRIALS*100)+'%';
    tStart=Date.now();
  }

  function answer(i){
    if(locked) return; locked=true;
    var fb=document.getElementById('fl-fb');
    var ok = COLORS[i].n===ink.n;
    if(ok){ correct++; rts.push(Date.now()-tStart); document.getElementById('fl-ok').textContent=correct; fb.textContent='✓'; fb.style.color='#7A8F72'; }
    else { fb.textContent='↺ l\u2019encre'; fb.style.color='#C7765C'; }
    trial++;
    setTimeout(function(){ if(trial>=TRIALS) finish(); else next(); if(document.getElementById('fl-fb'))document.getElementById('fl-fb').innerHTML='&nbsp;'; }, ok?260:620);
  }

  function finish(){
    var acc=Math.round(correct/TRIALS*100);
    var avgRt=rts.length?Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length):0;
    // indice de contrôle attentionnel : justesse pondérée par la vitesse
    var speedBonus=avgRt?Math.max(0,Math.min(20,Math.round((1200-avgRt)/40))):0;
    var idx=Math.max(0,Math.min(100, acc - (100-acc)*0 + speedBonus));
    var d=store(); d.filtre=d.filtre||{best:0,parties:0}; d.filtre.parties++; if(idx>d.filtre.best)d.filtre.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('filtre',{avant:window.__mdAvant, perf:acc/100, dureeSec:Math.round((Date.now()-t0)/1000), meta:{justesse:acc,rtMoyen:avgRt,indice:idx},
        title:'Filtre', stats:[{label:'justesse',value:acc+'%'},{label:'réaction moy.',value:avgRt+' ms'},{label:'contrôle attentionnel',value:idx+'/100'}],
        nav:{ primary:{label:'Rejouer'}, secondary:{label:'Retour au labo'} },
        onClose:function(){ window.__mdAvant=null; trial=0;correct=0;rts=[];t0=Date.now();render(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('filtre',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ justesse:acc, rtMoyen:avgRt, indice:idx } }); }
  }

  function begin(){
    trial=0;correct=0;rts=[];t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:'Filtre',
        lines:['Un mot de couleur apparaît, écrit dans une autre couleur.',
               'Touche la couleur de l\u2019ENCRE, pas le mot que tu lis.',
               'Vingt essais. Le plus juste, le plus vite possible.'],
        why:'Lire est automatique : r\u00e9pondre \u00e0 l\u2019encre oblige \u00e0 filtrer cette impulsion (effet Stroop). C\u2019est le contr\u00f4le attentionnel — la m\u00eame ressource qui aide \u00e0 ne pas suivre un automatisme de conso.',
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  document.getElementById('fl-start').addEventListener('click', begin);
  document.getElementById('fl-skip').addEventListener('click', begin);
  try{ MDCore.init({page:'filtre',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
