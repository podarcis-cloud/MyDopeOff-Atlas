/* MyDope Off — page-filtre.js
   Logique de filtre, extraite du script inline de filtre.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var COLORS_FR=[{n:'BLEU',c:'#69889A'},{n:'VERT',c:'#7A8F72'},{n:'JAUNE',c:'#D5A84A'},{n:'ROUGE',c:'#C7765C'}];
  var COLORS_EN=[{n:'BLUE',c:'#69889A'},{n:'GREEN',c:'#7A8F72'},{n:'YELLOW',c:'#D5A84A'},{n:'RED',c:'#C7765C'}];
  var COLORS = L==='en' ? COLORS_EN : COLORS_FR;
  var TRIALS=20;
  var body=document.getElementById('fl-body');
  var trial=0, correct=0, rts=[], tStart=0, ink=null, t0=0, locked=false;

  var T = {
    ok_count:{fr:'Justes : ',en:'Correct: '},
    check:{fr:'\u2713',en:'\u2713'},
    back_to_ink:{fr:'\u21ba l\u2019encre',en:'\u21ba the ink'},
    title:{fr:'Filtre',en:'Filter'},
    stat_acc:{fr:'justesse',en:'accuracy'},
    stat_rt:{fr:'réaction moy.',en:'avg. reaction'},
    stat_idx:{fr:'contrôle attentionnel',en:'attentional control'},
    replay:{fr:'Rejouer',en:'Replay'},
    back_labo:{fr:'Retour au labo',en:'Back to Lab'},
    rules_l1:{fr:'Un mot de couleur apparaît, écrit dans une autre couleur.',en:'A colour word appears, written in a different colour.'},
    rules_l2:{fr:'Touche la couleur de l\u2019ENCRE, pas le mot que tu lis.',en:'Tap the colour of the INK, not the word you\u2019re reading.'},
    rules_l3:{fr:'Vingt essais. Le plus juste, le plus vite possible.',en:'Twenty trials. As accurate, and as fast, as possible.'},
    rules_why:{fr:'Lire est automatique : répondre à l\u2019encre oblige à filtrer cette impulsion (effet Stroop). C\u2019est le contrôle attentionnel — la même ressource qui aide à ne pas suivre un automatisme de conso.',
      en:'Reading is automatic: responding to the ink forces you to filter out that impulse (the Stroop effect). That\u2019s attentional control \u2014 the same resource that helps you avoid following a habitual use pattern.'}
  };
  function t(k){ var e=T[k]; return e ? (L==='en'?e.en:e.fr) : k; }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'filtre.title':    { fr: 'Filtre', en: 'Filter' },
    'filtre.subtitle': { fr: 'Garde le signal, ignore le bruit.', en: 'Keep the signal, ignore the noise.' },
    'filtre.game_sub': { fr: "Un mot de couleur s'affiche, mais écrit dans une autre couleur. Touche la <b>couleur de l'encre</b>, pas le mot. Ton cerveau veut lire le mot : c'est ça, le bruit à filtrer.",
      en: "A colour word appears, but written in a different colour. Tap the <b>ink colour</b>, not the word. Your brain wants to read the word: that's the noise you're filtering out." }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;} return a; }

  function render(){
    var html='<p class="game-step">'+(trial+1)+' / '+TRIALS+'</p>'+
      '<div class="fl-stage"><span class="fl-word" id="fl-word"></span></div><div class="fl-pads">';
    COLORS.forEach(function(col,i){ html+='<button class="fl-pad" data-i="'+i+'" style="background:'+col.c+'"><small>'+col.n+'</small></button>'; });
    html+='</div><div class="game-hud"><span>'+t('ok_count')+'<b id="fl-ok">'+correct+'</b></span><span id="fl-fb">&nbsp;</span></div>'+
      '<div class="game-bar"><span id="fl-fill"></span></div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-i]').forEach(function(b){ b.addEventListener('click',function(){ answer(parseInt(b.getAttribute('data-i'),10)); }); });
    next();
  }

  function next(){
    locked=false;
    var word=COLORS[Math.floor(Math.random()*4)];
    // 72% incongruent (conflit), 28% congruent
    if(Math.random()<0.72){ do{ ink=COLORS[Math.floor(Math.random()*4)]; }while(ink.n===word.n); }
    else ink=word;
    var w=document.getElementById('fl-word'); w.textContent=word.n; w.style.color=ink.c;
    document.getElementById('fl-fill').style.width=Math.round(trial/TRIALS*100)+'%';
    tStart=Date.now();
  }

  function answer(i){
    if(locked) return; locked=true;
    var fb=document.getElementById('fl-fb');
    var ok = COLORS[i].n===ink.n;
    if(ok){ correct++; rts.push(Date.now()-tStart); document.getElementById('fl-ok').textContent=correct; fb.textContent=t('check'); fb.style.color='#7A8F72'; }
    else { fb.textContent=t('back_to_ink'); fb.style.color='#C7765C'; }
    trial++;
    setTimeout(function(){ if(trial>=TRIALS) finish(); else next(); if(document.getElementById('fl-fb'))document.getElementById('fl-fb').innerHTML='&nbsp;'; }, ok?260:620);
  }

  function finish(){
    var acc=Math.round(correct/TRIALS*100);
    var avgRt=rts.length?Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length):0;
    // indice de contrôle attentionnel : justesse pondérée par la vitesse
    var speedBonus=avgRt?Math.max(0,Math.min(20,Math.round((1200-avgRt)/40))):0;
    var idx=Math.max(0,Math.min(100, acc - (100-acc)*0 + speedBonus));
    var d=store(); d.filtre=d.filtre||{best:0,parties:0}; d.filtre.parties++; if(idx>d.filtre.best)d.filtre.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('filtre',{avant:window.__mdAvant, perf:acc/100, dureeSec:Math.round((Date.now()-t0)/1000), meta:{justesse:acc,rtMoyen:avgRt,indice:idx},
        title:t('title'), stats:[{label:t('stat_acc'),value:acc+'%'},{label:t('stat_rt'),value:avgRt+' ms'},{label:t('stat_idx'),value:idx+'/100'}],
        nav:{ primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose:function(){ window.__mdAvant=null; trial=0;correct=0;rts=[];t0=Date.now();render(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('filtre',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ justesse:acc, rtMoyen:avgRt, indice:idx } }); }
  }

  function begin(){
    trial=0;correct=0;rts=[];t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  try{ MDCore.init({page:'filtre',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
