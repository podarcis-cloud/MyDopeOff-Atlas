/* MyDope Off — page-fiches.js
   Scripts inline de fiches.html regroupés pour permettre une CSP stricte.
   Les gestionnaires inline (onclick, onmousedown…) ont été convertis en
   attributs data-* + délégation, incluse ici. Ordre d'origine préservé. */

(function(){
  window.MD_DICT = window.MD_DICT || {};
  var STATIC_T = {
    'fc.tetris_n': { en: 'Anti-craving Tetris' },
    'fc.tetris_s': { en: '3 min · occupies visuospatial working memory (Oxford 2015)' },
    'fc.maze_n': { en: 'Gyro maze' },
    'fc.maze_s': { en: '12 levels · redirects the mental imagery of the urge' },
    'fc.breathe_n': { en: 'Breath — cardiac coherence' },
    'fc.breathe_s': { en: 'Guided breathing 6/min · gyroscope &amp; mic · anti-stress' },
    'fc.surf_n': { en: 'Surfing the urge' },
    'fc.surf_s': { en: 'Craving is a wave: it rises, peaks, falls again · Marlatt 1985' },
    'fc.inhib_n': { en: 'Brake control' },
    'fc.inhib_s': { en: 'Go/No-Go · 2 min · trains response inhibition' },
    'fc.stopsignal_n': { en: 'Stop-Signal' },
    'fc.stopsignal_s': { en: '2 min · measures how fast your brake is (SSRT)' },
    'fc.patience_n': { en: 'Patience' },
    'fc.patience_s': { en: 'Waiting to gather more · impulsivity (delay discounting)' },
    'fc.echo_n': { en: 'Echo' },
    'fc.echo_s': { en: '2 min · remember and repeat the sequence · working memory' },
    'fc.filtre_n': { en: 'Filter' },
    'fc.filtre_s': { en: 'Respond to the ink, not the word · attention (Stroop)' },
    'fc.virage_n': { en: 'Switch' },
    'fc.virage_s': { en: 'The rule changes: sort by colour or shape · flexibility' },
    'fc.dualtask_n': { en: 'Dual task' },
    'fc.dualtask_s': { en: '1 min · the circle and the counter at once · divided attention' },
    'fc.elan_n': { en: 'Impulse' },
    'fc.elan_s': { en: 'Push the impulse away, pull in your values · approach bias' },
    'fc.antisabotage_n': { en: 'Anti-sabotage plan' },
    'fc.antisabotage_s': { en: 'Spot a pattern, prepare your response in advance' },
    'fc.recadrage_n': { en: 'Reframe' },
    'fc.recadrage_s': { en: '8 rounds · looking at an automatic thought differently · CBT' },
    'fc.sec_emo': { en: 'Regulate the emotion' },
    'fc.braise_n': { en: 'Ember' },
    'fc.braise_s': { en: 'Anticipate, act, savour · rekindles natural pleasure (PAT)' },
    'fc.valeurs_n': { en: 'My values' },
    'fc.valeurs_s': { en: 'What really matters · reread this mid-craving' },
    'fc.lettre_n': { en: 'Letter to your future self' },
    'fc.lettre_s': { en: 'Write it, read it on camera or into the mic · keep it in your path' },
    'fc.sec_frein': { en: 'Strengthen the brake' },
    'fc.sec_memoire': { en: 'Memory &amp; attention' },
    'fc.sec_plaisir': { en: 'Rekindle pleasure' },
    'fc.sec_qui': { en: 'Who I want to be' },
    'fc.sec_lettre': { en: 'Letter to your future self' }
  };
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });
})();

(function(){
        try{
          var d=JSON.parse(localStorage.getItem('ctc_v6'));
          if(d&&d.user&&d.user.name){
            var p='';
            document.getElementById('link-tetris').href='tetris.html'+p;
            document.getElementById('link-maze').href='maze.html'+p;
          }
        }catch(e){}
      })();

/* ---- bloc suivant ---- */

// ===== URL PARAMS =====
const params = new URLSearchParams(location.search);
const userName = params.get('name') || '';
const userRegion = params.get('region') || 'BE';

const KEY = 'ctc_v6';
function loadData() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ return {}; } }
function saveData(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch(e){} }

// ===== NAVIGATION =====
let currentScreen = 'hub';
let activeTimerInterval = null;

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + id).classList.add('active');
  currentScreen = id;
  var gb=document.getElementById('global-back'); if(gb) gb.style.display=(id==='hub')?'none':'';
  if(id==='hub'){ var tg=document.getElementById('topbar-tag'); if(tg) tg.textContent='Labo'; }
}

document.getElementById('global-back').onclick = () => {
  if (currentScreen === 'hub') {
    if(window.history.length>1) window.history.back(); else location.href='index.html';
  } else {
    if (activeTimerInterval) clearInterval(activeTimerInterval);
    showScreen('hub');
    document.getElementById('topbar-tag').textContent = 'Parcours';
  }
};


// ===== EXERCISES =====
const EXERCISES = [
  {id:"tetris_mental",name:"Effet Tetris Mental",emoji:"",type:"crisis",duration:90,tagline:"Oxford 2015 : 3 min de Tetris réduisent les cravings de 24%.",zone:"Hippocampe · Interférence visuospatiale",instruction:"Visualise des formes qui tombent dans ta tête. Fais-les tourner mentalement. Ton hippocampe est trop occupé pour alimenter l'envie.",science:"Le traitement visuospatial court-circuite les images mentales liées au désir.",messages:["Visualise. Fais pivoter.","La pièce en L va là...","Ton hippocampe est occupé.","Ligne complète. Craving réduit."]},
  {id:"wu_tang",name:"Méthode Wu-Tang",emoji:"",type:"crisis",duration:60,tagline:"C.R.E.A.M. — Craving Rules Everything Around Me.",zone:"Cortex préfrontal dorsolatéral",instruction:"Cite les 9 membres du Wu-Tang Clan par ordre alphabétique. Sinon : présidents français, capitales d'Europe.",science:"La mémoire déclarative et le craving utilisent les mêmes ressources.",messages:["RZA... GZA... Method Man...","Ghostface, Raekwon...","U-God, Masta Killa...","Craving neutralisé."]},
  {id:"ice_cube",name:"Protocole Glaçon",emoji:"",type:"crisis",duration:120,tagline:"Sensation physique intense vs désir chimique.",zone:"Cortex somatosensoriel · Insula",instruction:"Tiens un glaçon dans ta paume non-dominante. Concentre-toi sur la sensation de froid.",science:"Le froid intense active l'insula et le nerf vague.",messages:["Tiens bon.","Froid ? Bien. Nerf vague activé.","L'engourdissement remplace le manque.","Continue."]},
  {id:"surf",name:"Surf l'Envie",emoji:"",type:"crisis",duration:150,tagline:"Le craving est une vague. Ne te noie pas dedans.",zone:"Cortex préfrontal · Insula",instruction:"Assieds-toi. Observe le craving arriver, monter, puis redescendre. Ne le combats pas.",science:"L'urge surfing (Marlatt 1985) réduit l'intensité des cravings.",messages:["Laisse l'envie arriver.","Observe sans juger.","La vague monte... puis redescend.","Elle passe toujours."]},
  {id:"box_breathing",name:"Respiration Carrée",emoji:"",type:"crisis",duration:180,tagline:"La technique des Navy SEAL.",zone:"Nerf vague · Cortex préfrontal",instruction:"Inspire 4s, retiens 4s, expire 4s, retiens 4s. Répète 6 cycles.",science:"Réduit le cortisol de 15% en 5 minutes.",messages:["Inspire... 2... 3... 4...","Retiens... 2... 3... 4...","Expire... 2... 3... 4...","Rétention... Cortex en ligne."]},
  {id:"mirror",name:"Neurones Miroirs",emoji:"",type:"daily",duration:120,tagline:"Ton cerveau ne fait pas la différence entre faire et imaginer faire.",zone:"Cortex prémoteur · Neurones miroirs",instruction:"Visualise-toi en train de faire une activité que tu aimes vraiment. Rends la scène hyper détaillée.",science:"Les neurones miroirs activent les mêmes circuits que l'action réelle.",messages:["Ferme les yeux...","Rends la scène réelle.","Circuit de récompense activé.","Continue à visualiser."]},
  {id:"autopilot",name:"Hack l'Autopilote",emoji:"⊙",type:"daily",duration:60,tagline:"80% de tes actions sont automatiques. L'addiction en est une.",zone:"Ganglions de la base · Cortex préfrontal",instruction:"Fais UN truc différemment aujourd'hui (autre chemin, brossage avec l'autre main).",science:"La nouveauté force le cortex préfrontal à reprendre le contrôle.",messages:["Quel truc tu vas changer ?","Fais-le différemment.","Nouvelle connexion neuronale.","Autopilote hacké."]},
  {id:"letter",name:"Lettre au Futur Toi",emoji:"",type:"daily",duration:180,tagline:"Ton futur toi a des opinions arrêtées sur tes choix.",zone:"Cortex préfrontal médian",instruction:"Écris une lettre à toi-même dans 5 ans. Sois honnête.",science:"Les personnes en addiction voient leur futur soi comme un étranger. Cette lettre réduit la distance.",messages:["'Cher moi dans 5 ans...'","Sois honnête.","Ce que tu as surmonté...","Quelle version veux-tu être ?"]},
  {id:"gratitude_punk",name:"Gratitude Punk",emoji:"",type:"daily",duration:90,tagline:"La gratitude, c'est de la sérotonine gratuite.",zone:"Cortex préfrontal médian · Système limbique",instruction:"Écris 3 trucs ultra-concrets qui ont été moins nuls qu'escompté.",science:"3 minutes de gratitude concrète activent le cortex préfrontal médian.",messages:["1 truc concret.","2e truc. Même trivial.","3e truc. Sérotonine en route.","Trois ! Cortex activé."]},
  {id:"menu_dopamine",name:"Menu Dopamine",emoji:"",type:"daily",duration:120,tagline:"Ton cerveau est un gourmet.",zone:"Noyau accumbens",instruction:"Construis ton Menu Dopamine : entrées (1–5 min), plats (20–60 min), desserts (rares).",science:"Le noyau accumbens ne distingue pas les sources de dopamine.",messages:["Entrées : vite et gratuit.","Plats : effort → vraie satisfaction.","Desserts : ce qui vaut le coup.","Menu créé."]},
  {id:"non_dominant",name:"Main Rebelle",emoji:"",type:"plasticity",duration:90,tagline:"Réveille l'hémisphère qui dort.",zone:"Cortex moteur",instruction:"Écris ton prénom 10 fois avec ta main non-dominante. Puis dessine un carré et un cercle en même temps.",science:"Force la plasticité synaptique.",messages:["Écris. Maladroit ? Normal.","Carré d'un côté, cercle de l'autre...","Nouvelles cartes motrices.","Hémisphère réveillé."]},
  {id:"5_senses",name:"Scan 5 Sens",emoji:"",type:"plasticity",duration:120,tagline:"Ancrage sensoriel total.",zone:"Cortex insulaire",instruction:"Nomme 5 choses que tu vois, 4 que tu entends, 3 que tu touches, 2 que tu sens, 1 que tu goûtes.",science:"Désactive le réseau du mode par défaut.",messages:["5 choses que tu VOIS...","4 choses que tu ENTENDS...","3 choses que tu TOUCHES...","2 odeurs. 1 goût."]},
  {id:"cross_lateral",name:"Marche Croisée",emoji:"",type:"plasticity",duration:60,tagline:"Brain Gym redoutable.",zone:"Corps calleux",instruction:"Lève le genou droit, touche-le avec ta main gauche. Alterne. 40 répétitions lentes, puis les yeux fermés.",science:"Force la coopération interhémisphérique.",messages:["Genou droit, main gauche.","Genou gauche, main droite.","Les yeux fermés maintenant.","Corps calleux renforcé."]},
  {id:"memory_palace",name:"Palais de Mémoire",emoji:"",type:"plasticity",duration:150,tagline:"La technique des champions de mémoire.",zone:"Hippocampe",instruction:"Choisis un lieu connu. Place mentalement 5 mots : CALME – FORCE – DEMAIN – CHOIX – LIBERTÉ.",science:"Renforce l'hippocampe. Augmentation de matière grise après 6 semaines.",messages:["Place le premier mot...","Continue le parcours...","Hippocampe activé.","5 mots. Retrouve-les."]},
  {id:"reverse_counting",name:"Décompte Inversé",emoji:"",type:"plasticity",duration:120,tagline:"Charge cognitive anti-rumination.",zone:"Cortex préfrontal dorsolatéral · DLPFC",instruction:"Compte à rebours depuis 300 en soustrayant 7 à chaque fois. À voix haute. Sans t'arrêter.",science:"Active le DLPFC, la zone anti-craving et anti-rumination par excellence.",messages:["300, 293, 286...","Continue. Ne t'arrête pas.","DLPFC en pleine charge.","Objectif : 30 soustraction."]},
  {id:"tongue_map",name:"Carte Mentale Express",emoji:"",type:"plasticity",duration:90,tagline:"Visualisation spatiale rapide.",zone:"Gyrus angulaire · Cortex pariétal",instruction:"Ferme les yeux. Visualise le plan de ton appartement. Compte toutes les fenêtres. Puis les prises électriques.",science:"Active le cortex pariétal et renforce la représentation spatiale.",messages:["Visualise le plan...","Fenêtres : compte-les.","Prises électriques...","Carte mentale complète."]},
  {id:"color_word",name:"Stroop Challenge",emoji:"",type:"plasticity",duration:60,tagline:"L'exercice classique de contrôle cognitif.",zone:"Cortex cingulaire antérieur",instruction:"Dis la COULEUR de l'encre, pas le mot. ROUGE écrit en bleu → dis 'bleu'. Fais-le 30 fois vite.",science:"L'effet Stroop active le cortex cingulaire antérieur — nœud du contrôle inhibiteur.",messages:["Dis la COULEUR, pas le mot.","Vas plus vite.","Contrôle inhibiteur activé.","30 fois. Tu y es presque."]},
  {id:"backward_alphabet",name:"Alphabet à l'Envers",emoji:"",type:"plasticity",duration:90,tagline:"Mémoire de travail à fond.",zone:"Cortex préfrontal · Boucle phonologique",instruction:"Récite l'alphabet à l'envers : Z, Y, X, W… Le plus vite possible. Puis fais-le en ne disant qu'une lettre sur deux.",science:"Charge maximale la boucle phonologique de la mémoire de travail.",messages:["Z, Y, X, W...","Continue, sans hésiter.","Mémoire de travail sous charge.","Une lettre sur deux maintenant."]},
  {id:"rhythmic_tapping",name:"Polymétrie Cérébrale",emoji:"",type:"plasticity",duration:90,tagline:"Synchronisation interhémisphérique.",zone:"Ganglions de la base · Cervelet · Cortex moteur",instruction:"Tape 3 fois avec la main droite et 2 fois avec la gauche en même temps. Maintiens le rythme 90 secondes.",science:"La polymétrie coordonne ganglions de la base, cervelet et cortex moteur simultanément.",messages:["Main droite : 1-2-3.","Main gauche : 1-2.","Ensemble maintenant...","Cervelet et ganglions liés."]}];

function renderExercises() {
  const crisis = EXERCISES.filter(e => e.type === 'crisis');
  const daily = EXERCISES.filter(e => e.type === 'daily');
  const plasticity = EXERCISES.filter(e => e.type === 'plasticity');
  const wip = `<div style="background:var(--bg-2);border:1px solid var(--line);border-left:3px solid var(--ocre,#D5A84A);border-radius:12px;padding:10px 12px;margin-bottom:12px;font-size:var(--fs-xs);line-height:var(--lh-normal);color:var(--ink-2)">
    <b style="color:var(--ink,#1F2B25)">${pui('guided_exercises')}</b>${pui('guided_desc')}<b>${pui('guided_desc_b')}</b>${pui('guided_desc_end')}</div>`;
  document.getElementById('ex-crisis-list').innerHTML = wip + crisis.map(exCard).join('');
  document.getElementById('ex-daily-list').innerHTML = daily.map(exCard).join('');
  document.getElementById('ex-plasticity-list').innerHTML = plasticity.map(exCard).join('');
}

function exCard(ex) {
  return `<div class="ex-card ${ex.type}" data-open-ex="${ex.id}"> <div class="ex-icon">${ex.emoji}</div> <div class="ex-info"> <div class="ex-name">${tr(ex,'name')}</div> <div class="ex-tagline">${tr(ex,'tagline')}</div> <div class="ex-meta"> <span class="ex-badge ${ex.type}">${ex.type === 'crisis' ? pui('crisis') : ex.type === 'daily' ? pui('daily') : pui('plasticity')}</span> <span class="ex-duration">${ex.duration}s</span> <span style="font-size:var(--fs-caps);color:var(--ink-2);border:1px solid var(--line);border-radius:999px;padding:1px 7px">${pui('guided')}</span> </div> </div> <div class="ex-arrow">→</div> </div>`;
}

/* Délégation des actions (ex-attributs onclick, retirés pour permettre une CSP stricte).
   Couvre aussi les éléments générés dynamiquement, qui portent data-open-ex / data-timer. */
document.addEventListener('click', function(e){
  var t2 = e.target;
  var ex = t2.closest && t2.closest('[data-open-ex]');
  if (ex) { openExercise(ex.getAttribute('data-open-ex')); return; }
  var tm = t2.closest && t2.closest('[data-timer]');
  if (tm) { startTimer(parseInt(tm.getAttribute('data-timer'), 10), tm.getAttribute('data-timer-id')); return; }
  var act = t2.closest && t2.closest('[data-act]');
  if (!act) return;
  var a = act.getAttribute('data-act');
  if (a === 'global-back') { var gb = document.getElementById('global-back'); if (gb) gb.click(); }
  else if (a === 'identite') { e.preventDefault(); if (window.MDIdentite) MDIdentite.open(); }
  else if (a === 'inhib') { e.preventDefault(); if (window.MDInhib) MDInhib.open(); }
  else if (a === 'inhib-stop') { e.preventDefault(); if (window.MDInhib) MDInhib.openStop(); }
});

window.openExercise = (id) => {
  const ex = EXERCISES.find(e => e.id === id);
  if (!ex) return;
  document.getElementById('topbar-tag').textContent = tr(ex,'name').toUpperCase();
  const circum = 2 * Math.PI * 52;
  document.getElementById('ex-detail-content').innerHTML = `
    <div class="ex-detail"> <div class="ex-detail-icon">${ex.emoji}</div> <div class="ex-detail-name">${tr(ex,'name')}</div> <div class="ex-detail-tagline">${tr(ex,'tagline')}</div> <div class="info-block"> <div class="info-block-label">${pui('zone')}</div> <div class="info-block-val">${tr(ex,'zone')}</div> </div> <div class="info-block"> <div class="info-block-label">${pui('instructions')}</div> <div class="info-block-val">${tr(ex,'instruction')}</div> </div> <div class="info-block science"> <div class="info-block-label">${pui('science')}</div> <div class="info-block-val">${tr(ex,'science')}</div> </div> </div> <div class="timer-wrap"> <div class="timer-circle"> <svg class="timer-svg" width="120" height="120" viewBox="0 0 120 120"> <circle class="timer-track" cx="60" cy="60" r="52"/> <circle class="timer-fill" id="timer-fill" cx="60" cy="60" r="52"
            stroke-dasharray="${circum}" stroke-dashoffset="${circum}"/> </svg> <div class="timer-text"> <div class="timer-secs" id="timer-secs">${ex.duration}</div> <div class="timer-label">sec</div> </div> </div> <div class="timer-message" id="timer-msg">${tr(ex,'messages')[0]}</div> <button class="btn-primary" id="timer-start" data-timer="${ex.duration}" data-timer-id="${ex.id}">${pui('start')}</button> <button class="btn-outline" data-act="global-back">${pui('back')}</button> </div> `;
  showScreen('ex');
};

let timerRunning = false;
window.startTimer = (duration, exId) => {
  if (timerRunning) return;
  timerRunning = true;
  const ex = EXERCISES.find(e => e.id === exId);
  const circum = 2 * Math.PI * 52;
  let remaining = duration;
  let elapsed = 0;
  const fill = document.getElementById('timer-fill');
  const secsEl = document.getElementById('timer-secs');
  const msgEl = document.getElementById('timer-msg');
  const btn = document.getElementById('timer-start');
  btn.textContent = 'En cours…';
  btn.style.opacity = '.5';
  btn.style.pointerEvents = 'none';
  const MSGS = tr(ex,'messages'); const msgInterval = Math.floor(duration / MSGS.length);
  activeTimerInterval = setInterval(() => {
    remaining--;
    elapsed++;
    secsEl.textContent = remaining;
    const progress = elapsed / duration;
    fill.style.strokeDashoffset = circum * (1 - progress);
    const msgIdx = Math.min(MSGS.length - 1, Math.floor(elapsed / msgInterval));
    msgEl.textContent = MSGS[msgIdx];
    if (remaining <= 0) {
      clearInterval(activeTimerInterval);
      timerRunning = false;
      secsEl.textContent = '✓';
      msgEl.textContent = pui('exercise_done');
      btn.textContent = pui('back');
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'all';
      btn.onclick = () => document.getElementById('global-back').click();
      // Save
      const d = loadData();
      const sessions = d.sessions || [];
      sessions.push({ type:'ex', name: ex.name, date: Date.now() });
      d.sessions = sessions;
      d.score = (d.score || 0) + 2;
      saveData(d);
    }
  }, 1000);
};

// ===== QUESTIONNAIRES =====
// ===== INIT =====
// (rendu initial déclenché via DOMContentLoaded plus bas, une fois pLang/tr/pui définis)

/* ---- bloc suivant ---- */

(function(){
  try{
    var d=JSON.parse(localStorage.getItem('ctc_v6'));
    if(d&&d.user&&d.user.name){
      var p='';
    }
  }catch(e){}
  if(window.MDCore) MDCore.init({page:'fiches'});
})();
/* Overlay de traduction des protocoles (FR par défaut dans EXERCISES) */
function pLang(){ return window.MDCore ? MDCore.lang() : 'fr'; }
function tr(obj, field){
  var l=pLang(); if(l==='fr') return obj[field];
  var dict=(window.MD_PROTO_I18N||{})[l];
  if(dict && dict[obj.id] && dict[obj.id][field]!=null) return dict[obj.id][field];
  return obj[field];
}
function pui(key){
  var l=pLang();
  var dict=(window.MD_PROTO_I18N||{})[l];
  var fr={tab_exercises:"Exercices",tab_questionnaires:"Bilans",games_label:"Jeux cognitifs — Anti-craving",
    tetris_name:"Tetris anti-craving",tetris_meta:"Recommandé maintenant · 3 min",tetris_desc:"3 min · occupe la mémoire visuospatiale (Oxford 2015)",
    maze_name:"Labyrinthe gyroscope",maze_tag:"Anti-craving visuospatial · 12 niveaux",maze_desc:"12 niveaux · détourne l'imagerie mentale de l'envie",
    crisis:"Crise",daily:"Quotidien",plasticity:"Plasticité",zone:"Zone ciblée",instructions:"Instructions",science:"Science",
    start:"Démarrer",back:"← Retour",cancel:"← Annuler",topbar:"Parcours",sec:"sec",
    crisis_section:"Crise / craving immédiat",daily_section:"Quotidien",plasticity_section:"Plasticité cérébrale",
    guided:"Guidé",guided_exercises:"Exercices guidés",
    guided_desc:" — texte + minuteur, pleinement utilisables. On les transforme peu à peu en ",
    guided_desc_b:"mini-jeux interactifs",guided_desc_end:" comme ceux du haut.",
    exercise_done:"✓ Exercice terminé !"};
  if(dict && dict._ui && dict._ui[key]!=null) return dict._ui[key];
  return fr[key]!=null?fr[key]:key;
}
/* Traduit l'UI statique de la page protocoles */
function applyProtoUI(){
  var set=function(sel,val){var el=document.querySelector(sel); if(el) el.textContent=val;};
  var bb=document.getElementById('global-back'); if(bb) bb.textContent=pui('back');
  var gl=document.querySelector('#tab-exercises .section-label'); if(gl) gl.textContent=pui('games_label');
  // cartes jeux (structure .gtile canonique : .gname + .gsub)
  var tN=document.querySelector('#link-tetris .gname'); if(tN) tN.textContent=pui('tetris_name');
  var tD=document.querySelector('#link-tetris .gsub'); if(tD) tD.textContent=pui('tetris_desc');
  var mN=document.querySelector('#link-maze .gname'); if(mN) mN.textContent=pui('maze_name');
  var mD=document.querySelector('#link-maze .gsub'); if(mD) mD.textContent=pui('maze_desc');
  // titres de sections
  var titles=document.querySelectorAll('#tab-exercises .section-title');
  if(titles[0]) titles[0].textContent=pui('crisis_section');
  if(titles[1]) titles[1].textContent=pui('daily_section');
  if(titles[2]) titles[2].textContent=pui('plasticity_section');
  // topbar tag (si on est sur le hub)
  if(typeof currentScreen!=='undefined' && currentScreen==='hub'){
    var tag=document.getElementById('topbar-tag'); if(tag) tag.textContent=pui('topbar');
  }
}
document.addEventListener('langchange', function(){
  applyProtoUI();
  try{ renderExercises(); }catch(e){}
});
document.addEventListener('DOMContentLoaded', function(){ applyProtoUI(); try{ renderExercises(); }catch(e){} });
applyProtoUI();
/* Re-rendu fiable une fois MDCore + protocols-i18n chargés (le 1er rendu plus haut
   se faisait avant ces scripts, donc en français/vide selon le timing) */
try{ renderExercises(); }catch(e){}

/* ---- bloc suivant ---- */

try{MDCore.init({page:"fiches",section:"equilibre"});}catch(e){}

/* ---- bloc suivant ---- */

(function(){try{var host=document.getElementById('md-parcours');if(host&&window.MDParcours){window.MDParcours.renderInto(host);window.MDParcours.maybeReprise();}}catch(e){}})();

/* ---- bloc suivant ---- */

(function(){
  try{
    var trig = sessionStorage.getItem('mdAutoOpen');
    if (!trig) return;
    sessionStorage.removeItem('mdAutoOpen');
    if (window.MDInhib) {
      if (trig === 'stop' && MDInhib.openStop) MDInhib.openStop();
      else if (MDInhib.open) MDInhib.open();
    }
  }catch(e){}
})();
