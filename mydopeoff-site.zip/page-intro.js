/* MyDope Off — page-intro.js
   Encart mascotte inline pour les pages qui n'ont pas de dossier dédié (donc pas de
   dossier-guide.js) mais qui doivent quand même s'inscrire dans le même système visuel que
   le reste du site. Réutilise .dg-intro (composant partagé, components.css) et
   MDCompagnon.avatarHTML() (la vraie fonction partagée, pas une copie locale — contrairement à
   dossier-guide.js qui a sa propre implémentation ; à corriger séparément).
   Ancre : la section .shead présente sur la plupart de ces pages ; repli sur .hero pour les
   pages qui ont une structure d'en-tête différente (guide.html). Insertion juste après.
   100 % local. Expose window.MDPageIntro. */
window.MDPageIntro = (function () {
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var CONTENT_FR = {
    controles: { mood: 'vigilance',
      text: 'Ici, pas de mythe ni d\u2019astuce miracle \u2014 juste ce qu\u2019un contr\u00f4le v\u00e9rifie vraiment, et le seul geste qui fonctionne \u00e0 tous les coups.' },
    detection: { mood: 'explication',
      text: 'Ton m\u00e9tabolisme, ta consommation habituelle et le type de test font varier chaque chiffre \u2014 parfois du simple au triple.' },
    rdr: { mood: 'ecoute',
      text: 'Cinq onglets, un seul but : que tu saches quoi faire et \u00e0 qui parler, avant d\u2019en avoir besoin dans l\u2019urgence.' },
    psychochecker: { mood: 'clarification',
      text: 'Cherche une substance, v\u00e9rifie un m\u00e9lange \u2014 les infos ici viennent de la litt\u00e9rature clinique, jamais d\u2019un ou\u00ef-dire de soir\u00e9e.' },
    guide: { mood: 'ecoute',
      text: 'Pas besoin de tout lire d\u2019un coup \u2014 utilise cette page comme un plan, et reviens-y quand une question se pose.' }
  };
  var CONTENT_EN = {
    controles: { mood: 'vigilance',
      text: 'No myths or miracle tricks here \u2014 just what a stop actually checks, and the only thing that works every time.' },
    detection: { mood: 'explication',
      text: 'Your metabolism, your usual consumption and the type of test change every figure here \u2014 sometimes threefold.' },
    rdr: { mood: 'ecoute',
      text: 'Five tabs, one goal: knowing what to do and who to talk to, before you need it in an emergency.' },
    psychochecker: { mood: 'clarification',
      text: 'Look up a substance, check a mix \u2014 the info here comes from clinical literature, never from party hearsay.' },
    guide: { mood: 'ecoute',
      text: 'No need to read it all at once \u2014 use this page as a map, and come back whenever a question comes up.' }
  };
  function CONTENT(){ return lang()==='en' ? CONTENT_EN : CONTENT_FR; }

  function esc(s) { return String(s).replace(/[&<>"]/g, function (m) { return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[m]; }); }

  function init(pageId) {
    var data = CONTENT()[pageId];
    var anchor = document.querySelector('.shead') || document.querySelector('.hero');
    if (!data || !anchor || !window.MDCompagnon) return;
    var introEl = document.createElement('div');
    introEl.className = 'dg-intro';
    introEl.innerHTML = MDCompagnon.avatarHTML(data.mood, { size: 'sm' }) + '<p>' + esc(data.text) + '</p>';
    anchor.parentNode.insertBefore(introEl, anchor.nextSibling);
    document.addEventListener('langchange', function(){
      var p = introEl.querySelector('p');
      var fresh = CONTENT()[pageId];
      if (p && fresh) p.textContent = fresh.text;
    });
  }

  return { init: init };
})();
