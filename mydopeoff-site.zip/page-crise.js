/* MyDope Off — page-crise.js
   Dossier crise psychédélique. Seul besoin : MDCore.init() (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'crise', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
