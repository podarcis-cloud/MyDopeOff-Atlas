/* page-profil.js — Rend la galerie de cartes/trophées + stats de progression. */
(function () {
  'use strict';
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  var LOCK_SVG = '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
  var SOON_SVG = '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l2.5 2.5"/></svg>';

  function starStr(star, max){ return '\u2605'.repeat(star) + '\u2606'.repeat(Math.max(0,max-star)); }

  function renderGallery(){
    var host = document.getElementById('trophy-grid');
    if (!host || !window.MDTrophies) return;
    var CARTES = window.MDTrophies.CARTES;
    var byN = {}; CARTES.forEach(function(c){ byN[c.n] = c; });

    var html = '';
    for (var n = 1; n <= window.MDTrophies.MAX_N; n++) {
      var c = byN[n];
      if (!c) {
        // Numéro réservé, carte pas encore fournie (1-12, 20, 37+…) : silhouette « à venir ».
        html += '<div class="trophy-card soon"><div class="vis">' + SOON_SVG + '</div>' +
          '<div class="meta"><div class="n">' + n + '</div><h3>À venir</h3><p>Une prochaine carte.</p></div></div>';
        continue;
      }
      var star = window.MDTrophies.getTier(c.id);
      var maxStar = c.tiers.length;
      if (star > 0) {
        var tier = c.tiers.filter(function(t){ return t.star===star; })[0] || c.tiers[0];
        var nextTier = c.tiers.filter(function(t){ return t.star===star+1; })[0];
        html += '<div class="trophy-card unlocked" data-id="' + c.id + '"><div class="vis"><img src="' + c.img + '" alt="' + c.label + '" loading="lazy"></div>' +
          '<div class="meta"><div class="n">' + c.n + '</div><h3>' + c.label + '</h3>' +
          (maxStar > 1 ? '<div class="tstars">' + starStr(star, maxStar) + '</div>' : '') +
          '<p>' + tier.phrase + '</p>' +
          (nextTier ? '<p class="tnext">Prochain palier — ' + nextTier.mission + '</p>' : '') +
          '</div></div>';
      } else {
        html += '<div class="trophy-card locked"><div class="vis">' + LOCK_SVG + '</div>' +
          '<div class="meta"><div class="n">' + c.n + '</div><h3>Verrouillée</h3><p>' + c.tiers[0].mission + '</p></div></div>';
      }
    }
    host.innerHTML = html;
    host.querySelectorAll('.trophy-card.unlocked').forEach(function(el){
      el.addEventListener('click', function(){ openCard(el.getAttribute('data-id')); });
    });
  }

  function openCard(id){
    var c = window.MDTrophies.CARTES.filter(function(x){ return x.id===id; })[0];
    if (!c) return;
    var star = window.MDTrophies.getTier(id);
    var tier = c.tiers.filter(function(t){ return t.star===star; })[0] || c.tiers[0];
    var maxStar = c.tiers.length;
    var ov = document.createElement('div'); ov.className = 'tc-ov';
    ov.innerHTML = '<div class="tc-card">' +
      '<div class="vis"><img src="' + c.img + '" alt="' + c.label + '"></div>' +
      '<div class="meta"><div class="n">' + c.n + '</div><h3>' + c.label + '</h3>' +
      (maxStar > 1 ? '<div class="tstars" style="margin-bottom:8px">' + starStr(star, maxStar) + '</div>' : '') +
      '<p>' + tier.phrase + '</p>' +
      '<button type="button" class="tc-close">Fermer</button></div></div>';
    document.body.appendChild(ov);
    function close(){ if (ov.parentNode) ov.parentNode.removeChild(ov); }
    ov.addEventListener('click', function(e){ if (e.target===ov) close(); });
    ov.querySelector('.tc-close').addEventListener('click', close);
  }

  function renderStats(){
    if (!window.MDTrophies) return;
    var s = window.MDTrophies.stats();
    var elS = document.getElementById('st-streak'), elT = document.getElementById('st-total'), elC = document.getElementById('st-cartes');
    if (elS) elS.textContent = s.streak;
    if (elT) elT.textContent = s.total;
    if (elC) elC.textContent = window.MDTrophies.getUnlocked().length + '/' + window.MDTrophies.MAX_N;
  }

  function renderTrends(){
    var host = document.getElementById('trend-list'), empty = document.getElementById('trend-empty');
    if (!host || !window.MDData || !MDData.getDistinctSubstances || !MDData.substanceTrend) return;
    var subs = MDData.getDistinctSubstances();
    var rows = [];
    subs.forEach(function(sub){
      var t = MDData.substanceTrend(sub);
      if (t && t.overall) rows.push({ sub: sub, t: t });
    });
    if (!rows.length){ host.innerHTML=''; if (empty) empty.style.display='block'; return; }
    if (empty) empty.style.display='none';
    var ICONS = { up:'\u25B2', down:'\u25BC', stable:'\u2014' };
    var LABELS = { up:'en hausse (30 derniers jours)', down:'en baisse (30 derniers jours)', stable:'stable (30 derniers jours)' };
    function esc(s){ return (s||'').replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    host.innerHTML = rows.map(function(r){
      return '<div class="trend-row"><span class="t-ic '+r.t.overall+'">'+ICONS[r.t.overall]+'</span>' +
        '<span class="t-sub">'+esc(r.sub)+'</span><span class="t-lab">'+LABELS[r.t.overall]+'</span></div>';
    }).join('');
  }

  function wireBackup(){
    var exp = document.getElementById('bk-export'), imp = document.getElementById('bk-import');
    var file = document.getElementById('bk-file'), status = document.getElementById('bk-status');
    if (!exp || !imp || !file || !window.MDBackup) return;
    function showStatus(ok, msg){
      status.textContent = msg;
      status.style.color = ok ? 'var(--sauge-d,#4C5E45)' : 'var(--terra-d,#9E4F37)';
      status.style.fontWeight = 'var(--w-bold,700)';
    }
    exp.addEventListener('click', function(){
      exp.disabled = true;
      showStatus(true, 'Préparation de la sauvegarde…');
      window.MDBackup.exportData(function(ok, nLettres){
        exp.disabled = false;
        showStatus(ok, ok
          ? ('✓ Sauvegarde téléchargée dans le dossier Téléchargements' + (nLettres ? (' (' + nLettres + ' lettre' + (nLettres>1?'s':'') + ' incluse' + (nLettres>1?'s':'') + ')') : '') + '.')
          : '✗ Échec de la sauvegarde — réessaie.');
      });
    });
    imp.addEventListener('click', function(){ file.value=''; file.click(); });
    file.addEventListener('change', function(){
      if (file.files && file.files[0]) {
        window.MDBackup.confirmAndImport(file.files[0], function(ok){
          if (!ok) showStatus(false, '✗ Fichier de sauvegarde invalide ou restauration annulée.');
          // si ok: MDBackup affiche déjà sa propre confirmation puis recharge la page.
        });
      }
      file.value = '';
    });
  }

  function wireTabs(){
    function activateTab(name){
      var btn = document.querySelector('.tab-btn[data-tab="'+name+'"]');
      var panel = document.getElementById('tab-'+name);
      if (!btn || !panel) return false;
      document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
      document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
      btn.classList.add('active'); btn.setAttribute('aria-selected','true');
      panel.classList.add('active');
      return true;
    }
    document.querySelectorAll('.tab-btn').forEach(function(btn){
      btn.addEventListener('click', function(){ activateTab(btn.getAttribute('data-tab')); });
    });
    // Point d'entrée externe (ex. lien "Voir ma collection" depuis la popup trophée) :
    // profil.html#collection doit ouvrir directement le bon onglet, pas l'onglet par défaut.
    var wanted = (location.hash || '').replace('#', '');
    if (wanted) activateTab(wanted);
  }

  function wireRecit() {
    var b = document.getElementById('btn-recit');
    if (b) b.addEventListener('click', function () { if (window.MDProgressionRecit) MDProgressionRecit.open(); });
  }

  ready(function () {
    if (window.MDCore) MDCore.init({ page: 'profil', section: 'progression' });
    if (window.MDTrophies) MDTrophies.check(); // filet de sécurité, idempotent
    renderStats();
    renderGallery();
    renderTrends();
    wireBackup();
    wireTabs();
    wireRecit();
  });
})();
