/* MyDope Off — recherche-index.js
   ============================================================================
   Index de recherche interne. Statique, embarqué : aucune requête, rien qui sort
   de l'appareil, y compris les mots tapés.

   POURQUOI CET INDEX EXISTE
   Le produit est organisé par substance et par exercice. Ce n'est pas ainsi que les
   gens arrivent : ils arrivent avec une situation. « j'ai trop pris », « ça siffle
   depuis hier », « je suis enceinte et je consomme », « il est pas bien ».
   Cet index fait le pont entre ce que la personne tape et ce que le produit contient.
   Il répond donc en partie au chantier C6.1 (entrée par situation de vie).

   RÈGLE DE VOCABULAIRE
   Les mots-clés sont écrits comme les gens les tapent, pas comme le produit les écrit :
   argot, fautes fréquentes, formulations à 3 h du matier. Un index qui n'accepterait que
   le vocabulaire éditorial ne servirait qu'à ceux qui n'ont pas besoin de chercher.

   PIÈGE DE NORMALISATION
   Les accents sont retirés à la comparaison : « dosé » devient « dose ». Un mot-clé comme
   « trop dosé » injecte donc le mot isolé « dose » dans l'entrée, qui capture alors des
   requêtes sans rapport (« dose femme » remontait l'urgence overdose). Éviter dans les
   entrées d'urgence tout mot qui, désaccentué, devient un terme courant.

   RÈGLE D'URGENCE
   Certaines recherches ne doivent pas renvoyer une liste de liens : quelqu'un qui tape
   « il respire plus » a besoin d'une conduite immédiate, pas d'un menu. Ces entrées
   portent `urgence: true` et remontent toujours en tête avec leur geste affiché.
   ============================================================================ */
window.MD_RECHERCHE = [

  /* ---------- Urgences : conduite immédiate, jamais une liste ---------- */
  { url: 'rdr.html#overdose', urgence: true,
    titre_fr: 'Quelqu’un ne réagit plus', titre_en: 'Someone isn’t responding',
    geste_fr: 'Appelle les secours. Mets la personne sur le côté, dégage sa bouche, reste avec elle. Si tu as de la naloxone et qu’un opioïde est possible : donne-la, et redonne au bout de 3 minutes si rien ne change.',
    geste_en: 'Call emergency services. Put them on their side, clear their mouth, stay with them. If you have naloxone and an opioid is possible: give it, and give another after 3 minutes if nothing changes.',
    mots: 'overdose od surdose inconscient inconsciente respire plus respiration arrêtée bleu lèvres bleues réveille pas ronfle bizarre coma il est pas bien elle est pas bien naloxone narcan secours urgence mourir crise convulsion trop pris j’ai trop pris surdosé surdosage trop fort beaucoup trop' },

  { url: 'crise-psychedelique.html', urgence: true,
    titre_fr: 'Quelqu’un panique, ou toi', titre_en: 'Someone is panicking, or you are',
    geste_fr: 'Changer de pièce, baisser le son et la lumière, s’asseoir. Respirer lentement, plus long à l’expiration qu’à l’inspiration. Ça monte, ça culmine, ça redescend — même quand ça n’en a pas l’air. Ne pas rester seul·e.',
    geste_en: 'Move to another room, turn down sound and light, sit down. Breathe slowly, longer out than in. It rises, peaks and falls — even when it doesn’t feel like it. Don’t stay alone.',
    mots: 'bad trip badtrip panique angoisse crise d’angoisse parano paranoïa je flippe ça monte trop fort mauvais trip anxiété attaque de panique je deviens fou perds la tête crise psychédélique il panique elle panique calmer quelqu’un trip sitter accompagner un bad trip lsd champignons panique' },

  /* ---------- Dossiers transversaux ---------- */
  { url: 'chemsex.html',
    titre_fr: 'Chemsex', titre_en: 'Chemsex',
    mots: 'chemsex chem sexe drogue slam slamming plan chem 3-mmc 3mmc 3-cmc ghb gbl g tina crystal meth méthamphétamine cathinone session party and play pnp descente lundi consentement injection sexe sous produit hsh gay grindr' },

  { url: 'situations.html',
    titre_fr: 'Quand les conseils habituels ne collent pas', titre_en: 'When the usual advice doesn’t fit',
    mots: 'rue sans abri sans-abri sdf dehors dormir dehors squat précarité pauvre pas d’argent sans papiers sans adresse hébergement urgence sociale 115 maraude accueil de jour travail du sexe travailleuse du sexe travailleur du sexe prostitution escort client passe michetonnage lgbt lgbtqia gay lesbienne bi trans transgenre homophobie transphobie hormones traitement hormonal senior seniors vieux vieillir âgé personne âgée retraite foie reins médicaments prescrits chute isolement solitude' },

  { url: 'apres-une-pause.html',
    titre_fr: 'Après une pause', titre_en: 'After a break',
    mots: 'tolérance tolerance perdue reprise après arrêt sortie de prison sortie prison libération détention incarcération sortir de taule après l’hôpital hospitalisation cure post cure sevrage reprendre après reprendre la même dose dose d’avant naloxone narcan spray nasal overdose après arrêt premières semaines rechute dangereuse recommencer après des semaines' },

  { url: 'femmes.html',
    titre_fr: 'Quand on est une femme', titre_en: 'When you’re a woman',
    mots: 'femme femmes fille meuf dose femme effet plus fort alcool femme cycle règles hormones contraception hormonale mixité choisie violence conjugale violences sexuelles viol agression garde d’enfant enquête sociale mauvaise mère honte jugement soignant maman mère médicament pour dormir seule à la maison' },

  { url: 'grossesse.html',
    titre_fr: 'Grossesse et santé sexuelle', titre_en: 'Pregnancy and sexual health',
    mots: 'grossesse enceinte bébé fœtus foetus test de grossesse contraception pilule du lendemain contraception d’urgence préservatif capote stérilet dépistage ist mst vih sida hépatite prep tpe traitement post exposition allaitement méthadone enceinte signalement garde enfant placement asaf sage femme accouchement' },

  { url: 'paws.html',
    titre_fr: 'Le creux qui vient après', titre_en: 'The dip that comes afterwards' ,
    mots: 'paws syndrome prolongé sevrage post aigu après arrêt rechute tardive déprime après arrêt insomnie sevrage anxiété sevrage ça va pas mieux j’ai arrêté et je vais mal je vais mal après avoir arrêté vais mal depuis que j’ai arrêté toujours mal arrêté depuis anhédonie plus de plaisir humeur benzodiazépine sevrage alcool sevrage' },

  { url: 'audition.html',
    titre_fr: 'Tes oreilles', titre_en: 'Your ears',
    mots: 'oreilles audition acouphène acouphènes sifflement bourdonnement ça siffle hyperacousie surdité perte auditive bouchons d’oreilles protection auditive décibels db concert festival club son fort teuf rave sourd oreille bouchée' },

  { url: 'alertes.html',
    titre_fr: 'Alertes et actualités', titre_en: 'Alerts and news',
    mots: 'alerte alertes vendu comme falsifié coupé adultéré frelaté danger produit circule pmma nitazène nitazenes orphine faux médicament contrefait analyse drug checking tester son produit actualité news' },

  { url: 'rdr-vs-abstinence.html',
    titre_fr: 'Réduction des risques et abstinence', titre_en: 'Harm reduction and abstinence',
    mots: 'abstinence arrêter arrêt sobriété sevrage réduction des risques rdr pourquoi cette appli différence 12 étapes na aa sobre' },

  { url: 'mentions-legales.html',
    titre_fr: 'Ce que ce produit ne fait pas', titre_en: 'What this product doesn’t do',
    mots: 'données vie privée confidentialité anonyme qui voit mes données supprimer mes données mentions légales éditeur qui a fait ça surveillance signaler police' },

  /* ---------- Dossiers substances ---------- */
  { url: 'alcool.html', titre_fr: 'Alcool', titre_en: 'Alcohol',
    mots: 'alcool alcoolisme bière vin whisky vodka alcoolique cuite gueule de bois delirium tremens sevrage alcoolique binge boire trop' },
  { url: 'cannabis.html', titre_fr: 'Cannabis', titre_en: 'Cannabis',
    mots: 'cannabis weed beuh shit herbe joint pétard thc cbd hhc space cake bad trip weed dépendance cannabique' },
  { url: 'cocaine.html', titre_fr: 'Cocaïne', titre_en: 'Cocaine',
    mots: 'cocaïne coke coca c blanche sniff rail trace nez cloison lévamisole descente coke cœur palpitations' },
  { url: 'crack.html', titre_fr: 'Crack', titre_en: 'Crack',
    mots: 'crack caillou galette free base freebase pipe à crack cocaïne basée' },
  { url: 'mdma.html', titre_fr: 'MDMA', titre_en: 'MDMA',
    mots: 'mdma ecstasy exta taz cachet comprimé molly xtc pilule pmma hyperthermie eau descente mardi bruxisme mâchoire' },
  { url: 'ketamine.html', titre_fr: 'Kétamine', titre_en: 'Ketamine',
    mots: 'kétamine ketamine ké ket k special k k-hole khole vessie douleurs vésicales cystite kétamine' },
  { url: 'opioides-synthese.html', titre_fr: 'Opioïdes', titre_en: 'Opioids',
    mots: 'opioïde opioide héroïne héro rabla brown fentanyl nitazène nitazenes oxycodone oxy tramadol codéine morphine méthadone subutex buprénorphine naloxone narcan manque overdose opioïde' },
  { url: 'benzodiazepines.html', titre_fr: 'Benzodiazépines', titre_en: 'Benzodiazepines',
    mots: 'benzo benzodiazépine xanax alprazolam valium diazépam rivotril clonazépam lexomil temesta lysanxia zolpidem stilnox somnifère sevrage benzo trou noir amnésie' },
  { url: 'psychedeliques.html', titre_fr: 'Psychédéliques', titre_en: 'Psychedelics',
    mots: 'lsd acide buvard champignons champi psilocybine dmt ayahuasca 2c-b 2cb mescaline peyotl set setting bad trip flashback hppd trip sitter' },
  { url: 'nitreux.html', titre_fr: 'Protoxyde d’azote', titre_en: 'Nitrous oxide',
    mots: 'protoxyde azote proto ballon cartouche gaz hilarant n2o b12 fourmillements neuropathie' },
  { url: 'tabac-vapotage.html', titre_fr: 'Tabac et vapotage', titre_en: 'Tobacco and vaping',
    mots: 'tabac cigarette clope nicotine vape vapotage puff e-cigarette arrêter de fumer substitut patch' },
  { url: 'polyconsommation.html', titre_fr: 'Mélanges', titre_en: 'Combinations',
    mots: 'mélange mélanger combiner interaction polyconsommation deux produits ensemble alcool et cocaïne cocaéthylène dangereux ensemble compatible' },
  { url: 'psychochecker.html', titre_fr: 'Vérifier un mélange', titre_en: 'Check a combination',
    mots: 'interaction mélange vérifier compatible psychochecker médicament traitement antidépresseur ordonnance serotonine syndrome sérotoninergique' },
  { url: 'detection.html', titre_fr: 'Fenêtres de détection', titre_en: 'Detection windows',
    mots: 'test urinaire détection combien de temps dans le sang cheveux salive contrôle travail permis dépistage positif éliminer' },

  /* ---------- Mécanismes et situations ---------- */
  { url: 'rechute.html', titre_fr: 'Rechute', titre_en: 'Relapse',
    mots: 'rechute rechuté j’ai craqué recommencé faux pas échec reprise recommencer à zéro' },
  { url: 'autosabotage.html', titre_fr: 'Auto-sabotage', titre_en: 'Self-sabotage',
    mots: 'auto sabotage autosabotage je me sabote pourquoi je fais ça encore recommencer alors que je sais' },
  { url: 'environnement.html', titre_fr: 'Environnement', titre_en: 'Environment',
    mots: 'environnement déclencheur trigger lieu ami dealer entourage soirée sortir éviter tentation contexte' },
  { url: 'controles.html', titre_fr: 'Contrôles', titre_en: 'Police checks',
    mots: 'police contrôle fouille garde à vue droit arrestation flagrant délit interpellation avocat' },
  { url: 'soutenir.html', titre_fr: 'Aider quelqu’un', titre_en: 'Supporting someone',
    mots: 'aider un proche mon fils ma fille mon copain ma copine entourage famille comment aider quelqu’un qui consomme parler à' },
  { url: 'lettre.html', titre_fr: 'Lettre à soi', titre_en: 'Letter to yourself',
    mots: 'lettre écrire à moi futur message pour plus tard craving envie' },
  { url: 'suivi.html', titre_fr: 'Journal', titre_en: 'Journal',
    mots: 'journal noter suivi consommation dépenses combien j’ai dépensé jalons objectif' },
  { url: 'guide.html', titre_fr: 'Guide', titre_en: 'Guide',
    mots: 'guide aide mode d’emploi comment ça marche lexique sources anecdotes' }

];
