/* MyDope Off — recherche-index.js
   =========================================================================
   Index de recherche. Statique, embarqué : rien ne sort de l'appareil, y compris
   les mots tapés.

   POURQUOI CET INDEX EXISTE
   Le produit est rangé par substance et par exercice. Ce n'est pas ainsi que les
   gens arrivent : ils arrivent avec une situation, ou avec le mot qui leur vient.
   « jeux », « stress », « respirer », « combien de temps ça reste ».

   RÈGLE DES MOTS-CLÉS
   Écrire tous les ALIAS plausibles, pas le vocabulaire du produit. Un index qui
   n'accepte que les titres ne sert qu'à celui qui connaît déjà la réponse.
   Inclure : synonymes, argot, fautes fréquentes, formulations parlées, et le
   vocabulaire du lexique (les 45 termes du guide y sont répartis).

   RÈGLE D'URGENCE
   Les entrées `urgence: true` remontent avec leur geste affiché. Y mettre
   uniquement ce qui demande une conduite immédiate — et jamais un mot qui,
   désaccentué, devient courant (« trop dosé » -> « dose » capturait tout).
   ========================================================================= */
window.MD_RECHERCHE = [

  /* ============ URGENCES ============ */
  { url: 'rdr.html?tab=sos', urgence: true,
    titre_fr: 'Quelqu\u2019un ne réagit plus', titre_en: 'Someone isn\u2019t responding',
    geste_fr: 'Appelle les secours. Mets la personne sur le côté, dégage sa bouche, reste avec elle. Si tu as de la naloxone et qu\u2019un opioïde est possible : donne-la, et redonne au bout de 3 minutes si rien ne change.',
    geste_en: 'Call emergency services. Put them on their side, clear their mouth, stay with them. If you have naloxone and an opioid is possible: give it, and give another after 3 minutes if nothing changes.',
    mots: 'overdose od surdose surdosage inconscient inconsciente respire plus respiration arretee bleu levres bleues reveille pas ronfle bizarre coma il est pas bien elle est pas bien naloxone narcan secours urgence urgences mourir convulsion depression respiratoire 112 15 samu pompiers appeler les secours' },

  { url: 'crise-psychedelique.html', urgence: true,
    titre_fr: 'Quelqu\u2019un panique, ou toi', titre_en: 'Someone is panicking, or you are',
    geste_fr: 'Changer de pièce, baisser le son et la lumière, s\u2019asseoir. Respirer lentement, plus long à l\u2019expiration. Ça monte, ça culmine, ça redescend. Ne pas rester seul\u00b7e.',
    geste_en: 'Move to another room, turn down sound and light, sit down. Breathe slowly, longer out than in. It rises, peaks and falls. Don\u2019t stay alone.',
    mots: 'bad trip badtrip mauvais trip panique angoisse crise angoisse attaque de panique parano paranoia je flippe ca monte trop fort anxiete je deviens fou perds la tete crise psychedelique il panique elle panique calmer quelqu un trip sitter accompagner bad trip champignons lsd panique delire hallucination' },

  /* ============ SECTIONS PRINCIPALES ============ */
  { url: 'fiches.html',
    titre_fr: 'Labo \u2014 exercices et jeux', titre_en: 'Lab \u2014 exercises and games',
    desc_fr: 'Tous les exercices anti-craving, jeux cognitifs et outils.',
    desc_en: 'All the anti-craving exercises, cognitive games and tools.',
    mots: 'jeux jeu jouer exercice exercices exos activite activites atelier labo laboratoire parcours entrainement entrainer training outils outil anti craving anticraving occuper esprit distraction cognitif mini jeux quoi faire je m ennuie passer le temps' },

  { url: 'suivi.html',
    titre_fr: 'Journal', titre_en: 'Journal',
    desc_fr: 'Noter ses consommations, dépenses et objectifs.',
    desc_en: 'Track use, spending and goals.',
    mots: 'journal calendrier noter notes suivi suivre consommation conso depenses depense argent combien j ai depense budget cout prix jalons objectif objectifs but tracker agenda historique bilan quotidien noter ma journee' },

  { url: 'rdr.html',
    titre_fr: 'Réflexes', titre_en: 'Reflexes',
    desc_fr: 'Urgences, centres, cadre légal, dossiers.',
    desc_en: 'Emergencies, services, legal framework, files.',
    mots: 'reflexes urgence urgences aide assos associations centres caarud csapa ou aller a qui parler numeros telephone ligne ecoute secours legal loi droit avocat police reduction des risques rdr' },

  { url: 'alertes.html',
    titre_fr: 'Alertes et actualités', titre_en: 'Alerts and news',
    desc_fr: 'Ce qui circule en ce moment, et ce qui bouge autour.',
    desc_en: 'What\u2019s going around right now, and what\u2019s shifting around it.',
    mots: 'alerte alertes actu actualite actualites news info infos vendu comme falsifie coupe adultere frelate danger produit circule pmma nitazene nitazenes orphine faux medicament contrefait analyse drug checking tester son produit tester analyse laboratoire quoi de neuf' },

  { url: 'psychochecker.html',
    titre_fr: 'Vérifier un mélange', titre_en: 'Check a combination',
    desc_fr: 'Interactions entre substances et médicaments.',
    desc_en: 'Interactions between substances and medicines.',
    mots: 'interaction interactions melange melanger melanges combiner combinaison compatible compatibilite psychochecker checkeur checker verificateur verifier ensemble avec deux produits medicament medicaments traitement antidepresseur ordonnance serotonine syndrome serotoninergique imao dangereux ensemble puis je melanger' },

  { url: 'detection.html',
    titre_fr: 'Fenêtres de détection', titre_en: 'Detection windows',
    desc_fr: 'Combien de temps un produit reste détectable.',
    desc_en: 'How long a substance stays detectable.',
    mots: 'detection detectable test urinaire urine salive salivaire sang cheveux combien de temps ca reste elimine eliminer duree controle travail permis conduite depistage positif negatif analyse toxicologique fenetre de detection metabolite demi vie' },

  { url: 'profil.html',
    titre_fr: 'Mon profil', titre_en: 'My profile',
    desc_fr: 'Progression, collection de cartes, tendances.',
    desc_en: 'Progress, card collection, trends.',
    mots: 'profil compte progression progres carte cartes collection trophee trophees badge badges statistiques stats tendances mon parcours ma carte' },

  { url: 'admin.html',
    titre_fr: 'Mes données', titre_en: 'My data',
    desc_fr: 'Tout voir, exporter ou effacer.',
    desc_en: 'View, export or erase everything.',
    mots: 'donnees data export exporter sauvegarde backup effacer supprimer supprimer mes donnees reinitialiser reset vie privee confidentialite rgpd telecharger mes donnees' },

  { url: 'guide.html',
    titre_fr: 'Guide et lexique', titre_en: 'Guide and glossary',
    desc_fr: 'Mode d\u2019emploi, définitions, sources.',
    desc_en: 'How it works, definitions, sources.',
    mots: 'guide aide mode emploi comment ca marche lexique definition definitions glossaire vocabulaire mot terme sources references bibliographie anecdotes faq questions' },

  { url: 'soutenir.html',
    titre_fr: 'Aider quelqu\u2019un', titre_en: 'Supporting someone',
    desc_fr: 'Quand un proche consomme.',
    desc_en: 'When someone close to you uses.',
    mots: 'aider proche aider un proche mon fils ma fille mon copain ma copine mon frere ma soeur mon ami entourage famille parent parents comment aider quelqu un qui consomme parler a soutenir accompagner inquiet inquiete' },

  { url: 'mentions-legales.html',
    titre_fr: 'Ce que ce produit ne fait pas', titre_en: 'What this product doesn\u2019t do',
    desc_fr: 'Limites, données, discrétion d\u2019usage.',
    desc_en: 'Limits, data, using it discreetly.',
    mots: 'mentions legales editeur qui a fait ca donnees vie privee confidentialite anonyme qui voit mes donnees surveillance signaler police discretion cacher discret navigation privee limites' },

  /* ============ DOSSIERS TRANSVERSAUX ============ */
  { url: 'chemsex.html', titre_fr: 'Chemsex', titre_en: 'Chemsex',
    desc_fr: 'Dosage, descente, consentement, matériel.', desc_en: 'Dosing, comedown, consent, equipment.',
    mots: 'chemsex chem sexe drogue sexe sous produit slam slamming plan chem 3 mmc 3mmc 3 cmc ghb gbl g tina crystal meth methamphetamine cathinone session party and play pnp descente lundi consentement injection hsh gay grindr partouze' },

  { url: 'grossesse.html', titre_fr: 'Grossesse et santé sexuelle', titre_en: 'Pregnancy and sexual health',
    desc_fr: 'Arrêter brutalement peut être plus dangereux que continuer.', desc_en: 'Stopping abruptly can be more dangerous than carrying on.',
    mots: 'grossesse enceinte bebe foetus test de grossesse contraception pilule du lendemain contraception urgence preservatif capote sterilet depistage ist mst vih sida hepatite prep tpe traitement post exposition allaitement methadone enceinte signalement garde enfant placement sage femme accouchement avortement ivg' },

  { url: 'femmes.html', titre_fr: 'Quand on est une femme', titre_en: 'When you\u2019re a woman',
    desc_fr: 'Même dose, effet différent. Et des obstacles à l\u2019accès aux soins.', desc_en: 'Same dose, different effect. And barriers to care.',
    mots: 'femme femmes fille meuf dose femme effet plus fort alcool femme cycle regles hormones contraception hormonale mixite choisie violence conjugale violences sexuelles viol agression garde enfant enquete sociale mauvaise mere honte jugement soignant maman mere medicament pour dormir seule a la maison' },

  { url: 'paws.html', titre_fr: 'Le creux qui vient après', titre_en: 'The dip that comes afterwards',
    desc_fr: 'Syndrome prolongé de sevrage.', desc_en: 'Protracted withdrawal.',
    mots: 'paws syndrome prolonge sevrage post aigu apres arret rechute tardive deprime apres arret insomnie sevrage anxiete sevrage ca va pas mieux j ai arrete et je vais mal je vais mal depuis que j ai arrete anhedonie plus de plaisir humeur benzodiazepine sevrage alcool sevrage abstinence difficile' },

  { url: 'audition.html', titre_fr: 'Tes oreilles', titre_en: 'Your ears',
    desc_fr: 'Le seul risque de la soirée qui soit définitif.', desc_en: 'The one risk of the night that\u2019s permanent.',
    mots: 'oreilles oreille audition acouphene acouphenes sifflement bourdonnement ca siffle siffle hyperacousie surdite perte auditive sourd bouchons oreilles bouchon protection auditive decibels db concert festival club son fort teuf rave boite musique forte oreille bouchee' },

  { url: 'apres-une-pause.html', titre_fr: 'Après une pause', titre_en: 'After a break',
    desc_fr: 'La dose d\u2019avant peut tuer.', desc_en: 'The old dose can kill.',
    mots: 'tolerance tolerance perdue reprise apres arret sortie de prison prison liberation detention incarceration sortir de taule apres hopital hospitalisation cure post cure sevrage reprendre apres reprendre la meme dose dose avant naloxone narcan spray nasal overdose apres arret premieres semaines recommencer apres des semaines vacances' },

  { url: 'situations.html', titre_fr: 'Quand les conseils habituels ne collent pas', titre_en: 'When the usual advice doesn\u2019t fit',
    desc_fr: 'Rue, travail du sexe, LGBTQIA+, vieillir.', desc_en: 'Street, sex work, LGBTQIA+, growing older.',
    mots: 'rue sans abri sans domicile sdf dehors dormir dehors squat precarite pauvre pas d argent sans papiers sans adresse hebergement urgence sociale 115 maraude accueil de jour travail du sexe travailleuse du sexe travailleur du sexe prostitution escort client passe michetonnage lgbt lgbtqia gay lesbienne bi trans transgenre homophobie transphobie hormones traitement hormonal senior seniors vieux vieillir age personne agee retraite foie reins chute isolement solitude' },

  { url: 'crise-psychedelique.html', titre_fr: 'Quand ça se passe mal', titre_en: 'When it goes badly',
    desc_fr: 'Accompagner quelqu\u2019un en crise.', desc_en: 'Supporting someone in crisis.',
    mots: 'crise psychedelique accompagner rassurer trip sitter sitter presence calmer aider bad trip hyperthermie convulsion syndrome serotoninergique quoi faire si ca tourne mal' },

  { url: 'rdr-vs-abstinence.html', titre_fr: 'Réduction des risques et abstinence', titre_en: 'Harm reduction and abstinence',
    desc_fr: 'Pourquoi cette appli existe.', desc_en: 'Why this app exists.',
    mots: 'abstinence arreter arret sobriete sobre sevrage reduction des risques rdr harm reduction pourquoi cette appli difference 12 etapes na aa alcooliques anonymes narcotiques anonymes zieloffen ni encourager ni decourager approche' },

  /* ============ MÉCANISMES PSYCHOLOGIQUES ============ */
  { url: 'rechute.html', titre_fr: 'Rechute', titre_en: 'Relapse',
    desc_fr: 'Ce qui se passe vraiment, sans jugement.', desc_en: 'What really happens, without judgment.',
    mots: 'rechute rechute rechute j ai craque craque recommence faux pas echec echoue reprise recommencer a zero lapsus retour arriere j ai repris culpabilite honte marlatt' },

  { url: 'autosabotage.html', titre_fr: 'Auto-sabotage', titre_en: 'Self-sabotage',
    desc_fr: 'Pourquoi on recommence alors qu\u2019on sait.', desc_en: 'Why we start again knowing better.',
    mots: 'auto sabotage autosabotage je me sabote pourquoi je fais ca encore recommencer alors que je sais contre mon interet me faire du mal comportement absurde theorie echappement baumeister' },

  { url: 'environnement.html', titre_fr: 'Environnement', titre_en: 'Environment',
    desc_fr: 'Lieux, personnes, déclencheurs.', desc_en: 'Places, people, triggers.',
    mots: 'environnement declencheur declencheurs trigger triggers lieu lieux ami amis dealer entourage soiree sortir eviter tentation contexte habitude routine rat park situation a risque' },

  { url: 'controles.html', titre_fr: 'Contrôles et conduite', titre_en: 'Police checks and driving',
    desc_fr: 'Ce que dit la loi, ce qu\u2019un contrôle vérifie.', desc_en: 'What the law says, what a check tests.',
    mots: 'police controle controles fouille garde a vue droit droits arrestation flagrant delit interpellation avocat conduite volant conduire permis alcootest ethylotest stupefiants au volant amende retrait de permis' },

  /* ============ DOSSIERS SUBSTANCES ============ */
  { url: 'alcool.html', titre_fr: 'Alcool', titre_en: 'Alcohol',
    mots: 'alcool alcoolisme alcoolique biere vin whisky vodka rhum pastis cuite bourre bourree gueule de bois delirium tremens sevrage alcoolique binge drinking boire trop verre verres apero soiree arreter de boire foie cirrhose' },
  { url: 'cannabis.html', titre_fr: 'Cannabis', titre_en: 'Cannabis',
    mots: 'cannabis weed beuh shit herbe fumette joint pete pétard spliff bedo thc cbd hhc thcp h4cbd delta 8 delta 10 space cake gateau comestible edible bang bong vaporisateur dependance cannabique arreter de fumer du shit' },
  { url: 'cocaine.html', titre_fr: 'Cocaïne', titre_en: 'Cocaine',
    mots: 'cocaine coke coca c blanche neige poudre sniff sniffer rail trace ligne nez cloison septum levamisole phenacetine descente coke coeur palpitations cocaethylene' },
  { url: 'crack.html', titre_fr: 'Crack', titre_en: 'Crack',
    mots: 'crack caillou galette free base freebase base pipe a crack doseur cocaine basee fumer du crack modo' },
  { url: 'mdma.html', titre_fr: 'MDMA', titre_en: 'MDMA',
    mots: 'mdma ecstasy exta extasy taz teuse cachet cachetons comprime pilule molly xtc md cristal pmma hyperthermie eau electrolytes descente mardi bruxisme machoire pupilles' },
  { url: 'ketamine.html', titre_fr: 'Kétamine', titre_en: 'Ketamine',
    mots: 'ketamine keta ke ket k special k k hole khole trou vessie douleurs vesicales cystite ketamine uriner sang urine dissociatif' },
  { url: 'opioides-synthese.html', titre_fr: 'Opioïdes', titre_en: 'Opioids',
    mots: 'opioide opioides heroine hero rabla brown blanche fentanyl nitazene nitazenes orphine oxycodone oxy oxycontin tramadol codeine morphine skenan methadone subutex buprenorphine naloxone narcan manque etat de manque overdose opioide shoot injection seringue' },
  { url: 'benzodiazepines.html', titre_fr: 'Benzodiazépines', titre_en: 'Benzodiazepines',
    mots: 'benzo benzos benzodiazepine xanax alprazolam valium diazepam rivotril clonazepam lexomil bromazepam temesta lorazepam lysanxia seresta zolpidem stilnox somnifere dormir sommeil anxiolytique calmant sevrage benzo trou noir amnesie bromazolam flualprazolam' },
  { url: 'psychedeliques.html', titre_fr: 'Psychédéliques', titre_en: 'Psychedelics',
    mots: 'psychedelique psychedeliques lsd acide buvard carton champignons champi champis psilocybine truffe dmt ayahuasca changa 2c b 2cb mescaline peyotl san pedro salvia iboga ibogaine set setting bad trip flashback hppd trip sitter microdosing micro dosage datura brugmansia bufo crapaud amanite' },
  { url: 'nitreux.html', titre_fr: 'Protoxyde d\u2019azote', titre_en: 'Nitrous oxide',
    mots: 'protoxyde azote proto ballon ballons cartouche cartouches gaz hilarant n2o galaxy b12 vitamine b12 fourmillements neuropathie picotements mains pieds cracker' },
  { url: 'tabac-vapotage.html', titre_fr: 'Tabac et vapotage', titre_en: 'Tobacco and vaping',
    mots: 'tabac cigarette clope clopes fumer nicotine vape vapote vapotage puff e cigarette cigarette electronique arreter de fumer substitut patch patchs gomme chicha narguile' },
  { url: 'polyconsommation.html', titre_fr: 'Mélanges', titre_en: 'Combinations',
    mots: 'melange melanger melanges combiner combinaison interaction polyconsommation poly consommation deux produits ensemble alcool et cocaine cocaethylene speedball dangereux ensemble compatible depresseurs stimulants' },

  /* ============ EXERCICES ET JEUX (pages dédiées) ============ */
  { url: 'tetris.html', titre_fr: 'Tetris anti-craving', titre_en: 'Anti-craving Tetris',
    desc_fr: '3 minutes qui font baisser l\u2019intensité d\u2019une envie.', desc_en: '3 minutes that lower the intensity of an urge.',
    mots: 'tetris jeu jeux occuper esprit memoire de travail visuospatial craving envie distraction oxford blocs puzzle' },
  { url: 'breathe.html', titre_fr: 'Souffle \u2014 cohérence cardiaque', titre_en: 'Breath \u2014 heart coherence',
    desc_fr: 'Respiration guidée à 6 cycles par minute.', desc_en: 'Guided breathing at 6 cycles a minute.',
    mots: 'souffle respiration respirer breathe coherence cardiaque calme calmer stress anxiete angoisse detente relaxation relaxer cardiaque rythme cardiaque parasympathique nerf vague crise angoisse panique je stresse' },
  { url: 'surf.html', titre_fr: 'Surf de l\u2019envie', titre_en: 'Urge surfing',
    desc_fr: 'Traverser une envie plutôt que la combattre.', desc_en: 'Riding an urge rather than fighting it.',
    mots: 'surf surfer urge surfing envie craving vague vagues traverser tenir resister pulsion impulsion marlatt ca monte' },
  { url: 'braise.html', titre_fr: 'Braise \u2014 carte des plaisirs', titre_en: 'Embers \u2014 pleasure map',
    desc_fr: 'Réentraîner le circuit de la récompense.', desc_en: 'Retraining the reward circuit.',
    mots: 'braise plaisir plaisirs savourer gratitude recompense dopamine anhedonie plus rien ne me fait plaisir positive affect treatment petits plaisirs joie' },
  { url: 'maze.html', titre_fr: 'Labyrinthe', titre_en: 'Maze',
    desc_fr: 'Piloter une bille au gyroscope.', desc_en: 'Tilt-controlled marble maze.',
    mots: 'labyrinthe maze bille gyroscope incliner jeu jeux attention imagerie mentale occuper craving' },
  { url: 'filtre.html', titre_fr: 'Filtre \u2014 pensées automatiques', titre_en: 'Filter \u2014 automatic thoughts',
    desc_fr: 'Repérer ce qui précède une consommation.', desc_en: 'Spotting what precedes use.',
    mots: 'filtre filtrer pensee pensees automatiques rumination trier attention inhibition go nogo controle stress pression' },
  { url: 'echo.html', titre_fr: 'Écho \u2014 phrases répétées', titre_en: 'Echo \u2014 repeated phrases',
    desc_fr: 'Ce qu\u2019on se répète et son effet.', desc_en: 'What we tell ourselves, and its effect.',
    mots: 'echo phrase phrases repeter discours interieur voix interieure autocritique se parler memoire' },
  { url: 'elan.html', titre_fr: 'Élan \u2014 approche et évitement', titre_en: 'Momentum \u2014 approach and avoidance',
    desc_fr: 'Repousser l\u2019impulsion, attirer ses valeurs.', desc_en: 'Push the impulse away, pull your values in.',
    mots: 'elan motivation valeurs approche evitement swipe glisser impulsion wiers biais attentionnel entrainement' },
  { url: 'patience.html', titre_fr: 'Patience', titre_en: 'Patience',
    desc_fr: 'Attendre, et ce que ça coûte.', desc_en: 'Waiting, and what it costs.',
    mots: 'patience attendre attente delay discounting recompense differee impulsivite tenir tenir bon temporiser' },
  { url: 'recadrage.html', titre_fr: 'Recadrage', titre_en: 'Reframe',
    desc_fr: 'Voir une situation autrement, sans se mentir.', desc_en: 'Seeing a situation differently, honestly.',
    mots: 'recadrage recadrer reframe tcc therapie cognitive pensee point de vue perspective relativiser' },
  { url: 'virage.html', titre_fr: 'Virage \u2014 flexibilité', titre_en: 'Switch \u2014 flexibility',
    desc_fr: 'Changer de règle en cours de route.', desc_en: 'Changing rules mid-task.',
    mots: 'virage flexibilite cognitive changer regle adaptation rigidite mentale switch task switching' },
  { url: 'dualtask.html', titre_fr: 'Double tâche', titre_en: 'Dual task',
    desc_fr: 'Occuper l\u2019attention sur deux fronts.', desc_en: 'Occupying attention on two fronts.',
    mots: 'double tache dualtask dual task deux taches attention charge cognitive occuper esprit craving concentration' },
  { url: 'antisabotage.html', titre_fr: 'Anti-sabotage', titre_en: 'Anti-sabotage',
    desc_fr: 'Repérer ses mécanismes et construire des parades.', desc_en: 'Spotting your patterns and building defences.',
    mots: 'anti sabotage antisabotage parade plan preparer anticiper mecanisme piege se proteger' },
  { url: 'lettre.html', titre_fr: 'Une lettre pour plus tard', titre_en: 'A letter for later',
    desc_fr: 'Écrire à froid, relire quand c\u2019est difficile.', desc_en: 'Write when clear, reread when it\u2019s hard.',
    mots: 'lettre ecrire ecrit message pour plus tard futur moi soi futur craving envie relire mots a moi meme journal intime' },

  /* ============ LEXIQUE \u2014 les 45 termes du guide ============ */
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 pharmacologie', titre_en: 'Glossary \u2014 pharmacology',
    desc_fr: 'Agoniste, antagoniste, récepteur, demi-vie, biodisponibilité, IMAO, métabolite.',
    desc_en: 'Agonist, antagonist, receptor, half-life, bioavailability, MAOI, metabolite.',
    mots: 'agoniste antagoniste recepteur recepteurs demi vie biodisponibilite imao metabolite metabolisme pharmacologie definition ca veut dire quoi' },
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 usage et dépendance', titre_en: 'Glossary \u2014 use and dependence',
    desc_fr: 'Tolérance, dépendance, craving, sevrage, redose.',
    desc_en: 'Tolerance, dependence, craving, withdrawal, redosing.',
    mots: 'tolerance dependance craving envie irrepressible sevrage manque redose redoser reprendre une dose accoutumance addiction definition' },
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 risques', titre_en: 'Glossary \u2014 risks',
    desc_fr: 'Surdose, dépression respiratoire, syndrome sérotoninergique, speedball, cocaéthylène, adultérant, bad trip, vasoconstriction, hyperthermie.',
    desc_en: 'Overdose, respiratory depression, serotonin syndrome, speedball, cocaethylene, adulterant, bad trip, vasoconstriction, hyperthermia.',
    mots: 'surdose overdose depression respiratoire syndrome serotoninergique speedball cocaethylene adulterant produit de coupe coupe bad trip vasoconstriction hyperthermie coup de chaleur risque risques' },
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 familles de produits', titre_en: 'Glossary \u2014 substance families',
    desc_fr: 'Dépresseur, stimulant, opioïde, psychédélique, dissociatif, empathogène, cathinone, cannabinoïde de synthèse, délirant.',
    desc_en: 'Depressant, stimulant, opioid, psychedelic, dissociative, empathogen, cathinone, synthetic cannabinoid, deliriant.',
    mots: 'depresseur depresseurs stimulant stimulants opioide psychedelique dissociatif empathogene entactogene cathinone cannabinoide de synthese delirant anticholinergique famille familles categorie classification' },
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 produits et marché', titre_en: 'Glossary \u2014 substances and market',
    desc_fr: 'Tranq, lean, nitazène, RC, NPS, fenêtre de détection.',
    desc_en: 'Tranq, lean, nitazene, RC, NPS, detection window.',
    mots: 'tranq xylazine lean purple drank codeine sirop nitazene rc research chemical nps nouveau produit de synthese nouvelles substances fenetre de detection marche' },
  { url: 'guide.html#lexique', titre_fr: 'Lexique \u2014 cerveau et attention', titre_en: 'Glossary \u2014 brain and attention',
    desc_fr: 'Mémoire de travail, urge surfing, effet Stroop, flexibilité cognitive, delay discounting, cohérence cardiaque, parasympathique, circuit de la récompense.',
    desc_en: 'Working memory, urge surfing, Stroop effect, cognitive flexibility, delay discounting, heart coherence, parasympathetic, reward circuit.',
    mots: 'memoire de travail urge surfing effet stroop stroop flexibilite cognitive delay discounting coherence cardiaque systeme parasympathique nerf vague circuit de la recompense dopamine cerveau neurosciences attention controle' }

];
