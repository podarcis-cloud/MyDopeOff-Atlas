/* compagnon.js — Le compagnon Atlas (guide du site).
   Auto-contenu : injecte son propre DOM + styles (charte Atlas, couleurs en fallback pour
   les pages sans tokens.css). 100 % local, pas de dépendance.
   Le compagnon tutoie toujours, ne se présente jamais comme une IA/assistant, agit comme
   un compagnon de réflexion. Il explique, encourage, questionne, valorise — jamais il ne
   remplace le contenu ni ne juge.
   Usage :
     MDCompagnon.render('#mount', { mood:'serenite', text:'…', action:{href,label} })
     MDCompagnon.phrase('encouragement') -> une phrase aléatoire pour cette humeur
   Expose window.MDCompagnon. Réutilise les 10 avatars extraits de la planche Atlas
   (dossier /avatars). Respecte prefers-reduced-motion. */
window.MDCompagnon = (function () {
  'use strict';

  /* Humeur -> { fichier avatar, accent (variable de palette tokens.css) } */
  var MOODS = {
    serenite:      { c: 'sauge' },
    respiration:   { c: 'fjord' },
    reflexion:     { c: 'ocre' },
    explication:   { c: 'terra' },
    motivation:    { c: 'rose' },
    bienveillance: { c: 'rose' },
    ecoute:        { c: 'sauge' },
    action:        { c: 'fjord' },
    projection:    { c: 'fjord' },
    encouragement: { c: 'ocre' }
  };

  var FALLBACK = { sauge: '#7A8F72', fjord: '#69889A', ocre: '#D5A84A', terra: '#C7765C', rose: '#CBA8A0' };
  var FALLBACK50 = { sauge: '#EEF1E9', fjord: '#EAF0F2', ocre: '#F6EFDD', terra: '#F6EAE3', rose: '#F4ECE9' };

  var PHRASES = {
    serenite: [
      'Prends un instant pour toi, là, maintenant.',
      'Tu n\u2019as rien à prouver. Être là suffit déjà.',
      'Respire. Tu es déjà en train d\u2019avancer.'
    ],
    respiration: [
      'Prends un instant pour respirer.',
      'Une pause, ça compte aussi comme un pas.',
      'Le souffle d\u2019abord, le reste suit.'
    ],
    reflexion: [
      'Tu as déjà des réponses. On les cherche ensemble ?',
      'Pas besoin de tout comprendre d\u2019un coup.',
      'Une question à la fois, c\u2019est très bien.'
    ],
    explication: [
      'Je t\u2019explique, à ton rythme, sans jargon.',
      'Comprendre, c\u2019est déjà avancer.',
      'On peut reprendre autant de fois que tu veux.'
    ],
    motivation: [
      'Tu es prêt·e, même si ça ne semble pas évident.',
      'L\u2019élan vient souvent après le premier pas.',
      'Chaque pas compte, même petit.'
    ],
    bienveillance: [
      'Sois aussi doux·ce avec toi qu\u2019avec un ami.',
      'Tu n\u2019as pas besoin d\u2019être parfait·e pour avancer.',
      'Prends soin de toi, un pas après l\u2019autre.'
    ],
    ecoute: [
      'Je suis là. Dis-moi ce qui se passe pour toi.',
      'Ce que tu ressens compte, sans jugement.',
      'Tu peux tout poser ici, à ton rythme.'
    ],
    action: [
      'Une action même petite crée le changement.',
      'Envie d\u2019écrire ou de planifier un pas ?',
      'On y va doucement, une chose à la fois.'
    ],
    projection: [
      'Comment tu imagines la suite pour toi ?',
      'Un futur souhaité se construit pas à pas.',
      'Ton futur toi te dira merci pour ce moment.'
    ],
    encouragement: [
      'Tu avances, et c\u2019est l\u2019essentiel.',
      'Bravo d\u2019être revenu·e aujourd\u2019hui.',
      'Continue comme tu es, à ton rythme.'
    ]
  };

  var INJECTED = false;
  function inject() {
    if (INJECTED) return; INJECTED = true;
    var css =
      '.mdc{display:flex;align-items:flex-start;gap:12px;font-family:var(--ui,Inter,system-ui,sans-serif)}' +
      '.mdc-av{flex:0 0 auto;width:56px;height:56px;border-radius:50%;overflow:hidden;' +
      'background:var(--mc50);border:1px solid var(--line,#E2DCD0)}' +
      '.mdc-av img{width:100%;height:100%;object-fit:cover;display:block;transform-origin:50% 65%;' +
      'animation:mdc-breathe 5.6s ease-in-out infinite}' +
      '.mdc-bub{position:relative;flex:1;min-width:0;background:var(--mc50);border-radius:16px 16px 16px 4px;' +
      'padding:11px 14px;color:var(--ink,#1F2B25)}' +
      '.mdc-bub p{margin:0;font-family:var(--content,"Atkinson Hyperlegible Next",sans-serif);' +
      'font-size:14.5px;line-height:1.45}' +
      '.mdc-cta{display:inline-flex;align-items:center;gap:4px;margin-top:7px;font-family:var(--ui,Inter,sans-serif);' +
      'font-weight:700;font-size:13px;color:var(--mc,#33463E);text-decoration:none}' +
      '.mdc-cta:hover{text-decoration:underline}' +
      '.mdc.sm .mdc-av{width:44px;height:44px}.mdc.sm .mdc-bub p{font-size:13.5px}' +
      '@keyframes mdc-breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.045)}}' +
      '@media (prefers-reduced-motion:reduce){.mdc-av img{animation:none}}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function phrase(mood) { return pick(PHRASES[mood] || PHRASES.serenite); }

  /* render(mount, opts) -> élément .mdc monté, ou null si mount introuvable.
     opts.mood      : une des clés MOODS (défaut 'serenite')
     opts.text      : texte custom (sinon phrase aléatoire de l'humeur)
     opts.action    : {href,label} lien optionnel sous la bulle
     opts.size      : 'sm' pour une variante compacte
     opts.base      : chemin du dossier avatars (défaut 'avatars/') */
  function render(mount, opts) {
    opts = opts || {};
    inject();
    var host = typeof mount === 'string' ? document.querySelector(mount) : mount;
    if (!host) return null;
    var mood = MOODS[opts.mood] ? opts.mood : 'serenite';
    var m = MOODS[mood];
    var text = opts.text || phrase(mood);
    var base = opts.base || 'avatars/';
    var mc = 'var(--' + m.c + ',' + (FALLBACK[m.c] || '#7A8F72') + ')';
    var mc50 = 'var(--' + m.c + '-50,' + (FALLBACK50[m.c] || '#EEF1E9') + ')';
    var cls = 'mdc' + (opts.size === 'sm' ? ' sm' : '');
    var html = '<div class="' + cls + '" style="--mc:' + mc + ';--mc50:' + mc50 + '">' +
      '<span class="mdc-av"><img src="' + base + mood + '.png" alt="" width="56" height="56" loading="lazy"></span>' +
      '<div class="mdc-bub"><p>' + esc(text) + '</p>' +
      (opts.action ? '<a class="mdc-cta" href="' + opts.action.href + '">' + esc(opts.action.label) + ' <span aria-hidden="true">\u2192</span></a>' : '') +
      '</div></div>';
    host.innerHTML = html;
    return host.querySelector('.mdc');
  }

  return { render: render, phrase: phrase, moods: Object.keys(MOODS) };
})();
