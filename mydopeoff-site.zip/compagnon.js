/* compagnon.js — Le compagnon Atlas (guide du site).
   Auto-contenu : injecte son propre DOM + styles (charte Atlas, couleurs en fallback pour
   les pages sans tokens.css). 100 % local, pas de dépendance.
   Le compagnon tutoie toujours, ne se présente jamais comme une IA/assistant, agit comme
   un compagnon de réflexion. Il explique, encourage, questionne, valorise — jamais il ne
   remplace le contenu ni ne juge.
   Usage :
     MDCompagnon.render('#mount', { mood:'serenite', text:'…', action:{href,label} })
     MDCompagnon.phrase('encouragement') -> une phrase aléatoire pour cette humeur
     MDCompagnon.pickMood(pool, clé) -> pioche un mood sans répéter celui d'avant (localStorage)
   Expose window.MDCompagnon. Réutilise les 10 avatars extraits de la planche Atlas
   (dossier /avatars). Respecte prefers-reduced-motion. */
window.MDCompagnon = (function () {
  'use strict';

  /* Bibliothèque officielle : 24 expressions (planches Atlas). Chaque humeur ->
     { c: teinte de palette de l'avatar }. Le nom de clé = nom du fichier /avatars/<clé>.png */
  var MOODS = {
    serenite:        { c: 'sauge' },
    respiration:     { c: 'fjord' },
    reflexion:       { c: 'sauge' },
    explication:     { c: 'ocre' },
    motivation:      { c: 'terra' },
    bienveillance:   { c: 'rose' },
    ecoute:          { c: 'sauge' },
    action:          { c: 'fjord' },
    projection:      { c: 'fjord' },
    encouragement:   { c: 'ocre' },
    pause:           { c: 'sauge' },
    celebration:     { c: 'rose' },
    curiosite:       { c: 'sauge' },
    concentration:   { c: 'fjord' },
    doute:           { c: 'terra' },
    depassement:     { c: 'ocre' },
    changement:      { c: 'rose' },
    'prise-de-recul':{ c: 'sauge' },
    gratitude:       { c: 'fjord' },
    'lacher-prise':  { c: 'rose' },
    decision:        { c: 'ocre' },
    energie:         { c: 'terra' },
    introspection:   { c: 'sauge' },
    espoir:          { c: 'fjord' },
    inspiration:     { c: 'terra' },
    clarification:   { c: 'sauge' },
    vigilance:       { c: 'ocre' },
    adaptation:      { c: 'fjord' },
    acceptation:     { c: 'rose' },
    ancrage:         { c: 'sauge' },
    'curiosite-active': { c: 'fjord' },
    'choix-eclaire': { c: 'ocre' },
    ressource:       { c: 'terra' },
    transmission:    { c: 'sauge' },
    resilience:      { c: 'ocre' },
    horizon:         { c: 'fjord' },
    tristesse:       { c: 'fjord' },
    colere:          { c: 'terra' },
    fatigue:         { c: 'sauge' },
    solitude:        { c: 'fjord' },
    vulnerabilite:   { c: 'rose' },
    fierte:          { c: 'ocre' },
    soulagement:     { c: 'sauge' },
    confiance:       { c: 'terra' },
    complicite:      { c: 'sauge' },
    emerveillement:  { c: 'fjord' },
    tendresse:       { c: 'rose' },
    impatience:      { c: 'ocre' },
    craving:         { c: 'terra' }
  };

  var FALLBACK = { sauge: '#7A8F72', fjord: '#69889A', ocre: '#D5A84A', terra: '#C7765C', rose: '#CBA8A0' };
  var FALLBACK50 = { sauge: '#EEF1E9', fjord: '#EAF0F2', ocre: '#F6EFDD', terra: '#F6EAE3', rose: '#F4ECE9' };

  /* Banque de phrases courtes par mood — ton décontracté, posé, jamais donneur de leçons
     (charte fixée en Phase 5). Consommée via phrase(mood), avec anti-répétition (pickMood). */
  var PHRASES = {
    serenite: ['Pas besoin de faire quoi que ce soit dans l\u2019immédiat.', 'Deux minutes de calme, ça compte aussi comme une action.', 'Rien ne presse, là, maintenant.'],
    respiration: ['Le souffle ralentit avant le reste — toujours dans cet ordre-là.', 'Une respiration plus lente, et le corps suit.', 'Ça ne coûte rien d\u2019essayer trois respirations, là, tout de suite.'],
    reflexion: ['Pas besoin d\u2019avoir la réponse tout de suite.', 'Une question qui reste ouverte, ce n\u2019est pas un échec.', 'Prends le temps que ça prend.'],
    explication: ['Je peux t\u2019expliquer, sans jargon, si ça t\u2019aide.', 'Comprendre ce qui se passe, c\u2019est déjà une forme de contrôle.', 'On peut reprendre ça autant de fois que nécessaire.'],
    motivation: ['Le plus dur, c\u2019est souvent de commencer — le reste suit.', 'Un petit pas compte autant qu\u2019un grand, question de mécanique.', 'T\u2019as déjà fait la partie difficile : tu es là.'],
    bienveillance: ['Sois un peu plus indulgent·e avec toi qu\u2019avec un inconnu, pour une fois.', 'Ce que tu traverses ne te définit pas.', 'Personne ne tient les comptes ici.'],
    ecoute: ['Dis ce que tu as à dire, j\u2019écoute.', 'Pas de bonne ou de mauvaise réponse ici.', 'Prends ton temps, rien ne t\u2019oblige à aller vite.'],
    action: ['Une petite action concrète, et le reste devient plus clair.', 'Écrire, planifier, bouger — le choix t\u2019appartient.', 'On avance d\u2019un cran, pas besoin de courir.'],
    projection: ['\u00c0 quoi ressemble la suite, pour toi ?', 'Le futur se construit un jour à la fois, pas d\u2019un coup.', 'Ton futur toi lira peut-être ça un jour.'],
    encouragement: ['T\u2019es revenu·e. Ça, en soi, c\u2019est déjà quelque chose.', 'Chaque passage ici compte, même les petits.', 'Continue comme ça — littéralement, comme ça, à ton rythme.'],
    pause: ['Une pause n\u2019est pas un abandon.', 'Le silence a aussi son utilité.', 'Rien ne t\u2019oblige à décider maintenant.'],
    celebration: ['Ça mérite d\u2019être savouré, pas juste coché.', 'Prends deux secondes pour reconnaître ce que tu viens de faire.', 'C\u2019est un vrai moment. Traite-le comme tel.'],
    curiosite: ['Et si on regardait ça d\u2019un peu plus près ?', 'Il y a souvent plus à découvrir qu\u2019il n\u2019y paraît.', 'La curiosité est un bon point de départ, ici comme ailleurs.'],
    concentration: ['Une chose à la fois — le reste peut attendre.', 'Se recentrer, ça se muscle, comme le reste.', 'L\u2019attention va où tu la diriges.'],
    doute: ['Douter ne veut pas dire reculer.', 'T\u2019as pas besoin d\u2019être sûr·e à 100 % pour continuer.', 'Le doute fait partie du chemin, pas un détour.'],
    depassement: ['T\u2019as tenu plus longtemps que tu ne le pensais, probablement.', 'Ce que tu traverses aujourd\u2019hui, tu le portes déjà un peu mieux qu\u2019hier.', 'Un cap de plus, à ta mesure.'],
    changement: ['Le changement se voit rarement d\u2019un coup — surtout de l\u2019intérieur.', 'Chaque ajustement, même minuscule, compte dans la durée.', 'Tu n\u2019es plus exactement la même personne qu\u2019il y a un mois. C\u2019est déjà ça.'],
    'prise-de-recul': ['Prendre du recul, c\u2019est déjà changer d\u2019angle.', 'Vu de plus loin, les choses paraissent parfois différentes.', 'Un peu de distance ne fait jamais de mal à une décision.'],
    gratitude: ['Il y a peut-être un petit truc à noter, aujourd\u2019hui, qui a fait du bien.', 'La gratitude se muscle aussi — à force de la chercher, on la trouve plus souvent.', 'Pas besoin d\u2019un grand événement pour que ça compte.'],
    'lacher-prise': ['Tout ne se contrôle pas — et ce n\u2019est pas grave.', 'Lâcher un peu de prise, ce n\u2019est pas abandonner.', 'Certaines choses avancent mieux quand on arrête de les serrer trop fort.'],
    decision: ['Une décision imparfaite reste souvent mieux qu\u2019aucune décision.', 'Tu peux changer d\u2019avis plus tard — ça reste un choix valable maintenant.', 'Chaque choix, même petit, entraîne le muscle.'],
    energie: ['Il y a de l\u2019élan, là — autant s\u2019en servir tant qu\u2019il est là.', 'L\u2019énergie du jour ne se garde pas pour demain.', 'Ça se sent, cet élan. Suis-le un peu.'],
    introspection: ['Se regarder d\u2019un peu plus près, sans complaisance ni sévérité.', 'Ce que tu ressens mérite d\u2019être observé, pas jugé.', 'Un instant pour vraiment se demander comment ça va, pas juste répondre par automatisme.'],
    espoir: ['Un jour comme celui-là compte plus qu\u2019on ne le pense sur le moment.', 'L\u2019espoir n\u2019a pas besoin d\u2019être immense pour être réel.', 'Continuer, même modestement, c\u2019est déjà une forme d\u2019espoir en action.'],
    tristesse: ['C\u2019est lourd, et ça n\u2019a pas besoin d\u2019être expliqué pour être vrai.', 'Certains jours pèsent plus que d\u2019autres, sans raison qu\u2019on puisse toujours nommer.', 'Être triste ici ne change rien à ce que tu vaux.'],
    colere: ['La colère dit quelque chose, même si le message est confus sur le moment.', 'Ça n\u2019a pas besoin de sortir tout de suite, ni de rester coincé.', 'Sentir la colère monter, ce n\u2019est pas pareil que la laisser décider pour toi.'],
    fatigue: ['La fatigue n\u2019est pas une faiblesse à corriger, juste un signal à écouter.', 'Un jour où faire moins suffit, ça compte aussi.', 'Se reposer n\u2019est pas reculer.'],
    solitude: ['Se sentir seul\u00b7e ici, à cet instant, ne veut pas dire l\u2019être pour de bon.', 'Personne d\u2019autre n\u2019a besoin d\u2019être là pour que ce moment compte.', 'La solitude qu\u2019on ressent et la solitude réelle ne se recouvrent pas toujours.'],
    vulnerabilite: ['Se montrer un peu fragile, ici, ne change rien à ta force ailleurs.', 'Ce n\u2019est pas rien d\u2019admettre que quelque chose est difficile.', 'La vulnérabilité n\u2019est pas une preuve d\u2019échec, juste une preuve d\u2019honnêteté.'],
    fierte: ['Ce que tu viens de faire, tu peux te l\u2019attribuer sans détour.', 'La fierté n\u2019a pas besoin d\u2019être partagée pour être réelle.', 'Prends un instant pour reconnaître ce que ça t\u2019a demandé.'],
    soulagement: ['Ce relâchement-là, tu l\u2019as gagné.', 'Le soulagement n\u2019a pas besoin d\u2019être justifié pour être ressenti pleinement.', 'Une tension de moins, même petite, ça se remarque dans le corps.'],
    confiance: ['Cette confiance-là, tu l\u2019as construite, pas reçue par hasard.', 'Se faire confiance un peu plus aujourd\u2019hui qu\u2019hier, ça se travaille comme le reste.', 'Avancer avec un peu plus d\u2019assurance ne veut pas dire ne plus douter jamais.'],
    complicite: ['Se sentir compris\u00b7e par quelqu\u2019un change la donne, presque toujours.', 'La complicité ne s\u2019explique pas toujours \u2014 elle se remarque.', 'Ce lien-là compte, même s\u2019il est difficile à mettre en mots.'],
    emerveillement: ['S\u2019étonner de quelque chose, c\u2019est déjà une façon de sortir de sa tête.', 'L\u2019émerveillement ne demande pas grand-chose pour arriver, juste un peu d\u2019attention.', 'Il y a souvent plus à voir qu\u2019on ne le pense, au premier regard.'],
    tendresse: ['Un peu de douceur envers toi-même, ça ne coûte rien à essayer.', 'La tendresse qu\u2019on garde pour les autres, tu la mérites aussi.', 'Ce geste doux envers toi-même compte, même s\u2019il paraît minuscule.'],
    impatience: ['L\u2019impatience dit que quelque chose compte pour toi \u2014 c\u2019est déjà une information.', 'Vouloir que ça aille plus vite ne veut pas dire que tu échoues à attendre.', 'Ce n\u2019est pas grave de trouver le temps long, là, maintenant.'],
    craving: ['Nommer l\u2019envie, c\u2019est déjà commencer à ne plus la subir en silence.', 'Une envie qui monte fort redescend aussi \u2014 presque toujours, en quelques minutes.', 'Ce que tu ressens là a un nom et une courbe connue : ça aide déjà un peu de le savoir.'],
    acceptation: ['Accepter où tu en es aujourd\u2019hui, ce n\u2019est pas abandonner l\u2019idée d\u2019avancer.', 'Il y a une différence entre se résigner et accepter \u2014 la seconde laisse la porte ouverte.', 'Ce moment, tel qu\u2019il est, ne demande pas d\u2019être différent pour compter.'],
    adaptation: ['Changer d\u2019approche en cours de route, ce n\u2019est pas un échec du plan de départ.', 'Ce qui marchait hier peut avoir besoin d\u2019un ajustement aujourd\u2019hui \u2014 c\u2019est normal.', 'S\u2019adapter, c\u2019est une compétence en soi, pas un aveu que le reste ne fonctionne pas.'],
    ancrage: ['Revenir à quelque chose de stable, ça se travaille \u2014 un point d\u2019appui à la fois.', 'Un ancrage n\u2019a pas besoin d\u2019être grand pour tenir : un souffle, un geste, un mot suffisent parfois.', 'Se sentir un peu plus stable qu\u2019il y a une minute, c\u2019est déjà quelque chose.'],
    'choix-eclaire': ['Un choix fait en connaissance de cause reste un choix, même s\u2019il n\u2019est pas parfait.', 'Avoir l\u2019info ne force pas une décision \u2014 ça la rend juste plus tienne.', 'Savoir ce que tu sais maintenant change forcément un peu la suite.'],
    'curiosite-active': ['Se lancer dans quelque chose de nouveau, même à contrecœur, c\u2019est déjà de la curiosité en action.', 'Essayer pour voir, plutôt que d\u2019attendre d\u2019être sûr\u00b7e \u2014 ça aussi, c\u2019est une forme de curiosité.', 'L\u2019envie de tester compte autant que l\u2019envie de comprendre.'],
    horizon: ['Regarder devant, même flou, c\u2019est différent de ne regarder nulle part.', 'Le chemin parcouru jusqu\u2019ici en dit long sur celui qui reste \u2014 sans qu\u2019il soit besoin de tout prévoir.', 'Avoir une direction ne veut pas dire connaître chaque étape.'],
    inspiration: ['Une idée qui donne envie d\u2019agir, ça vaut la peine de la garder en tête.', 'Ce qui t\u2019inspire aujourd\u2019hui n\u2019a pas besoin d\u2019être immédiatement utile pour compter.', 'Se sentir porté\u00b7e par quelque chose, même un instant, ça se remarque après coup.'],
    'lacher-prise': ['Lâcher prise, ce n\u2019est pas abandonner \u2014 c\u2019est arrêter de forcer ce qui résiste.', 'Desserrer un peu l\u2019étau, même sur un seul sujet, ça change la respiration du reste.', 'Ce que tu n\u2019as pas besoin de contrôler tout de suite peut attendre.'],
    pause: ['Une vraie pause n\u2019a pas besoin d\u2019être justifiée par ce qui vient après.', 'S\u2019arrêter un instant ne veut pas dire que tout s\u2019arrête avec.', 'Ce moment de calme t\u2019appartient, sans condition.'],
    resilience: ['Revenir après un coup dur, ce n\u2019est pas repartir de zéro \u2014 c\u2019est repartir d\u2019ici.', 'La résilience ne se voit pas dans l\u2019absence de chute, mais dans ce qui se passe après.', 'Continuer malgré un revers compte plus que l\u2019avoir évité.'],
    transmission: ['Ce que tu as compris pour toi peut aussi éclairer quelqu\u2019un d\u2019autre, un jour.', 'Partager ce qu\u2019on a appris, même modestement, a une valeur propre.', 'Expliquer quelque chose à quelqu\u2019un d\u2019autre, c\u2019est souvent le mieux comprendre soi-même.']
  };

  var INJECTED = false;
  function inject() {
    if (INJECTED) return; INJECTED = true;
    var css =
      '.mdc{display:flex;align-items:flex-start;gap:12px;font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mdc-av{flex:0 0 auto;width:56px;height:56px;border-radius:50%;overflow:hidden;' +
      'background:var(--mc50);border:1px solid var(--line,#E2DCD0)}' +
      '.mdc-av img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdc-bub{position:relative;flex:1;min-width:0;background:var(--mc50);border-radius:16px 16px 16px 4px;' +
      'padding:11px 14px;color:var(--ink,#1F2B25)}' +
      '.mdc-bub p{margin:0;font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);' +
      'font-size:var(--fs-sm,14.5px);line-height:var(--lh-normal,1.45)}' +
      '.mdc-cta{display:inline-flex;align-items:center;gap:4px;margin-top:7px;font-family:var(--font-technical,Inter,sans-serif);' +
      'font-weight:var(--w-bold,700);font-size:var(--fs-xs,13px);color:var(--mc,#33463E);text-decoration:none}' +
      '.mdc-cta:hover{text-decoration:underline}' +
      '.mdc-inline{color:var(--mc,var(--c-d));font-weight:var(--w-medium,600);text-decoration:underline;text-underline-offset:2px;cursor:pointer}' +
      '.mdc-inline:hover{opacity:.8}' +
      '.mdc.sm .mdc-av{width:44px;height:44px}.mdc.sm .mdc-bub p{font-size:var(--fs-sm,13.5px)}' +
      /* — avatar seul (à insérer dans une carte/modale existante) — */
      '.mdc-ava{display:block;flex:0 0 auto;width:60px;height:60px;border-radius:50%;overflow:hidden;margin:0 auto 10px;' +
      'background:var(--mc50);border:1px solid var(--line,#E2DCD0)}' +
      '.mdc-ava img{width:100%;height:100%;object-fit:cover;display:block}' +
      /* — toast : popup discrète, temporaire, ne pousse jamais le contenu — */
      '.mdc-toast-wrap{position:fixed;left:0;right:0;bottom:0;z-index:var(--z-toast,3500);display:flex;justify-content:center;' +
      'padding:0 14px calc(14px + env(safe-area-inset-bottom));pointer-events:none}' +
      '.mdc-toast{pointer-events:auto;display:flex;align-items:flex-start;gap:10px;max-width:420px;width:100%;' +
      'background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:16px;padding:10px 12px;' +
      'box-shadow:0 12px 30px rgba(31,43,37,.18);cursor:pointer;text-align:left;' +
      'animation:mdc-toast-in .35s ease-out}' +
      '.mdc-toast .mdc-av{width:40px;height:40px}' +
      '.mdc-toast p{margin:0;flex:1;font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);' +
      'font-size:var(--fs-sm,14px);line-height:var(--lh-normal,1.4);color:var(--ink,#1F2B25)}' +
      '.mdc-toast .mdc-x{flex:0 0 auto;border:none;background:none;color:var(--ink-2,#58635E);font-size:var(--fs-body,16px);' +
      'line-height:var(--lh-solid,1);padding:2px 0 0 4px;cursor:pointer}' +
      '@keyframes mdc-toast-in{from{transform:translateY(14px);opacity:0}to{transform:translateY(0);opacity:1}}' +
      '@media (prefers-reduced-motion:reduce){.mdc-toast{animation:none}}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function phrase(mood) { return pick(PHRASES[mood] || PHRASES.serenite); }
  function accent(mood) {
    var m = MOODS[mood] || MOODS.serenite;
    return { mc: 'var(--' + m.c + ',' + (FALLBACK[m.c] || '#7A8F72') + ')', mc50: 'var(--' + m.c + '-50,' + (FALLBACK50[m.c] || '#EEF1E9') + ')' };
  }

  /* avatarHTML(mood, size) -> balisage <span><img></span> seul, à insérer dans une carte/modale
     déjà existante (ex. exercise.js). N'ouvre rien, ne prend pas de place fixe. */
  var AVATAR_SIZE_PX = { sm: 40, md: 52, lg: 88 }; // repli si le token CSS n'est pas résolu (attribut HTML width/height, qui exige un nombre)
  function avatarHTML(mood, opts) {
    inject();
    opts = opts || {};
    mood = MOODS[mood] ? mood : 'serenite';
    var a = accent(mood);
    var base = opts.base || 'avatars/';
    var sizeOpt = opts.size;
    var named = typeof sizeOpt === 'string' && AVATAR_SIZE_PX[sizeOpt];
    var px = named ? AVATAR_SIZE_PX[sizeOpt] : (sizeOpt || 60);
    var cssSize = named ? 'var(--avatar-' + sizeOpt + ',' + px + 'px)' : px + 'px';
    return '<span class="mdc-ava" style="--mc:' + a.mc + ';--mc50:' + a.mc50 + ';width:' + cssSize + ';height:' + cssSize + '">' +
      '<img src="' + base + mood + '.png" alt="" width="' + px + '" height="' + px + '"></span>';
  }

  /* render(mount, opts) -> variante « bulle » complète, pour un usage ponctuel et rare
     (ex. intro d'une page). À éviter en usage permanent : préférer toast() ou avatarHTML().
     opts.links : liens inline optionnels [{token,label,onClick}]. Dans opts.text, chaque
     marqueur {token} est remplacé par un <a> souligné ; le reste du texte reste échappé. */
  function render(mount, opts) {
    opts = opts || {};
    inject();
    var host = typeof mount === 'string' ? document.querySelector(mount) : mount;
    if (!host) return null;
    var mood = MOODS[opts.mood] ? opts.mood : 'serenite';
    var text = opts.text || phrase(mood);
    var base = opts.base || 'avatars/';
    var a = accent(mood);
    var cls = 'mdc' + (opts.size === 'sm' ? ' sm' : '');
    var links = opts.links || [];
    // Corps de bulle : texte échappé, avec les {token} remplacés par des liens inline.
    var bodyHTML = esc(text).replace(/\{(\w+)\}/g, function (m, tok) {
      for (var i = 0; i < links.length; i++) {
        if (links[i].token === tok) {
          return '<a class="mdc-inline" href="#" data-mdc-link="' + tok + '">' + esc(links[i].label) + '</a>';
        }
      }
      return '';
    });
    var html = '<div class="' + cls + '" style="--mc:' + a.mc + ';--mc50:' + a.mc50 + '">' +
      '<span class="mdc-av"><img src="' + base + mood + '.png" alt="" width="56" height="56"></span>' +
      '<div class="mdc-bub"><p>' + bodyHTML + '</p>' +
      (opts.action ? '<a class="mdc-cta" href="' + opts.action.href + '">' + esc(opts.action.label) + ' <span aria-hidden="true">\u2192</span></a>' : '') +
      '</div></div>';
    host.innerHTML = html;
    // Brancher les actions des liens inline (pas de href réel : comportement contrôlé)
    links.forEach(function (lnk) {
      if (typeof lnk.onClick !== 'function') return;
      var a = host.querySelector('[data-mdc-link="' + lnk.token + '"]');
      if (a) a.addEventListener('click', function (e) { e.preventDefault(); lnk.onClick(e); });
    });
    return host.querySelector('.mdc');
  }

  /* toast(opts) -> popup discrète en bas d'écran, auto-disparaît (défaut 5.5s) ou au tap.
     Ne pousse jamais le contenu de la page (position fixed). Idéale pour un changement
     d'écran ou une arrivée sur une page. opts.key : si fourni, ne s'affiche qu'une fois
     par onglet/session (sessionStorage) pour rester discret et non répétitif. */
  var TOAST_TIMER = null;
  function toast(opts) {
    opts = opts || {};
    inject();
    if (opts.key) {
      try { if (sessionStorage.getItem('mdc_toast_' + opts.key)) return null; sessionStorage.setItem('mdc_toast_' + opts.key, '1'); } catch (e) { }
    }
    var old = document.querySelector('.mdc-toast-wrap'); if (old && old.parentNode) old.parentNode.removeChild(old);
    if (TOAST_TIMER) { clearTimeout(TOAST_TIMER); TOAST_TIMER = null; }
    var mood = MOODS[opts.mood] ? opts.mood : 'serenite';
    var text = opts.text || phrase(mood);
    var base = opts.base || 'avatars/';
    var a = accent(mood);
    var wrap = document.createElement('div'); wrap.className = 'mdc-toast-wrap';
    var t = document.createElement('div'); t.className = 'mdc-toast'; t.style.cssText = '--mc:' + a.mc + ';--mc50:' + a.mc50;
    t.setAttribute('role', 'status');
    t.innerHTML = '<span class="mdc-av"><img src="' + base + mood + '.png" alt="" width="40" height="40"></span>' +
      '<p>' + esc(text) + '</p><button type="button" class="mdc-x" aria-label="Fermer">\u2715</button>';
    function close() { if (wrap.parentNode) wrap.parentNode.removeChild(wrap); if (TOAST_TIMER) { clearTimeout(TOAST_TIMER); TOAST_TIMER = null; } }
    t.addEventListener('click', close);
    wrap.appendChild(t); document.body.appendChild(wrap);
    TOAST_TIMER = setTimeout(close, opts.duration || 5500);
    return t;
  }

  /* Pioche un mood dans un pool donné, sans répéter celui d'avant (par clé de contexte).
     Réutilisable partout où la mascotte apparaît souvent avec un mood jusqu'ici figé en dur
     (toasts d'accueil, jauge pré-jeu…) — évite que ce soit toujours le même visage. */
  function pickMood(pool, storageKey) {
    if (!pool || !pool.length) return 'serenite';
    if (pool.length === 1) return pool[0];
    var last = null;
    try { last = localStorage.getItem('mdMoodLast_' + storageKey); } catch (e) {}
    var candidates = last ? pool.filter(function (m) { return m !== last; }) : pool;
    if (!candidates.length) candidates = pool;
    var pick = candidates[Math.floor(Math.random() * candidates.length)];
    try { localStorage.setItem('mdMoodLast_' + storageKey, pick); } catch (e) {}
    return pick;
  }

  return { render: render, avatarHTML: avatarHTML, toast: toast, phrase: phrase, pickMood: pickMood, moods: Object.keys(MOODS) };
})();
