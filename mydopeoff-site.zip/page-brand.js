/* page-brand.js — initialise la page « Atlas — Référence visuelle ». */
(function(){
  function start(){ if (window.MDCore && MDCore.init) MDCore.init({ page:'brand', section:'accueil' }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
