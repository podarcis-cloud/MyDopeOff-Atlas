/* MyDope Off — page-bilans.js */
(function(){function r(f){document.readyState!=='loading'?f():document.addEventListener('DOMContentLoaded',f);}
r(function(){ if(window.MDCore) MDCore.init({page:'bilans',section:'bilan'}); });})();
