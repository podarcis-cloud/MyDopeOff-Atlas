/* MyDope Off — page-grossesse.js
   Seul besoin : MDCore.init(). Sans lui la page reste en français quelle que soit la
   langue choisie (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'grossesse', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
