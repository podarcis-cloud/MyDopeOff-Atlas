/* ============================================================================
   MyDope Off — new-substances.js
   Ajout : POPPERS + SOLVANTS / INHALANTS, avec interactions et classes.
   Sources (vérifié début 2026) :
   • Poppers (nitrites d'alkyle) : Cleveland Clinic ; case reports PMC de
     méthémoglobinémie (méthylène bleu) ; poppers maculopathy (isopropyl) ;
     danger MAJEUR avec PDE5 (sildénafil/tadalafil) → hypotension, AVC, décès.
   • Solvants/gaz : NIDA Inhalants — « sudden sniffing death syndrome »
     (arythmie pouvant survenir dès le 1er usage), hypoxie, atteintes chroniques.
   Détection : ces produits ne sont PAS ciblés par les tests de routine
   (voir detection-data.js, detectable:false).
   ============================================================================
   1) À COLLER dans psychochecker.html, parmi les autres addSub(...) :
      (FR = source de vérité ; les traductions vont dans fiches-i18n.js)
   ---------------------------------------------------------------------------- */

addSub("Poppers",["inhalant","vasodilatateur","nitrite"],"Faible",
  ["Bouffée de chaleur","Vasodilatation","Euphorie brève","Relâchement des sphincters"],
  {faible:"1 inhalation brève",modere:"quelques inhalations",fort:"inhalations répétées (risque accru)"},
  "Onset 10–30 s | Total 1–5 min",
  "Poppers : tête qui tourne et chaleur pendant 1–2 min. JAMAIS avaler (méthémoglobinémie quasi fatale), JAMAIS avec Viagra/Cialis.",
  "Nitrites d'alkyle (amyle/isobutyle/isopropyle). Vasodilatateur. Risques : méthémoglobinémie (surtout si ingéré — sang « chocolat », urgence/méthylène bleu), maculopathie (perte de vision, surtout isopropyl), mort subite. Mortel avec sildénafil/tadalafil.",
  ["poppers","rush","jungle juice","liquid gold","nitrite","amyl","amyle","nitrite d'alkyle"]);

addSub("Solvants volatils",["inhalant","solvant"],"Élevé",
  ["Ébriété","Euphorie","Désinhibition","Hallucinations","Vertiges"],
  {faible:"non quantifiable",modere:"non quantifiable",fort:"inhalation prolongée — danger vital"},
  "Onset secondes | Total 5–30 min",
  "Colle/toluène : ivresse rapide et brève. Risque de MORT SUBITE par arythmie dès la 1re fois. Atteintes cérébrales si usage répété.",
  "Toluène, trichloréthylène, colles, peintures. « Sudden sniffing death syndrome » (sensibilisation cardiaque aux catécholamines → arythmie fatale), hypoxie. Chronique : leuco-encéphalopathie, atteinte rénale/cognitive.",
  ["colle","toluène","toluene","solvant","trichloréthylène","sniff colle","white spirit"]);

addSub("Butane / gaz",["inhalant","gaz"],"Élevé",
  ["Ébriété brève","Euphorie","Étourdissement"],
  {faible:"non quantifiable",modere:"non quantifiable",fort:"inhalation directe — danger vital"},
  "Onset secondes | Total 1–5 min",
  "Gaz briquet/aérosols : effet très bref. Mort subite par arythmie, asphyxie, gelures des voies respiratoires (spray direct).",
  "Butane/propane/aérosols. « Sudden sniffing death syndrome », asphyxie par déplacement de l'oxygène, laryngospasme/gelures. Aucune marge de sécurité.",
  ["butane","propane","gaz briquet","gaz","aérosol","déodorant"]);

addSub("Éther diéthylique",["inhalant","éther","dépresseur"],"Modéré",
  ["Sédation","Ébriété","Analgésie","Perte de conscience"],
  {faible:"inhalation brève",modere:"inhalation modérée",fort:"perte de conscience rapide"},
  "Onset secondes–minutes | Total court",
  "Éther : sédation type anesthésie. Perte de conscience rapide, vomissements, dépression respiratoire. Extrêmement inflammable.",
  "Anesthésique volatil. Dépression respiratoire, inhalation = perte de conscience et fausse route. Très inflammable. Synergie dangereuse avec alcool/benzos/opioïdes.",
  ["éther","ether","diéthyléther","ether diéthylique"]);

/* ----------------------------------------------------------------------------
   2) À AJOUTER à la base d'interactions structurée (interactions-data.js / DB) :
      (poppers + sildénafil existait déjà ; on le re-tague proprement + ajouts)
   ---------------------------------------------------------------------------- */
window.MD_NEW_INTERACTIONS = [
  { a:"poppers", b:"sildénafil", severity:"danger",
    msg:"Poppers + Viagra/Cialis (PDE5) : double vasodilatation → chute de tension brutale, collapsus, AVC ou infarctus.",
    action:"Ne JAMAIS associer. Malaise/perte de connaissance : allonger jambes surélevées, appeler le 112/15." },
  { a:"poppers", b:"alcool", severity:"warn",
    msg:"Poppers + alcool : hypotension et étourdissements majorés, risque de chute/syncope.",
    action:"Éviter ; rester assis, s'hydrater." },
  { a:"solvants volatils", b:"alcool", severity:"danger",
    msg:"Solvants + alcool : dépression du SNC additionnée et sensibilisation cardiaque — arythmie/mort subite.",
    action:"Ne pas associer ; jamais seul·e." },
  { a:"butane / gaz", b:"alcool", severity:"danger",
    msg:"Gaz inhalé + alcool : risque d'arythmie fatale et d'asphyxie majoré.",
    action:"Ne pas associer." },
  { a:"éther diéthylique", b:"alcool", severity:"danger",
    msg:"Éther + alcool : dépression respiratoire et perte de conscience — fausse route.",
    action:"Ne pas associer ; PLS si somnolence, 112/15." }
];
// Branchement si le moteur est présent :
if (window.MDInteractions && window.MDInteractions.DB) {
  window.MD_NEW_INTERACTIONS.forEach(function (ix) {
    var a = ix.a.toLowerCase(), b = ix.b.toLowerCase();
    var dup = window.MDInteractions.DB.some(function (e) {
      return (e.a===a&&e.b===b)||(e.a===b&&e.b===a);
    });
    if (!dup) window.MDInteractions.DB.push({ a:a, b:b, severity:ix.severity, msg:ix.msg, action:ix.action });
  });
}

/* ----------------------------------------------------------------------------
   3) À AJOUTER à substance-classes.js (CLASSES) — classes pharmaco :
      Poppers n'est PAS un dépresseur du SNC : son risque clé (PDE5) est géré
      par la paire explicite ci-dessus, on ne lui force donc pas de classe
      trompeuse. Les solvants/éther SONT des dépresseurs du SNC.
   ---------------------------------------------------------------------------- */
window.MD_NEW_CLASSES = {
  "Poppers":            [],                 // risque cardiovasculaire spécifique (voir paires)
  "Solvants volatils":  ["dépresseur"],
  "Butane / gaz":       ["dépresseur"],
  "Éther diéthylique":  ["dépresseur"]
};
if (window.MD_SUBSTANCE_CLASSES) {
  Object.keys(window.MD_NEW_CLASSES).forEach(function (k) {
    window.MD_SUBSTANCE_CLASSES[k] = window.MD_NEW_CLASSES[k];
  });
}
