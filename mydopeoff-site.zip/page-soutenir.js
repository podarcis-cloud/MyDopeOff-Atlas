/* MyDope Off — page-soutenir.js
   Scripts inline de soutenir.html regroupés ici pour permettre une CSP stricte
   (script-src 'self'). Contenu inchangé, ordre d'origine préservé. */

const params = new URLSearchParams(location.search);
const userName = params.get('name')||'';
const userAge  = params.get('age')||'';
const userRegion = params.get('region')||'BE';
document.getElementById('back-btn').onclick = () => {
  location.href = (window.LUCIDE?LUCIDE.link('index.html'):'index.html'); return;
  history.back();
};

// Ko-fi amount selection
let selectedAmt = 5;
/* Délégation : les montants portent data-amt (converti depuis onclick inline pour
   permettre une CSP stricte). Un seul écouteur, posé sur le document. */
document.addEventListener('click', function(e){
  var el = e.target.closest ? e.target.closest('[data-amt]') : null;
  if (!el) return;
  var raw = el.getAttribute('data-amt');
  selectAmt(raw === '' ? null : parseInt(raw, 10), el);
});

function selectAmt(amt, btn) {
  document.querySelectorAll('.kofi-amt').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  selectedAmt = amt;
  document.getElementById('kofi-btn').href = 'https://ko-fi.com/lucidebypodarcis';
  if (window.LUCIDE) { _koLabel(); }
  else { document.getElementById('kofi-btn-label').textContent = (amt===null?'Soutenir sur Ko-fi →':'Soutenir · ' + amt + '€ sur Ko-fi'); }
}

/* Partage : ex-attribut onclick, converti en data-act pour la CSP stricte. */
document.addEventListener('click', function(e){
  var el = e.target.closest && e.target.closest('[data-act="share"]');
  if (el) shareApp();
});

function shareApp() {
  const url = 'https://podarcis-cloud.github.io/Crack-the-code-v6/';
  const text = ' MyDope Off — neurosciences pour la réduction des risques. Gratuit, sans pub, basé sur la science.';
  if (navigator.share) {
    navigator.share({ title:'MyDope Off', text, url }).catch(()=>{});
  } else {
    navigator.clipboard?.writeText(url)
      .then(() => alert('Lien copié !'))
      .catch(() => prompt('Lien :', url));
  }
}

// Wire nav links
(function(){
  try {
    const d = JSON.parse(localStorage.getItem('ctc_v6'));
    if (d && d.user && d.user.name) {
      const p='';
    }
  } catch(e) {}
})();
// Label du bouton Ko-fi traduit + re-traduit au changement de langue
function _koLabel(){
  var el=document.getElementById('kofi-btn-label'); if(!el||!window.LUCIDE) return;
  if(selectedAmt===null){ el.textContent = LUCIDE.t('sout.kofi_btn').replace(/·.*$/, '→'); }
  else { var base=LUCIDE.t('sout.kofi_btn'); el.textContent = base.replace(/\d+€/, selectedAmt+'€'); }
}

/* ---- bloc suivant ---- */

(function(){
  function apply(){
    if(!window.LUCIDE) return false;
    try{ LUCIDE.applyI18n(); }catch(e){}
    try{ LUCIDE.renderLangSelect(); }catch(e){}
    try{ _koLabel(); }catch(e){}
    return true;
  }
  if(!apply()){ var n=0, iv=setInterval(function(){ if(apply()||++n>50) clearInterval(iv); },50); }
  document.addEventListener('langchange', function(){ try{ LUCIDE.applyI18n(); _koLabel(); }catch(e){} });
})();

/* ---- bloc suivant ---- */

try{MDCore.init({page:'soutenir',section:'equilibre'});}catch(e){}
