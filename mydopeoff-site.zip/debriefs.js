/* debriefs.js — Banque de débriefs de fin d'exercice (voix mascotte).
   Ton : factuel avant d'être gentil, une pointe d'humour sec qui vise la situation
   (jamais la personne), jamais mièvre. On dit ce qui vient de se passer dans le
   corps/cerveau, puis on encourage — sans faire semblant que c'est facile.

   Chaque jeu a son pool (variété quotidienne, plusieurs mood différents).
   _default sert de filet pour tout exercice futur non encore répertorié ici :
   il suffit d'ajouter une clé du même nom que le 2e argument de MDExercise.after(type, …)
   pour lui donner ses propres phrases ; sans clé, _default s'applique automatiquement.

   Chaque entrée : { id, mood, lines:[...], why, lines_en:[...], why_en } — why/why_en
   optionnels (encart « Pour info »). lines_en/why_en : traduction anglaise, résolue par
   exercise.js/pickDebrief() selon la langue active ; sans ces champs, le français reste
   affiché dans les deux langues (filet de sécurité plutôt que planter).
   Expose window.MDDebriefs. */
window.MDDebriefs = {

  tetris: [
    { id:'t1', mood:'depassement', lines:['Ta mémoire visuospatiale vient de passer trois minutes à empiler des blocs plutôt qu\u2019à te repasser l\u2019envie en boucle.'], why:'Elle n\u2019a pas eu le choix, mais le résultat est le même : occupée ailleurs, elle ne pouvait pas faire les deux (paradigme Tetris, Oxford 2015).',
      lines_en:['Your visuospatial working memory just spent three minutes stacking blocks instead of replaying the craving on a loop.'], why_en:'It didn\u2019t have a choice, but the result is the same: busy elsewhere, it couldn\u2019t do both (Tetris paradigm, Oxford 2015).' },
    { id:'t2', mood:'celebration', lines:['Lignes complètes, esprit occupé : exactement le mécanisme qu\u2019on cherchait.'], why:'Le prochain craving n\u2019a qu\u2019à bien se tenir.',
      lines_en:['Lines cleared, mind occupied: exactly the mechanism we were after.'], why_en:'The next craving had better watch out.' },
    { id:'t3', mood:'curiosite', lines:['Des chercheurs d\u2019Oxford ont montré qu\u2019un simple Tetris fait baisser l\u2019intensité du craving en temps réel.'], why:'Tu viens de leur donner raison, sans même le faire exprès.',
      lines_en:['Oxford researchers showed that a simple game of Tetris lowers craving intensity in real time.'], why_en:'You just proved them right, without even trying to.' },
    { id:'t4', mood:'encouragement', lines:['Peu importe le score : ton cerveau a été occupé ailleurs pendant plusieurs minutes entières.'], why:'C\u2019était exactement ça, la mission.',
      lines_en:['The score doesn\u2019t matter: your brain was busy elsewhere for several whole minutes.'], why_en:'That was exactly the mission.' },
    { id:'t5', mood:'bienveillance', lines:['Grille pleine ou pas, tu es resté·e avec le jeu jusqu\u2019au bout.'], why:'Un jour difficile, c\u2019est déjà beaucoup.',
      lines_en:['Full grid or not, you stayed with the game until the end.'], why_en:'On a hard day, that\u2019s already a lot.' }
  ],

  maze: [
    { id:'m1', mood:'concentration', lines:['Tu viens de piloter une bille avec ton corps entier, niveau après niveau.'], why:'Ton attention n\u2019avait clairement pas le temps de penser à autre chose.',
      lines_en:['You just steered a ball with your whole body, level after level.'], why_en:'Your attention clearly didn\u2019t have time to think about anything else.' },
    { id:'m2', mood:'depassement', lines:['Cervelet et cortex pariétal ont bossé dur pour éviter les murs.'], why:'Belle coordination — littéralement.',
      lines_en:['Cerebellum and parietal cortex worked hard to avoid the walls.'], why_en:'Nice coordination — literally.' },
    { id:'m3', mood:'celebration', lines:['Bille en poche, niveau après niveau.'], why:'Ton envie, elle, est restée coincée dans le labyrinthe.',
      lines_en:['Ball in the bag, level after level.'], why_en:'Your craving, meanwhile, stayed stuck in the maze.' },
    { id:'m4', mood:'curiosite', lines:['Incliner un téléphone pour guider une bille sollicite le même système que garder l\u2019équilibre à vélo.'], why:'Le corps a une mémoire que le mental n\u2019a pas toujours.',
      lines_en:['Tilting a phone to guide a ball uses the same system as keeping your balance on a bike.'], why_en:'The body has a memory that the mind doesn\u2019t always have.' },
    { id:'m5', mood:'bienveillance', lines:['Peu importe jusqu\u2019où tu es allé·e : ton attention est restée sur un geste précis, pas sur le manque.'], why:'C\u2019est tout ce qui comptait ici.',
      lines_en:['However far you got: your attention stayed on a precise gesture, not on the craving.'], why_en:'That\u2019s all that mattered here.' },
    { id:'m6', mood:'serenite', lines:['Chaque virage évité, chaque mur contourné — l\u2019attention est restée sur un geste concret, pas sur le manque.'],
      lines_en:['Every turn avoided, every wall skirted — attention stayed on a concrete gesture, not on the craving.'] }
  ],

  surf: [
    { id:'s1', mood:'depassement', lines:['Tu viens de rester debout sur une vague d\u2019envie sans lui céder un centimètre.'], why:'Marlatt appelait ça l\u2019urge surfing ; toi, tu viens de le vivre pour de vrai.',
      lines_en:['You just stayed standing on a wave of craving without giving it an inch.'], why_en:'Marlatt called this urge surfing; you just lived it for real.' },
    { id:'s2', mood:'celebration', lines:['La vague est montée, elle a culminé, elle est redescendue — et toi, tu es toujours là.'], why:'C\u2019est tout le principe, et ça vient de marcher.',
      lines_en:['The wave rose, it peaked, it fell back down — and you\u2019re still here.'], why_en:'That\u2019s the whole principle, and it just worked.' },
    { id:'s3', mood:'curiosite', lines:['Une envie dépasse rarement vingt minutes à son intensité maximale.'], why:'Tu viens d\u2019en surfer une entière sans bouger d\u2019un pouce.',
      lines_en:['A craving rarely lasts more than twenty minutes at its peak intensity.'], why_en:'You just surfed one entirely without moving an inch.' },
    { id:'s4', mood:'encouragement', lines:['Rester avec une sensation inconfortable sans agir dessus, c\u2019est un vrai muscle.'], why:'Tu viens de l\u2019entraîner.',
      lines_en:['Staying with an uncomfortable sensation without acting on it is a real muscle.'], why_en:'You just trained it.' },
    { id:'s5', mood:'bienveillance', lines:['La vague était haute aujourd\u2019hui. Tu es quand même resté·e dessus jusqu\u2019au bout.'], why:'Ça compte double.',
      lines_en:['The wave was high today. You still stayed on it until the end.'], why_en:'That counts double.' }
  ],

  breathe: [
    { id:'b1', mood:'serenite', lines:['Six respirations par minute, nerf vague activé, système nerveux calmé.'], why:'Rien de magique : juste de la physiologie qui fait son travail (cohérence cardiaque).',
      lines_en:['Six breaths per minute, vagus nerve activated, nervous system calmed.'], why_en:'Nothing magic: just physiology doing its job (cardiac coherence).' },
    { id:'b2', mood:'respiration', lines:['Ton corps vient d\u2019envoyer un signal de calme à ton cerveau, juste en respirant plus lentement.'], why:'Le plus vieux réflexe du monde, toujours le plus fiable.',
      lines_en:['Your body just sent a calm signal to your brain, just by breathing more slowly.'], why_en:'The oldest reflex in the book, still the most reliable.' },
    { id:'b3', mood:'curiosite', lines:['La cohérence cardiaque n\u2019a rien d\u2019ésotérique : c\u2019est mesurable, reproductible.'], why:'Et tu viens de la produire.',
      lines_en:['Cardiac coherence isn\u2019t remotely esoteric: it\u2019s measurable, reproducible.'], why_en:'And you just produced it.' },
    { id:'b4', mood:'celebration', lines:['Tu as suivi le rythme jusqu\u2019au bout sans lâcher l\u2019orbe des yeux.'], why:'Ton système parasympathique te remercie, probablement en silence.',
      lines_en:['You followed the rhythm all the way through without taking your eyes off the orb.'], why_en:'Your parasympathetic system thanks you, probably in silence.' },
    { id:'b5', mood:'bienveillance', lines:['Même un souffle un peu irrégulier compte.'], why:'L\u2019essentiel, c\u2019est d\u2019avoir pris ces quelques minutes pour toi.',
      lines_en:['Even a slightly irregular breath counts.'], why_en:'What matters is having taken these few minutes for yourself.' },
    { id:'b6', mood:'pause', lines:['Ces quelques minutes n\u2019ont rien produit de visible \u2014 et c\u2019est exactement le but.'], why:'Une pause qui doit se justifier par un résultat n\u2019en est plus vraiment une.',
      lines_en:['These few minutes produced nothing visible \u2014 and that\u2019s exactly the point.'], why_en:'A break that has to justify itself with a result isn\u2019t really a break anymore.' },
    { id:'b7', mood:'ancrage', lines:['Un souffle plus lent, un rythme qui redevient tien : c\u2019est un point d\u2019appui simple, mais un vrai.'], why:'Pas besoin d\u2019un grand geste pour se sentir un peu plus stable qu\u2019avant de commencer.',
      lines_en:['A slower breath, a rhythm that\u2019s yours again: it\u2019s a simple foothold, but a real one.'], why_en:'No need for a big gesture to feel a little more stable than before you started.' }
  ],

  echo: [
    { id:'e1', mood:'concentration', lines:['Tu viens de retenir puis restituer une séquence de plus en plus longue.'], why:'C\u2019est la même mémoire de travail qui aide à garder un objectif en tête face à une impulsion.',
      lines_en:['You just remembered then reproduced an increasingly long sequence.'], why_en:'That\u2019s the same working memory that helps keep a goal in mind when facing an impulse.' },
    { id:'e2', mood:'celebration', lines:['Suite retenue, couleur après couleur.'], why:'Ta mémoire de travail vient de faire un vrai sprint.',
      lines_en:['Sequence remembered, colour after colour.'], why_en:'Your working memory just ran a real sprint.' },
    { id:'e3', mood:'curiosite', lines:['Se souvenir d\u2019une séquence et la restituer sollicite le même circuit que résister à une envie sur la durée.'],
      lines_en:['Remembering a sequence and reproducing it uses the same circuit as resisting a craving over time.'] },
    { id:'e4', mood:'bienveillance', lines:['Peu importe jusqu\u2019où tu es allé·e : ton attention est restée sur la séquence.'], why:'C\u2019était exactement le but.',
      lines_en:['However far you got: your attention stayed on the sequence.'], why_en:'That was exactly the point.' },
    { id:'e5', mood:'encouragement', lines:['Se souvenir d\u2019une couleur à la fois, sans se presser — c\u2019est déjà tenir le fil.'],
      lines_en:['Remembering one colour at a time, without rushing — that\u2019s already holding the thread.'] }
  ],
  braise: [
    { id:'br1', mood:'motivation', lines:['Tu viens d\u2019anticiper, d\u2019agir, puis de savourer un vrai petit plaisir — pas juste d\u2019y penser.'], why:'C\u2019est exactement le circuit que le Positive Affect Treatment cherche à réentraîner.',
      lines_en:['You just anticipated, acted, then savoured a real small pleasure — not just thought about it.'], why_en:'That\u2019s exactly the circuit Positive Affect Treatment aims to retrain.' },
    { id:'br2', mood:'celebration', lines:['Une braise de plus dans ta carte des plaisirs.'], why:'Chaque fois compte, même les petites.',
      lines_en:['One more ember on your pleasure map.'], why_en:'Every time counts, even the small ones.' },
    { id:'br3', mood:'curiosite', lines:['La dopamine gouverne surtout la motivation vers la récompense, pas le plaisir lui-même.'], why:'Tu viens de nourrir les deux, dans l\u2019ordre.',
      lines_en:['Dopamine mostly governs motivation toward reward, not pleasure itself.'], why_en:'You just fed both, in the right order.' },
    { id:'br4', mood:'bienveillance', lines:['Prendre 30 secondes pour savourer quelque chose, sans se presser vers la suite.'], why:'C\u2019est plus rare, et plus utile, qu\u2019il n\u2019y paraît.',
      lines_en:['Taking 30 seconds to savour something, without rushing to what\u2019s next.'], why_en:'That\u2019s rarer, and more useful, than it seems.' },
    { id:'br5', mood:'serenite', lines:['Un tout petit plaisir remarqué, sans le laisser filer trop vite — ça compte, même discret.'],
      lines_en:['A tiny pleasure noticed, without letting it slip by too fast — it counts, even a quiet one.'] }
  ],
  filtre: [
    { id:'f1', mood:'depassement', lines:['Vingt essais à répondre à l\u2019encre plutôt qu\u2019au mot lu.'], why:'Filtrer un automatisme pour en suivre un autre : c\u2019est exactement le muscle utile ici (effet Stroop).',
      lines_en:['Twenty trials responding to the ink rather than the word you read.'], why_en:'Filtering out one automatism to follow another: that\u2019s exactly the useful muscle here (Stroop effect).' },
    { id:'f2', mood:'celebration', perfBand:'high', lines:['Ton contrôle attentionnel vient de passer vingt tours sans céder à la lecture automatique.'],
      lines_en:['Your attentional control just went twenty rounds without giving in to automatic reading.'] },
    { id:'f3', mood:'curiosite', lines:['Lire est presque impossible à désactiver — répondre à la couleur demande un vrai effort de filtrage.'], why:'C\u2019est ce même effort qui aide à ne pas suivre un automatisme de consommation.',
      lines_en:['Reading is almost impossible to switch off — responding to the colour takes real filtering effort.'], why_en:'That\u2019s the same effort that helps you avoid following a habitual use pattern.' },
    { id:'f4', mood:'bienveillance', perfBand:'mid', lines:['Quelques erreurs sur vingt essais, ça fait partie du jeu.'], why:'Le but n\u2019était pas la perfection.',
      lines_en:['A few mistakes out of twenty trials is part of the game.'], why_en:'The goal was never perfection.' },
    { id:'f5', mood:'encouragement', lines:['Vingt essais, avec ou sans erreurs — le seul fait de rester dessus a occupé l\u2019esprit ailleurs.'],
      lines_en:['Twenty trials, mistakes or not — the simple fact of staying with it kept the mind busy elsewhere.'] },
    { id:'f6', mood:'bienveillance', perfBand:'low', lines:['Cette manche a été difficile à tenir, et c\u2019est très bien ainsi.'], why:'Le réflexe de lecture est l\u2019un des automatismes les plus increvables du cerveau humain \u2014 lui résister ne devient jamais complètement facile, même après beaucoup d\u2019entraînement.',
      lines_en:['This round was hard to hold onto, and that\u2019s perfectly fine.'], why_en:'The reading reflex is one of the most stubborn automatisms in the human brain \u2014 resisting it never becomes completely easy, even after a lot of practice.' }
  ],
  patience: [
    { id:'p1', mood:'prise-de-recul', lines:['Tu as laissé au moins une graine grandir au lieu de la cueillir tout de suite.'], why:'Préférer une récompense plus tard à une plus petite maintenant, ça s\u2019entraîne — c\u2019est exactement ce que tu viens de faire.',
      lines_en:['You let at least one seed grow instead of picking it right away.'], why_en:'Preferring a later reward over a smaller one now is trainable — that\u2019s exactly what you just did.' },
    { id:'p2', mood:'celebration', lines:['Six graines, et tu as tenu la distance.'], why:'Le delay discounting recule un peu à chaque fois que tu résistes.',
      lines_en:['Six seeds, and you went the distance.'], why_en:'Delay discounting retreats a little every time you resist.' },
    { id:'p3', mood:'curiosite', lines:['Préférer le petit fruit immédiat au grand fruit plus tard est un moteur central de l\u2019addiction.'], why:'Chaque graine où tu attends l\u2019affaiblit un peu.',
      lines_en:['Preferring the small immediate fruit over the bigger later one is a central driver of addiction.'], why_en:'Every seed where you wait weakens it a little.' },
    { id:'p4', mood:'bienveillance', lines:['Même si tu as cueilli tôt cette fois, tu as joué le jeu jusqu\u2019au bout.'],
      lines_en:['Even if you picked early this time, you played the game all the way through.'] },
    { id:'p5', mood:'serenite', lines:['Attendre, même un peu, même une seule graine — c\u2019est déjà un pas dans l\u2019autre sens.'],
      lines_en:['Waiting, even a little, even for a single seed — that\u2019s already a step in the other direction.'] }
  ],
  virage: [
    { id:'v1', mood:'concentration', lines:['Les règles ont changé plusieurs fois sans prévenir, et tu as suivi le virage.'], why:'C\u2019est la flexibilité cognitive — l\u2019inverse de la rigidité qui nourrit les automatismes de conso.',
      lines_en:['The rules changed several times without warning, and you followed the switch.'], why_en:'That\u2019s cognitive flexibility — the opposite of the rigidity that feeds habitual use patterns.' },
    { id:'v2', mood:'celebration', lines:['Changement de règle après changement de règle, tu t\u2019es adapté·e à chaque fois.'],
      lines_en:['Rule change after rule change, you adapted every time.'] },
    { id:'v3', mood:'curiosite', lines:['La rigidité mentale nourrit les rituels.'], why:'Savoir changer de cap, comme tu viens de le faire, aide à en sortir.',
      lines_en:['Mental rigidity feeds rituals.'], why_en:'Knowing how to change course, like you just did, helps you break free of them.' },
    { id:'v4', mood:'bienveillance', lines:['Quelques ratés sur un changement de règle surprise, c\u2019est normal.'], why:'L\u2019important, c\u2019est d\u2019avoir suivi le mouvement.',
      lines_en:['A few misses on a surprise rule change is normal.'], why_en:'What matters is having followed the shift.' },
    { id:'v5', mood:'encouragement', lines:['Suivre les changements de règle, même imparfaitement, montre que l\u2019esprit reste souple.'],
      lines_en:['Following the rule changes, even imperfectly, shows the mind stays flexible.'] }
  ],
  inhib: [
    { id:'in1', mood:'concentration', lines:['Agir vite, ou se retenir — ton cerveau vient d\u2019arbitrer ça encore et encore, en une fraction de seconde à chaque fois.'], why:'C\u2019est exactement le même arbitrage qu\u2019entre pilote automatique et pause volontaire face à une envie.',
      lines_en:['Act fast, or hold back — your brain just made that call over and over, in a split second each time.'], why_en:'That\u2019s exactly the same call between autopilot and a deliberate pause when facing a craving.' },
    { id:'in2', mood:'celebration', lines:['Le frein a répondu présent, essai après essai.'],
      lines_en:['The brake showed up, trial after trial.'] },
    { id:'in3', mood:'curiosite', lines:['Retenir un geste déjà lancé sollicite un circuit cérébral différent de celui qui l\u2019a déclenché.'], why:'C\u2019est ce même circuit qui s\u2019active quand tu résistes à une impulsion.',
      lines_en:['Holding back a gesture already in motion uses a different brain circuit than the one that triggered it.'], why_en:'That\u2019s the same circuit that activates when you resist an impulse.' },
    { id:'in4', mood:'bienveillance', lines:['Quelques ratés sur un signal rapide, c\u2019est le principe même de l\u2019exercice.'], why:'Le frein se muscle justement en étant testé à sa limite.',
      lines_en:['A few misses on a fast signal is the whole point of the exercise.'], why_en:'The brake gets stronger precisely by being tested at its limit.' },
    { id:'in5', mood:'serenite', lines:['Le frein qui répond, même une fois sur deux, c\u2019est déjà un frein qui fonctionne.'],
      lines_en:['A brake that responds, even half the time, is already a brake that works.'] }
  ],
  dualtask: [
    { id:'dt1', mood:'concentration', lines:['Un rond à guetter, un compteur à surveiller — deux attentions tenues en même temps, sans en lâcher aucune.'], why:'C\u2019est le même partage de ressources mentales qui aide à garder un objectif en tête tout en gérant ce qui se passe autour.',
      lines_en:['A circle to watch for, a counter to keep an eye on — two attentions held at once, without dropping either.'], why_en:'That\u2019s the same sharing of mental resources that helps keep a goal in mind while handling what\u2019s going on around you.' },
    { id:'dt2', mood:'celebration', lines:['Les deux tâches ont tourné ensemble, et tu n\u2019as lâché ni l\u2019une ni l\u2019autre.'],
      lines_en:['Both tasks ran together, and you didn\u2019t drop either one.'] },
    { id:'dt3', mood:'curiosite', lines:['Le cerveau ne fait jamais vraiment deux choses « en même temps » — il bascule très vite entre les deux, et ce basculement a un coût mesurable.'], why:'Plus ce coût baisse avec l\u2019entraînement, plus la charge mentale du quotidien pèse légèrement moins.',
      lines_en:['The brain never truly does two things "at once" — it switches very fast between them, and that switching has a measurable cost.'], why_en:'The more that cost drops with practice, the lighter everyday mental load feels.' },
    { id:'dt4', mood:'bienveillance', lines:['Une des deux tâches a pris le dessus sur l\u2019autre, et c\u2019est exactement ce que l\u2019exercice teste.'], why:'Diviser son attention sans rien perdre, ça se muscle progressivement.',
      lines_en:['One of the two tasks took over the other, and that\u2019s exactly what the exercise tests.'], why_en:'Dividing your attention without losing anything builds up gradually.' },
    { id:'dt5', mood:'encouragement', lines:['Deux choses à la fois, dans un moment où l\u2019attention est déjà sollicitée ailleurs — le simple fait de s\u2019y être mis compte.'], why:'Revenir à un exercice structuré, même bref, aide à retrouver un point d\u2019appui.',
      lines_en:['Two things at once, at a moment when attention is already pulled elsewhere — the simple fact of showing up counts.'], why_en:'Coming back to a structured exercise, even briefly, helps you find a foothold again.' },
    { id:'dt6', mood:'serenite', lines:['Pas besoin d\u2019avoir parfaitement tout suivi. Le geste de recentrer l\u2019attention, répété, est déjà ce qui muscle la suite.'],
      lines_en:['No need to have tracked everything perfectly. The repeated gesture of refocusing attention is already what builds the rest.'] }
  ],
  elan: [
    { id:'el1', mood:'action', lines:['Repousser d\u2019un geste, attirer de l\u2019autre — ton corps vient de désapprendre un réflexe, pas juste ta tête.'], why:'C\u2019est exactement ce que ciblent les entraînements du biais d\u2019approche : l\u2019automatisme moteur se modifie par la répétition du geste, pas par la seule réflexion.',
      lines_en:['Pushing away with one gesture, pulling in with the other — your body just unlearned a reflex, not just your head.'], why_en:'That\u2019s exactly what approach-bias training targets: the motor automatism changes through repeating the gesture, not through thinking alone.' },
    { id:'el2', mood:'celebration', lines:['Les impulsions repoussées, les valeurs attirées — le geste a fait ce qu\u2019il fallait, essai après essai.'],
      lines_en:['Impulses pushed away, values pulled in — the gesture did what it needed to, trial after trial.'] },
    { id:'el3', mood:'curiosite', lines:['Le cerveau d\u2019une personne concernée par une addiction \u00ab rapproche \u00bb plus vite, presque malgré elle, ce qui évoque le manque.'], why:'Ce réflexe se mesure — et surtout, il se rentraîne dans l\u2019autre sens, ce que tu viens de faire.',
      lines_en:['The brain of someone affected by addiction "pulls closer" faster, almost against its will, anything that evokes the craving.'], why_en:'This reflex can be measured — and, more importantly, retrained in the other direction, which is exactly what you just did.' },
    { id:'el4', mood:'bienveillance', lines:['Quelques gestes dans le mauvais sens, ça fait partie de l\u2019exercice.'], why:'Le réflexe qu\u2019on veut affaiblir est justement celui qui va vite — le contrer prend du temps.',
      lines_en:['A few gestures in the wrong direction are part of the exercise.'], why_en:'The reflex we\u2019re trying to weaken is precisely the fast one — countering it takes time.' },
    { id:'el5', mood:'serenite', lines:['Un geste répété dans le bon sens, même modeste, laisse une trace motrice que la seule réflexion ne laisse pas.'], why:'C\u2019est tout l\u2019intérêt d\u2019un entraînement du biais d\u2019approche : le corps apprend, pas seulement la tête.',
      lines_en:['A gesture repeated in the right direction, even a modest one, leaves a motor trace that thinking alone doesn\u2019t.'], why_en:'That\u2019s the whole point of approach-bias training: the body learns, not just the head.' }
  ],

  antisabotage: [
    { id:'as1', mood:'reflexion', lines:['Tu viens de nommer un schéma qui, la plupart du temps, reste invisible — repéré seulement après coup, s\u2019il l\u2019est.'], why:'Voir venir un déclencheur avant qu\u2019il agisse est ce qui distingue une rechute qu\u2019on subit d\u2019un écart qu\u2019on traverse.',
      lines_en:['You just named a pattern that, most of the time, stays invisible — spotted only after the fact, if at all.'], why_en:'Seeing a trigger coming before it acts is what separates a relapse you endure from a slip you move through.' },
    { id:'as2', mood:'celebration', lines:['Ton plan existe maintenant, écrit noir sur blanc, prêt avant même que le signal arrive.'], why:'La volonté est la moins disponible pile au moment où on en aurait le plus besoin — c\u2019est pour ça qu\u2019on prépare la réponse à froid.',
      lines_en:['Your plan exists now, written down in black and white, ready before the signal even arrives.'], why_en:'Willpower is least available exactly when you\u2019d need it most — that\u2019s why the response gets prepared in advance, with a clear head.' },
    { id:'as3', mood:'curiosite', lines:['L\u2019auto-sabotage n\u2019est presque jamais un manque de volonté : c\u2019est un vieux réflexe de protection qui se déclenche au mauvais moment.'], why:'Le débusquer une fois le rend nettement plus facile à repérer la fois suivante.',
      lines_en:['Self-sabotage is almost never a lack of willpower: it\u2019s an old protective reflex firing at the wrong moment.'], why_en:'Catching it once makes it noticeably easier to spot the next time.' },
    { id:'as4', mood:'bienveillance', lines:['Regarder d\u2019aussi près la façon dont on peut se freiner soi-même demande une vraie honnêteté.'], why:'Tu viens de la pratiquer, sans te juger au passage — c\u2019est la partie la plus difficile de l\u2019exercice.',
      lines_en:['Looking this closely at how you can hold yourself back takes real honesty.'], why_en:'You just practised it, without judging yourself along the way — that\u2019s the hardest part of the exercise.' },
    { id:'as5', mood:'encouragement', lines:['Le signal est repéré, la réponse est prête. La prochaine fois, ce sera un réflexe de plus à disposition, pas une improvisation.'],
      lines_en:['The signal is spotted, the response is ready. Next time, it\u2019ll be one more reflex available, not an improvisation.'] },
    { id:'as6', mood:'resilience', lines:['Ce schéma a peut-être joué contre toi plusieurs fois avant aujourd\u2019hui \u2014 ça ne change rien à ce que tu viens d\u2019en faire.'], why:'Repérer un vieux réflexe après coup compte autant que de le voir venir à l\u2019avance : les deux réduisent sa prise la fois suivante.',
      lines_en:['This pattern may have worked against you several times before today \u2014 that changes nothing about what you just did with it.'], why_en:'Spotting an old reflex after the fact counts just as much as seeing it coming in advance: both loosen its grip the next time around.' }
  ],

  /* Filet générique : tout jeu/exercice futur sans clé dédiée reçoit ce pool tel quel,
     sans aucune modification de code — juste ajouter une clé du même nom pour se spécialiser. */
  _default: [
    { id:'d1', mood:'encouragement', lines:['Séance terminée. Ce qui vient de se passer dans ta tête compte plus que ce qui s\u2019est passé à l\u2019écran.'],
      lines_en:['Session complete. What just happened in your head matters more than what happened on screen.'] },
    { id:'d2', mood:'celebration', lines:['Tu es allé·e au bout de l\u2019exercice.'], why:'Le simple fait d\u2019avoir commencé était déjà la partie la plus dure.',
      lines_en:['You made it through to the end of the exercise.'], why_en:'The simple fact of having started was already the hardest part.' },
    { id:'d3', mood:'curiosite', lines:['Chaque exercice ici vise la même chose : occuper ton esprit ailleurs, le temps qu\u2019une envie retombe.'], why:'Celui-ci ne fait pas exception.',
      lines_en:['Every exercise here aims at the same thing: keeping your mind busy elsewhere while a craving fades.'], why_en:'This one is no exception.' },
    { id:'d4', mood:'depassement', lines:['Peu importe le détail : tu viens de tenir un moment entier sans céder au pilote automatique.'],
      lines_en:['Never mind the details: you just held a whole moment without giving in to autopilot.'] },
    { id:'d5', mood:'bienveillance', lines:['Pas besoin d\u2019avoir été parfait·e.'], why:'Tu as été présent·e, et c\u2019est exactement ce qu\u2019on te demandait.',
      lines_en:['No need to have been perfect.'], why_en:'You showed up, and that\u2019s exactly what was being asked of you.' },
    { id:'d6', mood:'reflexion', lines:['Tu peux refaire cet exercice demain, et après-demain.'], why:'C\u2019est en se répétant qu\u2019un réflexe finit par devenir automatique.',
      lines_en:['You can do this exercise again tomorrow, and the day after.'], why_en:'It\u2019s through repetition that a reflex eventually becomes automatic.' }
  ]
};
