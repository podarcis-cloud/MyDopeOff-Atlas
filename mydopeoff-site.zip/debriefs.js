/* debriefs.js — Banque de débriefs de fin d'exercice (voix mascotte).
   Ton : factuel avant d'être gentil, une pointe d'humour sec qui vise la situation
   (jamais la personne), jamais mièvre. On dit ce qui vient de se passer dans le
   corps/cerveau, puis on encourage — sans faire semblant que c'est facile.

   Chaque jeu a son pool (variété quotidienne, plusieurs mood différents).
   _default sert de filet pour tout exercice futur non encore répertorié ici :
   il suffit d'ajouter une clé du même nom que le 2e argument de MDExercise.after(type, …)
   pour lui donner ses propres phrases ; sans clé, _default s'applique automatiquement.

   Chaque entrée : { id, mood, lines:[...], why } — why optionnel (encart « Pour info »).
   Expose window.MDDebriefs. */
window.MDDebriefs = {

  tetris: [
    { id:'t1', mood:'depassement', lines:['Ta mémoire visuospatiale vient de passer trois minutes à empiler des blocs plutôt qu\u2019à te repasser l\u2019envie en boucle.'], why:'Elle n\u2019a pas eu le choix, mais le résultat est le même : occupée ailleurs, elle ne pouvait pas faire les deux (paradigme Tetris, Oxford 2015).' },
    { id:'t2', mood:'celebration', lines:['Lignes complètes, esprit occupé : exactement le mécanisme qu\u2019on cherchait.'], why:'Le prochain craving n\u2019a qu\u2019à bien se tenir.' },
    { id:'t3', mood:'curiosite', lines:['Des chercheurs d\u2019Oxford ont montré qu\u2019un simple Tetris fait baisser l\u2019intensité du craving en temps réel.'], why:'Tu viens de leur donner raison, sans même le faire exprès.' },
    { id:'t4', mood:'encouragement', lines:['Peu importe le score : ton cerveau a été occupé ailleurs pendant plusieurs minutes entières.'], why:'C\u2019était exactement ça, la mission.' },
    { id:'t5', mood:'bienveillance', lines:['Grille pleine ou pas, tu es resté·e avec le jeu jusqu\u2019au bout.'], why:'Un jour difficile, c\u2019est déjà beaucoup.' }
  ],

  maze: [
    { id:'m1', mood:'concentration', lines:['Tu viens de piloter une bille avec ton corps entier, niveau après niveau.'], why:'Ton attention n\u2019avait clairement pas le temps de penser à autre chose.' },
    { id:'m2', mood:'depassement', lines:['Cervelet et cortex pariétal ont bossé dur pour éviter les murs.'], why:'Belle coordination — littéralement.' },
    { id:'m3', mood:'celebration', lines:['Bille en poche, niveau après niveau.'], why:'Ton envie, elle, est restée coincée dans le labyrinthe.' },
    { id:'m4', mood:'curiosite', lines:['Incliner un téléphone pour guider une bille sollicite le même système que garder l\u2019équilibre à vélo.'], why:'Le corps a une mémoire que le mental n\u2019a pas toujours.' },
    { id:'m5', mood:'bienveillance', lines:['Peu importe jusqu\u2019où tu es allé·e : ton attention est restée sur un geste précis, pas sur le manque.'], why:'C\u2019est tout ce qui comptait ici.' },
    { id:'m6', mood:'serenite', lines:['Chaque virage évité, chaque mur contourné — l\u2019attention est restée sur un geste concret, pas sur le manque.'] }
  ],

  surf: [
    { id:'s1', mood:'depassement', lines:['Tu viens de rester debout sur une vague d\u2019envie sans lui céder un centimètre.'], why:'Marlatt appelait ça l\u2019urge surfing ; toi, tu viens de le vivre pour de vrai.' },
    { id:'s2', mood:'celebration', lines:['La vague est montée, elle a culminé, elle est redescendue — et toi, tu es toujours là.'], why:'C\u2019est tout le principe, et ça vient de marcher.' },
    { id:'s3', mood:'curiosite', lines:['Une envie dépasse rarement vingt minutes à son intensité maximale.'], why:'Tu viens d\u2019en surfer une entière sans bouger d\u2019un pouce.' },
    { id:'s4', mood:'encouragement', lines:['Rester avec une sensation inconfortable sans agir dessus, c\u2019est un vrai muscle.'], why:'Tu viens de l\u2019entraîner.' },
    { id:'s5', mood:'bienveillance', lines:['La vague était haute aujourd\u2019hui. Tu es quand même resté·e dessus jusqu\u2019au bout.'], why:'Ça compte double.' }
  ],

  breathe: [
    { id:'b1', mood:'serenite', lines:['Six respirations par minute, nerf vague activé, système nerveux calmé.'], why:'Rien de magique : juste de la physiologie qui fait son travail (cohérence cardiaque).' },
    { id:'b2', mood:'respiration', lines:['Ton corps vient d\u2019envoyer un signal de calme à ton cerveau, juste en respirant plus lentement.'], why:'Le plus vieux réflexe du monde, toujours le plus fiable.' },
    { id:'b3', mood:'curiosite', lines:['La cohérence cardiaque n\u2019a rien d\u2019ésotérique : c\u2019est mesurable, reproductible.'], why:'Et tu viens de la produire.' },
    { id:'b4', mood:'celebration', lines:['Tu as suivi le rythme jusqu\u2019au bout sans lâcher l\u2019orbe des yeux.'], why:'Ton système parasympathique te remercie, probablement en silence.' },
    { id:'b5', mood:'bienveillance', lines:['Même un souffle un peu irrégulier compte.'], why:'L\u2019essentiel, c\u2019est d\u2019avoir pris ces quelques minutes pour toi.' },
    { id:'b6', mood:'pause', lines:['Ces quelques minutes n\u2019ont rien produit de visible \u2014 et c\u2019est exactement le but.'], why:'Une pause qui doit se justifier par un résultat n\u2019en est plus vraiment une.' },
    { id:'b7', mood:'ancrage', lines:['Un souffle plus lent, un rythme qui redevient tien : c\u2019est un point d\u2019appui simple, mais un vrai.'], why:'Pas besoin d\u2019un grand geste pour se sentir un peu plus stable qu\u2019avant de commencer.' }
  ],

  echo: [
    { id:'e1', mood:'concentration', lines:['Tu viens de retenir puis restituer une séquence de plus en plus longue.'], why:'C\u2019est la même mémoire de travail qui aide à garder un objectif en tête face à une impulsion.' },
    { id:'e2', mood:'celebration', lines:['Suite retenue, couleur après couleur.'], why:'Ta mémoire de travail vient de faire un vrai sprint.' },
    { id:'e3', mood:'curiosite', lines:['Se souvenir d\u2019une séquence et la restituer sollicite le même circuit que résister à une envie sur la durée.'] },
    { id:'e4', mood:'bienveillance', lines:['Peu importe jusqu\u2019où tu es allé·e : ton attention est restée sur la séquence.'], why:'C\u2019était exactement le but.' },
    { id:'e5', mood:'encouragement', lines:['Se souvenir d\u2019une couleur à la fois, sans se presser — c\u2019est déjà tenir le fil.'] }
  ],
  braise: [
    { id:'br1', mood:'motivation', lines:['Tu viens d\u2019anticiper, d\u2019agir, puis de savourer un vrai petit plaisir — pas juste d\u2019y penser.'], why:'C\u2019est exactement le circuit que le Positive Affect Treatment cherche à réentraîner.' },
    { id:'br2', mood:'celebration', lines:['Une braise de plus dans ta carte des plaisirs.'], why:'Chaque fois compte, même les petites.' },
    { id:'br3', mood:'curiosite', lines:['La dopamine gouverne surtout la motivation vers la récompense, pas le plaisir lui-même.'], why:'Tu viens de nourrir les deux, dans l\u2019ordre.' },
    { id:'br4', mood:'bienveillance', lines:['Prendre 30 secondes pour savourer quelque chose, sans se presser vers la suite.'], why:'C\u2019est plus rare, et plus utile, qu\u2019il n\u2019y paraît.' },
    { id:'br5', mood:'serenite', lines:['Un tout petit plaisir remarqué, sans le laisser filer trop vite — ça compte, même discret.'] }
  ],
  filtre: [
    { id:'f1', mood:'depassement', lines:['Vingt essais à répondre à l\u2019encre plutôt qu\u2019au mot lu.'], why:'Filtrer un automatisme pour en suivre un autre : c\u2019est exactement le muscle utile ici (effet Stroop).' },
    { id:'f2', mood:'celebration', perfBand:'high', lines:['Ton contrôle attentionnel vient de passer vingt tours sans céder à la lecture automatique.'] },
    { id:'f3', mood:'curiosite', lines:['Lire est presque impossible à désactiver — répondre à la couleur demande un vrai effort de filtrage.'], why:'C\u2019est ce même effort qui aide à ne pas suivre un automatisme de consommation.' },
    { id:'f4', mood:'bienveillance', perfBand:'mid', lines:['Quelques erreurs sur vingt essais, ça fait partie du jeu.'], why:'Le but n\u2019était pas la perfection.' },
    { id:'f5', mood:'encouragement', lines:['Vingt essais, avec ou sans erreurs — le seul fait de rester dessus a occupé l\u2019esprit ailleurs.'] },
    { id:'f6', mood:'bienveillance', perfBand:'low', lines:['Cette manche a été difficile à tenir, et c\u2019est très bien ainsi.'], why:'Le réflexe de lecture est l\u2019un des automatismes les plus increvables du cerveau humain \u2014 lui résister ne devient jamais complètement facile, même après beaucoup d\u2019entraînement.' }
  ],
  patience: [
    { id:'p1', mood:'prise-de-recul', lines:['Tu as laissé au moins une graine grandir au lieu de la cueillir tout de suite.'], why:'Préférer une récompense plus tard à une plus petite maintenant, ça s\u2019entraîne — c\u2019est exactement ce que tu viens de faire.' },
    { id:'p2', mood:'celebration', lines:['Six graines, et tu as tenu la distance.'], why:'Le delay discounting recule un peu à chaque fois que tu résistes.' },
    { id:'p3', mood:'curiosite', lines:['Préférer le petit fruit immédiat au grand fruit plus tard est un moteur central de l\u2019addiction.'], why:'Chaque graine où tu attends l\u2019affaiblit un peu.' },
    { id:'p4', mood:'bienveillance', lines:['Même si tu as cueilli tôt cette fois, tu as joué le jeu jusqu\u2019au bout.'] },
    { id:'p5', mood:'serenite', lines:['Attendre, même un peu, même une seule graine — c\u2019est déjà un pas dans l\u2019autre sens.'] }
  ],
  virage: [
    { id:'v1', mood:'concentration', lines:['Les règles ont changé plusieurs fois sans prévenir, et tu as suivi le virage.'], why:'C\u2019est la flexibilité cognitive — l\u2019inverse de la rigidité qui nourrit les automatismes de conso.' },
    { id:'v2', mood:'celebration', lines:['Changement de règle après changement de règle, tu t\u2019es adapté·e à chaque fois.'] },
    { id:'v3', mood:'curiosite', lines:['La rigidité mentale nourrit les rituels.'], why:'Savoir changer de cap, comme tu viens de le faire, aide à en sortir.' },
    { id:'v4', mood:'bienveillance', lines:['Quelques ratés sur un changement de règle surprise, c\u2019est normal.'], why:'L\u2019important, c\u2019est d\u2019avoir suivi le mouvement.' },
    { id:'v5', mood:'encouragement', lines:['Suivre les changements de règle, même imparfaitement, montre que l\u2019esprit reste souple.'] }
  ],
  inhib: [
    { id:'in1', mood:'concentration', lines:['Agir vite, ou se retenir — ton cerveau vient d\u2019arbitrer ça encore et encore, en une fraction de seconde à chaque fois.'], why:'C\u2019est exactement le même arbitrage qu\u2019entre pilote automatique et pause volontaire face à une envie.' },
    { id:'in2', mood:'celebration', lines:['Le frein a répondu présent, essai après essai.'] },
    { id:'in3', mood:'curiosite', lines:['Retenir un geste déjà lancé sollicite un circuit cérébral différent de celui qui l\u2019a déclenché.'], why:'C\u2019est ce même circuit qui s\u2019active quand tu résistes à une impulsion.' },
    { id:'in4', mood:'bienveillance', lines:['Quelques ratés sur un signal rapide, c\u2019est le principe même de l\u2019exercice.'], why:'Le frein se muscle justement en étant testé à sa limite.' },
    { id:'in5', mood:'serenite', lines:['Le frein qui répond, même une fois sur deux, c\u2019est déjà un frein qui fonctionne.'] }
  ],
  dualtask: [
    { id:'dt1', mood:'concentration', lines:['Un rond à guetter, un compteur à surveiller — deux attentions tenues en même temps, sans en lâcher aucune.'], why:'C\u2019est le même partage de ressources mentales qui aide à garder un objectif en tête tout en gérant ce qui se passe autour.' },
    { id:'dt2', mood:'celebration', lines:['Les deux tâches ont tourné ensemble, et tu n\u2019as lâché ni l\u2019une ni l\u2019autre.'] },
    { id:'dt3', mood:'curiosite', lines:['Le cerveau ne fait jamais vraiment deux choses « en même temps » — il bascule très vite entre les deux, et ce basculement a un coût mesurable.'], why:'Plus ce coût baisse avec l\u2019entraînement, plus la charge mentale du quotidien pèse légèrement moins.' },
    { id:'dt4', mood:'bienveillance', lines:['Une des deux tâches a pris le dessus sur l\u2019autre, et c\u2019est exactement ce que l\u2019exercice teste.'], why:'Diviser son attention sans rien perdre, ça se muscle progressivement.' },
    { id:'dt5', mood:'encouragement', lines:['Deux choses à la fois, dans un moment où l\u2019attention est déjà sollicitée ailleurs — le simple fait de s\u2019y être mis compte.'], why:'Revenir à un exercice structuré, même bref, aide à retrouver un point d\u2019appui.' },
    { id:'dt6', mood:'serenite', lines:['Pas besoin d\u2019avoir parfaitement tout suivi. Le geste de recentrer l\u2019attention, répété, est déjà ce qui muscle la suite.'] }
  ],
  elan: [
    { id:'el1', mood:'action', lines:['Repousser d\u2019un geste, attirer de l\u2019autre — ton corps vient de désapprendre un réflexe, pas juste ta tête.'], why:'C\u2019est exactement ce que ciblent les entraînements du biais d\u2019approche : l\u2019automatisme moteur se modifie par la répétition du geste, pas par la seule réflexion.' },
    { id:'el2', mood:'celebration', lines:['Les impulsions repoussées, les valeurs attirées — le geste a fait ce qu\u2019il fallait, essai après essai.'] },
    { id:'el3', mood:'curiosite', lines:['Le cerveau d\u2019une personne concernée par une addiction \u00ab rapproche \u00bb plus vite, presque malgré elle, ce qui évoque le manque.'], why:'Ce réflexe se mesure — et surtout, il se rentraîne dans l\u2019autre sens, ce que tu viens de faire.' },
    { id:'el4', mood:'bienveillance', lines:['Quelques gestes dans le mauvais sens, ça fait partie de l\u2019exercice.'], why:'Le réflexe qu\u2019on veut affaiblir est justement celui qui va vite — le contrer prend du temps.' },
    { id:'el5', mood:'serenite', lines:['Un geste répété dans le bon sens, même modeste, laisse une trace motrice que la seule réflexion ne laisse pas.'], why:'C\u2019est tout l\u2019intérêt d\u2019un entraînement du biais d\u2019approche : le corps apprend, pas seulement la tête.' }
  ],

  antisabotage: [
    { id:'as1', mood:'reflexion', lines:['Tu viens de nommer un schéma qui, la plupart du temps, reste invisible — repéré seulement après coup, s\u2019il l\u2019est.'], why:'Voir venir un déclencheur avant qu\u2019il agisse est ce qui distingue une rechute qu\u2019on subit d\u2019un écart qu\u2019on traverse.' },
    { id:'as2', mood:'celebration', lines:['Ton plan existe maintenant, écrit noir sur blanc, prêt avant même que le signal arrive.'], why:'La volonté est la moins disponible pile au moment où on en aurait le plus besoin — c\u2019est pour ça qu\u2019on prépare la réponse à froid.' },
    { id:'as3', mood:'curiosite', lines:['L\u2019auto-sabotage n\u2019est presque jamais un manque de volonté : c\u2019est un vieux réflexe de protection qui se déclenche au mauvais moment.'], why:'Le débusquer une fois le rend nettement plus facile à repérer la fois suivante.' },
    { id:'as4', mood:'bienveillance', lines:['Regarder d\u2019aussi près la façon dont on peut se freiner soi-même demande une vraie honnêteté.'], why:'Tu viens de la pratiquer, sans te juger au passage — c\u2019est la partie la plus difficile de l\u2019exercice.' },
    { id:'as5', mood:'encouragement', lines:['Le signal est repéré, la réponse est prête. La prochaine fois, ce sera un réflexe de plus à disposition, pas une improvisation.'] },
    { id:'as6', mood:'resilience', lines:['Ce schéma a peut-être joué contre toi plusieurs fois avant aujourd\u2019hui \u2014 ça ne change rien à ce que tu viens d\u2019en faire.'], why:'Repérer un vieux réflexe après coup compte autant que de le voir venir à l\u2019avance : les deux réduisent sa prise la fois suivante.' }
  ],

  /* Filet générique : tout jeu/exercice futur sans clé dédiée reçoit ce pool tel quel,
     sans aucune modification de code — juste ajouter une clé du même nom pour se spécialiser. */
  _default: [
    { id:'d1', mood:'encouragement', lines:['Séance terminée. Ce qui vient de se passer dans ta tête compte plus que ce qui s\u2019est passé à l\u2019écran.'] },
    { id:'d2', mood:'celebration', lines:['Tu es allé·e au bout de l\u2019exercice.'], why:'Le simple fait d\u2019avoir commencé était déjà la partie la plus dure.' },
    { id:'d3', mood:'curiosite', lines:['Chaque exercice ici vise la même chose : occuper ton esprit ailleurs, le temps qu\u2019une envie retombe.'], why:'Celui-ci ne fait pas exception.' },
    { id:'d4', mood:'depassement', lines:['Peu importe le détail : tu viens de tenir un moment entier sans céder au pilote automatique.'] },
    { id:'d5', mood:'bienveillance', lines:['Pas besoin d\u2019avoir été parfait·e.'], why:'Tu as été présent·e, et c\u2019est exactement ce qu\u2019on te demandait.' },
    { id:'d6', mood:'reflexion', lines:['Tu peux refaire cet exercice demain, et après-demain.'], why:'C\u2019est en se répétant qu\u2019un réflexe finit par devenir automatique.' }
  ]
};
