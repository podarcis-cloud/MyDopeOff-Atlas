/* anecdotes.js — Banque d'anecdotes pour la grande discussion (bilan-hero).
   But : rendre le « faire le point » fascinant et donner envie d'y revenir.
   Chaque passage en pioche quelques-unes, sans répétition. Contenu de vulgarisation
   (neurosciences, histoire, culture, anthropologie) — jamais un mode d'emploi, jamais
   de dose ni de méthode d'usage. Ton littéraire mais accessible.
   Expose window.MDAnecdotes : [{ t:'texte', mood:'clé avatar' }]. */
window.MDAnecdotes = [
  // — Neurosciences de la consommation —
  { t: 'La dopamine n\u2019est pas la molécule du plaisir, mais de l\u2019anticipation : elle grimpe avant la récompense, pas pendant. C\u2019est pour ça que le manque fait si mal — le cerveau réclame ce qu\u2019il a appris à attendre.', mood: 'explication' },
  { t: 'Ton cerveau ne distingue pas une récompense « naturelle » d\u2019une artificielle : un like, un verre, une part de gâteau allument le même petit circuit. Toute la différence tient dans l\u2019intensité.', mood: 'reflexion' },
  { t: 'La tolérance n\u2019est pas qu\u2019une impression : à force de stimulation, certains récepteurs à dopamine diminuent réellement en nombre. Le plaisir s\u2019émousse, et l\u2019envie, elle, monte.', mood: 'explication' },
  { t: 'Le cortex préfrontal — ce « frein » qui pèse le pour et le contre — n\u2019achève sa maturation que vers vingt-cinq ans. La prudence avant cet âge n\u2019est pas de la morale, c\u2019est de la biologie.', mood: 'reflexion' },
  { t: 'L\u2019addiction laisse une empreinte tenace : même après des années, un lieu, une odeur, une chanson peuvent rallumer le circuit. Les chercheurs appellent ça la mémoire du craving.', mood: 'explication' },
  { t: 'Le noyau accumbens, gros comme un petit pois, est le carrefour de presque toutes les dépendances — substances, jeu, écrans. Un même relais minuscule pour mille tentations.', mood: 'curiosite' },
  { t: 'Nommer une émotion l\u2019apaise : l\u2019imagerie cérébrale montre que mettre des mots sur ce qu\u2019on ressent calme littéralement l\u2019amygdale, notre centre de l\u2019alarme.', mood: 'ecoute' },
  { t: 'Une seule nuit écourtée suffit à rendre l\u2019amygdale plus réactive — et les envies plus fortes. Le sommeil est un régulateur d\u2019humeur qu\u2019on sous-estime toujours.', mood: 'serenite' },
  { t: 'Respirer lentement, autour de six cycles par minute, synchronise le cœur et le système nerveux. Un frein d\u2019urgence intégré, gratuit, que tu portes en permanence.', mood: 'respiration' },
  { t: 'Le pic d\u2019une envie dure rarement plus de vingt minutes : c\u2019est une vague, pas un état. La « surfer » plutôt que la combattre change presque tout.', mood: 'motivation' },
  { t: 'Occuper l\u2019esprit visuel — un Tetris, un puzzle — réduit l\u2019intensité des envies : trop occupé à voir, le cerveau a moins de place pour imaginer la consommation. (Oxford, 2015.)', mood: 'explication' },

  // — Psychonautique & psychédéliques —
  { t: 'Le 19 avril 1943, le chimiste Albert Hofmann teste sur lui le LSD qu\u2019il vient de créer, puis rentre chez lui à vélo dans un monde devenu ondoyant. On célèbre depuis le « Bicycle Day ».', mood: 'reflexion' },
  { t: 'La DMT, à l\u2019origine des expériences les plus intenses, existe à l\u2019état de traces dans d\u2019innombrables plantes. La nature en est discrètement tapissée, sans mode d\u2019emploi.', mood: 'curiosite' },
  { t: 'Beaucoup de récits d\u2019expériences intenses se ressemblent étrangement d\u2019une personne à l\u2019autre : tunnels, motifs géométriques, sentiment de « rentrer à la maison ». La science s\u2019interroge encore sur cette phénoménologie partagée.', mood: 'curiosite' },
  { t: 'Certains états modifiés et les expériences de mort imminente activent des régions cérébrales communes — d\u2019où ces récits de décorporation et de lumière qui se répondent d\u2019une culture à l\u2019autre.', mood: 'reflexion' },
  { t: 'Le mot « psychédélique » a été forgé en 1956 par le psychiatre Humphry Osmond : du grec, « qui révèle l\u2019âme ». Il l\u2019a glissé à Aldous Huxley dans un petit distique.', mood: 'explication' },
  { t: 'Le « default mode network », réseau du bavardage mental et du sentiment de soi, se met en veille sous psychédéliques. Beaucoup décrivent alors une étrange dissolution du « moi ».', mood: 'reflexion' },
  { t: 'Le LSD est actif à l\u2019ordre du millionième de gramme — l\u2019une des molécules les plus puissantes jamais décrites. L\u2019infime qui bouleverse tout.', mood: 'curiosite' },

  // — Chamanisme, ayahuasca, usages tribaux —
  { t: 'En Amazonie, l\u2019ayahuasca est une science empirique : deux plantes qui, séparées, ne font presque rien, mais dont l\u2019association devient active. Comment des peuples sans laboratoire l\u2019ont trouvée reste une énigme.', mood: 'curiosite' },
  { t: 'Les Bwiti du Gabon emploient l\u2019iboga dans des rites initiatiques de plusieurs jours. La même plante intrigue aujourd\u2019hui les chercheurs travaillant sur la dépendance aux opioïdes.', mood: 'explication' },
  { t: 'Le peyotl est utilisé rituellement depuis des millénaires par des peuples d\u2019Amérique du Nord ; il est aujourd\u2019hui protégé, dans certains États, au titre de la liberté religieuse.', mood: 'reflexion' },
  { t: 'Chez de nombreux peuples, une substance rituelle n\u2019est jamais prise seul : toujours un cadre, un guide, un chant. Le « set and setting » avant l\u2019heure.', mood: 'ecoute' },
  { t: 'Une vieille histoire ethnographique raconte que des chamanes de Sibérie observaient les rennes, friands d\u2019amanite tue-mouches, pour apprendre. Mythe ou mémoire, l\u2019image est saisissante.', mood: 'curiosite' },

  // — Recherche récente : plasticité, thérapies —
  { t: 'La psilocybine relance la plasticité du cerveau : sous son effet, des régions qui se parlent peu se mettent soudain à dialoguer. Les chercheurs y voient une piste contre la dépression résistante.', mood: 'explication' },
  { t: 'À Johns Hopkins comme à l\u2019Imperial College de Londres, des essais cliniques réhabilitent, sous protocole très strict, des molécules longtemps bannies — pour le trauma, la dépression, le deuil.', mood: 'reflexion' },
  { t: 'La MDMA a été brevetée par Merck dès 1912, puis oubliée des décennies durant. Elle est aujourd\u2019hui étudiée, encadrée, pour le stress post-traumatique.', mood: 'explication' },
  { t: 'La kétamine, anesthésique des hôpitaux et des champs de bataille, intéresse la psychiatrie pour son effet antidépresseur rapide — sous contrôle médical strict.', mood: 'explication' },
  { t: 'Le « micro-dosing » fait beaucoup parler, mais les études rigoureuses peinent encore à le distinguer d\u2019un effet placebo. La prudence scientifique avance à petits pas.', mood: 'reflexion' },

  // — Histoire, personnalités, narcotrafic —
  { t: 'À sa naissance en 1886, le Coca-Cola contenait vraiment un extrait de feuille de coca. La cocaïne en fut retirée au tout début du XXe siècle ; le nom, lui, est resté.', mood: 'curiosite' },
  { t: 'L\u2019héroïne fut vendue par Bayer en 1898… comme sirop contre la toux, réputé « sans danger de dépendance ». L\u2019histoire de la pharmacie est pavée de bonnes intentions.', mood: 'reflexion' },
  { t: 'La nicotine doit son nom à Jean Nicot, diplomate qui introduisit le tabac à la cour de France au XVIe siècle en le vantant comme un remède.', mood: 'explication' },
  { t: 'En 1884, Freud publie « Über Coca », un éloge enflammé de la cocaïne. Il en reviendra, amèrement, après avoir vu un ami sombrer.', mood: 'reflexion' },
  { t: 'Sherlock Holmes s\u2019injectait une solution de cocaïne entre deux enquêtes : Conan Doyle décrivait là un usage presque banal de l\u2019époque victorienne.', mood: 'curiosite' },
  { t: 'La prohibition américaine (1920-1933) n\u2019a pas tari l\u2019alcool : elle a enrichi les mafias et rendu la boisson plus dangereuse. Une leçon que l\u2019histoire aime répéter.', mood: 'reflexion' },
  { t: 'On raconte que Pablo Escobar dépensait des fortunes… en élastiques, pour tenir ses liasses de billets. La démesure du narcotrafic dépasse souvent la fiction.', mood: 'curiosite' },
  { t: 'Le mot « assassin » viendrait, selon une légende tenace, du « haschich » — étymologie séduisante, mais que les historiens contestent volontiers.', mood: 'explication' },
  { t: 'Le café fut suspecté ou interdit un peu partout à ses débuts — à La Mecque, à Constantinople, en Europe — avant de devenir le carburant du monde moderne.', mood: 'curiosite' },
  { t: 'L\u2019absinthe, « fée verte » des poètes du XIXe, fut accusée de tous les maux puis interdite. On sait aujourd\u2019hui que le vrai coupable était surtout son taux d\u2019alcool colossal.', mood: 'reflexion' },
  { t: 'Steve Jobs a qualifié ses expériences de jeunesse de l\u2019une des choses « les plus importantes » de sa vie. La Silicon Valley a longtemps entretenu ce genre de récits.', mood: 'curiosite' },
  { t: 'Une partie de l\u2019esthétique des années 60 — pochettes, mélodies, couleurs — est née dans un brouillard psychédélique assumé par toute une génération d\u2019artistes.', mood: 'curiosite' },

  // — Danger, réduction des risques —
  { t: 'L\u2019alcool est, statistiquement, l\u2019une des substances les plus meurtrières au monde — précisément parce qu\u2019il est légal, banal et présent partout.', mood: 'reflexion' },
  { t: 'Le tabac tue plus que toutes les drogues illégales réunies — lentement, discrètement, sans jamais faire la une des journaux.', mood: 'reflexion' },
  { t: 'Le pire danger n\u2019est pas toujours la molécule, mais le mélange : associer alcool et opioïdes, ou alcool et benzodiazépines, multiplie le risque pour la respiration.', mood: 'explication' },
  { t: 'La naloxone peut inverser une overdose d\u2019opioïdes en quelques minutes. Dans plusieurs pays, elle se glisse désormais dans une poche, comme un petit extincteur de vie.', mood: 'explication' },
  { t: 'Le fentanyl est d\u2019une puissance telle qu\u2019une quantité invisible peut être fatale. C\u2019est pourquoi les bandelettes de détection et la naloxone sauvent, concrètement, des vies.', mood: 'reflexion' },
  { t: 'La caféine est la substance psychoactive la plus consommée sur Terre. Elle a ses limites, mais il en faudrait des dizaines de tasses d\u2019affilée pour vraiment jouer avec le feu.', mood: 'curiosite' },

  // — Culture, langue, science douce —
  { t: 'Paracelse, médecin de la Renaissance, écrivait déjà : « c\u2019est la dose qui fait le poison ». Cinq siècles plus tard, c\u2019est le socle même de la réduction des risques.', mood: 'explication' },
  { t: 'Le mot « toxique » vient du grec « toxikon » : le poison dont on enduisait les flèches. La langue garde la mémoire des dangers anciens.', mood: 'curiosite' },
  { t: 'Le houblon de ta bière et le chanvre sont cousins botaniques — même famille, les Cannabaceae. La nature a décidément le sens de la parenté.', mood: 'curiosite' },
  { t: 'Le fameux « high » du coureur ne vient pas que des endorphines : ton corps fabrique aussi ses propres endocannabinoïdes. Une ivresse légale, gratuite, sécrétée par l\u2019effort.', mood: 'motivation' },
  { t: '« Set and setting » : deux mots popularisés par Timothy Leary pour dire que l\u2019état d\u2019esprit et le décor comptent autant que le reste. Vrai pour à peu près tout, d\u2019ailleurs.', mood: 'reflexion' },

  { t: 'Le mot « addiction » vient du droit romain : « addictere » désignait la mise en gage du corps d\u2019un débiteur pour rembourser une dette. Le mot parle de contrainte depuis plus de deux mille ans, bien avant qu\u2019on parle de substances.', mood: 'reflexion', tags: ['liberté', 'responsabilité'] },
  { t: 'Pavlov n\u2019étudiait pas du tout le conditionnement au départ — il mesurait la salive de chiens pour une recherche sur la digestion. Ses sujets ont commencé à saliver au bruit des pas de l\u2019assistant, avant même de voir la nourriture. La découverte la plus citée de la psychologie est née d\u2019un accident de labo.', mood: 'curiosite' },
  { t: 'Des chirurgiens ont un jour testé une opération du genou en pratiquant, sur un groupe témoin, exactement les mêmes gestes et la même anesthésie — sans rien réparer à l\u2019intérieur. Les patients se sont sentis tout aussi soulagés. Publié dans le New England Journal of Medicine, pas dans un magazine de curiosités.', mood: 'curiosite' },
  { t: 'Un économiste a un jour vendu des billets de 20 dollars aux enchères — mais le deuxième plus offrant devait payer aussi, sans rien recevoir. Les gens ont fini par miser plus de 20 dollars pour un billet de 20 dollars, juste pour ne pas perdre ce qu\u2019ils avaient déjà engagé. L\u2019expérience porte un nom : le piège de l\u2019escalade d\u2019engagement.', mood: 'reflexion', tags: ['lucidité', 'décision'] },
  { t: 'Les octopus (poulpes) ont neuf cerveaux — un central, et un dans chacun de leurs huit bras, capable de décider seul comment attraper quelque chose. Le tien n\u2019en a qu\u2019un, mais il négocie en permanence avec lui-même.', mood: 'emerveillement' },
  { t: 'Le premier groupe d\u2019entraide entre pairs pour l\u2019alcool s\u2019est fondé en 1935 autour d\u2019une seule idée simple : une personne qui a traversé la même chose comprend des choses qu\u2019aucun manuel ne peut enseigner. L\u2019idée a essaimé partout dans le monde depuis.', mood: 'complicite', tags: ['entraide', 'communauté'] },
  { t: 'Une étude a suivi des gens qui devaient résister à une envie en se disant simplement « je ne peux pas » face à ceux qui se disaient « je ne veux pas ». Le second groupe a mieux tenu, presque deux fois plus souvent. Le choix des mots change littéralement le sentiment de contrôle.', mood: 'decision', tags: ['liberté', 'contrôle'] },
  { t: 'Le kangourou ne peut pas reculer — son anatomie l\u2019en empêche physiquement. C\u2019est pour ça qu\u2019il figure sur les armoiries australiennes : un symbole involontaire d\u2019un pays qui « avance toujours ».', mood: 'curiosite' },
  { t: 'La roue n\u2019a été inventée que 300 ans après l\u2019écriture. Les civilisations anciennes savaient déjà raconter des histoires et tenir des comptes bien avant de savoir faire rouler quoi que ce soit.', mood: 'curiosite' },
  { t: 'Un institut néerlandais analyse gratuitement des échantillons de drogue depuis les années 1990 — pas pour juger, seulement pour dire ce qu\u2019il y a vraiment dedans. Le principe a depuis essaimé dans une dizaine de pays.', mood: 'ressource', tags: ['sécurité', 'information'] },
  { t: 'Le cerveau adolescent termine sa maturation vers 25 ans — le cortex préfrontal, celui qui pèse le risque et freine l\u2019impulsion, est la toute dernière région à finir de se câbler. Ce n\u2019est pas un manque de caractère, c\u2019est un chantier en cours.', mood: 'explication' },
  { t: 'Une expérience a proposé à des singes de choisir entre un jus qu\u2019ils recevaient à coup sûr et un autre, aléatoire, parfois plus généreux, parfois vide. Beaucoup ont fini par préférer l\u2019incertain — l\u2019attente elle-même semblait devenir le plaisir. Le cerveau humain n\u2019est pas si différent face à une notification.', mood: 'reflexion', tags: ['lucidité'] },
  { t: 'Les manchots empereurs se relaient en cercle contre le vent, chacun passant tour à tour à l\u2019extérieur du groupe, le poste le plus froid. Aucun chef ne distribue les tours — le mouvement s\u2019organise tout seul, par la seule répétition du geste.', mood: 'complicite', tags: ['entraide'] },
  { t: 'Un patient amnésique célèbre (connu dans la littérature scientifique sous les initiales H.M.) ne pouvait plus former de nouveaux souvenirs après une opération — mais il apprenait quand même de nouvelles habiletés motrices, sans jamais se souvenir les avoir apprises. La mémoire du geste et la mémoire du récit ne vivent pas au même endroit.', mood: 'emerveillement' },
  { t: 'Une expérience de 2021 a proposé à des fumeurs de retarder leur prochaine cigarette de dix minutes, encore et encore, plutôt que d\u2019essayer d\u2019arrêter d\u2019un coup. Beaucoup ont fini par fumer bien moins, sans jamais avoir eu l\u2019impression de se battre contre quoi que ce soit.', mood: 'ressource', tags: ['patience'] },
  { t: 'Le premier programme d\u2019échange de seringues moderne est né aux Pays-Bas en 1984, lancé par une association d\u2019usagers eux-mêmes — pas par des médecins, pas par l\u2019État. Ce sont les personnes concernées qui ont inventé l\u2019outil avant qu\u2019il ne devienne une politique publique.', mood: 'fierte', tags: ['autonomie', 'responsabilité'] },
  { t: 'La caféine met en moyenne 5 heures à être éliminée à moitié par le corps — un café bu à 16h peut encore couper le sommeil à 22h, même sans sensation de nervosité perçue.', mood: 'vigilance' },
  { t: 'Un économiste comportemental a montré qu\u2019il suffit parfois de renommer un compte d\u2019épargne « vacances de mes enfants » plutôt que « compte n°2 » pour que les gens y touchent deux fois moins souvent. Donner un nom à un objectif change la façon dont on le protège.', mood: 'decision', tags: ['valeurs', 'engagement'] }
];

/* Anecdotes régionales — preuve de concept sur 3 régions (recherche réelle, sourcée),
   pas une couverture complète des pays de regions.js. Les régions non listées ici
   se rabattent simplement sur le pool générique ci-dessus : aucune case vide, aucune
   anecdote inventée pour combler un pays non couvert. */
window.MDAnecdotesRegion = {
  BE: [
    { t: 'Bruxelles a été la première région de Belgique à légaliser les salles de consommation à moindre risque, en 2021 — après des années de flou juridique pour ceux qui y travaillaient.', mood: 'curiosite', theme: 'salles-conso' },
    { t: 'En Belgique francophone, des opérations comme « Boule de neige » forment d\u2019anciens usagers pour aller à la rencontre d\u2019autres usagers, dans la rue ou en prison — la réduction des risques par les pairs, au sens propre.', mood: 'curiosite', theme: 'pairs' },
    { t: 'L\u2019asbl Modus Vivendi fait ce travail depuis 1993, née en pleine épidémie de VIH — la santé des usagers de drogues n\u2019était, avant ça, presque jamais pensée comme une politique de santé publique à part entière.', mood: 'reflexion', theme: 'histoire-vih' }
  ],
  FR: [
    { t: 'En France, la vente libre de seringues en pharmacie ne date que de 1987 — avant cette date, s\u2019en procurer une propre relevait presque du parcours du combattant.', mood: 'curiosite', theme: 'seringues' },
    { t: 'Le mouvement techno français a fondé ses propres structures de réduction des risques dès le milieu des années 90 — Techno+, Keep Smiling — nées directement des soirées qu\u2019elles cherchaient à sécuriser.', mood: 'curiosite', theme: 'festif' },
    { t: 'Depuis 2016, la France expérimente des « Haltes Soins Addictions » — un nom qui a remplacé l\u2019ancien « salle de consommation à moindre risque », jugé trop stigmatisant.', mood: 'reflexion', theme: 'salles-conso' },
    { t: 'Le gouvernement français a lui-même commandé une étude pour prouver que l\u2019absinthe rendait fou. Résultat : la région qui en buvait le plus affichait le taux de troubles mentaux le plus bas du pays. L\u2019interdiction a quand même été votée en 1915, et elle a tenu près d\u2019un siècle.', mood: 'curiosite', theme: 'panique-morale' }
  ],
  CA: [
    { t: 'En 1989, une petite équipe de quatre infirmières a ouvert à Montréal le tout premier programme d\u2019échange de seringues d\u2019Amérique du Nord — CACTUS existe toujours aujourd\u2019hui.', mood: 'inspiration', theme: 'seringues' },
    { t: 'Vancouver a ouvert Insite en 2003 — le premier site d\u2019injection supervisée d\u2019Amérique du Nord. L\u2019affaire est allée jusqu\u2019à la Cour suprême du Canada, qui a tranché en sa faveur.', mood: 'curiosite', theme: 'salles-conso' },
    { t: 'Au Québec, la loi du bon samaritain protège explicitement les témoins d\u2019une overdose qui appellent le 911 — même en cas de simple possession.', mood: 'reflexion', theme: 'bon-samaritain' },
    { t: 'La toute première loi antidrogue du Canada, en 1908, n\u2019est pas née d\u2019un problème de santé publique : un futur premier ministre, envoyé évaluer les dégâts d\u2019une émeute raciste à Vancouver, en a profité pour faire interdire l\u2019opium. Le cannabis, lui, a été ajouté quinze ans plus tard à la liste — pour une raison qu\u2019aucun historien n\u2019a jamais réussi à retrouver.', mood: 'curiosite', theme: 'panique-morale' }
  ],
  DE: [
    { t: 'Fixpunkt, à Berlin, tient depuis des années des salles de consommation supervisée — le nom dit bien l\u2019idée : un point fixe où atterrir, plutôt que la rue.', mood: 'curiosite', theme: 'salles-conso' },
    { t: 'L\u2019Allemagne appelle sa politique des drogues la « politique des quatre piliers » : prévention, thérapie, réduction des risques, répression — posés comme quatre égaux plutôt qu\u2019une hiérarchie.', mood: 'reflexion', theme: 'politique-cadre' },
    { t: 'Berlin a ouvert ses premières salles de consommation dès les années 1990 — parmi les toutes premières d\u2019Europe, bien avant que l\u2019idée ne se répande ailleurs.', mood: 'curiosite', theme: 'salles-conso' },
    { t: 'Le MDMA n\u2019a jamais été inventé pour faire la fête, ni comme sérum de vérité, contrairement à la légende : en 1912, un chimiste allemand de chez Merck l\u2019a obtenu par accident, en cherchant tout autre chose. Le brevet, déposé un 24 décembre, l\u2019a laissé dormir plus de 40 ans dans une archive avant que quelqu\u2019un ne le redécouvre.', mood: 'curiosite', theme: 'accident-labo' }
  ],
  GB: [
    { t: 'Dans les années 1980, c\u2019est à Liverpool qu\u2019est né ce qu\u2019on appelle encore aujourd\u2019hui le « modèle de Mersey » — l\u2019un des tout premiers programmes d\u2019échange de seringues au monde.', mood: 'curiosite', theme: 'seringues' },
    { t: 'Dès 1926, un rapport officiel britannique (Rolleston) autorisait déjà les médecins à prescrire de la morphine à des personnes incapables de s\u2019en passer — un siècle avant que le terme « réduction des risques » n\u2019existe.', mood: 'curiosite', theme: 'prescription' },
    { t: 'Dans l\u2019Angleterre victorienne, des sirops à base d\u2019opium se vendaient librement en pharmacie — et par correspondance — pour endormir les bébés qui pleuraient trop. Le plus connu s\u2019appelait « Mrs. Winslow\u2019s Soothing Syrup ».', mood: 'curiosite', theme: 'medecine-oubliee' }
  ],
  NL: [
    { t: 'Les coffeeshops néerlandais ne sont pas nés d\u2019une envie de tout légaliser, mais d\u2019un calcul de réduction des risques : séparer le marché du cannabis de celui des drogues dures, pour qu\u2019un usager occasionnel ne croise jamais un dealer d\u2019héroïne.', mood: 'curiosite', theme: 'tolerance-cannabis' },
    { t: 'La tolérance des coffeeshops remonte à 1976 — les Pays-Bas eux-mêmes appellent ça le « gedoogbeleid », littéralement la politique de la tolérance.', mood: 'reflexion', theme: 'tolerance-cannabis' },
    { t: 'La Compagnie néerlandaise des Indes orientales, fondée en 1602 et souvent citée comme la première entreprise cotée en bourse au monde, vendait aussi de l\u2019opium — certains de ses exercices affichaient des rendements de 742 %.', mood: 'curiosite', theme: 'histoire-coloniale' },
    { t: 'Les graines de cannabis néerlandaises voyagent depuis longtemps : au Maroc, des hybrides venus des Pays-Bas ont croisé le kif traditionnel du Rif au début des années 2000, donnant naissance à de nouvelles variétés locales.', mood: 'curiosite', theme: 'genetique-cannabis' }
  ],
  ES: [
    { t: 'En 1974, la Cour suprême espagnole a tranché : posséder une drogue pour sa propre consommation n\u2019est pas un délit — une jurisprudence toujours valable aujourd\u2019hui, cinquante ans plus tard.', mood: 'curiosite', theme: 'decrim' },
    { t: 'Energy Control, en Espagne, analyse des échantillons de drogue depuis la fin des années 1990 — l\u2019un des tout premiers services de ce genre en Europe.', mood: 'curiosite', theme: 'testing' },
    { t: 'Les clubs cannabiques espagnols ne vendent jamais rien : leurs membres cotisent, cultivent en commun et se partagent la récolte — un système pensé pour rester dans le flou juridique plutôt que l\u2019affronter, contrairement aux coffeeshops néerlandais qui, eux, vendent ouvertement.', mood: 'curiosite', theme: 'tolerance-cannabis' }
  ],
  PT: [
    { t: 'En 2001, le Portugal est devenu le premier pays au monde à décriminaliser l\u2019usage personnel de toutes les drogues — pas seulement le cannabis, toutes.', mood: 'curiosite', theme: 'decrim' },
    { t: 'Le taux de VIH chez les usagers de drogues portugais est passé de 104 cas pour un million d\u2019habitants en 2000 à seulement 4,2 quinze ans plus tard.', mood: 'reflexion', theme: 'histoire-vih' },
    { t: 'Au Portugal, une personne interpellée avec une petite quantité ne va pas devant un tribunal, mais rencontre une commission de trois personnes — un médecin, un avocat, un travailleur social.', mood: 'curiosite', theme: 'decrim' }
  ],
  IT: [
    { t: 'Les services italiens de soin en addictologie ont changé de nom plusieurs fois en cinquante ans — CMAS, puis SerT, aujourd\u2019hui Ser.D — chaque nom disant un peu plus « soin » que le précédent.', mood: 'reflexion', theme: 'politique-cadre' },
    { t: 'L\u2019Italie compte aujourd\u2019hui plus de 550 Ser.D. sur son territoire — à peu près un pour 100 000 habitants.', mood: 'curiosite', theme: 'politique-cadre' }
  ],
  MA: [
    { t: 'Le Maroc a été le premier pays de la région Moyen-Orient/Afrique du Nord à rejoindre le Groupe Pompidou du Conseil de l\u2019Europe — reconnu comme pionnier régional pour sa gestion intégrée des addictions, malgré un cadre légal par ailleurs très répressif.', mood: 'curiosite' },
    { t: 'Dans le Rif marocain, le kif traditionnel — appelé « beldiya » — est cultivé par les Berbères depuis des générations, bien avant qu\u2019aucune loi n\u2019existe pour l\u2019encadrer ou l\u2019interdire.', mood: 'curiosite', theme: 'genetique-cannabis' }
  ],
  DZ: [
    { t: 'Le centre de Bouchaoui, ouvert en 2018 dans une forêt à l\u2019ouest d\u2019Alger, propose une prise en charge sans traitement chimique — sport et nature plutôt que médicaments — pour les jeunes consommateurs de cannabis. Plus de 7 700 personnes y sont déjà passées.', mood: 'curiosite' }
  ],
  TN: [
    { t: 'En Tunisie, c\u2019est la loi qui punit le plus sévèrement le simple usage — jusqu\u2019à cinq ans de prison — qui a fini par pousser le pays à écrire, en 2021, sa toute première stratégie nationale de réduction des risques.', mood: 'reflexion' }
  ]
};

/* Renvoie le pool d'anecdotes à utiliser : générique + régional si la région de l'utilisateur
   est couverte (sinon générique seul, jamais de trou). Les entrées régionales sont répétées
   (poids x3) : fusionnées à parts égales avec ~50 génériques, elles ne sortiraient quasiment
   jamais au tirage et la personnalisation resterait invisible en pratique. */
window.getAnecdotePool = function (regionCode) {
  var regionPool = (regionCode && window.MDAnecdotesRegion[regionCode]) || null;
  if (!regionPool) return window.MDAnecdotes;
  var weighted = regionPool.concat(regionPool).concat(regionPool);
  return window.MDAnecdotes.concat(weighted);
};

/* --- Croisement inter-régions ---------------------------------------------------------
   Objectif : inviter un·e utilisateur·rice belge, par exemple, à découvrir qu'un thème qui
   la concerne existe aussi ailleurs — et inversement. Contrairement à une première version
   qui combinait deux anecdotes au vol (juxtaposition mécanique, sans lien réel), chaque
   jonction ci-dessous est écrite à la main : la troisième phrase relie vraiment les deux
   faits (écart de dates, même idée sous un autre nom, chemins différents vers la même
   solution) — jamais une simple addition de deux informations côte à côte. Les faits restent
   ceux déjà sourcés dans MDAnecdotesRegion ; rien n'est inventé, seule la mise en relation
   est nouvelle. Clé : "A-B" avec les codes région dans l'ordre alphabétique. */
window.MDAnecdoteBridges = {
  'BE-CA': { t: 'Bruxelles a légalisé ses salles de consommation en 2021. Vancouver l\u2019avait fait dix-huit ans plus tôt, en 2003, après un passage devant la Cour suprême du Canada — la même idée a mis presque deux décennies à traverser l\u2019Atlantique.', mood: 'curiosite' },
  'BE-DE': { t: 'Bruxelles a légalisé ses salles de consommation en 2021. Berlin en ouvrait déjà dans les années 1990 — ce que la Belgique vient d\u2019acter, l\u2019Allemagne le pratiquait depuis trente ans sans l\u2019avoir jamais formellement décidé de la même façon.', mood: 'curiosite' },
  'BE-FR': { t: 'Bruxelles a légalisé ses salles de consommation en 2021. La France fait à peu près la même chose depuis 2016, sous un autre nom — « Halte Soins Addictions » plutôt que « salle de consommation », jugé moins stigmatisant.', mood: 'reflexion' },
  'CA-FR': { t: 'La France a libéralisé la vente de seringues en pharmacie en 1987. Deux ans plus tard, à Montréal, quatre infirmières ouvraient le tout premier programme d\u2019échange de seringues d\u2019Amérique du Nord — la même urgence sanitaire, presque au même moment, sur deux continents qui ne se concertaient pas.', mood: 'curiosite' },
  'DE-FR': { t: 'Ce que la France appelle depuis 2016 une « Halte Soins Addictions », Berlin le pratique sous le nom plus direct de salle de consommation depuis les années 1990 — même principe, vingt-cinq ans d\u2019écart, et un nom choisi pour rassurer plutôt que pour décrire.', mood: 'reflexion' },
  'CA-DE': { t: 'Vancouver a ouvert sa salle de consommation en 2003, Berlin dans les années 1990 — deux pays, deux continents, la même réponse à la même question, chacun de son côté.', mood: 'curiosite' },
  'CA-GB': { t: 'Le « modèle de Mersey » est né à Liverpool au milieu des années 1980. CACTUS Montréal, le premier programme nord-américain du genre, a ouvert en 1989 — la même idée, un océan et quelques années plus tard.', mood: 'curiosite' },
  'FR-GB': { t: 'Liverpool a lancé son programme d\u2019échange de seringues au milieu des années 1980. La France n\u2019a libéralisé la vente en pharmacie qu\u2019en 1987 — deux ou trois ans de retard, le temps qu\u2019une idée traverse la Manche.', mood: 'curiosite' },
  'ES-PT': { t: 'L\u2019Espagne a dépénalisé l\u2019usage personnel dès 1974, par une simple décision de justice, presque en silence. Le Portugal a fait le même choix en 2001, mais par une loi votée et débattue publiquement — vingt-sept ans d\u2019écart, et deux façons radicalement différentes d\u2019arriver au même endroit.', mood: 'reflexion' },
  'BE-PT': { t: 'En Belgique, c\u2019est l\u2019épidémie de VIH qui a fait naître Modus Vivendi en 1993. Au Portugal, cette même épidémie — combinée à une crise de l\u2019héroïne — a poussé le pays à décriminaliser en 2001. Le VIH n\u2019a pas changé qu\u2019un pays : il a redessiné la politique des drogues sur tout le continent.', mood: 'reflexion' },
  'DE-IT': { t: 'L\u2019Allemagne organise sa politique en quatre piliers nommés et posés comme égaux. L\u2019Italie, elle, a fait évoluer ses services d\u2019addictologie par étapes discrètes — CMAS, puis SerT, puis Ser.D — sans jamais formaliser de grand cadre à quatre piliers. Deux philosophies d\u2019organisation, pour le même objectif.', mood: 'reflexion' },
  'CA-FR-panique': { t: 'La France a interdit l\u2019absinthe en 1915 malgré sa propre étude officielle qui disait l\u2019inverse. Le Canada a interdit le cannabis en 1923 sans qu\u2019aucun historien n\u2019ait jamais retrouvé la raison exacte. Deux pays, deux décennies différentes, la même chose : une loi votée sur la peur plutôt que sur les faits.', mood: 'reflexion' },
  'ES-NL': { t: 'Les Pays-Bas tolèrent la vente ouverte de cannabis dans des coffeeshops commerciaux depuis 1976. L\u2019Espagne, elle, a choisi l\u2019inverse : des clubs privés où l\u2019on cotise et cultive en commun, jamais de vente — la même tolérance de fond, mais une architecture légale presque opposée.', mood: 'curiosite' },
  'MA-NL': { t: 'Le kif traditionnel du Rif marocain, le « beldiya », se cultive depuis des générations chez les Berbères. Au début des années 2000, des graines venues des Pays-Bas l\u2019ont croisé pour donner des variétés plus fortes — la génétique du cannabis a voyagé du nord de l\u2019Europe jusqu\u2019aux montagnes marocaines, sans qu\u2019aucune frontière ne l\u2019arrête vraiment.', mood: 'curiosite' }
};

/* Cherche, pour la région donnée, une jonction écrite impliquant une autre région couverte.
   Renvoie null si la région n'est pas couverte ou n'a aucune jonction écrite pour l'instant
   (jamais de contenu généré à la volée pour combler un manque). */
window.pickBridgeAnecdote = function (regionCode) {
  if (!regionCode) return null;
  var keys = Object.keys(window.MDAnecdoteBridges).filter(function (k) {
    var parts = k.split('-');
    return parts[0] === regionCode || parts[1] === regionCode;
  });
  if (!keys.length) return null;
  var key = keys[Math.floor(Math.random() * keys.length)];
  return window.MDAnecdoteBridges[key];
};
