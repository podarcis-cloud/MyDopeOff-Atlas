/* MyDope Off — page-echo.js
   Logique de echo, extraite du script inline de echo.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var pads=[].slice.call(document.querySelectorAll('.echo-pad'));
  var statusEl=document.getElementById('echo-status'), subEl=document.getElementById('echo-sub');
  var startBtn=document.getElementById('echo-start'), endEl=document.getElementById('echo-end');
  var FREQ=[329.6,392.0,493.9,587.3];
  var seq=[], userIdx=0, level=0, best=0, accepting=false, t0=0, ac=null, mistakes=0;
  var MAX_MISTAKES=2; // deux chances tolérées ; la 3e erreur termine la partie

  function beep(i,dur){
    try{ if(!ac) ac=new (window.AudioContext||window.webkitAudioContext)();
      var o=ac.createOscillator(), g=ac.createGain();
      o.frequency.value=FREQ[i]; o.type='sine'; o.connect(g); g.connect(ac.destination);
      g.gain.setValueAtTime(0.0001,ac.currentTime); g.gain.exponentialRampToValueAtTime(0.14,ac.currentTime+0.02);
      g.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+(dur||0.35));
      o.start(); o.stop(ac.currentTime+(dur||0.35));
    }catch(e){}
  }
  function light(i,dur){ var p=pads[i]; p.classList.add('on'); beep(i,dur/1000);
    setTimeout(function(){ p.classList.remove('on'); }, dur*0.8); }

  function playSeq(){
    accepting=false; pads.forEach(function(p){p.classList.add('lock');});
    statusEl.textContent='Regarde bien…'; subEl.textContent='Séquence de '+seq.length;
    var step=Math.max(360, 620-level*20), t=500;
    seq.forEach(function(idx){ setTimeout(function(){ light(idx,step*0.7); }, t); t+=step; });
    setTimeout(function(){ accepting=true; userIdx=0; pads.forEach(function(p){p.classList.remove('lock');});
      statusEl.textContent='À toi !'; subEl.textContent='Répète la séquence'; }, t+120);
  }
  function nextRound(){ level++; seq.push(Math.floor(Math.random()*4)); playSeq(); }

  function press(i){
    if(!accepting) return;
    light(i,240);
    if(i===seq[userIdx]){
      userIdx++;
      if(userIdx===seq.length){ best=Math.max(best,seq.length); accepting=false;
        statusEl.textContent='Bien joué !'; subEl.textContent='On allonge…';
        setTimeout(nextRound, 720);
      }
    } else {
      mistakes++;
      if(mistakes<=MAX_MISTAKES){
        accepting=false;
        statusEl.textContent = mistakes===1 ? 'Pas tout à fait — on retente.' : 'Encore une fois — dernière chance.';
        subEl.textContent = (MAX_MISTAKES-mistakes+1)+' chance(s) restante(s)';
        setTimeout(playSeq, 900);
      } else {
        accepting=false; finish();
      }
    }
  }
  pads.forEach(function(p){ p.addEventListener('click', function(){ press(parseInt(p.getAttribute('data-i'),10)); }); });

  function finish(){
    pads.forEach(function(p){p.classList.add('lock');});
    var span=best; // plus longue séquence reproduite
    statusEl.textContent='Séance terminée';
    subEl.textContent='';
    startBtn.textContent='Rejouer'; startBtn.style.display='block';
    if(window.MDExercise){
      MDExercise.after('echo',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{span:span,niveau:level},
        title:'Écho', stats:[{label:'séquence atteinte',value:span}],
        nav:{ primary:{label:'Rejouer'} },
        onClose:function(){ window.__mdAvant=null; runGame(); }});
    } else if(window.MDData){ MDData.logSession('echo',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ span:span, niveau:level } }); }
  }

  function begin(){
    endEl.innerHTML='';
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:'Écho',
        lines:['Le compagnon allume des couleurs, une par une.',
               'Quand c\u2019est ton tour, touche les mêmes couleurs, dans le même ordre.',
               'À chaque réussite, la suite s\u2019allonge d\u2019un cran.'],
        why:'Retenir puis restituer une séquence entra\u00eene la mémoire de travail — la m\u00eame ressource qui aide \u00e0 r\u00e9sister \u00e0 une impulsion en gardant ton objectif en t\u00eate.',
        onStart:function(avant){ window.__mdAvant=avant; runGame(); } });
    } else { runGame(); }
  }
  function runGame(){ seq=[]; level=0; best=0; userIdx=0; mistakes=0; t0=Date.now();
    startBtn.style.display='none'; endEl.innerHTML=''; setTimeout(nextRound, 300); }

  startBtn.addEventListener('click', begin);
  try{ MDCore.init({page:'echo',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
