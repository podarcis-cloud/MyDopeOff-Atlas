/* MyDope Off — page-echo.js
   Logique de echo, extraite du script inline de echo.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var T = {
    watch:{fr:'Regarde bien…',en:'Watch closely…'},
    seq_of:{fr:'Séquence de ',en:'Sequence of '},
    your_turn:{fr:'À toi !',en:'Your turn!'},
    repeat_seq:{fr:'Répète la séquence',en:'Repeat the sequence'},
    well_played:{fr:'Bien joué !',en:'Well played!'},
    lengthening:{fr:'On allonge…',en:'Making it longer…'},
    not_quite:{fr:'Pas tout à fait — on retente.',en:'Not quite — let\u2019s try again.'},
    once_more:{fr:'Encore une fois — dernière chance.',en:'One more time — last chance.'},
    chances_left:{fr:' chance(s) restante(s)',en:' chance(s) left'},
    session_done:{fr:'Séance terminée',en:'Session complete'},
    title:{fr:'Écho',en:'Echo'},
    stat_span:{fr:'séquence atteinte',en:'sequence reached'},
    replay:{fr:'Rejouer',en:'Replay'},
    rules_l1:{fr:'Le compagnon allume des couleurs, une par une.',en:'The companion lights up colours, one by one.'},
    rules_l2:{fr:'Quand c\u2019est ton tour, touche les mêmes couleurs, dans le même ordre.',en:'When it\u2019s your turn, tap the same colours, in the same order.'},
    rules_l3:{fr:'À chaque réussite, la suite s\u2019allonge d\u2019un cran.',en:'Each success makes the sequence one step longer.'},
    rules_why:{fr:'Retenir puis restituer une séquence entraîne la mémoire de travail — la même ressource qui aide à résister à une impulsion en gardant ton objectif en tête.',
      en:'Remembering then repeating a sequence trains working memory \u2014 the same resource that helps you resist an impulse by keeping your goal in mind.'},
    'game.back_labo':{fr:'Retour au Labo',en:'Back to Lab'},
    'game.labo_badge':{fr:'Labo',en:'Lab'},
    'echo.title':{fr:'Écho',en:'Echo'},
    'echo.subtitle':{fr:'Retiens la séquence, puis reproduis-la. Ta mémoire de travail s\u2019entraîne.',en:'Remember the sequence, then reproduce it. Your working memory is training.'},
    'echo.ready':{fr:'Prêt·e ?',en:'Ready?'},
    'echo.ready_sub':{fr:'Le compagnon va jouer une suite de couleurs. À toi de la répéter.',en:'The companion is about to play a sequence of colours. Your job is to repeat it.'}
  };
  function t(k){ var e=T[k]; return e ? (L==='en'?e.en:e.fr) : k; }
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(T).forEach(function(k){ if(k.indexOf('.')>-1 && !window.MD_DICT[k]) window.MD_DICT[k] = { fr:T[k].fr, en:T[k].en }; });

  var pads=[].slice.call(document.querySelectorAll('.echo-pad'));
  var statusEl=document.getElementById('echo-status'), subEl=document.getElementById('echo-sub');
  var endEl=document.getElementById('echo-end');
  var FREQ=[329.6,392.0,493.9,587.3];
  var seq=[], userIdx=0, level=0, best=0, accepting=false, t0=0, ac=null, mistakes=0;
  var MAX_MISTAKES=2; // deux chances tolérées ; la 3e erreur termine la partie

  function beep(i,dur){
    try{ if(!ac) ac=new (window.AudioContext||window.webkitAudioContext)();
      var o=ac.createOscillator(), g=ac.createGain();
      o.frequency.value=FREQ[i]; o.type='sine'; o.connect(g); g.connect(ac.destination);
      g.gain.setValueAtTime(0.0001,ac.currentTime); g.gain.exponentialRampToValueAtTime(0.14,ac.currentTime+0.02);
      g.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+(dur||0.35));
      o.start(); o.stop(ac.currentTime+(dur||0.35));
    }catch(e){}
  }
  function light(i,dur){ var p=pads[i]; p.classList.add('on'); beep(i,dur/1000);
    setTimeout(function(){ p.classList.remove('on'); }, dur*0.8); }

  function playSeq(){
    accepting=false; pads.forEach(function(p){p.classList.add('lock');});
    statusEl.textContent=t('watch'); subEl.textContent=t('seq_of')+seq.length;
    var step=Math.max(360, 620-level*20), t2=500;
    seq.forEach(function(idx){ setTimeout(function(){ light(idx,step*0.7); }, t2); t2+=step; });
    setTimeout(function(){ accepting=true; userIdx=0; pads.forEach(function(p){p.classList.remove('lock');});
      statusEl.textContent=t('your_turn'); subEl.textContent=t('repeat_seq'); }, t2+120);
  }
  function nextRound(){ level++; seq.push(Math.floor(Math.random()*4)); playSeq(); }

  function press(i){
    if(!accepting) return;
    light(i,240);
    if(i===seq[userIdx]){
      userIdx++;
      if(userIdx===seq.length){ best=Math.max(best,seq.length); accepting=false;
        statusEl.textContent=t('well_played'); subEl.textContent=t('lengthening');
        setTimeout(nextRound, 720);
      }
    } else {
      mistakes++;
      if(mistakes<=MAX_MISTAKES){
        accepting=false;
        statusEl.textContent = mistakes===1 ? t('not_quite') : t('once_more');
        subEl.textContent = (MAX_MISTAKES-mistakes+1)+t('chances_left');
        setTimeout(playSeq, 900);
      } else {
        accepting=false; finish();
      }
    }
  }
  pads.forEach(function(p){ p.addEventListener('click', function(){ press(parseInt(p.getAttribute('data-i'),10)); }); });

  function finish(){
    pads.forEach(function(p){p.classList.add('lock');});
    var span=best; // plus longue séquence reproduite
    statusEl.textContent=t('session_done');
    subEl.textContent='';
    if(window.MDExercise){
      MDExercise.after('echo',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{span:span,niveau:level},
        title:t('title'), stats:[{label:t('stat_span'),value:span}],
        nav:{ primary:{label:t('replay')} },
        onClose:function(){ window.__mdAvant=null; runGame(); }});
    } else if(window.MDData){ MDData.logSession('echo',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ span:span, niveau:level } }); }
  }

  function begin(){
    endEl.innerHTML='';
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; runGame(); } });
    } else { runGame(); }
  }
  function runGame(){ seq=[]; level=0; best=0; userIdx=0; mistakes=0; t0=Date.now();
    endEl.innerHTML=''; setTimeout(nextRound, 300); }

  try{ MDCore.init({page:'echo',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
