/* parcours.js — Moteur « Mon Parcours » (100 % local).
   - recompute() : recalcule les 5 axes neurocognitifs (EMA asymétrique) + le Rythme depuis
     ctc_v6.sessions (déterministe, idempotent), écrit dans ctc_v6.parcours.
   - renderInto(el) : rend le hub (chapitre + rythme + carte à barres accessibles).
   - maybeReprise() : overlay de reprise douce après une absence (anti-honte).
   Dépend de MDData (data.js). Expose window.MDParcours. */
window.MDParcours = (function () {
  var _newly = [], _adv = false;
  var CHAPITRES = [
    { n: 1, t: 'Reprendre pied' }, { n: 2, t: 'Traverser les pics' },
    { n: 3, t: 'Détourner l\u2019esprit' }, { n: 4, t: 'Renforcer le frein' },
    { n: 5, t: 'Réorienter le regard' }, { n: 6, t: 'Devenir' }, { n: 7, t: 'Entretien' }
  ];
  var AXES = [
    { k: 'inhib', t: 'Contrôle inhibiteur' }, { k: 'emo', t: 'Résilience émotionnelle' },
    { k: 'attn', t: 'Attention' }, { k: 'envies', t: 'Gestion des envies' },
    { k: 'stab', t: 'Stabilité comportementale' }
  ];
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function norm(x, a, b) { return clamp((x - a) / (b - a), 0, 1); }

  /* Jalons (M5) — conditions d'EXPÉRIENCE/compétence, jamais « N séances » (anti-grind).
     cond(ctx) où ctx = { ss:sessions, ax:axes, p:parcours, days:nbJoursActifs }. */
  function joursActifs(ss) { var d = {}; ss.forEach(function (s) { d[Math.floor((s.date || 0) / 86400000)] = 1; }); return Object.keys(d).length; }
  function nbType(ss, t) { return ss.filter(function (s) { return s.type === t; }).length; }
  var JALONS = [
    { id: 'ch1_scan', ch: 1, key: true, label: 'Faire une première séance', cond: function (c) { return c.ss.length >= 1; } },
    { id: 'ch1_mesure', ch: 1, key: true, label: 'Mesurer une envie avant/après', cond: function (c) { return c.ss.some(function (s) { return s.envieAvant != null && s.envieApres != null; }); } },
    { id: 'ch1_3jours', ch: 1, key: true, label: 'Revenir sur 3 jours différents', cond: function (c) { return c.days >= 3; } },
    { id: 'ch2_surf', ch: 2, key: true, label: 'Traverser un pic (urge surfing)', cond: function (c) { return nbType(c.ss, 'surf') >= 1; } },
    { id: 'ch2_envies', ch: 2, key: true, label: 'Gestion des envies dépasse 40', cond: function (c) { return c.ax.envies >= 40; } },
    { id: 'ch2_urgence', ch: 2, key: false, label: 'Utiliser le mode urgence', cond: function (c) { return nbType(c.ss, 'urgence') >= 1; } },
    { id: 'ch3_attn', ch: 3, key: true, label: 'Attention dépasse 40', cond: function (c) { return c.ax.attn >= 40; } },
    { id: 'ch3_jeux', ch: 3, key: true, label: 'Détourner l\u2019esprit 5 fois', cond: function (c) { return nbType(c.ss, 'tetris') + nbType(c.ss, 'maze') >= 5; } },
    { id: 'ch4_frein', ch: 4, key: true, label: 'Entraîner le frein (Go/No-Go)', cond: function (c) { return nbType(c.ss, 'inhib') >= 1; } },
    { id: 'ch4_inhib', ch: 4, key: true, label: 'Contrôle inhibiteur dépasse 40', cond: function (c) { return c.ax.inhib >= 40; } },
    { id: 'ch6_valeurs', ch: 6, key: true, identity: true, label: 'Nommer qui tu veux être', cond: function (c) { return (c.p.valeurs || []).length >= 1; } },
    { id: 'ch6_lettre', ch: 6, key: true, label: 'Écrire à ton futur toi', cond: function (c) { return nbType(c.ss, 'lettre') >= 1; } }
  ];

  /* Scores de séance par axe (0–100) — mapping module -> axes (P6.4, version Lot 2). */
  function sessionScores(s) {
    var sc = {};
    var meta = s.meta || {};
    // contribution par le delta d'envie (toute séance mesurée)
    if (s.envieAvant != null && s.envieApres != null) {
      var dn = (s.envieAvant - s.envieApres) / Math.max(1, s.envieAvant); // -1..1
      sc.envies = clamp(50 + 50 * dn, 0, 100);
      sc.emo = clamp(40 + 60 * dn, 0, 100);
    }
    if (s.type === 'breathe') {
      var coh = (meta.coherence != null ? meta.coherence / 100 : 0.5);
      var comp = (s.dureeSec != null ? norm(s.dureeSec, 0, 180) : 0.5);
      sc.emo = Math.max(sc.emo || 0, clamp(100 * (0.5 * coh + 0.5 * comp), 0, 100));
    } else if (s.type === 'tetris') {
      sc.attn = clamp(100 * norm(meta.lines != null ? meta.lines : 6, 0, 30), 30, 100);
    } else if (s.type === 'maze') {
      sc.attn = Math.max(sc.attn || 0, 58); sc.stab = 55;
    } else if (s.type === 'surf') {
      sc.envies = Math.max(sc.envies || 0, 60); sc.stab = 50;
    } else if (s.type === 'lettre') {
      sc.stab = 56;
    } else if (s.type === 'inhib') {
      sc.inhib = clamp(100 * (0.6 * (meta.justesse || 0.6) + 0.4 * (1 - norm(meta.ssrt || 450, 200, 600))), 0, 100);
    } else if (s.type === 'identite') {
      sc.stab = 62;  // affirmer ses valeurs ancre le sens / la stabilité
    }
    // toute séance active nourrit un peu la stabilité comportementale
    if (sc.stab == null) sc.stab = 45;
    return sc;
  }

  function recompute() {
    var o = (window.MDData ? window.MDData.getCtc() : (function(){try{return JSON.parse(localStorage.getItem('ctc_v6')||'{}');}catch(e){return {};}})());
    var sessions = (Array.isArray(o.sessions) ? o.sessions : []).slice()
      .sort(function (a, b) { return (a.date || 0) - (b.date || 0); });
    var axes = { inhib: 0, emo: 0, attn: 0, envies: 0, stab: 0 };
    sessions.forEach(function (s) {
      var sc = sessionScores(s);
      for (var k in sc) {
        if (axes[k] == null) continue;
        var eta = (sc[k] >= axes[k]) ? 0.18 : 0.06;        // monte vite, descend lentement
        axes[k] = clamp((1 - eta) * axes[k] + eta * sc[k], 0, 100);
      }
    });
    // Rythme : déterministe depuis les jours actifs (P6.6)
    var rythme = 0.3, lastDay = 0;
    var days = {};
    sessions.forEach(function (s) { days[Math.floor((s.date || 0) / 86400000)] = 1; });
    Object.keys(days).map(Number).sort(function (a, b) { return a - b; }).forEach(function (d) {
      var gap = lastDay ? (d - lastDay) : 0;
      rythme = clamp(rythme - 0.03 * gap + 0.15, 0.1, 1);
      lastDay = d;
    });
    if (lastDay) {
      var gapNow = Math.floor(Date.now() / 86400000) - lastDay;
      if (gapNow > 0) rythme = clamp(rythme - 0.03 * gapNow, 0.1, 1);
    }
    var p = o.parcours || {};
    p.schemaVersion = p.schemaVersion || 1;
    p.chapitre = p.chapitre || 1;
    p.jalonsFaits = p.jalonsFaits || [];
    p.valeurs = p.valeurs || []; p.identite = p.identite || [];
    p.axes = { inhib: Math.round(axes.inhib), emo: Math.round(axes.emo), attn: Math.round(axes.attn), envies: Math.round(axes.envies), stab: Math.round(axes.stab) };
    p.rythme = Math.round(rythme * 100) / 100;
    p.dernierJourActif = lastDay ? lastDay * 86400000 : (p.dernierJourActif || 0);
    // historique échantillonné (comparaison radar « il y a 4 semaines »), throttle 6 h, max 60
    p.axesHist = Array.isArray(p.axesHist) ? p.axesHist : [];
    var lastH = p.axesHist[p.axesHist.length - 1];
    if (!lastH || (Date.now() - (lastH.ts || 0)) > 21600000) {
      p.axesHist.push({ ts: Date.now(), inhib: p.axes.inhib, emo: p.axes.emo, attn: p.axes.attn, envies: p.axes.envies, stab: p.axes.stab });
      if (p.axesHist.length > 60) p.axesHist = p.axesHist.slice(-60);
    }
    o.parcours = p;
    // Jalons (M5) : détecter les franchissements + avancer le chapitre
    _newly = []; _adv = false;
    p.jalonsFaits = Array.isArray(p.jalonsFaits) ? p.jalonsFaits : [];
    var ctx = { ss: sessions, ax: p.axes, p: p, days: joursActifs(sessions) };
    JALONS.forEach(function (j) { if (p.jalonsFaits.indexOf(j.id) < 0 && j.cond(ctx)) { p.jalonsFaits.push(j.id); _newly.push(j); } });
    var ch = p.chapitre || 1, kj = JALONS.filter(function (j) { return j.ch === ch && j.key; });
    if (kj.length && kj.every(function (j) { return p.jalonsFaits.indexOf(j.id) >= 0; }) && ch < 7) { p.chapitre = ch + 1; _adv = true; }
    if (window.MDData) window.MDData.write(o); else { try{localStorage.setItem('ctc_v6', JSON.stringify(o));}catch(e){} }
    return p;
  }
  function prochaineMarche(p) {
    var ch = p.chapitre || 1, faits = p.jalonsFaits || [];
    var next = JALONS.filter(function (j) { return j.ch === ch && faits.indexOf(j.id) < 0; })[0]
      || JALONS.filter(function (j) { return faits.indexOf(j.id) < 0; })[0];
    return next ? next.label : null;
  }
  function showMilestone(j, adv, p) {
    inject();
    var ov = el('div', 'mdp-ov'); var card = el('div', 'mdp-card');
    card.appendChild(el('p', 'mdp-q', adv ? 'Chapitre franchi' : 'Étape franchie'));
    card.appendChild(el('p', 'mdp-msg', adv
      ? ('Tu entres dans : ' + CHAPITRES[clamp((p.chapitre || 1) - 1, 0, CHAPITRES.length - 1)].t + '. Regarde le chemin parcouru.')
      : ('\u00AB ' + (j ? j.label : 'Une étape') + ' \u00BB \u2014 c\u2019est une preuve comportementale, pas un hasard.')));
    if (j && j.identity) {
      var aff = el('button', 'mdp-go', 'Affirmer qui je deviens'); aff.type = 'button';
      aff.onclick = function () { if (ov.parentNode) ov.parentNode.removeChild(ov); if (window.MDIdentite) window.MDIdentite.open(); };
      card.appendChild(aff);
      var sk = el('button', 'mdp-go', 'Plus tard'); sk.type = 'button'; sk.style.cssText = 'background:none;color:var(--ink-2,#58635E);text-decoration:underline;padding:8px';
      sk.onclick = function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }; card.appendChild(sk);
    } else {
      var go = el('button', 'mdp-go', 'Continuer'); go.type = 'button'; go.onclick = function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }; card.appendChild(go);
    }
    ov.appendChild(card); document.body.appendChild(ov); if (window.MDDecor) window.MDDecor.into(ov, { dots: true });
  }

  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  function renderInto(host) {
    if (!host) return;
    inject();
    var p = recompute();
    var sessions = window.MDData ? window.MDData.getSessions() : [];
    var total = sessions.length;
    var week = sessions.filter(function (s) { return Date.now() - (s.date || 0) <= 604800000; }).length;
    var chap = CHAPITRES[clamp((p.chapitre || 1) - 1, 0, CHAPITRES.length - 1)];
    host.innerHTML = '';

    // En-tête : chapitre + rythme
    var head = el('div', 'mdp-head');
    head.appendChild(el('div', 'mdp-chap', 'Chapitre ' + chap.n + ' \u00B7 ' + chap.t));
    var ry = el('div', 'mdp-rythme');
    ry.appendChild(el('span', 'mdp-rythme-lbl', 'Rythme'));
    var bar = el('span', 'mdp-rythme-bar'); var fill = el('span', 'mdp-rythme-fill');
    fill.style.width = Math.round((p.rythme || 0.1) * 100) + '%'; bar.appendChild(fill); ry.appendChild(bar);
    head.appendChild(ry);
    host.appendChild(head);

    // Compteur reformulé (sobre, pas culpabilisant)
    var sub = el('div', 'mdp-sub', total === 0
      ? 'Lance un exercice : ta carte se construit séance après séance.'
      : (total + ' séance' + (total > 1 ? 's' : '') + ' \u00B7 ' + week + ' cette semaine'));
    host.appendChild(sub);

    // Prochaine marche (jalon courant, M5) — oriente sans culpabiliser
    var pm = prochaineMarche(p);
    if (pm) { var marche = el('div', 'mdp-marche'); marche.innerHTML = '<span>Prochaine marche</span> ' + pm; host.appendChild(marche); }

    // Action première : « Faire une séance » -> Scanner (M1) qui route vers le bon exercice
    if (window.MDScanner) {
      var faire = el('button', 'mdp-faire', '\u25B6  Faire une séance'); faire.type = 'button';
      faire.onclick = function () { window.MDScanner.open(); };
      host.appendChild(faire);
      host.appendChild(el('div', 'mdp-pick', 'ou choisis un exercice ci-dessous'));
    }

    // Carte neurocognitive — vue barres (accessible : libellé + chiffre) ; tap -> radar détaillé
    var carte = el('div', 'mdp-carte');
    carte.setAttribute('role', 'button'); carte.setAttribute('tabindex', '0');
    carte.onclick = function () { openRadar(); };
    var ct = el('div', 'mdp-carte-t', 'Ma carte neurocognitive');
    ct.appendChild(el('span', 'mdp-detail', 'détail \u203A'));
    carte.appendChild(ct);
    AXES.forEach(function (a) {
      var v = (p.axes && p.axes[a.k] != null) ? p.axes[a.k] : 0;
      var row = el('div', 'mdp-axe');
      row.appendChild(el('span', 'mdp-axe-lbl', a.t));
      var track = el('span', 'mdp-axe-track'); var f = el('span', 'mdp-axe-fill');
      f.style.width = v + '%'; track.appendChild(f); row.appendChild(track);
      row.appendChild(el('span', 'mdp-axe-val', String(v)));
      carte.appendChild(row);
    });
    carte.appendChild(el('div', 'mdp-note', 'Indicateurs de soutien \u00B7 ne remplace pas un avis médical.'));
    host.appendChild(carte);

    // Jalon(s) franchi(s) pendant la séance précédente -> célébration sobre (M5)
    if (_newly.length || _adv) {
      var jal = _newly.length ? _newly[_newly.length - 1] : null, adv = _adv;
      _newly = []; _adv = false;
      setTimeout(function () { showMilestone(jal, adv, p); }, 450);
    }
  }

  /* Reprise douce : après une absence (>= 3 jours) avec un historique existant. */
  function maybeReprise() {
    try {
      var o = window.MDData ? window.MDData.getCtc() : JSON.parse(localStorage.getItem('ctc_v6') || '{}');
      var p = o.parcours || {}; var last = p.dernierJourActif || 0;
      if (!last || !(o.sessions && o.sessions.length)) return;
      var gapDays = Math.floor((Date.now() - last) / 86400000);
      if (gapDays < 3) return;
      if (sessionFlag('mdp_reprise_seen')) return;     // une fois par session de navigation
      setFlag('mdp_reprise_seen');
      inject();
      var ov = el('div', 'mdp-ov'); var card = el('div', 'mdp-card');
      card.appendChild(el('p', 'mdp-q', 'Content de te revoir.'));
      card.appendChild(el('p', 'mdp-msg', 'Ça arrive. On reprend tranquillement \u2014 ta progression est intacte.'));
      var go = el('button', 'mdp-go', 'Une petite marche'); go.type = 'button';
      go.onclick = function () { if (ov.parentNode) ov.parentNode.removeChild(ov); };
      card.appendChild(go); ov.appendChild(card); document.body.appendChild(ov); if (window.MDDecor) window.MDDecor.into(ov, { dots: true, arc: true });
    } catch (e) { }
  }
  function sessionFlag(k) { try { return sessionStorage.getItem(k) === '1'; } catch (e) { return false; } }
  function setFlag(k) { try { sessionStorage.setItem(k, '1'); } catch (e) { } }

  var INJ = false;
  function svgEl(tag, attrs) { var e = document.createElementNS('http://www.w3.org/2000/svg', tag); for (var k in attrs) e.setAttribute(k, attrs[k]); return e; }
  function radarPoint(cx, cy, R, i, n, val) { var ang = (-90 + 360 / n * i) * Math.PI / 180; var r = R * (val / 100); return [cx + r * Math.cos(ang), cy + r * Math.sin(ang)]; }
  function openRadar() {
    inject();
    var p = recompute(); var axes = p.axes || { inhib: 0, emo: 0, attn: 0, envies: 0, stab: 0 };
    var keys = AXES.map(function (a) { return a.k; });
    var ov = el('div', 'mdp-radov');
    var head = el('div', 'mdp-radhead'); head.appendChild(el('div', 'mdp-radh', 'Ma carte neurocognitive'));
    var x = el('button', 'mdp-radx', 'Fermer'); x.type = 'button'; x.onclick = function () { if (ov.parentNode) ov.parentNode.removeChild(ov); };
    head.appendChild(x); ov.appendChild(head);
    ov.appendChild(el('div', 'mdp-radsub', 'Indicateurs de soutien \u2014 une tendance, pas un diagnostic.'));
    var N = AXES.length, S = 300, cx = S / 2, cy = S / 2 + 4, R = 104, i, pt;
    var svg = svgEl('svg', { 'class': 'mdp-radsvg', width: S, height: S, viewBox: '0 0 ' + S + ' ' + S });
    [25, 50, 75, 100].forEach(function (g) {
      var pts = ''; for (var i = 0; i < N; i++) { var q = radarPoint(cx, cy, R, i, N, g); pts += q[0].toFixed(1) + ',' + q[1].toFixed(1) + ' '; }
      svg.appendChild(svgEl('polygon', { points: pts.trim(), fill: 'none', stroke: '#E2DCD0', 'stroke-width': g === 100 ? 1.4 : 1 }));
    });
    for (i = 0; i < N; i++) {
      var pe = radarPoint(cx, cy, R, i, N, 100);
      svg.appendChild(svgEl('line', { x1: cx, y1: cy, x2: pe[0].toFixed(1), y2: pe[1].toFixed(1), stroke: '#E2DCD0', 'stroke-width': 1 }));
      var pl = radarPoint(cx, cy, R + 18, i, N, 100);
      var t = svgEl('text', { x: pl[0].toFixed(1), y: pl[1].toFixed(1), 'text-anchor': 'middle', 'dominant-baseline': 'middle', 'font-size': '10', fill: '#58635E', 'font-family': 'Inter,sans-serif' });
      t.textContent = AXES[i].t.split(' ')[0]; svg.appendChild(t);
    }
    var hist = p.axesHist || [], past = null, target = Date.now() - 2419200000;
    for (var h = 0; h < hist.length; h++) { if (hist[h].ts <= target) past = hist[h]; }
    if (past) {
      var pp = ''; for (i = 0; i < N; i++) { pt = radarPoint(cx, cy, R, i, N, past[keys[i]] || 0); pp += pt[0].toFixed(1) + ',' + pt[1].toFixed(1) + ' '; }
      svg.appendChild(svgEl('polygon', { points: pp.trim(), fill: 'none', stroke: '#C9C2B4', 'stroke-width': 1.5, 'stroke-dasharray': '4 3' }));
    }
    var cp = ''; for (i = 0; i < N; i++) { pt = radarPoint(cx, cy, R, i, N, axes[keys[i]] || 0); cp += pt[0].toFixed(1) + ',' + pt[1].toFixed(1) + ' '; }
    svg.appendChild(svgEl('polygon', { points: cp.trim(), fill: 'rgba(122,143,114,.32)', stroke: '#7A8F72', 'stroke-width': 2 }));
    ov.appendChild(svg);
    AXES.forEach(function (a) {
      var line = el('div', 'mdp-axline');
      var n = el('div', 'mdp-axn'); n.innerHTML = '<b style="background:#7A8F72"></b>' + a.t; line.appendChild(n);
      var d = el('div', 'mdp-axd');
      if (past && past[a.k] != null) { var dv = (axes[a.k] || 0) - past[a.k]; d.innerHTML = dv > 0 ? ('<span class="up">+' + dv + ' / 4 sem.</span>') : (dv < 0 ? ('<span class="dn">' + dv + ' / 4 sem.</span>') : 'stable'); }
      line.appendChild(d); line.appendChild(el('div', 'mdp-axv', String(axes[a.k] || 0)));
      ov.appendChild(line);
    });
    if (window.MDDecor) { window.MDDecor.into(ov, { dots: false }); for (var qi = 0; qi < ov.children.length; qi++) { var ch = ov.children[qi]; if (ch.className !== 'atlas-decor') { ch.style.position = 'relative'; ch.style.zIndex = '1'; } } }
    document.body.appendChild(ov);
  }

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdp-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:2px 0 6px}' +
      '.mdp-chap{font-family:var(--title,Newsreader,serif);font-size:17px;color:var(--ink,#1F2B25)}' +
      '.mdp-rythme{display:flex;align-items:center;gap:6px}' +
      '.mdp-rythme-lbl{font-family:var(--ui,Inter,sans-serif);font-size:11px;color:var(--ink-2,#58635E)}' +
      '.mdp-rythme-bar{display:inline-block;width:54px;height:7px;border-radius:5px;background:var(--line,#E2DCD0);overflow:hidden}' +
      '.mdp-rythme-fill{display:block;height:100%;background:var(--ocre,#D5A84A);border-radius:5px}' +
      '.mdp-sub{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13px;color:var(--ink-2,#58635E);margin-bottom:12px}' +
      '.mdp-marche{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13px;color:var(--ink,#1F2B25);background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-left:3px solid var(--ocre,#D5A84A);border-radius:10px;padding:9px 12px;margin-bottom:12px}' +
      '.mdp-marche span{display:block;font-family:var(--ui,Inter,sans-serif);font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink-2,#58635E);margin-bottom:1px}' +
      '.mdp-faire{width:100%;border:none;border-radius:14px;background:var(--foret,#33463E);color:#fff;font-family:var(--ui,Inter,sans-serif);font-weight:700;font-size:15px;padding:14px;cursor:pointer;margin:2px 0 6px;-webkit-tap-highlight-color:transparent}' +
      '.mdp-pick{text-align:center;font-size:12px;color:var(--ink-2,#58635E);margin-bottom:14px}' +
      '.mdp-carte{background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:16px;padding:14px 14px 10px;margin-bottom:14px}' +
      '.mdp-carte-t{font-family:var(--ui,Inter,sans-serif);font-weight:700;font-size:13px;color:var(--ink,#1F2B25);margin-bottom:10px}' +
      '.mdp-axe{display:flex;align-items:center;gap:10px;margin-bottom:9px}' +
      '.mdp-axe-lbl{flex:0 0 42%;font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:12.5px;color:var(--ink,#1F2B25)}' +
      '.mdp-axe-track{flex:1;height:9px;border-radius:6px;background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);overflow:hidden}' +
      '.mdp-axe-fill{display:block;height:100%;background:var(--sauge,#7A8F72);border-radius:6px}' +
      '.mdp-axe-val{flex:0 0 26px;text-align:right;font-family:var(--ui,Inter,sans-serif);font-weight:700;font-size:12.5px;color:var(--ink-2,#58635E)}' +
      '.mdp-note{font-size:10.5px;color:var(--ink-2,#58635E);margin-top:4px}' +
      '.mdp-ov{position:fixed;inset:0;z-index:4000;display:flex;align-items:center;justify-content:center;padding:22px;background:rgba(31,43,37,.5);font-family:var(--ui,Inter,sans-serif)}' +
      '.mdp-card{position:relative;z-index:1;background:var(--surface,#fff);color:var(--ink,#1F2B25);border-radius:18px;max-width:340px;width:100%;padding:22px;text-align:center;box-shadow:0 18px 50px rgba(31,43,37,.25)}' +
      '.mdp-q{font-family:var(--title,Newsreader,serif);font-size:20px;margin:0 0 6px}' +
      '.mdp-msg{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14.5px;margin:0 0 16px}' +
      '.mdp-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:700;font-size:15px;padding:13px;cursor:pointer}' +
      '.mdp-carte{cursor:pointer}.mdp-detail{float:right;font-size:11px;color:var(--fjord,#69889A);font-weight:700}' +
      '.mdp-radov{position:fixed;inset:0;z-index:4100;background:var(--bg,#F5F2EA);overflow-y:auto;font-family:var(--ui,Inter,sans-serif);padding:20px}' +
      '.mdp-radhead{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}' +
      '.mdp-radh{font-family:var(--title,Newsreader,serif);font-size:22px;color:var(--ink,#1F2B25)}' +
      '.mdp-radx{background:none;border:none;font-size:14px;color:var(--ink-2,#58635E);cursor:pointer;text-decoration:underline}' +
      '.mdp-radsub{font-size:12.5px;color:var(--ink-2,#58635E);margin-bottom:6px}' +
      '.mdp-axline{display:flex;align-items:center;gap:8px;margin:8px 0;padding:0 2px}' +
      '.mdp-axn{flex:1;font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13px;color:var(--ink,#1F2B25)}' +
      '.mdp-axn b{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:6px;vertical-align:middle}' +
      '.mdp-axd{flex:0 0 78px;text-align:right;font-size:11.5px}.mdp-axd .up{color:var(--sauge,#7A8F72)}.mdp-axd .dn{color:var(--terra,#C7765C)}' +
      '.mdp-axv{flex:0 0 28px;text-align:right;font-weight:700;font-size:14px;color:var(--ink,#1F2B25)}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  return { recompute: recompute, renderInto: renderInto, maybeReprise: maybeReprise, openRadar: openRadar, CHAPITRES: CHAPITRES, AXES: AXES };
})();
