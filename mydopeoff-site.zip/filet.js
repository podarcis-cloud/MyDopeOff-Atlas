/* MyDope Off — filet.js
   ============================================================================
   Filet de sécurité pour les textes libres (note du journal, lettre à son futur soi).
   Chapitre de référence : 42_ETHIQUE_CLINIQUE.md.

   Six règles, toutes contraignantes :

   1. Il DEMANDE, il n'affirme jamais. Le produit ne peut pas savoir si quelqu'un va mal.
      Il peut seulement remarquer un mot et proposer. Toute formulation qui affirmerait un
      état (« tu traverses une crise ») diagnostiquerait — ce que le produit ne fait jamais.
   2. Il ne bloque rien. L'entrée est déjà enregistrée quand il apparaît. Il n'interrompt
      aucune action, ne verrouille rien, et se ferme d'un geste.
   3. Il ne change pas de ton. Principe de proportionnalité (ch. 23) : l'intensité décrit une
      proximité, jamais une alarme. Aucun rouge, aucune icône d'alerte, aucune majuscule,
      aucun point d'exclamation. La teinte est celle de la famille rose — « les moments où la
      personne est la moins protégée » — jamais une couleur de gravité.
   4. Il sur-détecte plutôt que de sous-détecter (protocole Woebot). Coût d'un faux positif :
      une phrase ignorée. Coût d'un faux négatif : irréversible. La sur-détection impose la
      règle 1 : puisqu'on se trompe souvent, on ne peut jamais affirmer.
   5. Il ne stocke ni ne transmet rien. Aucun compteur, aucune donnée dérivée, aucun appel
      réseau. L'anti-répétition vit dans une variable de module : elle meurt avec la page.
   6. Il propose une ressource réelle et locale. Mesuré le 11/08/2026 : seules 4 régions sur
      21 déclarent une ligne de prévention du suicide (BE, FR, CA, NL). D'où la cascade
      ci-dessous — mieux vaut une ligne d'écoute réelle qu'un numéro d'un autre pays.
   ============================================================================ */
(function (global) {
  'use strict';

  /* Motifs de détresse. Volontairement larges (règle 4) : « j'en peux plus » est le plus
     souvent bénin, et c'est très bien ainsi. On travaille sur du texte normalisé (minuscules,
     sans accents) pour ne pas manquer une graphie. */
  var SIGNAUX = [
    // français
    'me tuer', 'me suicider', 'suicide', 'suicidaire', 'en finir', 'en terminer',
    'plus envie de vivre', 'envie de mourir', 'veux mourir', 'veux plus vivre',
    'plus vivre', 'disparaitre', 'me faire disparaitre', 'plus la force',
    'jen peux plus', 'j en peux plus', 'peux plus continuer', 'a quoi bon',
    'sert a rien', 'me faire du mal', 'me scarifier', 'me couper',
    'personne ne me manquerait', 'mieux sans moi', 'tout arreter definitivement',
    'derniere fois que jecris', 'derniere lettre',
    // anglais
    'kill myself', 'end my life', 'end it all', 'want to die', 'wanna die',
    'dont want to live', 'do not want to live', 'no point living', 'whats the point',
    'hurt myself', 'harm myself', 'cut myself', 'better off without me',
    'cant go on', 'can not go on', 'suicidal', 'last letter'
  ];

  var affiche = false;   // anti-répétition, portée page — jamais écrit sur disque

  function normalise(txt) {
    return String(txt || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')   // sans accents
      .replace(/['’`]/g, '')                              // apostrophes
      .replace(/\s+/g, ' ');
  }

  function detecte(txt) {
    var n = normalise(txt);
    if (n.length < 3) return false;
    for (var i = 0; i < SIGNAUX.length; i++) if (n.indexOf(SIGNAUX[i]) !== -1) return true;
    return false;
  }

  function lang() {
    try { return (global.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; }
  }

  function tr(o) { return o[lang()] || o.fr; }

  /* Ressource locale, en cascade : ligne de prévention → écoute → info drogues.
     Retourne null si la région ne déclare rien d'utilisable : on renvoie alors vers les
     centres, qui existent pour toutes les régions couvertes. */
  function ressource() {
    try {
      var st = JSON.parse(localStorage.getItem('ctc_v6')) || {};
      var code = (st.user && st.user.region) || null;
      if (!code || !global.MDRegions || !MDRegions.get) return null;
      var r = MDRegions.get(code);
      if (!r || !r.emergency) return null;
      var ordre = ['suicide', 'ecoute', 'drogue'];
      for (var i = 0; i < ordre.length; i++) {
        for (var j = 0; j < r.emergency.length; j++) {
          if (r.emergency[j].kind === ordre[i] && r.emergency[j].tel) return r.emergency[j];
        }
      }
    } catch (e) {}
    return null;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function styles() {
    if (document.getElementById('mdfilet-css')) return;
    var st = document.createElement('style');
    st.id = 'mdfilet-css';
    /* Aucune valeur hors tokens.css. Rose = douceur et vulnérabilité (ch. 23), pas gravité. */
    st.textContent =
      '.mdfilet{position:relative;margin:14px 0 0;padding:14px 15px;border-radius:var(--r,16px);' +
        'background:var(--rose-50);border:1px solid var(--rose);' +
        'font-size:var(--fs-sm,14.5px);line-height:var(--lh-normal,1.5);color:var(--ink)}' +
      '.mdfilet h4{font-family:var(--font-editorial);font-size:var(--fs-body,16px);' +
        'font-weight:var(--w-medium,500);margin:0 0 6px;letter-spacing:var(--ls-title)}' +
      '.mdfilet p{margin:0 0 8px}' +
      '.mdfilet p:last-of-type{margin-bottom:0}' +
      '.mdfilet a{color:var(--rose-d);font-weight:var(--w-bold,700);text-decoration:underline}' +
      '.mdfilet-x{position:absolute;top:8px;right:10px;background:none;border:none;padding:4px 6px;' +
        'font-size:var(--fs-body,16px);line-height:1;color:var(--ink-2);cursor:pointer}';
    document.head.appendChild(st);
  }

  /* Le texte. Il ne dit jamais ce que la personne ressent — il dit ce que le produit a
     remarqué, et rappelle que ça ne veut peut-être rien dire. Il nomme aussi ce que le
     produit ne fait pas : rien ne part, personne n'est prévenu (ch. 42, limites visibles). */
  var T = {
    titre:   { fr: 'Juste au cas où', en: 'Just in case' },
    corps:   { fr: 'Un mot dans ce que tu viens d’écrire fait penser à un moment difficile. Ça ne veut peut-être rien dire — c’est toi qui sais, pas nous.',
               en: 'Something in what you just wrote reads like a hard moment. It may mean nothing at all — you know, we don’t.' },
    avec:    { fr: 'Si jamais ça compte : {lien} répond, sans que tu aies à expliquer quoi que ce soit.',
               en: 'If it does matter: {lien} will pick up, with nothing to explain.' },
    sans:    { fr: 'Si jamais ça compte, {lien} près de chez toi répondent, sans que tu aies à expliquer quoi que ce soit.',
               en: 'If it does matter, {lien} near you will pick up, with nothing to explain.' },
    centres: { fr: 'des lignes d’écoute', en: 'helplines' },
    rien:    { fr: 'Ce que tu écris ici ne part nulle part et personne n’est prévenu — jamais.',
               en: 'What you write here goes nowhere and nobody is alerted — ever.' },
    fermer:  { fr: 'Fermer', en: 'Close' }
  };

  /* check(texte, cible)
     - texte : la chaîne à examiner
     - cible : élément DOM sous lequel insérer l'encart
     Retourne true si l'encart a été affiché. */
  function check(texte, cible) {
    if (affiche || !cible || !detecte(texte)) return false;
    affiche = true;
    styles();

    var r = ressource();
    var ligne;
    if (r) {
      var href = (global.MDRegions && MDRegions.telHref) ? MDRegions.telHref(r.tel) : ('tel:' + r.tel);
      ligne = tr(T.avec).replace('{lien}',
        '<a href="' + esc(href) + '">' + esc(r.name) + ' · ' + esc(r.tel) + '</a>');
    } else {
      ligne = tr(T.sans).replace('{lien}',
        '<a href="rdr.html?tab=centres">' + esc(tr(T.centres)) + '</a>');
    }

    var box = document.createElement('div');
    box.className = 'mdfilet';
    box.setAttribute('role', 'note');
    box.innerHTML =
      '<button type="button" class="mdfilet-x" aria-label="' + esc(tr(T.fermer)) + '">×</button>' +
      '<h4>' + esc(tr(T.titre)) + '</h4>' +
      '<p>' + esc(tr(T.corps)) + '</p>' +
      '<p>' + ligne + '</p>' +
      '<p>' + esc(tr(T.rien)) + '</p>';
    box.querySelector('.mdfilet-x').addEventListener('click', function () {
      if (box.parentNode) box.parentNode.removeChild(box);
    });

    cible.appendChild(box);
    return true;
  }

  global.MDFilet = { check: check, detecte: detecte };
})(window);
