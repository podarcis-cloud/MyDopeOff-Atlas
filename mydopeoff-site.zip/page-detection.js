/* MyDope Off — page-detection.js · fenêtres de détection (salive/urine/sang)
   Usage unique vs régulier : l'usage régulier allonge surtout l'URINE
   (accumulation des métabolites), parfois la salive. Estimations + disclaimer. */
(function () {
  'use strict';
  function $(id){ return document.getElementById(id); }
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function det(){ return (window.MD_DETECTION||[]); }
  var usage='single';

  function fmtH(h){ if(h==null) return '—'; return h<24 ? (String(h).replace('.',',')+' h') : (Math.round(h/24)+' j'); }
  function fmtR(a){ return (a&&a.length===2) ? fmtH(a[0])+'\u2013'+fmtH(a[1]) : '\u2014'; }

  /* Usage régulier : prolonge la fenêtre (surtout urine). Cas particuliers + facteur de famille. */
  function adjUri(rec){
    var ur=rec.uri; if(!ur) return ur;
    if(usage!=='regular') return ur;
    var n=(rec.nom||'').toLowerCase(), f=rec.fam||'';
    if(/cannabis|thc|hhc|thcp|delta-9|cbn/.test(n)) return [Math.max(ur[0],2*24), 30*24];
    if(f==='benzodiazepine' || /diazépam|diazepam|clonazépam|clonazepam|valium|rivotril|alprazolam|xanax|lorazépam|nordazépam/.test(n)) return [ur[0], Math.max(ur[1],30*24)];
    if(/méthadone|methadone/.test(n)) return [ur[0], Math.max(ur[1],14*24)];
    if(/buprénorphine|buprenorphine|subutex|suboxone/.test(n)) return [ur[0], Math.max(ur[1],11*24)];
    if(/phénobarbital|phenobarbital|barbiturique/.test(n)) return [ur[0], Math.max(ur[1],21*24)];
    var k = (f==='opioide'||f==='stimulant'||f==='empathogene') ? 2 : (f==='dissociatif'?1.8:1.7);
    return [ur[0], Math.round(ur[1]*k)];
  }
  function adjSal(rec){
    var s=rec.sal; if(!s) return s;
    if(usage!=='regular') return s;
    var n=(rec.nom||'').toLowerCase();
    if(/cannabis|thc|hhc|thcp|delta-9/.test(n)) return [s[0], Math.max(s[1], 3*24)];
    return [s[0], Math.round(s[1]*1.3)];
  }

  function windowsHTML(rec){
    if(rec.detectable===false){
      return '<div class="s-row"><span class="s-key">Détection</span><span class="s-val">Non détecté en test de routine.</span></div>';
    }
    var sal=adjSal(rec), uri=adjUri(rec), blo=rec.blo;
    return '<div class="s-row"><span class="s-key">Salive</span><span class="s-val">~ '+fmtR(sal)+'</span></div>'+
      '<div class="s-row"><span class="s-key">Urine</span><span class="s-val">~ '+fmtR(uri)+(usage==='regular'?' <span class="muted xs">(usage régulier)</span>':'')+'</span></div>'+
      (blo?'<div class="s-row"><span class="s-key">Sang</span><span class="s-val">~ '+fmtR(blo)+'</span></div>':'')+
      (rec.note?'<div class="s-row"><span class="s-key">Note</span><span class="s-val">'+esc(rec.note)+'</span></div>':'');
  }
  function card(rec){
    var fam=rec.fam?'<span class="s-tag '+esc(rec.fam)+'">'+esc(rec.fam)+'</span>':'';
    return '<div class="s-card"><div class="s-card-head"><div class="s-card-name">'+esc(rec.nom)+'</div><div class="s-tags">'+fam+
      (rec.detectable===false?'<span class="s-tag" style="background:var(--ok-50);color:var(--ok)">non détecté</span>':'')+'</div></div>'+
      '<div class="s-card-body">'+windowsHTML(rec)+'</div>'+
      '<div class="s-footer">'+(rec.source?esc(String(rec.source).split('\u00b7')[0].trim()):'Estimation RDR')+'</div></div>';
  }

  function canonRec(q){
    if(!q) return null; q=q.trim().toLowerCase();
    var d=det();
    for(var i=0;i<d.length;i++){ if(d[i].nom.toLowerCase()===q || (d[i].aliases||[]).some(function(a){return a.toLowerCase()===q;})) return d[i]; }
    // via index global -> nom canonique -> detection
    var ix=(window.MD_SUBS_INDEX||[]); var canon=null;
    for(var j=0;j<ix.length;j++){ if(ix[j].n.toLowerCase()===q||(ix[j].a||[]).some(function(a){return a.toLowerCase()===q;})){ canon=ix[j].n; break; } }
    if(canon){ for(var k=0;k<d.length;k++){ if(d[k].nom.toLowerCase()===canon.toLowerCase()) return d[k]; } }
    return null;
  }

  function renderResult(q){
    var box=$('det-result'); if(!box) return;
    var rec=canonRec(q);
    if(!q){ box.innerHTML=''; return; }
    if(rec){ box.innerHTML='<div style="margin:6px 0 18px">'+card(rec)+'</div>'; }
    else { box.innerHTML='<div class="notice" style="margin:6px 0 18px"><span>Aucune fenêtre documentée pour « '+esc(q)+' ». Essaie un autre nom ou un alias.</span></div>'; }
  }

  function renderList(filter){
    var host=$('det-list'); if(!host) return;
    var d=det().slice().sort(function(a,b){return a.nom.localeCompare(b.nom,'fr');});
    var f=(filter||'').trim().toLowerCase();
    if(f) d=d.filter(function(r){ return r.nom.toLowerCase().indexOf(f)>=0 || (r.aliases||[]).some(function(a){return a.toLowerCase().indexOf(f)>=0;}); });
    $('det-count').textContent='— '+d.length;
    host.innerHTML=d.map(card).join('');
  }

  /* suggestions (alias) */
  function matches(q){
    q=(q||'').trim().toLowerCase(); if(!q) return [];
    var d=det(), pre=[], inc=[], seen={};
    function push(arr,nom,al){ if(seen[nom])return; seen[nom]=1; arr.push({nom:nom,alias:al}); }
    d.forEach(function(r){
      var n=r.nom.toLowerCase();
      if(n.indexOf(q)===0) return push(pre,r.nom,null);
      var ap=(r.aliases||[]).filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap) return push(pre,r.nom,ap);
      if(n.indexOf(q)>0) return push(inc,r.nom,null);
      var ai=(r.aliases||[]).filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,r.nom,ai);
    });
    return pre.concat(inc).slice(0,8);
  }
  function renderSug(q){
    var box=$('det-sug'); if(!box) return; var m=matches(q);
    if(!q||!m.length){ box.classList.remove('open'); box.innerHTML=''; return; }
    box.innerHTML=m.map(function(x){ return '<div data-val="'+esc(x.nom)+'">'+esc(x.nom)+(x.alias?' <small>'+esc(x.alias)+'</small>':'')+'</div>'; }).join('');
    box.classList.add('open');
    box.querySelectorAll('[data-val]').forEach(function(el){ el.addEventListener('mousedown',function(ev){ ev.preventDefault(); pick(el.getAttribute('data-val')); }); });
  }
  function pick(nom){ $('det-search').value=nom; $('det-sug').classList.remove('open'); renderResult(nom); renderList(''); }

  ready(function(){
    if(window.MDCore) MDCore.init({ page:'suivi', section:'substances' });
    var s=$('det-search');
    s.addEventListener('input', function(){ renderSug(s.value); renderResult(s.value); renderList(s.value); });
    s.addEventListener('focus', function(){ renderSug(s.value); });
    s.addEventListener('blur', function(){ setTimeout(function(){ $('det-sug').classList.remove('open'); },150); });
    document.querySelectorAll('#usage-seg button').forEach(function(b){ b.addEventListener('click', function(){
      usage=b.getAttribute('data-usage');
      document.querySelectorAll('#usage-seg button').forEach(function(x){ x.classList.toggle('on', x===b); });
      renderResult($('det-search').value); renderList($('det-search').value);
    }); });
    renderList('');
  });
})();
