/* MyDope Off — page-detection.js · fenêtres de détection (salive/urine/sang)
   Usage unique vs régulier : l'usage régulier allonge surtout l'URINE
   (accumulation des métabolites), parfois la salive. Estimations + disclaimer. */
(function () {
  'use strict';
  function $(id){ return document.getElementById(id); }
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function det(){ return (window.MD_DETECTION||[]); }
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  function trCat(c){ var d=window.MD_PSY_CATEGORIES_EN||{}; return (lang()==='en' && d[c]!=null) ? d[c] : c; }
  function trNote(n){ var d=window.MD_DETECTION_NOTES_EN||{}; return (lang()==='en' && n && d[n]!=null) ? d[n] : n; }
  var T = {
    detection_lbl:{fr:'Détection', en:'Detection'},
    not_detected_routine:{fr:'Non détecté en test de routine.', en:'Not detected in routine testing.'},
    saliva:{fr:'Salive', en:'Saliva'}, urine:{fr:'Urine', en:'Urine'}, blood:{fr:'Sang', en:'Blood'}, note_lbl:{fr:'Note', en:'Note'},
    not_detected_tag:{fr:'non détecté', en:'not detected'}, estimate_tag:{fr:'estimation', en:'estimate'},
    rdr_estimate:{fr:'Estimation RDR', en:'Harm reduction estimate'},
    no_window:{fr:function(q){return 'Aucune fenêtre documentée pour \u00ab '+q+' \u00bb. Essaie un autre nom ou un alias.';},
               en:function(q){return 'No documented window for "'+q+'". Try another name or an alias.';}},
    based_on_journal:{fr:'D\u2019apr\u00e8s ton suivi \u00b7 30 derniers jours', en:'Based on your journal \u00b7 last 30 days'},
    regular_use:{fr:'usage r\u00e9gulier', en:'regular use'}, single_use:{fr:'usage occasionnel', en:'occasional use'},
    no_window_name:{fr:'Aucune fen\u00eatre document\u00e9e pour ce nom.', en:'No documented window for this name.'},
    days_of_30:{fr:function(n){return n+' j / 30';}, en:function(n){return n+' d / 30';}},
    class_estimate:{fr:function(fam){return 'Estimation par classe ('+trCat(fam)+') \u2014 indicative, non sp\u00e9cifique \u00e0 la mol\u00e9cule.';},
                     en:function(fam){return 'Class-based estimate ('+trCat(fam)+') \u2014 indicative, not molecule-specific.';}},
    note_thc:{fr:'Non détecté par les tests THC standards ; test spécifique requis.', en:'Not detected by standard THC tests; a specific test is required.'},
    note_psyche:{fr:'Rarement détecté en test de routine ; analyses spécialisées seulement.', en:'Rarely detected in routine testing; specialised analysis only.'},
    note_limited:{fr:'Données limitées.', en:'Limited data.'},
    note_mix:{fr:'Composition variable : dépend des produits présents.', en:'Variable composition: depends on the products present.'},
    note_default:{fr:'Données limitées pour cette molécule.', en:'Limited data for this molecule.'}
  };
  function t(k, a){ var e=T[k]; if(!e) return k; var v=lang()==='en'?e.en:e.fr; return (typeof v==='function')?v(a):v; }
  var usage='single';
  var CLASS_EST_KEYS = {
    'cannabinoïde synthétique':'note_thc',
    'psychédélique':'note_psyche',
    'délirant':'note_limited',
    'délirant-sédatif':'note_limited',
    'anticholinergique':'note_limited',
    'mélange':'note_mix',
    '_default':'note_default'
  };
  var CLASS_EST = {
    'stimulant':{sal:[12,48],uri:[48,96],blo:[12,48]},
    'empathogène':{sal:[24,48],uri:[48,96],blo:[12,48]},
    'entactogène':{sal:[24,48],uri:[48,96],blo:[12,48]},
    'opioïde':{sal:[24,48],uri:[48,96],blo:[12,48]},
    'opioïde partiel':{sal:[24,48],uri:[48,120],blo:[12,48]},
    'antidote opioïde':{sal:[6,24],uri:[12,72],blo:[6,24]},
    'antagoniste opioïde':{sal:[6,24],uri:[12,96],blo:[6,24]},
    'benzodiazépine':{sal:[24,48],uri:[72,240],blo:[24,120]},
    'benzodiazépine designer':{sal:[24,48],uri:[72,240],blo:[24,120]},
    'thienodiazépine':{sal:[24,48],uri:[72,240],blo:[24,120]},
    'Z-drug':{sal:[12,24],uri:[24,72],blo:[8,24]},
    'dissociatif':{sal:[24,48],uri:[48,168],blo:[24,96]},
    'dissociatif-sédatif':{sal:[24,48],uri:[48,120],blo:[12,72]},
    'cannabinoïde':{sal:[12,48],uri:[72,168],blo:[24,168]},
    'cannabinoïde synthétique':{sal:[12,48],uri:[48,168],blo:[12,72]},
    'psychédélique':{sal:[6,24],uri:[12,72],blo:[6,24],detectable:false},
    'dépresseur':{sal:[6,24],uri:[12,96],blo:[6,48]},
    'dépresseur léger':{sal:[6,24],uri:[12,72],blo:[6,24]},
    'barbituriqué':{sal:[24,48],uri:[72,336],blo:[24,168]},
    'antiépileptique':{sal:[12,48],uri:[48,120],blo:[12,72]},
    'GABA-B':{sal:[6,24],uri:[12,72],blo:[6,24]},
    'délirant':{sal:[6,24],uri:[24,96],blo:[6,48]},
    'délirant-sédatif':{sal:[6,24],uri:[24,96],blo:[6,48]},
    'anticholinergique':{sal:[6,24],uri:[24,96],blo:[6,48]},
    'antihistaminique':{sal:[6,24],uri:[24,96],blo:[6,48]},
    'antipsychotique':{sal:[12,48],uri:[48,168],blo:[12,72]},
    'antidépresseur':{sal:[12,48],uri:[48,168],blo:[12,72]},
    'myorelaxant':{sal:[12,24],uri:[24,96],blo:[8,48]},
    'anesthésique':{sal:[6,12],uri:[12,48],blo:[4,24]},
    'mélange':{sal:[12,48],uri:[48,120],blo:[12,72]},
    '_default':{sal:[12,48],uri:[24,96],blo:[12,48]}
  };
  function estFromClass(nom,fam){
    var usedDefault = !CLASS_EST[fam];
    var e=CLASS_EST[fam]||CLASS_EST['_default'];
    var noteKey = usedDefault ? CLASS_EST_KEYS['_default'] : CLASS_EST_KEYS[fam];
    var baseNote = noteKey ? t(noteKey) : '';
    var n=t('class_estimate',fam);
    return { nom:nom, fam:fam, sal:e.sal, uri:e.uri, blo:e.blo,
      note:(baseNote?baseNote+' ':'')+n, detectable:e.detectable!==false, source:t('rdr_estimate'), _est:true };
  }

  function fmtH(h){ if(h==null) return '—'; return h<24 ? (String(h).replace('.',',')+' h') : (Math.round(h/24)+' j'); }
  function fmtR(a){ return (a&&a.length===2) ? fmtH(a[0])+'\u2013'+fmtH(a[1]) : '\u2014'; }

  /* Fenêtre "usage régulier/chronique", calculée à partir de l'occasionnel. */
  function regSal(rec){ var s=rec.sal; if(!s) return s; var n=(rec.nom||'').toLowerCase();
    if(/cannabis|thc|hhc|thcp|delta-9/.test(n)) return [s[0], Math.max(s[1], 8*24)];
    return [s[0], Math.round(s[1]*1.4)];
  }
  function regUri(rec){ var ur=rec.uri; if(!ur) return ur; var n=(rec.nom||'').toLowerCase(), f=rec.fam||'';
    if(/cannabis|thc|hhc|thcp|delta-9|cbn/.test(n)) return [Math.max(ur[0],2*24), 30*24];
    if(/diazépam|diazepam|clonazépam|clonazepam|nordazépam|flubromazolam|clonazolam|prazépam/.test(n)) return [ur[0], Math.max(ur[1],30*24)];
    if(/méthadone|methadone/.test(n)) return [ur[0], Math.max(ur[1],14*24)];
    if(/buprénorphine|buprenorphine|subutex|suboxone/.test(n)) return [ur[0], Math.max(ur[1],11*24)];
    if(/phénobarbital|phenobarbital|barbiturique/.test(n)) return [ur[0], Math.max(ur[1],21*24)];
    var k=(f==='opioide'||f==='stimulant'||f==='empathogene')?1.8:1.6;
    return [ur[0], Math.round(ur[1]*k)];
  }
  function usageRow(label, occ, reg){
    if(!occ) return '';
    var v = (usage==='regular' && reg) ? reg : occ;
    return '<div class="s-row"><span class="s-key">'+label+'</span><span class="s-val">~ '+fmtR(v)+'</span></div>';
  }
  function windowsHTML(rec){
    if(rec.detectable===false){
      return '<div class="s-row"><span class="s-key">'+t('detection_lbl')+'</span><span class="s-val">'+t('not_detected_routine')+'</span></div>';
    }
    return usageRow(t('saliva'), rec.sal, regSal(rec))+
      usageRow(t('urine'), rec.uri, regUri(rec))+
      (rec.blo?'<div class="s-row"><span class="s-key">'+t('blood')+'</span><span class="s-val">~ '+fmtR(rec.blo)+'</span></div>':'')+
      (rec.note?'<div class="s-row"><span class="s-key">'+t('note_lbl')+'</span><span class="s-val">'+esc(trNote(rec.note))+'</span></div>':'');
  }
  function card(rec){
    var fam=rec.fam?'<span class="s-tag '+esc(rec.fam)+'">'+esc(trCat(rec.fam))+'</span>':'';
    return '<div class="s-card"><div class="s-card-head"><div class="s-card-name">'+esc(window.MDSubName?MDSubName(rec.nom):rec.nom)+'</div><div class="s-tags">'+fam+
      (rec.detectable===false?'<span class="s-tag" style="background:var(--ok-50);color:var(--ok)">'+t('not_detected_tag')+'</span>':'')+(rec._est?'<span class="s-tag" style="background:var(--warn-50);color:var(--warn)">'+t('estimate_tag')+'</span>':'')+'</div></div>'+
      '<div class="s-card-body">'+windowsHTML(rec)+'</div>'+
      '<div class="s-footer">'+(rec.source?esc(String(rec.source).split('\u00b7')[0].trim()):t('rdr_estimate'))+'</div></div>';
  }

  function canonRec(q){
    if(!q) return null; q=q.trim().toLowerCase();
    var d=det();
    for(var i=0;i<d.length;i++){ if(d[i].nom.toLowerCase()===q || (window.MDSubName&&MDSubName(d[i].nom).toLowerCase()===q) || (d[i].aliases||[]).some(function(a){return a.toLowerCase()===q;}) || (window.MDSubAliasesEN&&MDSubAliasesEN(d[i].nom).some(function(a){return a.toLowerCase()===q;}))) return d[i]; }
    // index global -> molécule -> fiche détection précise, sinon estimation par classe
    var ix=(window.MD_SUBS_INDEX||[]); var hit=null;
    for(var j=0;j<ix.length;j++){ if(ix[j].n.toLowerCase()===q||(ix[j].a||[]).some(function(a){return a.toLowerCase()===q;})){ hit=ix[j]; break; } }
    if(hit){
      for(var k=0;k<d.length;k++){ if(d[k].nom.toLowerCase()===hit.n.toLowerCase()) return d[k]; }
      return estFromClass(hit.n, hit.f||'');
    }
    return null;
  }

  function renderResult(q){
    var box=$('det-result'); if(!box) return;
    var rec=canonRec(q);
    if(!q){ box.innerHTML=''; return; }
    if(rec){ box.innerHTML='<div style="margin:6px 0 18px">'+card(rec)+'</div>'; }
    else { box.innerHTML='<div class="notice" style="margin:6px 0 18px"><span>'+t('no_window',esc(q))+'</span></div>'; }
  }

  function renderList(filter){
    var host=$('det-list'); if(!host) return;
    var d=det().slice().sort(function(a,b){return a.nom.localeCompare(b.nom,'fr');});
    var f=(filter||'').trim().toLowerCase();
    if(f) d=d.filter(function(r){ return r.nom.toLowerCase().indexOf(f)>=0 || (window.MDSubName?MDSubName(r.nom).toLowerCase():'').indexOf(f)>=0 || (r.aliases||[]).some(function(a){return a.toLowerCase().indexOf(f)>=0;}) || (window.MDSubAliasesEN?MDSubAliasesEN(r.nom):[]).some(function(a){return a.toLowerCase().indexOf(f)>=0;}); });
    $('det-count').textContent='— '+d.length;
    host.innerHTML=d.map(card).join('');
  }

  /* suggestions (alias) */
  function matches(q){
    q=(q||'').trim().toLowerCase(); if(!q) return [];
    var d=det(), pre=[], inc=[], seen={};
    function push(arr,nom,al){ if(seen[nom])return; seen[nom]=1; arr.push({nom:nom,alias:al}); }
    d.forEach(function(r){
      var n=r.nom.toLowerCase(), en=(window.MDSubName?MDSubName(r.nom):r.nom).toLowerCase();
      if(n.indexOf(q)===0||en.indexOf(q)===0) return push(pre,r.nom,null);
      var extraEN=(window.MDSubAliasesEN?MDSubAliasesEN(r.nom):[]);
      var allAl=(r.aliases||[]).concat(extraEN);
      var ap=allAl.filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap) return push(pre,r.nom,ap);
      if(n.indexOf(q)>0||en.indexOf(q)>0) return push(inc,r.nom,null);
      var ai=allAl.filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,r.nom,ai);
    });
    (window.MD_SUBS_INDEX||[]).forEach(function(r){
      var n=r.n.toLowerCase(), en=(window.MDSubName?MDSubName(r.n):r.n).toLowerCase();
      if(n.indexOf(q)===0||en.indexOf(q)===0) return push(pre,r.n,null);
      var extraEN=(window.MDSubAliasesEN?MDSubAliasesEN(r.n):[]);
      var allAl=(r.a||[]).concat(extraEN);
      var ap=allAl.filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap) return push(pre,r.n,ap);
      if(n.indexOf(q)>0||en.indexOf(q)>0) return push(inc,r.n,null);
      var ai=allAl.filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,r.n,ai);
    });
    return pre.concat(inc).slice(0,10);
  }
  function renderSug(q){
    var box=$('det-sug'); if(!box) return; var m=matches(q);
    if(!q||!m.length){ box.classList.remove('open'); box.innerHTML=''; return; }
    box.innerHTML=m.map(function(x){ return '<div data-val="'+esc(x.nom)+'">'+esc(window.MDSubName?MDSubName(x.nom):x.nom)+(x.alias?' <small>'+esc(x.alias)+'</small>':'')+'</div>'; }).join('');
    box.classList.add('open');
    box.querySelectorAll('[data-val]').forEach(function(el){ el.addEventListener('mousedown',function(ev){ ev.preventDefault(); pick(el.getAttribute('data-val')); }); });
  }
  function pick(nom){ $('det-search').value=nom; $('det-sug').classList.remove('open'); renderResult(nom); renderList(''); }

  function pEntries(){ try{ var s=JSON.parse(localStorage.getItem('ctc_v6')||'{}'); return Array.isArray(s.entries)?s.entries:[]; }catch(e){ return []; } }
  function personalUsage(){
    var now=Date.now(), MS=86400000, map={};
    pEntries().forEach(function(e){
      if(!e||!e.date||(Number(e.level)||0)<=0||!e.substance) return;
      if((now-new Date(e.date+'T00:00:00').getTime())>30*MS) return;
      var k=String(e.substance).trim(); if(!k) return;
      (map[k]=map[k]||{})[e.date]=1;
    });
    return Object.keys(map).map(function(k){ var days=Object.keys(map[k]).length; return {sub:k,days:days,type:days>=6?'regular':'single'}; })
      .sort(function(a,b){ return b.days-a.days; });
  }
  function renderPersonal(){
    var box=$('det-personal'); if(!box) return;
    var list=personalUsage();
    if(!list.length){ box.hidden=true; box.innerHTML=''; return; }
    var saved=usage, h='<p class="seclabel" style="margin:2px 0 8px">'+t('based_on_journal')+'</p>';
    list.forEach(function(it){
      var rec=canonRec(it.sub); usage=it.type;
      var lab=(it.type==='regular'?t('regular_use'):t('single_use'));
      var body = rec ? windowsHTML(rec) : '<div class="s-row"><span class="s-key">'+t('detection_lbl')+'</span><span class="s-val">'+t('no_window_name')+'</span></div>';
      h+='<div class="s-card"><div class="s-card-head"><div class="s-card-name">'+esc(it.sub)+'</div><div class="s-tags"><span class="s-tag">'+t('days_of_30',it.days)+' \u00b7 '+lab+'</span></div></div><div class="s-card-body">'+body+'</div></div>';
    });
    usage=saved; box.innerHTML=h; box.hidden=false;
  }
  ready(function(){
    if(window.MDCore) MDCore.init({ page:'suivi', section:'substances' });
    var s=$('det-search');
    s.addEventListener('input', function(){ renderSug(s.value); renderResult(s.value); renderList(s.value); });
    s.addEventListener('focus', function(){ renderSug(s.value); });
    s.addEventListener('blur', function(){ setTimeout(function(){ $('det-sug').classList.remove('open'); },150); });
    document.querySelectorAll('#usage-seg button').forEach(function(b){ b.addEventListener('click', function(){
      usage=b.getAttribute('data-usage');
      document.querySelectorAll('#usage-seg button').forEach(function(x){ x.classList.toggle('on', x===b); });
      renderResult($('det-search').value); renderList($('det-search').value);
    }); });
    renderList(''); renderPersonal();
    document.addEventListener('langchange', function(){ renderResult(s.value); renderList(s.value); renderPersonal(); });
  });
})();
try{ if(window.MDPageIntro) MDPageIntro.init('detection'); }catch(e){}
