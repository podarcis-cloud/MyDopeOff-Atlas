/* MyDope Off — mascotte-systeme.js
   ────────────────────────────────────────────────────────────────────────
   Système mascotte unifié, construit en parallèle de l'existant.
   N'altère rien : compagnon.js, debriefs.js, anecdotes.js et
   memoire-mascotte.js continuent de fonctionner exactement comme avant.
   Ce module s'ajoute à côté et sera branché progressivement.

   RAISON D'ÊTRE
   Le chapitre 23 du Handbook définit trois notions structurantes que le code
   ne connaissait pas : le REGISTRE (4), le CONTEXTE DE RESPONSABILITÉ (7) et
   l'INTENSITÉ (3). Sans elles, chaque point d'invocation choisit son humeur
   en dur, et la connaissance de ce qui convient à un écran n'existe que dans
   la tête de qui l'a écrit — le mécanisme exact qui a produit, une première
   fois, dix implémentations divergentes.

   Ce module déplace cette connaissance du contributeur vers le système.

   API
     MDMascotte.pour('craving')            -> descripteur complet du contexte
     MDMascotte.humeur('craving')          -> une humeur légitime pour ce contexte
     MDMascotte.verifier('craving','colere') -> {ok, raison} sans rien afficher
     MDMascotte.avatar('craving')          -> balisage prêt à insérer
   ──────────────────────────────────────────────────────────────────────── */
window.MDMascotte = (function () {
  'use strict';

  /* ── Les 4 registres (chapitre 23, partie V) ───────────────────────────
     Un registre décrit COMMENT elle parle. Ils ne se mélangent jamais. */
  var REGISTRES = {
    ambiance:  { enjeu: 'faible', reagit: false, note: 'Présence sans commentaire. En cas de doute : ne pas apparaître.' },
    reaction:  { enjeu: 'moyen',  reagit: true,  note: 'Répond à un fait observé. Doit varier selon le résultat réel.' },
    anecdote:  { enjeu: 'faible', reagit: false, note: 'Informatif pur. Jamais de leçon en conclusion.' },
    parcours:  { enjeu: 'eleve',  reagit: true,  note: 'Restitue sans classer. Aucune série à ne pas casser.' }
  };

  /* ── Les 3 intensités (chapitre 23, partie X) ──────────────────────────
     L'intensité élevée décrit une proximité plus grande, JAMAIS un ton plus
     alarmant. Cette distinction est ce qui empêche le soutien de devenir de
     la panique. */
  var INTENSITES = {
    basse:  { motsMax: 140, avatar: 'sm', note: 'Présence discrète, jamais insistante.' },
    moyenne:{ motsMax: 220, avatar: 'md', note: 'Engagement normal, tenu par le résultat réel.' },
    elevee: { motsMax: 90,  avatar: 'md', note: 'Phrases courtes. Plus près, jamais plus fort.' }
  };

  /* ── Les 7 contextes de responsabilité (chapitre 23, partie VI) ────────
     Un contexte décrit ce qu'elle ENGAGE. Chacun déclare les humeurs qui
     lui sont légitimes : c'est ce qui empêche qu'une humeur d'alarme se
     retrouve un jour sur un écran de crise. */
  var CONTEXTES = {
    ambiance: {
      registre: 'ambiance', intensite: 'basse',
      humeurs: ['serenite','curiosite','pause','ecoute','reflexion','respiration','horizon','emerveillement'],
      enJeu: 'Rien de critique. Une apparition ratée ici est du bruit, pas un dommage.'
    },
    debrief: {
      registre: 'reaction', intensite: 'moyenne',
      humeurs: ['encouragement','celebration','fierte','reflexion','bienveillance','concentration',
                'depassement','resilience','curiosite','acceptation','motivation','clarification'],
      enJeu: 'Sa crédibilité future. Une célébration uniforme dépense un crédit qui manquera au vrai accomplissement.',
      exigeVariation: true
    },
    bilan: {
      registre: 'reaction', intensite: 'elevee',
      humeurs: ['ecoute','bienveillance','reflexion','celebration','acceptation','clarification','ancrage','encouragement'],
      interdites: ['craving','colere','vigilance','impatience'],
      enJeu: 'La façon dont une personne comprend un résultat qui la concerne intimement.',
      clotureObligatoire: 'porte ouverte — un exercice, ou la mention qu\u2019un soutien existe. Jamais une conclusion.'
    },
    craving: {
      registre: 'reaction', intensite: 'elevee',
      humeurs: ['bienveillance','ecoute','ancrage','respiration','encouragement','acceptation','lacher-prise'],
      interdites: ['celebration','fierte','vigilance','impatience','colere','motivation'],
      enJeu: 'Tout. Le moment où les principes fondateurs deviennent une phrase lue en difficulté réelle.',
      obligatoires: ['valeurs personnelles rappelées si elles existent',
                     'un geste concret et immédiatement actionnable',
                     'une porte de réduction des risques, jamais fermée']
    },
    identite: {
      registre: 'reaction', intensite: 'elevee',
      humeurs: ['ecoute','bienveillance','curiosite','introspection','clarification','tendresse','acceptation'],
      interdites: ['celebration','fierte','encouragement'],
      enJeu: 'La capacité de quelqu\u2019un à nommer ce qui compte pour lui, souvent pour la première fois.',
      note: 'Elle reçoit plus qu\u2019elle ne donne. Toute réaction évaluative — y compris positive — transforme une exploration en examen.'
    },
    substances: {
      registre: 'ambiance', intensite: 'moyenne',
      humeurs: ['explication','clarification','vigilance','curiosite','transmission','choix-eclaire'],
      enJeu: 'La frontière entre accompagner et informer.',
      note: 'Passerelle vers le contenu, jamais source elle-même. Elle ne dit jamais un fait sur une substance.'
    },
    /* Contexte ajouté le 4 août 2026, hors des 7 du chapitre 23 — décision explicite de Simon.
       Motif : trois dossiers de dossier-guide.js (rechute, autosabotage, environnement) n'ont pas
       de fait chimique à transmettre — ce sont des mécanismes psychologiques et relationnels à
       recevoir avec chaleur. Ni « substances » (elle ne dit jamais un fait — ici il n'y a pas de
       fait à esquiver), ni « identité » (ce contexte reçoit plus qu'il ne donne — ici la mascotte
       explique, elle n'interroge pas). À reporter au chapitre 23 du Handbook. */
    mecanismes: {
      registre: 'ambiance', intensite: 'moyenne',
      humeurs: ['bienveillance','reflexion','ancrage','horizon'],
      enJeu: 'Aider quelqu\u2019un à comprendre un mécanisme qui le concerne (rechute, auto-sabotage, environnement de consommation) sans jamais le lui faire porter comme une faute.',
      note: 'Distinct de « substances » : rien à vérifier, rien à sourcer — un mécanisme à expliquer avec chaleur, pas un fait à transmettre.'
    },
    recommandation: {
      registre: 'reaction', intensite: 'moyenne',
      humeurs: ['encouragement','ecoute','curiosite','ressource','adaptation','ancrage'],
      enJeu: 'La frontière entre suggérer et prescrire.',
      note: 'Toujours une suggestion. La personne qui ne la suit pas n\u2019a rien fait de mal.'
    }
  };

  /* ── Interdits transversaux (chapitre 23, partie VIII) ─────────────────
     Motifs de formulation qui trahissent une des erreurs bien intentionnées
     que le manifeste proscrit. Servent à `auditerTexte`, jamais à censurer
     silencieusement : le module signale, il ne réécrit pas. */
  var MOTIFS_INTERDITS = [
    { re: /je sais ce que tu (traverses|ressens|vis)/i,        regle: 'prétendre connaître le ressenti' },
    { re: /(ça|ca) doit (être|etre) (difficile|dur|pénible)/i, regle: 'prétendre connaître le ressenti' },
    { re: /tu (dois|devais) te sentir/i,                        regle: 'prétendre connaître le ressenti' },
    { re: /\btu devrais\b/i,                                    regle: 'injonction déguisée' },
    { re: /il faut que tu\b/i,                                  regle: 'injonction déguisée' },
    { re: /\bbravo\b(?![^.!?]*\bparce que\b)/i,                 regle: 'flatterie sans motif concret' },
    { re: /tu es (incroyable|génial|formidable|exceptionnel)/i, regle: 'flatterie sans motif concret' },
    { re: /\bdommage\b/i,                                       regle: 'culpabilisation par regret déguisé' },
    { re: /tu (étais|etais) si (près|pres)/i,                   regle: 'culpabilisation par regret déguisé' },
    { re: /(oups|désolé|desole)[,\s!]/i,                        regle: 'commenter un état système' },
    { re: /\b(tu souffres d|tu fais (une|un) (dépression|burn))/i, regle: 'poser un diagnostic' }
  ];

  function contexte(nom) { return CONTEXTES[nom] || null; }

  /* Descripteur complet d'un contexte : registre, intensité, humeurs
     légitimes et contraintes. Sert autant au code qu'à la relecture. */
  function pour(nom) {
    var c = contexte(nom);
    if (!c) return null;
    var r = REGISTRES[c.registre], i = INTENSITES[c.intensite];
    return {
      contexte: nom,
      registre: c.registre, registreNote: r.note, reagit: r.reagit,
      intensite: c.intensite, intensiteNote: i.note, motsMax: i.motsMax, tailleAvatar: i.avatar,
      humeurs: c.humeurs.slice(), interdites: (c.interdites || []).slice(),
      enJeu: c.enJeu, note: c.note || '',
      obligatoires: (c.obligatoires || []).slice(),
      clotureObligatoire: c.clotureObligatoire || '',
      exigeVariation: !!c.exigeVariation
    };
  }

  /* Vérifie qu'une humeur est légitime dans un contexte, sans rien afficher.
     Utilisable en développement pour attraper une erreur avant qu'elle
     n'atteigne un écran. */
  function verifier(nomContexte, humeur) {
    var c = contexte(nomContexte);
    if (!c) return { ok: false, raison: 'contexte inconnu : ' + nomContexte };
    if ((c.interdites || []).indexOf(humeur) >= 0) {
      return { ok: false, raison: 'humeur explicitement interdite dans « ' + nomContexte + ' » : ' + humeur };
    }
    if (c.humeurs.indexOf(humeur) < 0) {
      return { ok: false, raison: 'humeur hors du répertoire de « ' + nomContexte + ' » : ' + humeur };
    }
    return { ok: true, raison: '' };
  }

  /* Choisit une humeur légitime pour ce contexte.
     Délègue l'anti-répétition à MDMascotteMemoire quand il est présent —
     un seul moteur de sélection, jamais deux (chapitre 23, partie V). */
  function humeur(nomContexte, opts) {
    var c = contexte(nomContexte);
    if (!c) return 'serenite';
    var pool = c.humeurs;
    if (opts && opts.preferee && verifier(nomContexte, opts.preferee).ok) return opts.preferee;
    try {
      if (window.MDMascotteMemoire && window.MDMascotteMemoire.pick) {
        var cands = pool.map(function (m) { return { id: m, mood: m }; });
        var choisi = window.MDMascotteMemoire.pick('humeur:' + nomContexte, cands);
        if (choisi && choisi.id) return choisi.id;
      }
    } catch (e) { /* le repli ci-dessous couvre le cas */ }
    return pool[Math.floor(Math.random() * pool.length)];
  }

  /* Balisage d'avatar à la bonne taille pour le contexte.
     S'appuie sur MDCompagnon.avatarHTML — ne réimplémente rien. */
  function avatar(nomContexte, opts) {
    var c = contexte(nomContexte);
    if (!c || !window.MDCompagnon || !window.MDCompagnon.avatarHTML) return '';
    var m = (opts && opts.humeur) || humeur(nomContexte, opts);
    return window.MDCompagnon.avatarHTML(m, { size: INTENSITES[c.intensite].avatar });
  }

  /* Signale les formulations qui enfreignent un interdit du chapitre 23.
     Ne réécrit jamais : la décision reste humaine. */
  function auditerTexte(texte, nomContexte) {
    var pbs = [];
    if (!texte) return pbs;
    MOTIFS_INTERDITS.forEach(function (m) {
      if (m.re.test(texte)) pbs.push({ regle: m.regle, extrait: (texte.match(m.re) || [''])[0] });
    });
    var c = contexte(nomContexte);
    if (c) {
      var max = INTENSITES[c.intensite].motsMax;
      var n = texte.replace(/<[^>]*>/g, ' ').trim().split(/\s+/).length;
      if (n > max) {
        pbs.push({ regle: 'longueur excessive pour l\u2019intensité « ' + c.intensite + ' »',
                   extrait: n + ' mots (repère : ' + max + ')' });
      }
    }
    return pbs;
  }

  function contextes() { return Object.keys(CONTEXTES); }

  return {
    pour: pour, humeur: humeur, avatar: avatar,
    verifier: verifier, auditerTexte: auditerTexte,
    contextes: contextes,
    REGISTRES: REGISTRES, INTENSITES: INTENSITES
  };
})();
