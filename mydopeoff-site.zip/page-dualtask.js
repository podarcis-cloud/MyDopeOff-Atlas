/* MyDope Off — page-dualtask.js
   Logique de dualtask, extraite du script inline de dualtask.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var DURATION=60000;        // durée totale de la manche (ms)
  var WIN_MS=1100;           // fenêtre de réponse à un stimulus primaire
  var SHAPES=['circle','square','triangle'];
  var body=document.getElementById('dt-body');

  // état primaire (formes)
  var primHits=0, primMiss=0, primFalse=0, primCorrectRej=0, primRts=[];
  // état secondaire (compteur)
  var secHits=0, secMiss=0, secTotal=0;
  var counter=0, secTimer=null, alertActive=false, alertTimeout=null;
  var stageTimer=null, running=false, t0=0, endAt=0;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }

  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var T = {
    ready:{fr:'Prêt\u2026',en:'Ready\u2026'},
    good:{fr:'Bien vu.',en:'Nice catch.'},
    not_circle:{fr:'C\u2019était pas un rond.',en:'That wasn\u2019t a circle.'},
    lbl_circle:{fr:'Rond',en:'Circle'}, lbl_counter:{fr:'Compteur',en:'Counter'},
    lbl_track:{fr:'Suivi',en:'Tracking'}, lbl_tempo:{fr:'Tempo',en:'Tempo'},
    track_hint:{fr:'Pose le doigt sur le point bleu et suis-le en tournant.',en:'Put your finger on the blue dot and follow it as it turns.'},
    lbl_accuracy:{fr:'Justesse',en:'Accuracy'},
    side_active:{fr:'Côté actif : ',en:'Active side: '}, left_word:{fr:'GAUCHE',en:'LEFT'}, right_word:{fr:'DROITE',en:'RIGHT'},
    wrong_side:{fr:'Mauvais côté.',en:'Wrong side.'},
    remember_order:{fr:'Retiens cet ordre',en:'Remember this order'},
    three_colors:{fr:'Trois couleurs, une par une\u2026',en:'Three colours, one at a time\u2026'},
    which_order:{fr:'Dans quel ordre ? (',en:'What order? ('},
    lbl_calc:{fr:'Calcul',en:'Maths'}, pair_word:{fr:'PAIR',en:'EVEN'}, impair_word:{fr:'IMPAIR',en:'ODD'},
    not_this_time:{fr:'Pas cette fois.',en:'Not this time.'},
    lbl_target:{fr:'Cible : ',en:'Target: '}, lbl_only:{fr:' uniquement',en:' only'},
    lbl_spotting:{fr:'Repérage',en:'Spotting'},
    shape_circle:{fr:'rond',en:'circle'}, shape_square:{fr:'carré',en:'square'},
    color_sauge:{fr:'vert',en:'green'}, color_terra:{fr:'terracotta',en:'terracotta'}, color_fjord:{fr:'bleu',en:'blue'}, color_ocre:{fr:'ocre',en:'ochre'},
    not_right_combo:{fr:'Pas la bonne combinaison.',en:'Not the right combination.'},
    lbl_memory:{fr:'Mémoire',en:'Memory'},
    first_two_landmark:{fr:'Les deux premières couleurs servent juste de repère \u2014 rien à taper encore.',en:'The first two colours are just a reference \u2014 nothing to tap yet.'},
    match_btn:{fr:'ÇA CORRESPOND',en:'IT MATCHES'},
    no_match:{fr:'Ça ne correspondait pas.',en:'That didn\u2019t match.'},
    a_bit_more_landmark:{fr:'Encore un peu de repère\u2026',en:'A little more reference first\u2026'},
    ink_not_word:{fr:'Touche la couleur de l\u2019',en:'Tap the colour of the '}, ink_word:{fr:'encre',en:'ink'}, not_word:{fr:', pas le mot',en:', not the word'},
    lbl_stroop:{fr:'Stroop',en:'Stroop'},
    color_VERT:{fr:'VERT',en:'GREEN'}, color_ROUGE:{fr:'ROUGE',en:'ROUGE'}, color_BLEU:{fr:'BLEU',en:'BLUE'}, color_JAUNE:{fr:'JAUNE',en:'YELLOW'},
    was_ink_not_word:{fr:'C\u2019était l\u2019encre, pas le mot.',en:'It was the ink, not the word.'},
    tap_arrow_zone:{fr:'Tape la zone que la flèche indique',en:'Tap the zone the arrow points to'},
    lbl_direction:{fr:'Direction',en:'Direction'},
    good_direction:{fr:'Bonne direction.',en:'Right direction.'},
    wrong_direction:{fr:'Pas cette direction-là.',en:'Not that direction.'},
    bigger_smaller_q:{fr:'Plus grand ou plus petit que le nombre précédent ?',en:'Bigger or smaller than the previous number?'},
    bigger_btn:{fr:'\u2191 Plus grand',en:'\u2191 Bigger'}, smaller_btn:{fr:'\u2193 Plus petit',en:'\u2193 Smaller'},
    lbl_trend:{fr:'Tendance',en:'Trend'},
    correct_word:{fr:'Correct.',en:'Correct.'},
    wrong_way:{fr:'Pas dans ce sens-là.',en:'Not that way.'},
    first_number:{fr:'Premier nombre \u2014 rien à comparer encore.',en:'First number \u2014 nothing to compare yet.'},
    label_track:{fr:'Suivi de la piste',en:'Track following'},
    label_switch:{fr:'Bascule (bon côté)',en:'Switching (right side)'},
    label_calc:{fr:'Calcul (pair/impair)',en:'Maths (even/odd)'},
    label_spotting:{fr:'Repérage combiné',en:'Combined spotting'},
    label_2back:{fr:'Mémoire glissante (2-back)',en:'Sliding memory (2-back)'},
    label_main:{fr:'Tâche principale (rond)',en:'Main task (circle)'},
    label_secondary:{fr:'tâche secondaire (tempo)',en:'secondary task (tempo)'},
    label_seq_memory:{fr:'mémoire de la séquence',en:'sequence memory'},
    label_divided_attn:{fr:'attention divisée',en:'divided attention'},
    debrief_title:{fr:'Double tâche — Niveau ',en:'Double task \u2014 Level '},
    replay_level:{fr:'Rejouer ce niveau',en:'Replay this level'},
    change_level:{fr:'Changer de niveau',en:'Change level'},
    'game.back_labo':{fr:'Retour au Labo',en:'Back to Lab'},
    back_to_levels:{fr:'Retour aux niveaux',en:'Back to levels'}
  };
  function t(key){ var e = T[key]; return e ? (L==='en' ? e.en : e.fr) : key; }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'dt.title':    { fr: 'Double tâche', en: 'Dual task' },
    'dt.subtitle': { fr: 'Deux attentions à la fois, sans en lâcher aucune.', en: 'Two attentions at once, without dropping either.' }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function render(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_circle')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_counter')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-stage').addEventListener('click', tapPrimary);
  }

  function tapSecondary(){
    if (!running) return;
    if (alertActive){
      alertActive=false; clearTimeout(alertTimeout);
      secHits++; document.getElementById('dt-s-ok').textContent=secHits;
      var badge=document.getElementById('dt-badge');
      badge.classList.remove('alert');
      badge.classList.remove('hit'); void badge.offsetWidth; badge.classList.add('hit');
      badge.addEventListener('animationend', function h(){ badge.classList.remove('hit'); badge.removeEventListener('animationend', h); });
      scheduleSecondary();
    }
  }

  var curShape=null, responded=false, stimT0=0;
  function tapPrimary(){
    if (!running || responded) return;
    responded=true;
    var hint=document.getElementById('dt-hint');
    if (curShape==='circle'){ primHits++; primRts.push(Date.now()-stimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { primFalse++; hint.textContent=t('not_circle'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=primHits;
  }

  function nextPrimary(){
    if (!running) return;
    responded=false;
    curShape = Math.random()<0.4 ? 'circle' : SHAPES[1+Math.floor(Math.random()*2)];
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape '+curShape+'"></div>';
    stimT0=Date.now();
    document.getElementById('dt-hint').style.color='var(--ink-2)';
    document.getElementById('dt-hint').textContent='\u00a0';
    setTimeout(function(){
      if (!running) return;
      if (!responded){
        if (curShape==='circle'){ primMiss++; }
        else { primCorrectRej++; }
      }
      stage.innerHTML='';
      var remain = endAt - Date.now();
      document.getElementById('dt-fill').style.width = Math.round((1 - Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft = Math.max(0, Math.ceil(remain/1000));
      var tEl = document.getElementById('dt-time');
      if (tEl) tEl.textContent = Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain > 300) setTimeout(nextPrimary, 220); else if (running) finish();
    }, WIN_MS);
  }

  function scheduleSecondary(){
    if (!running) return;
    var delay = 3000 + Math.random()*3000;
    secTimer = setTimeout(function(){
      if (!running) return;
      counter++; document.getElementById('dt-badge').textContent=counter;
      secTotal++;
      alertActive=true;
      document.getElementById('dt-badge').classList.add('alert');
      alertTimeout=setTimeout(function(){
        if (alertActive){ alertActive=false; secMiss++; document.getElementById('dt-badge').classList.remove('alert'); }
        scheduleSecondary();
      }, 1200);
    }, delay);
  }

  function finish(){
    stopRoundCleanup();
    if (level===4){ showRecall(); return; }
    renderResults(0);
  }
  function finishWithMemory(){
    var correct=0;
    for (var i=0;i<memSeq.length;i++) if (memRecall[i]===memSeq[i].k) correct++;
    renderResults(Math.round(correct/memSeq.length*100));
  }
  function renderResults(memAcc){
    var primAcc, rtMoyen=0, labelPrim;
    if (level===2){
      primAcc = trackSamples ? Math.round(trackOnTarget/trackSamples*100) : 0;
      labelPrim = t('label_track');
    } else if (level===3){
      var l3Total=l3Hits+l3Miss+l3False+l3CorrectRej;
      primAcc = l3Total ? Math.round(((l3Hits+l3CorrectRej)/l3Total)*100) : 0;
      rtMoyen = l3Rts.length ? Math.round(l3Rts.reduce(function(a,b){return a+b;},0)/l3Rts.length) : 0;
      labelPrim = t('label_switch');
    } else if (level===5){
      var l5Total=l5Hits+l5Errors+l5Miss;
      primAcc = l5Total ? Math.round((l5Hits/l5Total)*100) : 0;
      rtMoyen = l5Rts.length ? Math.round(l5Rts.reduce(function(a,b){return a+b;},0)/l5Rts.length) : 0;
      labelPrim = t('label_calc');
    } else if (level===6){
      var l6Total=l6Hits+l6Miss+l6False+l6CorrectRej;
      primAcc = l6Total ? Math.round(((l6Hits+l6CorrectRej)/l6Total)*100) : 0;
      rtMoyen = l6Rts.length ? Math.round(l6Rts.reduce(function(a,b){return a+b;},0)/l6Rts.length) : 0;
      labelPrim = t('label_spotting');
    } else if (level===7){
      var l7Total=l7Hits+l7Miss+l7False+l7CorrectRej;
      primAcc = l7Total ? Math.round(((l7Hits+l7CorrectRej)/l7Total)*100) : 0;
      rtMoyen = l7Rts.length ? Math.round(l7Rts.reduce(function(a,b){return a+b;},0)/l7Rts.length) : 0;
      labelPrim = t('label_2back');
    } else {
      var primTotal=primHits+primMiss+primFalse+primCorrectRej;
      primAcc = primTotal ? Math.round(((primHits+primCorrectRej)/primTotal)*100) : 0;
      rtMoyen = primRts.length ? Math.round(primRts.reduce(function(a,b){return a+b;},0)/primRts.length) : 0;
      labelPrim = t('label_main');
    }
    var secAcc = secTotal ? Math.round((secHits/secTotal)*100) : 0;
    var indice = (level===4) ? Math.round((primAcc+secAcc+memAcc)/3) : Math.round((primAcc+secAcc)/2);
    var d=store(); d.dualtask=d.dualtask||{best:0,parties:0}; d.dualtask.parties++; if(indice>d.dualtask.best)d.dualtask.best=indice; save(d);
    var statsList=[{label:labelPrim,value:primAcc+'%'},{label:t('label_secondary'),value:secAcc+'%'}];
    if(level===4) statsList.push({label:t('label_seq_memory'),value:memAcc+'%'});
    statsList.push({label:t('label_divided_attn'),value:indice+'/100'});
    if (window.MDExercise){
      MDExercise.after('dualtask', { avant: window.__mdAvant, dureeSec: Math.round((Date.now()-t0)/1000),
        meta:{ niveau:level, justessePrincipale:primAcc, justesseSecondaire:secAcc, memoire:(level===4?memAcc:null), rtMoyen:rtMoyen, indice:indice },
        title:t('debrief_title')+level, stats:statsList,
        nav:{ primary:{label:t('replay_level')}, secondary:{label:t('change_level'), onClick:showLevelSelect} },
        onClose:function(){ window.__mdAvant=null; startRound(level); } });
    } else if (window.MDData && MDData.logSession){
      MDData.logSession('dualtask', { dureeSec: Math.round((Date.now()-t0)/1000), meta:{ niveau:level, justessePrincipale:primAcc, justesseSecondaire:secAcc, memoire:(level===4?memAcc:null), rtMoyen:rtMoyen, indice:indice } });
    }
  }

  var level=1;
  var LEVEL_READY_FR = {
    1: { t:'Rond & Compteur', lines:[
          'Touche le <b>rond</b> dès qu\u2019il apparaît \u2014 ignore le carré et le triangle.',
          'En haut, un <b>compteur</b> s\u2019allume de temps en temps : touche-le vite avant qu\u2019il ne s\u2019éteigne.',
          'Les deux tournent en même temps, sans interruption, pendant 60 secondes.' ] },
    2: { t:'Piste & Tempo', lines:[
          'Un point tourne sur le cercle : pose ton doigt dessus et <b>suis-le</b> sans le lâcher.',
          'En même temps, un compteur s\u2019allume à côté \u2014 touche-le vite, sans interrompre le suivi.',
          'Les deux comptent en même temps : suivre la piste ET réagir au compteur.' ] },
    3: { t:'Bascule', lines:[
          'Une consigne (<b>gauche</b> ou <b>droite</b>) s\u2019affiche \u2014 tape du bon côté quand ça s\u2019allume.',
          'Le bon côté <b>change sans prévenir</b>, toutes les 2 à 4 réponses.',
          'Reste attentif\u00b7ve à la consigne affichée, pas à l\u2019habitude prise juste avant.' ] },
    4: { t:'Mémoire chargée', lines:[
          'Trois couleurs s\u2019affichent l\u2019une après l\u2019autre \u2014 retiens-les, dans l\u2019ordre.',
          'Ensuite, le jeu du niveau 1 (rond & compteur) commence normalement, pendant 60 secondes.',
          'À la fin, tu devras redonner l\u2019ordre des trois couleurs mémorisées au début.' ] },
    5: { t:'Calcul & Compteur', lines:[
          'Un nombre apparaît \u2014 tape <b>PAIR</b> ou <b>IMPAIR</b> selon sa valeur, le plus vite possible.',
          'En même temps, le compteur s\u2019allume à côté \u2014 touche-le vite, sans arrêter de calculer.',
          'Deux charges différentes à la fois : le calcul, et la réaction au compteur.' ] },
    6: { t:'Repérage combiné', lines:[
          'La cible n\u2019est pas juste une forme : c\u2019est une <b>forme ET une couleur</b> précises, rappelées en haut.',
          'Touche uniquement quand les deux correspondent \u2014 ignore tout le reste, même une bonne forme de la mauvaise couleur.',
          'Le compteur continue en parallèle, comme toujours.' ] },
    7: { t:'Mémoire glissante', lines:[
          'Des couleurs défilent une par une \u2014 tape <b>ÇA CORRESPOND</b> quand la couleur actuelle est la même que celle vue <b>deux étapes plus tôt</b>.',
          'Ne tape pas si ça ne correspond pas \u2014 se tromper dans les deux sens compte.',
          'Le compteur tourne toujours en parallèle.' ] },
    8: { t:'Stroop & Compteur', lines:[
          'Un mot de couleur apparaît, écrit dans une <b>autre couleur</b> \u2014 touche le bouton qui correspond à l\u2019<b>encre</b>, pas au mot lui-même.',
          'C\u2019est le réflexe le plus dur à retenir : le mot « ROUGE » peut être écrit en bleu.',
          'Le compteur continue en parallèle, comme toujours.' ] },
    9: { t:'Direction & Compteur', lines:[
          'Une flèche apparaît \u2014 tape la zone correspondante parmi les quatre autour (haut, bas, gauche, droite).',
          'Va vite : la flèche ne reste affichée qu\u2019un court instant.',
          'Le compteur tourne toujours en parallèle.' ] },
    10: { t:'Tendance & Compteur', lines:[
          'Des nombres défilent un par un \u2014 tape si le nombre actuel est <b>plus grand</b> ou <b>plus petit</b> que le précédent.',
          'Le tout premier nombre ne demande rien : rien à comparer encore.',
          'Le compteur tourne toujours en parallèle.' ] }
  };
  var LEVEL_READY_EN = {
    1: { t:'Circle & Counter', lines:[
          'Tap the <b>circle</b> as soon as it appears \u2014 ignore the square and the triangle.',
          'At the top, a <b>counter</b> lights up now and then: tap it fast before it goes out.',
          'Both run at the same time, without interruption, for 60 seconds.' ] },
    2: { t:'Track & Tempo', lines:[
          'A dot moves around the circle: put your finger on it and <b>follow it</b> without letting go.',
          'At the same time, a counter lights up alongside \u2014 tap it fast, without breaking your tracking.',
          'Both count at once: following the track AND reacting to the counter.' ] },
    3: { t:'Switch', lines:[
          'An instruction (<b>left</b> or <b>right</b>) is shown \u2014 tap the right side when it lights up.',
          'The right side <b>changes without warning</b>, every 2 to 4 answers.',
          'Stay focused on the instruction shown, not the habit you just picked up.' ] },
    4: { t:'Loaded memory', lines:[
          'Three colours appear one after another \u2014 remember them, in order.',
          'Then, the level 1 game (circle & counter) starts normally, for 60 seconds.',
          'At the end, you\u2019ll need to give back the order of the three colours memorised at the start.' ] },
    5: { t:'Maths & Counter', lines:[
          'A number appears \u2014 tap <b>EVEN</b> or <b>ODD</b> depending on its value, as fast as possible.',
          'At the same time, the counter lights up alongside \u2014 tap it fast, without stopping your maths.',
          'Two different loads at once: the maths, and reacting to the counter.' ] },
    6: { t:'Combined spotting', lines:[
          'The target isn\u2019t just a shape: it\u2019s a specific <b>shape AND colour</b>, reminded at the top.',
          'Only tap when both match \u2014 ignore everything else, even the right shape in the wrong colour.',
          'The counter keeps running in parallel, as always.' ] },
    7: { t:'Sliding memory', lines:[
          'Colours scroll by one at a time \u2014 tap <b>IT MATCHES</b> when the current colour is the same as the one seen <b>two steps earlier</b>.',
          'Don\u2019t tap if it doesn\u2019t match \u2014 mistakes in both directions count.',
          'The counter keeps running in parallel.' ] },
    8: { t:'Stroop & Counter', lines:[
          'A colour word appears, written in a <b>different colour</b> \u2014 tap the button matching the <b>ink</b>, not the word itself.',
          'It\u2019s the hardest reflex to hold onto: the word "RED" might be written in blue.',
          'The counter keeps running in parallel, as always.' ] },
    9: { t:'Direction & Counter', lines:[
          'An arrow appears \u2014 tap the matching zone among the four around it (up, down, left, right).',
          'Be quick: the arrow only stays on screen briefly.',
          'The counter keeps running in parallel.' ] },
    10: { t:'Trend & Counter', lines:[
          'Numbers scroll by one at a time \u2014 tap whether the current number is <b>bigger</b> or <b>smaller</b> than the previous one.',
          'The very first number asks nothing: nothing to compare yet.',
          'The counter keeps running in parallel.' ] }
  };
  var LEVEL_READY = L==='en' ? LEVEL_READY_EN : LEVEL_READY_FR;
  var LVL_WORD = {fr:'Niveau ',en:'Level '};
  function showReady(lvl, onGo){
    var info = LEVEL_READY[lvl];
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:(L==='en'?LVL_WORD.en:LVL_WORD.fr)+lvl+' \u00b7 '+info.t,
        lines: info.lines,
        why: L==='en'
          ? 'Holding two tasks at once engages the prefrontal cortex and the frontoparietal network \u2014 the same capacity for juggling several priorities that helps you avoid getting absorbed by a single thought \u2014 like a craving.'
          : 'Tenir deux tâches à la fois sollicite le cortex préfrontal et le réseau frontopariétal : la même capacité à gérer plusieurs priorités qui aide à ne pas se laisser absorber par une seule pensée \u2014 comme un craving.',
        onStart: function(avant){ if(avant!=null) window.__mdAvant=avant; onGo(); }, onSkip: showLevelSelect, skipLabel:t('change_level') });
    } else { onGo(); }
  }

  function startRound(lvl){
    level = lvl || 1;
    dtScreen='playing'; updateBackLink();
    primHits=0;primMiss=0;primFalse=0;primCorrectRej=0;primRts=[];
    secHits=0;secMiss=0;secTotal=0;counter=0;
    if (level===4){
      showReady(level, function(){ running=false; startLevel4(); });
      return;
    }
    showReady(level, function(){
      t0=Date.now();
      running=true; endAt=Date.now()+DURATION;
      if (level === 2) startLevel2();
      else if (level === 3) startLevel3();
      else if (level === 5) startLevel5();
      else if (level === 6) startLevel6();
      else if (level === 7) startLevel7();
      else if (level === 8) startLevel8();
      else if (level === 9) startLevel9();
      else if (level === 10) startLevel10();
      else startLevel1();
    });
  }

  function startLevel1(){
    render();
    nextPrimary();
    scheduleSecondary();
  }

  /* ---- Niveau 2 : Piste & Tempo (suivi circulaire continu + frappe rythmée en parallèle) ---- */
  var trackAngle=0, trackRAF=0, fingerDown=false, fingerAngle=0, trackSamples=0, trackOnTarget=0, sampleTimer=null, tickTimer=null;
  var R_TRACK=88, CENTER=110;

  function angleDiff(a,b){ var d=a-b; while(d>Math.PI)d-=2*Math.PI; while(d<-Math.PI)d+=2*Math.PI; return d; }

  function renderLevel2(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-track" id="dt-track"><div class="dt-target" id="dt-target"></div><div class="dt-finger" id="dt-finger"></div></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('track_hint')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_track')+' : <b id="dt-p-ok">0</b>%</span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    wireTrack();
  }

  var trackPointerId=null;
  function wireTrack(){
    var trackEl=document.getElementById('dt-track'), fingerEl=document.getElementById('dt-finger');
    function angleFromEvent(e){
      var r=trackEl.getBoundingClientRect();
      var cx=r.left+r.width/2, cy=r.top+r.height/2;
      var px=(e.touches?e.touches[0].clientX:e.clientX)-cx, py=(e.touches?e.touches[0].clientY:e.clientY)-cy;
      return Math.atan2(py,px);
    }
    function place(el,angle){ el.style.left=(CENTER+Math.cos(angle)*R_TRACK)+'px'; el.style.top=(CENTER+Math.sin(angle)*R_TRACK)+'px'; }
    trackEl.addEventListener('pointerdown', function(e){ fingerDown=true; trackPointerId=e.pointerId; fingerAngle=angleFromEvent(e); place(fingerEl,fingerAngle); fingerEl.classList.add('on'); trackEl.classList.add('tracking'); });
    trackEl.addEventListener('pointermove', function(e){ if(!fingerDown || e.pointerId!==trackPointerId) return; fingerAngle=angleFromEvent(e); place(fingerEl,fingerAngle); });
    trackEl.addEventListener('touchmove', function(e){ if (fingerDown) e.preventDefault(); }, {passive:false});
    window.addEventListener('pointerup', function(e){ if(e.pointerId!==trackPointerId) return; fingerDown=false; trackPointerId=null; if(fingerEl){fingerEl.classList.remove('on');} if(trackEl){trackEl.classList.remove('tracking');} });
  }

  function targetLoop(){
    if (!running || level!==2) return;
    trackAngle += 0.016;
    var target=document.getElementById('dt-target');
    if (target){ target.style.left=(CENTER+Math.cos(trackAngle)*R_TRACK)+'px'; target.style.top=(CENTER+Math.sin(trackAngle)*R_TRACK)+'px'; }
    trackRAF=requestAnimationFrame(targetLoop);
  }

  function startLevel2(){
    trackAngle=0; fingerDown=false; trackSamples=0; trackOnTarget=0;
    renderLevel2();
    trackRAF=requestAnimationFrame(targetLoop);
    scheduleSecondary();
    sampleTimer=setInterval(function(){
      if (!running) return;
      if (fingerDown){
        trackSamples++;
        if (Math.abs(angleDiff(trackAngle,fingerAngle)) < 0.5) trackOnTarget++;
        var pct = trackSamples ? Math.round(trackOnTarget/trackSamples*100) : 0;
        var el=document.getElementById('dt-p-ok'); if (el) el.textContent=pct;
      }
    }, 200);
    tickTimer=setInterval(function(){
      if (!running) return;
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain<=0) finish();
    }, 250);
  }

  /* ---- Niveau 3 : Bascule (le côté valide change sans prévenir) ---- */
  var activeSide='left', sinceSwitch=0, stimSide=null, l3Responded=false, l3StimT0=0;
  var l3Hits=0, l3Miss=0, l3False=0, l3CorrectRej=0, l3Rts=[];

  function updateSideLabel(){
    var el=document.getElementById('dt-side-label');
    if (el) el.textContent = t('side_active')+(activeSide==='left'?t('left_word'):t('right_word'));
    ['left','right'].forEach(function(s){
      var z=document.getElementById('dt-side-'+s);
      if (z) z.classList.toggle('active-zone', s===activeSide);
    });
  }

  function renderLevel3(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label" id="dt-side-label">'+t('side_active')+t('left_word')+'</p>'+
      '<div class="dt-sides"><div class="dt-side" id="dt-side-left"></div><div class="dt-side" id="dt-side-right"></div></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_accuracy')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-side-left').addEventListener('click', function(){ tapSide('left'); });
    document.getElementById('dt-side-right').addEventListener('click', function(){ tapSide('right'); });
    updateSideLabel();
  }

  function tapSide(side){
    if (!running || l3Responded || level!==3) return;
    l3Responded=true;
    var hint=document.getElementById('dt-hint');
    if (side===stimSide && stimSide===activeSide){ l3Hits++; l3Rts.push(Date.now()-l3StimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { l3False++; hint.textContent=t('wrong_side'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l3Hits;
  }

  function nextLevel3(){
    if (!running) return;
    l3Responded=false;
    stimSide = Math.random()<0.5 ? 'left':'right';
    var zone=document.getElementById('dt-side-'+stimSide);
    if (zone) zone.innerHTML='<div class="dt-shape circle" style="width:64px;height:64px"></div>';
    l3StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); hint.style.color='var(--ink-2)'; hint.textContent='\u00a0';
    setTimeout(function(){
      if (!running) return;
      if (!l3Responded){ if (stimSide===activeSide) l3Miss++; else l3CorrectRej++; }
      ['left','right'].forEach(function(s){ var z=document.getElementById('dt-side-'+s); if (z) z.innerHTML=''; });
      sinceSwitch++;
      if (sinceSwitch>=2 && Math.random()<0.3){ activeSide = activeSide==='left'?'right':'left'; sinceSwitch=0; updateSideLabel(); }
      var remain = endAt - Date.now();
      document.getElementById('dt-fill').style.width = Math.round((1 - Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft = Math.max(0, Math.ceil(remain/1000));
      var tEl = document.getElementById('dt-time');
      if (tEl) tEl.textContent = Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain > 300) setTimeout(nextLevel3, 220); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel3(){
    activeSide = Math.random()<0.5?'left':'right'; sinceSwitch=0;
    l3Hits=0;l3Miss=0;l3False=0;l3CorrectRej=0;l3Rts=[];
    renderLevel3();
    nextLevel3();
    scheduleSecondary();
  }

  /* ---- Niveau 4 : Mémoire chargée (retenir une séquence de couleurs, restituée à la fin) ---- */
  var MEM_COLORS=[{k:'sauge'},{k:'terra'},{k:'ocre'},{k:'fjord'}];
  var memSeq=[], memRecall=[];

  function showMemorize(cb){
    memSeq=[];
    for (var n=0;n<3;n++) memSeq.push(MEM_COLORS[Math.floor(Math.random()*MEM_COLORS.length)]);
    var i=0;
    body.innerHTML='<p class="game-q">'+t('remember_order')+'</p><div class="dt-memrow" id="dt-memrow"></div><p class="dt-hint">'+t('three_colors')+'</p>';
    var row=document.getElementById('dt-memrow');
    function showNext(){
      if (i>=memSeq.length){ setTimeout(cb, 500); return; }
      row.innerHTML = '<div class="dt-memdot" style="background:var(--'+memSeq[i].k+')"></div>';
      i++;
      setTimeout(function(){ if(row) row.innerHTML=''; setTimeout(showNext, 250); }, 700);
    }
    showNext();
  }

  function renderRecallStep(){
    var step=memRecall.length;
    if (step>=memSeq.length){ finishWithMemory(); return; }
    body.innerHTML='<p class="game-q">'+t('which_order')+(step+1)+'/'+memSeq.length+')</p><div class="dt-mempick" id="dt-mempick"></div>';
    var pick=document.getElementById('dt-mempick');
    MEM_COLORS.forEach(function(c){
      var b=document.createElement('button'); b.type='button'; b.className='dt-memdot pick'; b.style.background='var(--'+c.k+')';
      b.addEventListener('click', function(){ memRecall.push(c.k); renderRecallStep(); });
      pick.appendChild(b);
    });
  }
  function showRecall(){ memRecall=[]; renderRecallStep(); }

  function startLevel4(){
    showMemorize(function(){
      running=true; endAt=Date.now()+DURATION;
      startLevel1();
    });
  }

  /* ---- Niveau 5 : Calcul & Compteur ---- */
  var l5Num=null, l5Responded=false, l5StimT0=0;
  var l5Hits=0, l5Errors=0, l5Miss=0, l5Rts=[];

  function renderLevel5(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"><span style="font-family:var(--font-editorial);font-size:48px;font-weight:var(--w-bold);color:var(--ink)" id="dt-num"></span></div>'+
      '<div class="dt-sides"><div class="dt-side" id="dt-side-left" style="font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--ink)">'+t('pair_word')+'</div><div class="dt-side" id="dt-side-right" style="font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--ink)">'+t('impair_word')+'</div></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_calc')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-side-left').addEventListener('click', function(){ answerL5(true); });
    document.getElementById('dt-side-right').addEventListener('click', function(){ answerL5(false); });
  }

  function answerL5(saidPair){
    if (!running || l5Responded || level!==5) return;
    l5Responded=true;
    var isPair = (l5Num%2===0);
    var hint=document.getElementById('dt-hint');
    if (saidPair===isPair){ l5Hits++; l5Rts.push(Date.now()-l5StimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { l5Errors++; hint.textContent=t('not_this_time'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l5Hits;
  }

  function nextLevel5(){
    if (!running) return;
    l5Responded=false;
    l5Num = 1+Math.floor(Math.random()*98);
    var numEl=document.getElementById('dt-num'); if (numEl) numEl.textContent=l5Num;
    l5StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l5Responded) l5Miss++;
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel5,260); else if (running) finish();
    }, WIN_MS+400);
  }

  function startLevel5(){
    l5Hits=0;l5Errors=0;l5Miss=0;l5Rts=[];
    renderLevel5();
    nextLevel5();
    scheduleSecondary();
  }

  /* ---- Niveau 6 : Repérage combiné ---- */
  var L6_SHAPES=['circle','square'], L6_COLORS_FR=[{k:'sauge',n:'vert'},{k:'terra',n:'terracotta'},{k:'fjord',n:'bleu'},{k:'ocre',n:'ocre'}];
  var L6_COLORS_EN=[{k:'sauge',n:'green'},{k:'terra',n:'terracotta'},{k:'fjord',n:'blue'},{k:'ocre',n:'ochre'}];
  var L6_COLORS = L==='en' ? L6_COLORS_EN : L6_COLORS_FR;
  var l6Target=null, l6Cur=null, l6Responded=false, l6StimT0=0;
  var l6Hits=0, l6Miss=0, l6False=0, l6CorrectRej=0, l6Rts=[];

  function renderLevel6(){
    l6Target = { shape:L6_SHAPES[Math.floor(Math.random()*L6_SHAPES.length)], color:L6_COLORS[Math.floor(Math.random()*L6_COLORS.length)] };
    var shapeName = l6Target.shape==='circle' ? t('shape_circle') : t('shape_square');
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">'+t('lbl_target')+'<span style="color:var(--'+l6Target.color.k+'-d,var(--ink))">'+shapeName+' '+l6Target.color.n+'</span>'+t('lbl_only')+'</p>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_spotting')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-stage').addEventListener('click', tapLevel6);
  }

  function tapLevel6(){
    if (!running || l6Responded || level!==6) return;
    l6Responded=true;
    var hint=document.getElementById('dt-hint');
    var isMatch = l6Cur.shape===l6Target.shape && l6Cur.color.k===l6Target.color.k;
    if (isMatch){ l6Hits++; l6Rts.push(Date.now()-l6StimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { l6False++; hint.textContent=t('not_right_combo'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l6Hits;
  }

  function nextLevel6(){
    if (!running) return;
    l6Responded=false;
    var isTarget = Math.random()<0.35;
    if (isTarget){ l6Cur = { shape:l6Target.shape, color:l6Target.color }; }
    else {
      var shape, color;
      do {
        shape=L6_SHAPES[Math.floor(Math.random()*L6_SHAPES.length)];
        color=L6_COLORS[Math.floor(Math.random()*L6_COLORS.length)];
      } while (shape===l6Target.shape && color.k===l6Target.color.k);
      l6Cur = { shape:shape, color:color };
    }
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape dyn '+l6Cur.shape+'" style="background:var(--'+l6Cur.color.k+')"></div>';
    l6StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l6Responded){ if (l6Cur.shape===l6Target.shape && l6Cur.color.k===l6Target.color.k) l6Miss++; else l6CorrectRej++; }
      stage.innerHTML='';
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel6,220); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel6(){
    l6Hits=0;l6Miss=0;l6False=0;l6CorrectRej=0;l6Rts=[];
    renderLevel6();
    nextLevel6();
    scheduleSecondary();
  }

  /* ---- Niveau 7 : Mémoire glissante (2-back) ---- */
  var L7_COLORS=['sauge','terra','fjord','ocre'];
  var l7Hist=[], l7Cur=null, l7Responded=false, l7StimT0=0;
  var l7Hits=0, l7Miss=0, l7False=0, l7CorrectRej=0, l7Rts=[];

  function renderLevel7(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('first_two_landmark')+'</div>'+
      '<button type="button" class="game-cta" id="dt-match-btn" style="margin:8px 0">'+t('match_btn')+'</button>'+
      '<div class="game-hud"><span>'+t('lbl_memory')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-match-btn').addEventListener('click', tapLevel7);
  }

  function tapLevel7(){
    if (!running || l7Responded || level!==7 || l7Hist.length<3) return;
    l7Responded=true;
    var twoBack = l7Hist[l7Hist.length-3];
    var hint=document.getElementById('dt-hint');
    var isMatch = twoBack===l7Cur;
    if (isMatch){ l7Hits++; l7Rts.push(Date.now()-l7StimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { l7False++; hint.textContent=t('no_match'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l7Hits;
  }

  function nextLevel7(){
    if (!running) return;
    l7Responded=false;
    l7Cur = L7_COLORS[Math.floor(Math.random()*L7_COLORS.length)];
    l7Hist.push(l7Cur);
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape square" style="background:var(--'+l7Cur+')"></div>';
    l7StimT0=Date.now();
    var hint=document.getElementById('dt-hint');
    if (hint) { hint.style.color='var(--ink-2)'; hint.textContent = l7Hist.length<3 ? t('a_bit_more_landmark') : '\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (l7Hist.length>=3 && !l7Responded){ var twoBack=l7Hist[l7Hist.length-3]; if (twoBack===l7Cur) l7Miss++; else l7CorrectRej++; }
      stage.innerHTML='';
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel7,300); else if (running) finish();
    }, WIN_MS+300);
  }

  function startLevel7(){
    l7Hist=[];l7Hits=0;l7Miss=0;l7False=0;l7CorrectRej=0;l7Rts=[];
    renderLevel7();
    nextLevel7();
    scheduleSecondary();
  }

  /* ---- Niveau 8 : Stroop & Compteur ---- */
  var L8_COLORS_FR=[{k:'sauge',n:'VERT'},{k:'terra',n:'ROUGE'},{k:'fjord',n:'BLEU'},{k:'ocre',n:'JAUNE'}];
  var L8_COLORS_EN=[{k:'sauge',n:'GREEN'},{k:'terra',n:'RED'},{k:'fjord',n:'BLUE'},{k:'ocre',n:'YELLOW'}];
  var L8_COLORS = L==='en' ? L8_COLORS_EN : L8_COLORS_FR;
  var l8Cur=null, l8Responded=false, l8StimT0=0;
  var l8Hits=0, l8Miss=0, l8False=0, l8Rts=[];

  function renderLevel8(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">'+t('ink_not_word')+'<b>'+t('ink_word')+'</b>'+t('not_word')+'</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div class="dt-opts" id="dt-opts" style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:10px"></div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_stroop')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    var opts=document.getElementById('dt-opts');
    L8_COLORS.forEach(function(c){
      var b=document.createElement('button'); b.type='button'; b.textContent=c.n;
      b.style.cssText='flex:1 1 40%;min-height:44px;border-radius:12px;border:none;font-weight:var(--w-bold);color:#fff;background:var(--'+c.k+')';
      b.addEventListener('click', function(){ tapLevel8(c.k); });
      opts.appendChild(b);
    });
  }

  function tapLevel8(pickedKey){
    if (!running || l8Responded || level!==8) return;
    l8Responded=true;
    var hint=document.getElementById('dt-hint');
    if (pickedKey===l8Cur.ink.k){ l8Hits++; l8Rts.push(Date.now()-l8StimT0); hint.textContent=t('good'); hint.style.color='var(--sauge)'; }
    else { l8False++; hint.textContent=t('was_ink_not_word'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l8Hits;
  }

  function nextLevel8(){
    if (!running) return;
    l8Responded=false;
    var word=L8_COLORS[Math.floor(Math.random()*L8_COLORS.length)];
    var ink; do { ink=L8_COLORS[Math.floor(Math.random()*L8_COLORS.length)]; } while (ink.k===word.k);
    l8Cur={ word:word, ink:ink };
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-family:var(--font-editorial);font-size:34px;font-weight:var(--w-bold);color:var(--'+ink.k+')">'+word.n+'</span>';
    l8StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l8Responded){ l8Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel8,250); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel8(){
    l8Hits=0;l8Miss=0;l8False=0;l8Rts=[];
    renderLevel8();
    nextLevel8();
    scheduleSecondary();
  }

  /* ---- Niveau 9 : Direction & Compteur ---- */
  var L9_DIRS=[{k:'up',n:'\u2191'},{k:'down',n:'\u2193'},{k:'left',n:'\u2190'},{k:'right',n:'\u2192'}];
  var l9Cur=null, l9Responded=false, l9StimT0=0;
  var l9Hits=0, l9Miss=0, l9False=0, l9Rts=[];

  function renderLevel9(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">'+t('tap_arrow_zone')+'</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div id="dt-cross" style="display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr 1fr;gap:6px;max-width:220px;margin:10px auto 0">'+
        '<div></div><button type="button" data-d="up" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2191</button><div></div>'+
        '<button type="button" data-d="left" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2190</button><div></div>'+
        '<button type="button" data-d="right" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2192</button>'+
        '<div></div><button type="button" data-d="down" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2193</button><div></div>'+
      '</div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_direction')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.querySelectorAll('#dt-cross [data-d]').forEach(function(b){
      b.addEventListener('click', function(){ tapLevel9(b.getAttribute('data-d')); });
    });
  }

  function tapLevel9(pickedDir){
    if (!running || l9Responded || level!==9) return;
    l9Responded=true;
    var hint=document.getElementById('dt-hint');
    if (pickedDir===l9Cur.k){ l9Hits++; l9Rts.push(Date.now()-l9StimT0); hint.textContent=t('good_direction'); hint.style.color='var(--sauge)'; }
    else { l9False++; hint.textContent=t('wrong_direction'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l9Hits;
  }

  function nextLevel9(){
    if (!running) return;
    l9Responded=false;
    l9Cur=L9_DIRS[Math.floor(Math.random()*L9_DIRS.length)];
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-size:44px;font-weight:var(--w-bold);color:var(--ink)">'+l9Cur.n+'</span>';
    l9StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l9Responded){ l9Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel9,280); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel9(){
    l9Hits=0;l9Miss=0;l9False=0;l9Rts=[];
    renderLevel9();
    nextLevel9();
    scheduleSecondary();
  }

  /* ---- Niveau 10 : Tendance & Compteur ---- */
  var l10Prev=null, l10Cur=null, l10Responded=false, l10StimT0=0;
  var l10Hits=0, l10Miss=0, l10False=0, l10Rts=[];

  function renderLevel10(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">'+t('bigger_smaller_q')+'</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div style="display:flex;gap:10px;margin-top:10px">'+
        '<button type="button" id="dt-l10-up" style="flex:1;min-height:48px;border-radius:12px;border:none;background:var(--sauge);color:#fff;font-weight:var(--w-bold)">'+t('bigger_btn')+'</button>'+
        '<button type="button" id="dt-l10-down" style="flex:1;min-height:48px;border-radius:12px;border:none;background:var(--terra);color:#fff;font-weight:var(--w-bold)">'+t('smaller_btn')+'</button>'+
      '</div>'+
      '<div class="dt-hint" id="dt-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('lbl_trend')+' : <b id="dt-p-ok">0</b></span><span>'+t('lbl_tempo')+' : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-l10-up').addEventListener('click', function(){ tapLevel10('up'); });
    document.getElementById('dt-l10-down').addEventListener('click', function(){ tapLevel10('down'); });
  }

  function tapLevel10(pick){
    if (!running || l10Responded || level!==10 || l10Prev==null) return;
    l10Responded=true;
    var hint=document.getElementById('dt-hint');
    var actual = l10Cur>l10Prev ? 'up' : 'down';
    if (pick===actual){ l10Hits++; l10Rts.push(Date.now()-l10StimT0); hint.textContent=t('correct_word'); hint.style.color='var(--sauge)'; }
    else { l10False++; hint.textContent=t('wrong_way'); hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l10Hits;
  }

  function nextLevel10(){
    if (!running) return;
    l10Responded=false;
    l10Prev=l10Cur;
    var n; do { n=1+Math.floor(Math.random()*20); } while (n===l10Prev);
    l10Cur=n;
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-family:var(--font-editorial);font-size:40px;font-weight:var(--w-bold);color:var(--ink)">'+n+'</span>';
    l10StimT0=Date.now();
    var hint=document.getElementById('dt-hint');
    if (hint){ hint.style.color='var(--ink-2)'; hint.textContent = l10Prev==null ? t('first_number') : '\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l10Responded && l10Prev!=null){ l10Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel10,280); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel10(){
    l10Prev=null; l10Cur=null; l10Hits=0;l10Miss=0;l10False=0;l10Rts=[];
    renderLevel10();
    nextLevel10();
    scheduleSecondary();
  }

  var dtScreen='select';
  function stopRoundCleanup(){
    running=false;
    clearTimeout(secTimer); clearTimeout(alertTimeout);
    cancelAnimationFrame(trackRAF); clearInterval(sampleTimer); clearInterval(tickTimer);
  }
  function updateBackLink(){
    var back=document.getElementById('dt-back'), txt=document.getElementById('dt-back-txt');
    if (!back) return;
    if (dtScreen==='select'){
      back.setAttribute('href','fiches.html'); if (txt) txt.textContent=t('game.back_labo'); back.onclick=null;
    } else {
      back.removeAttribute('href'); if (txt) txt.textContent=t('back_to_levels');
      back.onclick=function(e){ e.preventDefault(); stopRoundCleanup(); showLevelSelect(); };
    }
  }

  var LVLSEL = {
    choose:{fr:'Choisis un niveau',en:'Choose a level'},
    t1:{fr:'Rond & Compteur',en:'Circle & Counter'}, s1:{fr:'Touche le rond, surveille le compteur',en:'Tap the circle, watch the counter'},
    t2:{fr:'Piste & Tempo',en:'Track & Tempo'}, s2:{fr:'Suis le point en tournant, tape le tempo à côté',en:'Follow the dot as it turns, tap the tempo alongside'},
    t3:{fr:'Bascule',en:'Switch'}, s3:{fr:'Le bon côté change sans prévenir, en plus du tempo',en:'The right side changes without warning, on top of the tempo'},
    t4:{fr:'Mémoire chargée',en:'Loaded memory'}, s4:{fr:'Retiens 3 couleurs, joue, puis restitue l\u2019ordre',en:'Remember 3 colours, play, then recall the order'},
    t5:{fr:'Calcul & Compteur',en:'Maths & Counter'}, s5:{fr:'Pair ou impair, en plus du tempo',en:'Even or odd, on top of the tempo'},
    t6:{fr:'Repérage combiné',en:'Combined spotting'}, s6:{fr:'Une forme ET une couleur précises, pas juste l\u2019une des deux',en:'A specific shape AND colour, not just one of the two'},
    t7:{fr:'Mémoire glissante',en:'Sliding memory'}, s7:{fr:'Ça correspond à il y a deux étapes, ou pas',en:'It matches two steps back, or it doesn\u2019t'},
    t8:{fr:'Stroop & Compteur',en:'Stroop & Counter'}, s8:{fr:'Touche l\u2019encre, pas le mot — en plus du tempo',en:'Tap the ink colour, not the word \u2014 on top of the tempo'},
    t9:{fr:'Direction & Compteur',en:'Direction & Counter'}, s9:{fr:'Suis la flèche parmi 4 zones, en plus du tempo',en:'Follow the arrow among 4 zones, on top of the tempo'},
    t10:{fr:'Tendance & Compteur',en:'Trend & Counter'}, s10:{fr:'Plus grand ou plus petit que le précédent, en plus du tempo',en:'Bigger or smaller than the previous one, on top of the tempo'}
  };
  function tl(k){ var e=LVLSEL[k]; return e ? (L==='en'?e.en:e.fr) : k; }

  function showLevelSelect(){
    dtScreen='select'; updateBackLink();
    body.innerHTML =
      '<p class="game-q">'+tl('choose')+'</p>'+
      '<div class="dt-levels">'+
        '<button type="button" class="dt-lvl" data-lvl="1"><span class="num">1</span><span class="tx"><span class="tt">'+tl('t1')+'</span><br><span class="sb">'+tl('s1')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="2"><span class="num">2</span><span class="tx"><span class="tt">'+tl('t2')+'</span><br><span class="sb">'+tl('s2')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="3"><span class="num">3</span><span class="tx"><span class="tt">'+tl('t3')+'</span><br><span class="sb">'+tl('s3')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="4"><span class="num">4</span><span class="tx"><span class="tt">'+tl('t4')+'</span><br><span class="sb">'+tl('s4')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="5"><span class="num">5</span><span class="tx"><span class="tt">'+tl('t5')+'</span><br><span class="sb">'+tl('s5')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="6"><span class="num">6</span><span class="tx"><span class="tt">'+tl('t6')+'</span><br><span class="sb">'+tl('s6')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="7"><span class="num">7</span><span class="tx"><span class="tt">'+tl('t7')+'</span><br><span class="sb">'+tl('s7')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="8"><span class="num">8</span><span class="tx"><span class="tt">'+tl('t8')+'</span><br><span class="sb">'+tl('s8')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="9"><span class="num">9</span><span class="tx"><span class="tt">'+tl('t9')+'</span><br><span class="sb">'+tl('s9')+'</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="10"><span class="num">10</span><span class="tx"><span class="tt">'+tl('t10')+'</span><br><span class="sb">'+tl('s10')+'</span></span></button>'+
      '</div>';
    body.querySelectorAll('[data-lvl]').forEach(function(b){
      b.addEventListener('click', function(){ startRound(parseInt(b.getAttribute('data-lvl'),10)); });
    });
  }

  try{ MDCore.init({page:'dualtask',section:'equilibre'}); }catch(e){}
  showLevelSelect(); // écran unique au chargement : la liste des niveaux. Les règles (+ pourquoi)
                      // s'affichent ensuite via le compagnon, au moment où un niveau est choisi.
})();
