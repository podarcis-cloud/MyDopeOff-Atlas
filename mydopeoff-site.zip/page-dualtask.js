/* MyDope Off — page-dualtask.js
   Logique de dualtask, extraite du script inline de dualtask.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var DURATION=60000;        // durée totale de la manche (ms)
  var WIN_MS=1100;           // fenêtre de réponse à un stimulus primaire
  var SHAPES=['circle','square','triangle'];
  var body=document.getElementById('dt-body');

  // état primaire (formes)
  var primHits=0, primMiss=0, primFalse=0, primCorrectRej=0, primRts=[];
  // état secondaire (compteur)
  var secHits=0, secMiss=0, secTotal=0;
  var counter=0, secTimer=null, alertActive=false, alertTimeout=null;
  var stageTimer=null, running=false, t0=0, endAt=0;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }

  function render(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">Prêt\u2026</div>'+
      '<div class="game-hud"><span>Rond : <b id="dt-p-ok">0</b></span><span>Compteur : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-stage').addEventListener('click', tapPrimary);
  }

  function tapSecondary(){
    if (!running) return;
    if (alertActive){
      alertActive=false; clearTimeout(alertTimeout);
      secHits++; document.getElementById('dt-s-ok').textContent=secHits;
      var badge=document.getElementById('dt-badge');
      badge.classList.remove('alert');
      badge.classList.remove('hit'); void badge.offsetWidth; badge.classList.add('hit');
      badge.addEventListener('animationend', function h(){ badge.classList.remove('hit'); badge.removeEventListener('animationend', h); });
      scheduleSecondary();
    }
  }

  var curShape=null, responded=false, stimT0=0;
  function tapPrimary(){
    if (!running || responded) return;
    responded=true;
    var hint=document.getElementById('dt-hint');
    if (curShape==='circle'){ primHits++; primRts.push(Date.now()-stimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { primFalse++; hint.textContent='C\u2019était pas un rond.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=primHits;
  }

  function nextPrimary(){
    if (!running) return;
    responded=false;
    curShape = Math.random()<0.4 ? 'circle' : SHAPES[1+Math.floor(Math.random()*2)];
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape '+curShape+'"></div>';
    stimT0=Date.now();
    document.getElementById('dt-hint').style.color='var(--ink-2)';
    document.getElementById('dt-hint').textContent='\u00a0';
    setTimeout(function(){
      if (!running) return;
      if (!responded){
        if (curShape==='circle'){ primMiss++; }
        else { primCorrectRej++; }
      }
      stage.innerHTML='';
      var remain = endAt - Date.now();
      document.getElementById('dt-fill').style.width = Math.round((1 - Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft = Math.max(0, Math.ceil(remain/1000));
      var tEl = document.getElementById('dt-time');
      if (tEl) tEl.textContent = Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain > 300) setTimeout(nextPrimary, 220); else if (running) finish();
    }, WIN_MS);
  }

  function scheduleSecondary(){
    if (!running) return;
    var delay = 3000 + Math.random()*3000;
    secTimer = setTimeout(function(){
      if (!running) return;
      counter++; document.getElementById('dt-badge').textContent=counter;
      secTotal++;
      alertActive=true;
      document.getElementById('dt-badge').classList.add('alert');
      alertTimeout=setTimeout(function(){
        if (alertActive){ alertActive=false; secMiss++; document.getElementById('dt-badge').classList.remove('alert'); }
        scheduleSecondary();
      }, 1200);
    }, delay);
  }

  function finish(){
    stopRoundCleanup();
    if (level===4){ showRecall(); return; }
    renderResults(0);
  }
  function finishWithMemory(){
    var correct=0;
    for (var i=0;i<memSeq.length;i++) if (memRecall[i]===memSeq[i].k) correct++;
    renderResults(Math.round(correct/memSeq.length*100));
  }
  function renderResults(memAcc){
    var primAcc, rtMoyen=0, labelPrim;
    if (level===2){
      primAcc = trackSamples ? Math.round(trackOnTarget/trackSamples*100) : 0;
      labelPrim = 'Suivi de la piste';
    } else if (level===3){
      var l3Total=l3Hits+l3Miss+l3False+l3CorrectRej;
      primAcc = l3Total ? Math.round(((l3Hits+l3CorrectRej)/l3Total)*100) : 0;
      rtMoyen = l3Rts.length ? Math.round(l3Rts.reduce(function(a,b){return a+b;},0)/l3Rts.length) : 0;
      labelPrim = 'Bascule (bon côté)';
    } else if (level===5){
      var l5Total=l5Hits+l5Errors+l5Miss;
      primAcc = l5Total ? Math.round((l5Hits/l5Total)*100) : 0;
      rtMoyen = l5Rts.length ? Math.round(l5Rts.reduce(function(a,b){return a+b;},0)/l5Rts.length) : 0;
      labelPrim = 'Calcul (pair/impair)';
    } else if (level===6){
      var l6Total=l6Hits+l6Miss+l6False+l6CorrectRej;
      primAcc = l6Total ? Math.round(((l6Hits+l6CorrectRej)/l6Total)*100) : 0;
      rtMoyen = l6Rts.length ? Math.round(l6Rts.reduce(function(a,b){return a+b;},0)/l6Rts.length) : 0;
      labelPrim = 'Repérage combiné';
    } else if (level===7){
      var l7Total=l7Hits+l7Miss+l7False+l7CorrectRej;
      primAcc = l7Total ? Math.round(((l7Hits+l7CorrectRej)/l7Total)*100) : 0;
      rtMoyen = l7Rts.length ? Math.round(l7Rts.reduce(function(a,b){return a+b;},0)/l7Rts.length) : 0;
      labelPrim = 'Mémoire glissante (2-back)';
    } else {
      var primTotal=primHits+primMiss+primFalse+primCorrectRej;
      primAcc = primTotal ? Math.round(((primHits+primCorrectRej)/primTotal)*100) : 0;
      rtMoyen = primRts.length ? Math.round(primRts.reduce(function(a,b){return a+b;},0)/primRts.length) : 0;
      labelPrim = 'Tâche principale (rond)';
    }
    var secAcc = secTotal ? Math.round((secHits/secTotal)*100) : 0;
    var indice = (level===4) ? Math.round((primAcc+secAcc+memAcc)/3) : Math.round((primAcc+secAcc)/2);
    var d=store(); d.dualtask=d.dualtask||{best:0,parties:0}; d.dualtask.parties++; if(indice>d.dualtask.best)d.dualtask.best=indice; save(d);
    var statsList=[{label:labelPrim,value:primAcc+'%'},{label:'tâche secondaire (tempo)',value:secAcc+'%'}];
    if(level===4) statsList.push({label:'mémoire de la séquence',value:memAcc+'%'});
    statsList.push({label:'attention divisée',value:indice+'/100'});
    if (window.MDExercise){
      MDExercise.after('dualtask', { avant: window.__mdAvant, dureeSec: Math.round((Date.now()-t0)/1000),
        meta:{ niveau:level, justessePrincipale:primAcc, justesseSecondaire:secAcc, memoire:(level===4?memAcc:null), rtMoyen:rtMoyen, indice:indice },
        title:'Double tâche — Niveau '+level, stats:statsList,
        nav:{ primary:{label:'Rejouer ce niveau'}, secondary:{label:'Changer de niveau', onClick:showLevelSelect} },
        onClose:function(){ window.__mdAvant=null; startRound(level); } });
    } else if (window.MDData && MDData.logSession){
      MDData.logSession('dualtask', { dureeSec: Math.round((Date.now()-t0)/1000), meta:{ niveau:level, justessePrincipale:primAcc, justesseSecondaire:secAcc, memoire:(level===4?memAcc:null), rtMoyen:rtMoyen, indice:indice } });
    }
  }

  var level=1;
  var LEVEL_READY = {
    1: { t:'Rond & Compteur', lines:[
          'Touche le <b>rond</b> dès qu\u2019il appara\u00eet \u2014 ignore le carr\u00e9 et le triangle.',
          'En haut, un <b>compteur</b> s\u2019allume de temps en temps : touche-le vite avant qu\u2019il ne s\u2019\u00e9teigne.',
          'Les deux tournent en m\u00eame temps, sans interruption, pendant 60 secondes.' ] },
    2: { t:'Piste & Tempo', lines:[
          'Un point tourne sur le cercle : pose ton doigt dessus et <b>suis-le</b> sans le l\u00e2cher.',
          'En m\u00eame temps, un compteur s\u2019allume \u00e0 c\u00f4t\u00e9 \u2014 touche-le vite, sans interrompre le suivi.',
          'Les deux comptent en m\u00eame temps : suivre la piste ET r\u00e9agir au compteur.' ] },
    3: { t:'Bascule', lines:[
          'Une consigne (<b>gauche</b> ou <b>droite</b>) s\u2019affiche \u2014 tape du bon c\u00f4t\u00e9 quand \u00e7a s\u2019allume.',
          'Le bon c\u00f4t\u00e9 <b>change sans pr\u00e9venir</b>, toutes les 2 \u00e0 4 r\u00e9ponses.',
          'Reste attentif\u00b7ve \u00e0 la consigne affich\u00e9e, pas \u00e0 l\u2019habitude prise juste avant.' ] },
    5: { t:'Calcul & Compteur', lines:[
          'Un nombre appara\u00eet \u2014 tape <b>PAIR</b> ou <b>IMPAIR</b> selon sa valeur, le plus vite possible.',
          'En m\u00eame temps, le compteur s\u2019allume \u00e0 c\u00f4t\u00e9 \u2014 touche-le vite, sans arr\u00eater de calculer.',
          'Deux charges diff\u00e9rentes \u00e0 la fois : le calcul, et la r\u00e9action au compteur.' ] },
    6: { t:'Repérage combiné', lines:[
          'La cible n\u2019est pas juste une forme : c\u2019est une <b>forme ET une couleur</b> pr\u00e9cises, rappel\u00e9es en haut.',
          'Touche uniquement quand les deux correspondent \u2014 ignore tout le reste, m\u00eame une bonne forme de la mauvaise couleur.',
          'Le compteur continue en parall\u00e8le, comme toujours.' ] },
    7: { t:'Mémoire glissante', lines:[
          'Des couleurs d\u00e9filent une par une \u2014 tape <b>\u00c7A CORRESPOND</b> quand la couleur actuelle est la m\u00eame que celle vue <b>deux \u00e9tapes plus t\u00f4t</b>.',
          'Ne tape pas si \u00e7a ne correspond pas \u2014 se tromper dans les deux sens compte.',
          'Le compteur tourne toujours en parall\u00e8le.' ] },
    8: { t:'Stroop & Compteur', lines:[
          'Un mot de couleur appara\u00eet, \u00e9crit dans une <b>autre couleur</b> \u2014 touche le bouton qui correspond \u00e0 l\u2019<b>encre</b>, pas au mot lui-m\u00eame.',
          'C\u2019est le r\u00e9flexe le plus dur \u00e0 retenir : le mot « ROUGE » peut \u00eatre \u00e9crit en bleu.',
          'Le compteur continue en parall\u00e8le, comme toujours.' ] },
    9: { t:'Direction & Compteur', lines:[
          'Une fl\u00e8che appara\u00eet \u2014 tape la zone correspondante parmi les quatre autour (haut, bas, gauche, droite).',
          'Va vite : la fl\u00e8che ne reste affich\u00e9e qu\u2019un court instant.',
          'Le compteur tourne toujours en parall\u00e8le.' ] },
    10: { t:'Tendance & Compteur', lines:[
          'Des nombres d\u00e9filent un par un \u2014 tape si le nombre actuel est <b>plus grand</b> ou <b>plus petit</b> que le pr\u00e9c\u00e9dent.',
          'Le tout premier nombre ne demande rien : rien \u00e0 comparer encore.',
          'Le compteur tourne toujours en parall\u00e8le.' ] }
  };
  function showReady(lvl, onGo){
    var info = LEVEL_READY[lvl];
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:'Niveau '+lvl+' \u00b7 '+info.t,
        lines: info.lines,
        why:'Tenir deux t\u00e2ches \u00e0 la fois sollicite le cortex pr\u00e9frontal et le r\u00e9seau frontopari\u00e9tal : la m\u00eame capacit\u00e9 \u00e0 g\u00e9rer plusieurs priorit\u00e9s qui aide \u00e0 ne pas se laisser absorber par une seule pens\u00e9e \u2014 comme un craving.',
        onStart: function(avant){ if(avant!=null) window.__mdAvant=avant; onGo(); }, onSkip: showLevelSelect, skipLabel:'Changer de niveau' });
    } else { onGo(); }
  }

  function startRound(lvl){
    level = lvl || 1;
    dtScreen='playing'; updateBackLink();
    primHits=0;primMiss=0;primFalse=0;primCorrectRej=0;primRts=[];
    secHits=0;secMiss=0;secTotal=0;counter=0;
    if (level===4){
      running=false;
      startLevel4();
      return;
    }
    showReady(level, function(){
      t0=Date.now();
      running=true; endAt=Date.now()+DURATION;
      if (level === 2) startLevel2();
      else if (level === 3) startLevel3();
      else if (level === 5) startLevel5();
      else if (level === 6) startLevel6();
      else if (level === 7) startLevel7();
      else if (level === 8) startLevel8();
      else if (level === 9) startLevel9();
      else if (level === 10) startLevel10();
      else startLevel1();
    });
  }

  function startLevel1(){
    render();
    nextPrimary();
    scheduleSecondary();
  }

  /* ---- Niveau 2 : Piste & Tempo (suivi circulaire continu + frappe rythmée en parallèle) ---- */
  var trackAngle=0, trackRAF=0, fingerDown=false, fingerAngle=0, trackSamples=0, trackOnTarget=0, sampleTimer=null, tickTimer=null;
  var R_TRACK=88, CENTER=110;

  function angleDiff(a,b){ var d=a-b; while(d>Math.PI)d-=2*Math.PI; while(d<-Math.PI)d+=2*Math.PI; return d; }

  function renderLevel2(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-track" id="dt-track"><div class="dt-target" id="dt-target"></div><div class="dt-finger" id="dt-finger"></div></div>'+
      '<div class="dt-hint" id="dt-hint">Pose le doigt sur le point bleu et suis-le en tournant.</div>'+
      '<div class="game-hud"><span>Suivi : <b id="dt-p-ok">0</b>%</span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    wireTrack();
  }

  var trackPointerId=null;
  function wireTrack(){
    var trackEl=document.getElementById('dt-track'), fingerEl=document.getElementById('dt-finger');
    function angleFromEvent(e){
      var r=trackEl.getBoundingClientRect();
      var cx=r.left+r.width/2, cy=r.top+r.height/2;
      var px=(e.touches?e.touches[0].clientX:e.clientX)-cx, py=(e.touches?e.touches[0].clientY:e.clientY)-cy;
      return Math.atan2(py,px);
    }
    function place(el,angle){ el.style.left=(CENTER+Math.cos(angle)*R_TRACK)+'px'; el.style.top=(CENTER+Math.sin(angle)*R_TRACK)+'px'; }
    trackEl.addEventListener('pointerdown', function(e){ fingerDown=true; trackPointerId=e.pointerId; fingerAngle=angleFromEvent(e); place(fingerEl,fingerAngle); fingerEl.classList.add('on'); trackEl.classList.add('tracking'); });
    trackEl.addEventListener('pointermove', function(e){ if(!fingerDown || e.pointerId!==trackPointerId) return; fingerAngle=angleFromEvent(e); place(fingerEl,fingerAngle); });
    trackEl.addEventListener('touchmove', function(e){ if (fingerDown) e.preventDefault(); }, {passive:false});
    window.addEventListener('pointerup', function(e){ if(e.pointerId!==trackPointerId) return; fingerDown=false; trackPointerId=null; if(fingerEl){fingerEl.classList.remove('on');} if(trackEl){trackEl.classList.remove('tracking');} });
  }

  function targetLoop(){
    if (!running || level!==2) return;
    trackAngle += 0.016;
    var target=document.getElementById('dt-target');
    if (target){ target.style.left=(CENTER+Math.cos(trackAngle)*R_TRACK)+'px'; target.style.top=(CENTER+Math.sin(trackAngle)*R_TRACK)+'px'; }
    trackRAF=requestAnimationFrame(targetLoop);
  }

  function startLevel2(){
    trackAngle=0; fingerDown=false; trackSamples=0; trackOnTarget=0;
    renderLevel2();
    trackRAF=requestAnimationFrame(targetLoop);
    scheduleSecondary();
    sampleTimer=setInterval(function(){
      if (!running) return;
      if (fingerDown){
        trackSamples++;
        if (Math.abs(angleDiff(trackAngle,fingerAngle)) < 0.5) trackOnTarget++;
        var pct = trackSamples ? Math.round(trackOnTarget/trackSamples*100) : 0;
        var el=document.getElementById('dt-p-ok'); if (el) el.textContent=pct;
      }
    }, 200);
    tickTimer=setInterval(function(){
      if (!running) return;
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain<=0) finish();
    }, 250);
  }

  /* ---- Niveau 3 : Bascule (le côté valide change sans prévenir) ---- */
  var activeSide='left', sinceSwitch=0, stimSide=null, l3Responded=false, l3StimT0=0;
  var l3Hits=0, l3Miss=0, l3False=0, l3CorrectRej=0, l3Rts=[];

  function updateSideLabel(){
    var el=document.getElementById('dt-side-label');
    if (el) el.textContent = 'Côté actif : '+(activeSide==='left'?'GAUCHE':'DROITE');
    ['left','right'].forEach(function(s){
      var z=document.getElementById('dt-side-'+s);
      if (z) z.classList.toggle('active-zone', s===activeSide);
    });
  }

  function renderLevel3(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label" id="dt-side-label">Côté actif : GAUCHE</p>'+
      '<div class="dt-sides"><div class="dt-side" id="dt-side-left"></div><div class="dt-side" id="dt-side-right"></div></div>'+
      '<div class="dt-hint" id="dt-hint">Prêt\u2026</div>'+
      '<div class="game-hud"><span>Justesse : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-side-left').addEventListener('click', function(){ tapSide('left'); });
    document.getElementById('dt-side-right').addEventListener('click', function(){ tapSide('right'); });
    updateSideLabel();
  }

  function tapSide(side){
    if (!running || l3Responded || level!==3) return;
    l3Responded=true;
    var hint=document.getElementById('dt-hint');
    if (side===stimSide && stimSide===activeSide){ l3Hits++; l3Rts.push(Date.now()-l3StimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { l3False++; hint.textContent='Mauvais côté.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l3Hits;
  }

  function nextLevel3(){
    if (!running) return;
    l3Responded=false;
    stimSide = Math.random()<0.5 ? 'left':'right';
    var zone=document.getElementById('dt-side-'+stimSide);
    if (zone) zone.innerHTML='<div class="dt-shape circle" style="width:64px;height:64px"></div>';
    l3StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); hint.style.color='var(--ink-2)'; hint.textContent='\u00a0';
    setTimeout(function(){
      if (!running) return;
      if (!l3Responded){ if (stimSide===activeSide) l3Miss++; else l3CorrectRej++; }
      ['left','right'].forEach(function(s){ var z=document.getElementById('dt-side-'+s); if (z) z.innerHTML=''; });
      sinceSwitch++;
      if (sinceSwitch>=2 && Math.random()<0.3){ activeSide = activeSide==='left'?'right':'left'; sinceSwitch=0; updateSideLabel(); }
      var remain = endAt - Date.now();
      document.getElementById('dt-fill').style.width = Math.round((1 - Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft = Math.max(0, Math.ceil(remain/1000));
      var tEl = document.getElementById('dt-time');
      if (tEl) tEl.textContent = Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain > 300) setTimeout(nextLevel3, 220); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel3(){
    activeSide = Math.random()<0.5?'left':'right'; sinceSwitch=0;
    l3Hits=0;l3Miss=0;l3False=0;l3CorrectRej=0;l3Rts=[];
    renderLevel3();
    nextLevel3();
    scheduleSecondary();
  }

  /* ---- Niveau 4 : Mémoire chargée (retenir une séquence de couleurs, restituée à la fin) ---- */
  var MEM_COLORS=[{k:'sauge'},{k:'terra'},{k:'ocre'},{k:'fjord'}];
  var memSeq=[], memRecall=[];

  function showMemorize(cb){
    memSeq=[];
    for (var n=0;n<3;n++) memSeq.push(MEM_COLORS[Math.floor(Math.random()*MEM_COLORS.length)]);
    var i=0;
    body.innerHTML='<p class="game-q">Retiens cet ordre</p><div class="dt-memrow" id="dt-memrow"></div><p class="dt-hint">Trois couleurs, une par une\u2026</p>';
    var row=document.getElementById('dt-memrow');
    function showNext(){
      if (i>=memSeq.length){ setTimeout(cb, 500); return; }
      row.innerHTML = '<div class="dt-memdot" style="background:var(--'+memSeq[i].k+')"></div>';
      i++;
      setTimeout(function(){ if(row) row.innerHTML=''; setTimeout(showNext, 250); }, 700);
    }
    showNext();
  }

  function renderRecallStep(){
    var step=memRecall.length;
    if (step>=memSeq.length){ finishWithMemory(); return; }
    body.innerHTML='<p class="game-q">Dans quel ordre ? ('+(step+1)+'/'+memSeq.length+')</p><div class="dt-mempick" id="dt-mempick"></div>';
    var pick=document.getElementById('dt-mempick');
    MEM_COLORS.forEach(function(c){
      var b=document.createElement('button'); b.type='button'; b.className='dt-memdot pick'; b.style.background='var(--'+c.k+')';
      b.addEventListener('click', function(){ memRecall.push(c.k); renderRecallStep(); });
      pick.appendChild(b);
    });
  }
  function showRecall(){ memRecall=[]; renderRecallStep(); }

  function startLevel4(){
    showMemorize(function(){
      running=true; endAt=Date.now()+DURATION;
      startLevel1();
    });
  }

  /* ---- Niveau 5 : Calcul & Compteur ---- */
  var l5Num=null, l5Responded=false, l5StimT0=0;
  var l5Hits=0, l5Errors=0, l5Miss=0, l5Rts=[];

  function renderLevel5(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"><span style="font-family:var(--font-editorial);font-size:48px;font-weight:var(--w-bold);color:var(--ink)" id="dt-num"></span></div>'+
      '<div class="dt-sides"><div class="dt-side" id="dt-side-left" style="font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--ink)">PAIR</div><div class="dt-side" id="dt-side-right" style="font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--ink)">IMPAIR</div></div>'+
      '<div class="dt-hint" id="dt-hint">Prêt\u2026</div>'+
      '<div class="game-hud"><span>Calcul : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-side-left').addEventListener('click', function(){ answerL5(true); });
    document.getElementById('dt-side-right').addEventListener('click', function(){ answerL5(false); });
  }

  function answerL5(saidPair){
    if (!running || l5Responded || level!==5) return;
    l5Responded=true;
    var isPair = (l5Num%2===0);
    var hint=document.getElementById('dt-hint');
    if (saidPair===isPair){ l5Hits++; l5Rts.push(Date.now()-l5StimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { l5Errors++; hint.textContent='Pas cette fois.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l5Hits;
  }

  function nextLevel5(){
    if (!running) return;
    l5Responded=false;
    l5Num = 1+Math.floor(Math.random()*98);
    var numEl=document.getElementById('dt-num'); if (numEl) numEl.textContent=l5Num;
    l5StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l5Responded) l5Miss++;
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel5,260); else if (running) finish();
    }, WIN_MS+400);
  }

  function startLevel5(){
    l5Hits=0;l5Errors=0;l5Miss=0;l5Rts=[];
    renderLevel5();
    nextLevel5();
    scheduleSecondary();
  }

  /* ---- Niveau 6 : Repérage combiné ---- */
  var L6_SHAPES=['circle','square'], L6_COLORS=[{k:'sauge',n:'vert'},{k:'terra',n:'terracotta'},{k:'fjord',n:'bleu'},{k:'ocre',n:'ocre'}];
  var l6Target=null, l6Cur=null, l6Responded=false, l6StimT0=0;
  var l6Hits=0, l6Miss=0, l6False=0, l6CorrectRej=0, l6Rts=[];

  function renderLevel6(){
    l6Target = { shape:L6_SHAPES[Math.floor(Math.random()*L6_SHAPES.length)], color:L6_COLORS[Math.floor(Math.random()*L6_COLORS.length)] };
    var shapeName = l6Target.shape==='circle' ? 'rond' : 'carré';
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">Cible : <span style="color:var(--'+l6Target.color.k+'-d,var(--ink))">'+shapeName+' '+l6Target.color.n+'</span> uniquement</p>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">Prêt\u2026</div>'+
      '<div class="game-hud"><span>Repérage : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-stage').addEventListener('click', tapLevel6);
  }

  function tapLevel6(){
    if (!running || l6Responded || level!==6) return;
    l6Responded=true;
    var hint=document.getElementById('dt-hint');
    var isMatch = l6Cur.shape===l6Target.shape && l6Cur.color.k===l6Target.color.k;
    if (isMatch){ l6Hits++; l6Rts.push(Date.now()-l6StimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { l6False++; hint.textContent='Pas la bonne combinaison.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l6Hits;
  }

  function nextLevel6(){
    if (!running) return;
    l6Responded=false;
    var isTarget = Math.random()<0.35;
    if (isTarget){ l6Cur = { shape:l6Target.shape, color:l6Target.color }; }
    else {
      var shape, color;
      do {
        shape=L6_SHAPES[Math.floor(Math.random()*L6_SHAPES.length)];
        color=L6_COLORS[Math.floor(Math.random()*L6_COLORS.length)];
      } while (shape===l6Target.shape && color.k===l6Target.color.k);
      l6Cur = { shape:shape, color:color };
    }
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape dyn '+l6Cur.shape+'" style="background:var(--'+l6Cur.color.k+')"></div>';
    l6StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l6Responded){ if (l6Cur.shape===l6Target.shape && l6Cur.color.k===l6Target.color.k) l6Miss++; else l6CorrectRej++; }
      stage.innerHTML='';
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel6,220); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel6(){
    l6Hits=0;l6Miss=0;l6False=0;l6CorrectRej=0;l6Rts=[];
    renderLevel6();
    nextLevel6();
    scheduleSecondary();
  }

  /* ---- Niveau 7 : Mémoire glissante (2-back) ---- */
  var L7_COLORS=['sauge','terra','fjord','ocre'];
  var l7Hist=[], l7Cur=null, l7Responded=false, l7StimT0=0;
  var l7Hits=0, l7Miss=0, l7False=0, l7CorrectRej=0, l7Rts=[];

  function renderLevel7(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<div class="dt-stage" id="dt-stage"></div>'+
      '<div class="dt-hint" id="dt-hint">Les deux premi\u00e8res couleurs servent juste de rep\u00e8re \u2014 rien \u00e0 taper encore.</div>'+
      '<button type="button" class="game-cta" id="dt-match-btn" style="margin:8px 0">\u00c7A CORRESPOND</button>'+
      '<div class="game-hud"><span>Mémoire : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-match-btn').addEventListener('click', tapLevel7);
  }

  function tapLevel7(){
    if (!running || l7Responded || level!==7 || l7Hist.length<3) return;
    l7Responded=true;
    var twoBack = l7Hist[l7Hist.length-3];
    var hint=document.getElementById('dt-hint');
    var isMatch = twoBack===l7Cur;
    if (isMatch){ l7Hits++; l7Rts.push(Date.now()-l7StimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { l7False++; hint.textContent='Ça ne correspondait pas.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l7Hits;
  }

  function nextLevel7(){
    if (!running) return;
    l7Responded=false;
    l7Cur = L7_COLORS[Math.floor(Math.random()*L7_COLORS.length)];
    l7Hist.push(l7Cur);
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<div class="dt-shape square" style="background:var(--'+l7Cur+')"></div>';
    l7StimT0=Date.now();
    var hint=document.getElementById('dt-hint');
    if (hint) { hint.style.color='var(--ink-2)'; hint.textContent = l7Hist.length<3 ? 'Encore un peu de rep\u00e8re\u2026' : '\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (l7Hist.length>=3 && !l7Responded){ var twoBack=l7Hist[l7Hist.length-3]; if (twoBack===l7Cur) l7Miss++; else l7CorrectRej++; }
      stage.innerHTML='';
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel7,300); else if (running) finish();
    }, WIN_MS+300);
  }

  function startLevel7(){
    l7Hist=[];l7Hits=0;l7Miss=0;l7False=0;l7CorrectRej=0;l7Rts=[];
    renderLevel7();
    nextLevel7();
    scheduleSecondary();
  }

  /* ---- Niveau 8 : Stroop & Compteur ---- */
  var L8_COLORS=[{k:'sauge',n:'VERT'},{k:'terra',n:'ROUGE'},{k:'fjord',n:'BLEU'},{k:'ocre',n:'JAUNE'}];
  var l8Cur=null, l8Responded=false, l8StimT0=0;
  var l8Hits=0, l8Miss=0, l8False=0, l8Rts=[];

  function renderLevel8(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">Touche la couleur de l\u2019<b>encre</b>, pas le mot</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div class="dt-opts" id="dt-opts" style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:10px"></div>'+
      '<div class="dt-hint" id="dt-hint">Pr\u00eat\u2026</div>'+
      '<div class="game-hud"><span>Stroop : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    var opts=document.getElementById('dt-opts');
    L8_COLORS.forEach(function(c){
      var b=document.createElement('button'); b.type='button'; b.textContent=c.n;
      b.style.cssText='flex:1 1 40%;min-height:44px;border-radius:12px;border:none;font-weight:var(--w-bold);color:#fff;background:var(--'+c.k+')';
      b.addEventListener('click', function(){ tapLevel8(c.k); });
      opts.appendChild(b);
    });
  }

  function tapLevel8(pickedKey){
    if (!running || l8Responded || level!==8) return;
    l8Responded=true;
    var hint=document.getElementById('dt-hint');
    if (pickedKey===l8Cur.ink.k){ l8Hits++; l8Rts.push(Date.now()-l8StimT0); hint.textContent='Bien vu.'; hint.style.color='var(--sauge)'; }
    else { l8False++; hint.textContent='C\u2019\u00e9tait l\u2019encre, pas le mot.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l8Hits;
  }

  function nextLevel8(){
    if (!running) return;
    l8Responded=false;
    var word=L8_COLORS[Math.floor(Math.random()*L8_COLORS.length)];
    var ink; do { ink=L8_COLORS[Math.floor(Math.random()*L8_COLORS.length)]; } while (ink.k===word.k);
    l8Cur={ word:word, ink:ink };
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-family:var(--font-editorial);font-size:34px;font-weight:var(--w-bold);color:var(--'+ink.k+')">'+word.n+'</span>';
    l8StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l8Responded){ l8Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel8,250); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel8(){
    l8Hits=0;l8Miss=0;l8False=0;l8Rts=[];
    renderLevel8();
    nextLevel8();
    scheduleSecondary();
  }

  /* ---- Niveau 9 : Direction & Compteur ---- */
  var L9_DIRS=[{k:'up',n:'\u2191'},{k:'down',n:'\u2193'},{k:'left',n:'\u2190'},{k:'right',n:'\u2192'}];
  var l9Cur=null, l9Responded=false, l9StimT0=0;
  var l9Hits=0, l9Miss=0, l9False=0, l9Rts=[];

  function renderLevel9(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">Tape la zone que la fl\u00e8che indique</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div id="dt-cross" style="display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr 1fr;gap:6px;max-width:220px;margin:10px auto 0">'+
        '<div></div><button type="button" data-d="up" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2191</button><div></div>'+
        '<button type="button" data-d="left" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2190</button><div></div>'+
        '<button type="button" data-d="right" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2192</button>'+
        '<div></div><button type="button" data-d="down" style="min-height:52px;border-radius:12px;border:1px solid var(--line);background:var(--surface);font-size:20px">\u2193</button><div></div>'+
      '</div>'+
      '<div class="dt-hint" id="dt-hint">Pr\u00eat\u2026</div>'+
      '<div class="game-hud"><span>Direction : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.querySelectorAll('#dt-cross [data-d]').forEach(function(b){
      b.addEventListener('click', function(){ tapLevel9(b.getAttribute('data-d')); });
    });
  }

  function tapLevel9(pickedDir){
    if (!running || l9Responded || level!==9) return;
    l9Responded=true;
    var hint=document.getElementById('dt-hint');
    if (pickedDir===l9Cur.k){ l9Hits++; l9Rts.push(Date.now()-l9StimT0); hint.textContent='Bonne direction.'; hint.style.color='var(--sauge)'; }
    else { l9False++; hint.textContent='Pas cette direction-l\u00e0.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l9Hits;
  }

  function nextLevel9(){
    if (!running) return;
    l9Responded=false;
    l9Cur=L9_DIRS[Math.floor(Math.random()*L9_DIRS.length)];
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-size:44px;font-weight:var(--w-bold);color:var(--ink)">'+l9Cur.n+'</span>';
    l9StimT0=Date.now();
    var hint=document.getElementById('dt-hint'); if (hint){ hint.style.color='var(--ink-2)'; hint.textContent='\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l9Responded){ l9Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel9,280); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel9(){
    l9Hits=0;l9Miss=0;l9False=0;l9Rts=[];
    renderLevel9();
    nextLevel9();
    scheduleSecondary();
  }

  /* ---- Niveau 10 : Tendance & Compteur ---- */
  var l10Prev=null, l10Cur=null, l10Responded=false, l10StimT0=0;
  var l10Hits=0, l10Miss=0, l10False=0, l10Rts=[];

  function renderLevel10(){
    body.innerHTML =
      '<div class="dt-head">'+
        '<span id="dt-time">1:00</span>'+
        '<span class="dt-badge" id="dt-badge">0</span>'+
      '</div>'+
      '<p class="dt-side-label">Plus grand ou plus petit que le nombre pr\u00e9c\u00e9dent ?</p>'+
      '<div class="dt-stage" id="dt-stage" style="display:flex;align-items:center;justify-content:center"></div>'+
      '<div style="display:flex;gap:10px;margin-top:10px">'+
        '<button type="button" id="dt-l10-up" style="flex:1;min-height:48px;border-radius:12px;border:none;background:var(--sauge);color:#fff;font-weight:var(--w-bold)">\u2191 Plus grand</button>'+
        '<button type="button" id="dt-l10-down" style="flex:1;min-height:48px;border-radius:12px;border:none;background:var(--terra);color:#fff;font-weight:var(--w-bold)">\u2193 Plus petit</button>'+
      '</div>'+
      '<div class="dt-hint" id="dt-hint">Pr\u00eat\u2026</div>'+
      '<div class="game-hud"><span>Tendance : <b id="dt-p-ok">0</b></span><span>Tempo : <b id="dt-s-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="dt-fill"></span></div>';
    document.getElementById('dt-badge').addEventListener('click', tapSecondary);
    document.getElementById('dt-l10-up').addEventListener('click', function(){ tapLevel10('up'); });
    document.getElementById('dt-l10-down').addEventListener('click', function(){ tapLevel10('down'); });
  }

  function tapLevel10(pick){
    if (!running || l10Responded || level!==10 || l10Prev==null) return;
    l10Responded=true;
    var hint=document.getElementById('dt-hint');
    var actual = l10Cur>l10Prev ? 'up' : 'down';
    if (pick===actual){ l10Hits++; l10Rts.push(Date.now()-l10StimT0); hint.textContent='Correct.'; hint.style.color='var(--sauge)'; }
    else { l10False++; hint.textContent='Pas dans ce sens-l\u00e0.'; hint.style.color='var(--terra)'; }
    document.getElementById('dt-p-ok').textContent=l10Hits;
  }

  function nextLevel10(){
    if (!running) return;
    l10Responded=false;
    l10Prev=l10Cur;
    var n; do { n=1+Math.floor(Math.random()*20); } while (n===l10Prev);
    l10Cur=n;
    var stage=document.getElementById('dt-stage');
    stage.innerHTML='<span style="font-family:var(--font-editorial);font-size:40px;font-weight:var(--w-bold);color:var(--ink)">'+n+'</span>';
    l10StimT0=Date.now();
    var hint=document.getElementById('dt-hint');
    if (hint){ hint.style.color='var(--ink-2)'; hint.textContent = l10Prev==null ? 'Premier nombre \u2014 rien \u00e0 comparer encore.' : '\u00a0'; }
    setTimeout(function(){
      if (!running) return;
      if (!l10Responded && l10Prev!=null){ l10Miss++; }
      var remain=endAt-Date.now();
      var fillEl=document.getElementById('dt-fill'); if (fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
      var secsLeft=Math.max(0,Math.ceil(remain/1000));
      var tEl=document.getElementById('dt-time'); if (tEl) tEl.textContent=Math.floor(secsLeft/60)+':'+(secsLeft%60<10?'0':'')+(secsLeft%60);
      if (remain>300) setTimeout(nextLevel10,280); else if (running) finish();
    }, WIN_MS);
  }

  function startLevel10(){
    l10Prev=null; l10Cur=null; l10Hits=0;l10Miss=0;l10False=0;l10Rts=[];
    renderLevel10();
    nextLevel10();
    scheduleSecondary();
  }

  var dtScreen='select';
  function stopRoundCleanup(){
    running=false;
    clearTimeout(secTimer); clearTimeout(alertTimeout);
    cancelAnimationFrame(trackRAF); clearInterval(sampleTimer); clearInterval(tickTimer);
  }
  function updateBackLink(){
    var back=document.getElementById('dt-back'), txt=document.getElementById('dt-back-txt');
    if (!back) return;
    if (dtScreen==='select'){
      back.setAttribute('href','fiches.html'); if (txt) txt.textContent='Retour au Labo'; back.onclick=null;
    } else {
      back.removeAttribute('href'); if (txt) txt.textContent='Retour aux niveaux';
      back.onclick=function(e){ e.preventDefault(); stopRoundCleanup(); showLevelSelect(); };
    }
  }

  function showLevelSelect(){
    dtScreen='select'; updateBackLink();
    body.innerHTML =
      '<p class="game-q">Choisis un niveau</p>'+
      '<div class="dt-levels">'+
        '<button type="button" class="dt-lvl" data-lvl="1"><span class="num">1</span><span class="tx"><span class="tt">Rond & Compteur</span><br><span class="sb">Touche le rond, surveille le compteur</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="2"><span class="num">2</span><span class="tx"><span class="tt">Piste & Tempo</span><br><span class="sb">Suis le point en tournant, tape le tempo à côté</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="3"><span class="num">3</span><span class="tx"><span class="tt">Bascule</span><br><span class="sb">Le bon côté change sans prévenir, en plus du tempo</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="4"><span class="num">4</span><span class="tx"><span class="tt">Mémoire chargée</span><br><span class="sb">Retiens 3 couleurs, joue, puis restitue l\u2019ordre</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="5"><span class="num">5</span><span class="tx"><span class="tt">Calcul & Compteur</span><br><span class="sb">Pair ou impair, en plus du tempo</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="6"><span class="num">6</span><span class="tx"><span class="tt">Repérage combiné</span><br><span class="sb">Une forme ET une couleur précises, pas juste l\u2019une des deux</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="7"><span class="num">7</span><span class="tx"><span class="tt">Mémoire glissante</span><br><span class="sb">Ça correspond à il y a deux étapes, ou pas</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="8"><span class="num">8</span><span class="tx"><span class="tt">Stroop & Compteur</span><br><span class="sb">Touche l\u2019encre, pas le mot — en plus du tempo</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="9"><span class="num">9</span><span class="tx"><span class="tt">Direction & Compteur</span><br><span class="sb">Suis la flèche parmi 4 zones, en plus du tempo</span></span></button>'+
        '<button type="button" class="dt-lvl" data-lvl="10"><span class="num">10</span><span class="tx"><span class="tt">Tendance & Compteur</span><br><span class="sb">Plus grand ou plus petit que le précédent, en plus du tempo</span></span></button>'+
      '</div>';
    body.querySelectorAll('[data-lvl]').forEach(function(b){
      b.addEventListener('click', function(){ startRound(parseInt(b.getAttribute('data-lvl'),10)); });
    });
  }

  try{ MDCore.init({page:'dualtask',section:'equilibre'}); }catch(e){}
  showLevelSelect(); // écran unique au chargement : la liste des niveaux. Les règles (+ pourquoi)
                      // s'affichent ensuite via le compagnon, au moment où un niveau est choisi.
})();
