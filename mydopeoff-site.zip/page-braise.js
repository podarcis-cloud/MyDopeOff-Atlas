/* MyDope Off — page-braise.js
   Logique de braise, extraite du script inline de braise.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();

  // ---- Deck généreux de micro-plaisirs naturels, gratuits ----
  var CATS_FR={ sens:{n:'Sens',c:'#D5A84A'}, corps:{n:'Corps',c:'#7A8F72'}, nature:{n:'Nature',c:'#69889A'},
             lien:{n:'Lien',c:'#C7765C'}, creer:{n:'Créer',c:'#B08BA5'}, calme:{n:'Calme',c:'#8FA98C'}, neuf:{n:'Nouveau',c:'#C79A5C'} };
  var CATS_EN={ sens:{n:'Senses',c:'#D5A84A'}, corps:{n:'Body',c:'#7A8F72'}, nature:{n:'Nature',c:'#69889A'},
             lien:{n:'Connection',c:'#C7765C'}, creer:{n:'Create',c:'#B08BA5'}, calme:{n:'Calm',c:'#8FA98C'}, neuf:{n:'New',c:'#C79A5C'} };
  var CATS = L==='en' ? CATS_EN : CATS_FR;
  var DECK_FR=[
    ['Une douche bien chaude, sentir l\u2019eau','sens'],['Le soleil sur ton visage, 2 minutes','sens'],
    ['Ta chanson préférée, à fond','sens'],['Boire un café ou un thé, lentement','sens'],
    ['Sentir une odeur que tu aimes','sens'],['Un pull ou un plaid tout doux','sens'],
    ['Goûter un carré de chocolat, les yeux fermés','sens'],['Écouter la pluie ou le vent','sens'],
    ['T\u2019étirer longuement, comme un chat','corps'],['Marcher 10 minutes dehors','corps'],
    ['Danser sur une chanson, seul·e','corps'],['Quelques pompes ou squats','corps'],
    ['Monter les escaliers à fond','corps'],['Un peu de vélo','corps'],['Respirer profondément une minute','corps'],
    ['Regarder le ciel et les nuages','nature'],['Observer un coucher de soleil','nature'],
    ['Poser la main sur l\u2019écorce d\u2019un arbre','nature'],['Écouter les oiseaux','nature'],
    ['Regarder de l\u2019eau qui coule','nature'],['T\u2019asseoir dans un parc','nature'],
    ['Mettre les pieds nus dans l\u2019herbe','nature'],['Envoyer un message gentil à quelqu\u2019un','lien'],
    ['Appeler un·e proche','lien'],['Caresser un animal','lien'],['Faire un vrai câlin','lien'],
    ['Dire merci à quelqu\u2019un, sincèrement','lien'],['Complimenter quelqu\u2019un','lien'],
    ['Sourire à un inconnu','lien'],['Gribouiller ou dessiner','creer'],
    ['Écrire trois lignes, n\u2019importe lesquelles','creer'],['Chanter à tue-tête','creer'],
    ['Cuisiner un truc simple','creer'],['Prendre une photo de quelque chose de beau','creer'],
    ['Jouer d\u2019un instrument','creer'],['Ranger un petit coin','creer'],
    ['Finir une petite tâche que tu repousses','creer'],['Lire quelques pages','calme'],
    ['Un moment sans téléphone','calme'],['Allumer une bougie','calme'],
    ['Regarder de vieilles photos heureuses','calme'],['Une courte sieste','calme'],
    ['Te préparer un vrai bon repas','calme'],['Te coucher tôt ce soir','calme'],
    ['Fermer les yeux et ne rien faire, 3 min','calme'],['Prendre un chemin différent','neuf'],
    ['Goûter un aliment que tu ne connais pas','neuf'],['Écouter un morceau tout nouveau','neuf'],
    ['Réarranger un meuble','neuf'],['Apprendre un mot dans une autre langue','neuf'],
    ['Découvrir un lieu à côté de chez toi','neuf']
  ];
  var DECK_EN=[
    ['A really hot shower, feel the water','sens'],['Sun on your face, 2 minutes','sens'],
    ['Your favourite song, turned up loud','sens'],['Drinking a coffee or tea, slowly','sens'],
    ['Smelling a scent you love','sens'],['A soft jumper or blanket','sens'],
    ['Tasting a square of chocolate, eyes closed','sens'],['Listening to rain or wind','sens'],
    ['A long stretch, like a cat','corps'],['A 10-minute walk outside','corps'],
    ['Dancing to a song, alone','corps'],['A few push-ups or squats','corps'],
    ['Running up the stairs','corps'],['A bit of cycling','corps'],['Breathing deeply for a minute','corps'],
    ['Looking at the sky and clouds','nature'],['Watching a sunset','nature'],
    ['Resting a hand on a tree\u2019s bark','nature'],['Listening to birds','nature'],
    ['Watching water flow','nature'],['Sitting in a park','nature'],
    ['Bare feet on the grass','nature'],['Sending someone a kind message','lien'],
    ['Calling someone close to you','lien'],['Petting an animal','lien'],['A real hug','lien'],
    ['Sincerely thanking someone','lien'],['Complimenting someone','lien'],
    ['Smiling at a stranger','lien'],['Doodling or drawing','creer'],
    ['Writing three lines, about anything','creer'],['Singing at the top of your lungs','creer'],
    ['Cooking something simple','creer'],['Taking a photo of something beautiful','creer'],
    ['Playing an instrument','creer'],['Tidying a small corner','creer'],
    ['Finishing a small task you\u2019ve been putting off','creer'],['Reading a few pages','calme'],
    ['A moment without your phone','calme'],['Lighting a candle','calme'],
    ['Looking at old happy photos','calme'],['A short nap','calme'],
    ['Making yourself a real good meal','calme'],['Going to bed early tonight','calme'],
    ['Closing your eyes and doing nothing, 3 min','calme'],['Taking a different route','neuf'],
    ['Trying a food you don\u2019t know','neuf'],['Listening to something brand new','neuf'],
    ['Rearranging a piece of furniture','neuf'],['Learning a word in another language','neuf'],
    ['Discovering a spot near where you live','neuf']
  ];
  var DECK = L==='en' ? DECK_EN : DECK_FR;
  var LVL_FR=[ {t:'Presque rien',v:1}, {t:'Un peu',v:3}, {t:'Pas mal',v:5}, {t:'Beaucoup',v:7}, {t:'Énorme',v:9} ];
  var LVL_EN=[ {t:'Almost nothing',v:1}, {t:'A little',v:3}, {t:'Decent',v:5}, {t:'A lot',v:7}, {t:'Huge',v:9} ];
  var LVL = L==='en' ? LVL_EN : LVL_FR;
  var T = {
    step1_label:{fr:'1 · Anticiper',en:'1 · Anticipate'}, step1_q:{fr:'Lequel te tente le plus, là ?',en:'Which one tempts you most, right now?'},
    step1_sub:{fr:'Écoute ton élan — même léger. C\u2019est ta motivation qui se réveille.',en:'Listen to the pull \u2014 even a small one. That\u2019s your motivation waking up.'},
    reroll:{fr:'Autres propositions',en:'Show other options'},
    step2_label:{fr:'2 · Anticiper',en:'2 · Anticipate'}, step2_q:{fr:'Ça te ferait du bien à combien ?',en:'How good would this feel, on a scale?'},
    step2_sub:{fr:'Ta prédiction, sans réfléchir trop.',en:'Your prediction, without overthinking it.'},
    step3_label:{fr:'3 · Agir',en:'3 · Act'}, step3_q:{fr:'Vas-y — pour de vrai.',en:'Go for it \u2014 for real.'},
    step3_sub:{fr:'Fais-le maintenant si tu peux. Sinon, revis-le intensément en tête : ton cerveau y répond presque pareil.',en:'Do it now if you can. Otherwise, relive it vividly in your head: your brain responds almost the same way.'},
    did:{fr:'C\u2019est fait — on savoure',en:'Done \u2014 let\u2019s savour it'}, later:{fr:'Je le garde pour aujourd\u2019hui',en:'I\u2019ll save it for later today'},
    kept_q:{fr:'Gardé au chaud.',en:'Kept warm.'},
    kept_sub:{fr:'offre-toi ça dans la journée. Reviens sur cette page, tu pourras reprendre exactement là où tu t\u2019es arrêté·e.',en:'treat yourself to it later today. Come back to this page and you\u2019ll pick up exactly where you left off.'},
    finish:{fr:'Terminer',en:'Finish'},
    step4_label:{fr:'4 · Savourer',en:'4 · Savour'}, step4_q:{fr:'Ferme presque les yeux, 30 secondes.',en:'Almost close your eyes, for 30 seconds.'},
    savor_done:{fr:'J\u2019ai savouré',en:'I savoured it'}, savor_end:{fr:'Doucement, reviens.',en:'Gently, come back.'},
    prompt1:{fr:'Revois l\u2019image\u2026 où étais-tu ?',en:'Picture it again\u2026 where were you?'},
    prompt2:{fr:'Un son, une odeur qui va avec\u2026',en:'A sound, a smell that goes with it\u2026'},
    prompt3:{fr:'Une sensation sur ta peau\u2026',en:'A sensation on your skin\u2026'},
    prompt4:{fr:'Le meilleur instant — reste dessus\u2026',en:'The best moment \u2014 stay with it\u2026'},
    prompt5:{fr:'Laisse la chaleur se diffuser\u2026',en:'Let the warmth spread\u2026'},
    prompt_value:{fr:'Ça touche peut-être un peu à « {v} », à ta façon\u2026',en:'This might connect a little to \u201c{v}\u201d, in your own way\u2026'},
    step5_label:{fr:'Savourer',en:'Savour'}, step5_q:{fr:'À combien tu le ressens, là ?',en:'How much do you feel it, right now?'},
    learn_up:{fr:'Belle surprise — ton cerveau vient d\u2019enregistrer que ça vaut le coup, plus que prévu.',en:'A nice surprise \u2014 your brain just registered that it was worth it, more than expected.'},
    learn_down:{fr:'Un peu moins fort qu\u2019attendu, et c\u2019est ok. Le plaisir se ré-entraîne — chaque essai compte.',en:'A little less than expected, and that\u2019s okay. Pleasure gets retrained \u2014 every try counts.'},
    learn_even:{fr:'Juste. Tu réapprends à lire ce qui te fait du bien, avec de plus en plus de précision.',en:'Right on target. You\u2019re relearning to read what feels good, with growing precision.'},
    title:{fr:'Braise',en:'Ember'}, again:{fr:'Encore un plaisir',en:'One more pleasure'},
    see_map:{fr:'Voir ma carte des plaisirs',en:'See my pleasure map'},
    map_title:{fr:'Ta carte des plaisirs',en:'Your pleasure map'},
    map_empty:{fr:'Ta carte se remplira à chaque plaisir savouré.',en:'Your map will fill in with every pleasure you savour.'},
    map_top:{fr:'Top de tes récompenses naturelles',en:'Your top natural rewards'},
    map_relight:{fr:'Raviver la braise',en:'Relight the ember'},
    resume_label:{fr:'Gardé pour aujourd\u2019hui',en:'Saved for today'}, resume_q:{fr:'Envie de le savourer maintenant\u00a0?',en:'Want to savour it now?'},
    resume_yes:{fr:'Oui, on y va',en:'Yes, let\u2019s go'}, resume_no:{fr:'Non, choisir autre chose',en:'No, choose something else'},
    rules_l1:{fr:'Choisis un petit plaisir simple qui te tente.',en:'Choose a small, simple pleasure that tempts you.'},
    rules_l2:{fr:'Fais-le pour de vrai (ou revis-le intensément), puis savoure-le 30 secondes.',en:'Do it for real (or relive it vividly), then savour it for 30 seconds.'},
    rules_l3:{fr:'Note ce que tu ressens : la braise grandit, ta carte des plaisirs se dessine.',en:'Note how it feels: the ember grows, your pleasure map takes shape.'},
    rules_why:{fr:'La dopamine gouverne surtout la MOTIVATION vers les récompenses (pas le plaisir lui-même). En anticipant, en agissant puis en savourant de vrais petits plaisirs, tu réentraînes ton système de récompense à répondre à la vie sans substance (d\u2019après le Positive Affect Treatment).',
      en:'Dopamine mostly governs the MOTIVATION toward rewards (not pleasure itself). By anticipating, acting, then savouring real small pleasures, you retrain your reward system to respond to life without a substance (based on Positive Affect Treatment).'}
  };
  function t(k, sub){ var e = T[k]; var s = e ? (L==='en'?e.en:e.fr) : k; if(sub){ Object.keys(sub).forEach(function(kk){ s=s.replace('{'+kk+'}', sub[kk]); }); } return s; }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'br.title':        { fr: 'Braise', en: 'Ember' },
    'br.subtitle':     { fr: 'Rallumer le plaisir, un petit feu à la fois.', en: 'Relighting pleasure, one small fire at a time.' },
    'br.ready_q':      { fr: 'Prêt·e à raviver la braise ?', en: 'Ready to relight the ember?' },
    'br.ready_sub':    { fr: 'Un petit plaisir simple, choisi, vécu, savouré. C\u2019est comme ça que le cerveau réapprend que la vie vaut le coup — sans substance.',
                         en: 'One small pleasure, chosen, lived, savoured. That\u2019s how the brain relearns that life is worth it \u2014 without a substance.' },
    'br.see_map':      { fr: 'Voir ma carte des plaisirs', en: 'See my pleasure map' }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  var ember=document.getElementById('br-ember'), body=document.getElementById('br-body');
  var chosen=null, predit=0, ressenti=0, t0=0, savorTimer=null;

  var PENDING_KEY='mdBraisePending';
  function savePending(){ try{ localStorage.setItem(PENDING_KEY, JSON.stringify({label:chosen[0], cat:chosen[1], predit:predit, day:new Date().toDateString()})); }catch(e){} }
  function clearPending(){ try{ localStorage.removeItem(PENDING_KEY); }catch(e){} }
  function getPending(){
    try{
      var p=JSON.parse(localStorage.getItem(PENDING_KEY)||'null');
      if(p && p.day===new Date().toDateString()) return p;
      if(p) clearPending(); // périmé (jour différent) : nettoyage silencieux
    }catch(e){}
    return null;
  }

  function store(){ try{ return (window.MDData&&MDData.read&&MDData.read())||{}; }catch(e){ return {}; } }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function braiseData(){ var d=store(); d.braise=d.braise||{cards:{},total:0,heat:0}; return d; }

  function setEmber(scale, live){ ember.style.transform='scale('+scale+')'; ember.classList.toggle('live',!!live); }
  function heatScale(){ var d=braiseData(); return Math.min(1.25, 0.7 + (d.braise.heat||0)*0.012); }

  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;} return a; }

  // 1) ANTICIPER — tirer 3 cartes, choisir
  function stepPick(){
    setEmber(heatScale(), false);
    var hand=shuffle(DECK).slice(0,3);
    var html='<p class="game-step">'+t('step1_label')+'</p><p class="game-q">'+t('step1_q')+'</p>'+
      '<p class="game-sub">'+t('step1_sub')+'</p><div class="br-cards">';
    hand.forEach(function(c,i){ var cat=CATS[c[1]];
      html+='<button class="br-card" data-i="'+i+'" style="--cc:'+cat.c+';--c:'+cat.c+'"><span class="cdot"></span><span>'+c[0]+'</span><span class="ctag">'+cat.n+'</span></button>'; });
    html+='</div><button class="game-cta-link" id="br-reroll">'+t('reroll')+'</button>';
    body.innerHTML=html;
    body.querySelectorAll('[data-i]').forEach(function(b){ b.addEventListener('click',function(){ chosen=hand[parseInt(b.getAttribute('data-i'),10)]; stepPredict(); }); });
    document.getElementById('br-reroll').addEventListener('click', stepPick);
  }

  // 2) PRÉDIRE
  function stepPredict(){
    var html='<p class="game-step">'+t('step2_label')+'</p><p class="br-chosen">'+chosen[0]+'</p>'+
      '<p class="game-q">'+t('step2_q')+'</p><p class="game-sub">'+t('step2_sub')+'</p><div class="br-scale">';
    LVL.forEach(function(l){ html+='<button class="br-lvl" data-v="'+l.v+'" style="--lc:'+CATS[chosen[1]].c+'"><span class="ld"></span><span>'+l.t+'</span></button>'; });
    html+='</div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-v]').forEach(function(b){ b.addEventListener('click',function(){ predit=parseInt(b.getAttribute('data-v'),10); stepEngage(); }); });
  }

  // 3) AGIR
  function stepEngage(){
    body.innerHTML='<p class="game-step">'+t('step3_label')+'</p><p class="br-chosen">'+chosen[0]+'</p>'+
      '<p class="game-q">'+t('step3_q')+'</p>'+
      '<p class="game-sub">'+t('step3_sub')+'</p>'+
      '<button class="game-cta" id="br-did">'+t('did')+'</button>'+
      '<button class="br-alt" id="br-later">'+t('later')+'</button>';
    document.getElementById('br-did').addEventListener('click', stepSavor);
    document.getElementById('br-later').addEventListener('click', function(){
      savePending();
      body.innerHTML='<p class="game-q">'+t('kept_q')+'</p><p class="game-sub">« '+chosen[0]+' » — '+t('kept_sub')+'</p>'+
        '<button class="game-cta" id="br-end2">'+t('finish')+'</button>';
      document.getElementById('br-end2').addEventListener('click', function(){ location.href='fiches.html'; });
    });
  }

  // 4) SAVOURER — 30 s, braise qui respire
  function stepSavor(){
    setEmber(Math.max(heatScale(),0.95), true);
    var prompts=[t('prompt1'),t('prompt2'),t('prompt3'),t('prompt4'),t('prompt5')];
    try{
      var vals = window.MDData ? MDData.getValeurs() : [];
      if (vals.length){ var v = vals[Math.floor(Math.random()*vals.length)]; prompts.push(t('prompt_value',{v:v})); }
    }catch(e){}
    var i=0, secs=30;
    body.innerHTML='<p class="game-step">'+t('step4_label')+'</p><p class="game-q">'+t('step4_q')+'</p>'+
      '<p class="br-prompt" id="br-prompt">'+prompts[0]+'</p><p class="br-count" id="br-count">30</p>'+
      '<button class="game-cta" id="br-done" style="display:none">'+t('savor_done')+'</button>';
    var pr=document.getElementById('br-prompt'), ct=document.getElementById('br-count'), dn=document.getElementById('br-done');
    savorTimer=setInterval(function(){
      secs--; ct.textContent=secs>0?secs:'';
      if(secs%6===0){ i=(i+1)%prompts.length; pr.textContent=prompts[i]; }
      if(secs<=15) dn.style.display='block';
      if(secs<=0){ clearInterval(savorTimer); pr.textContent=t('savor_end'); dn.style.display='block'; }
    },1000);
    dn.addEventListener('click', function(){ clearInterval(savorTimer); stepRate(); });
  }

  // 5) NOTER le ressenti
  function stepRate(){
    var html='<p class="game-step">'+t('step5_label')+'</p><p class="game-q">'+t('step5_q')+'</p><div class="br-scale">';
    LVL.forEach(function(l){ html+='<button class="br-lvl" data-v="'+l.v+'" style="--lc:'+CATS[chosen[1]].c+'"><span class="ld"></span><span>'+l.t+'</span></button>'; });
    html+='</div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-v]').forEach(function(b){ b.addEventListener('click',function(){ ressenti=parseInt(b.getAttribute('data-v'),10); stepLearn(); }); });
  }

  // 6) APPRENDRE — erreur de prédiction + persistance
  function stepLearn(){
    var d=braiseData(); var delta=ressenti-predit;
    d.braise.heat=(d.braise.heat||0)+ressenti; d.braise.total=(d.braise.total||0)+1;
    var key=chosen[0]; var m=d.braise.cards[key]||{n:0,sum:0}; m.n++; m.sum+=ressenti; d.braise.cards[key]=m;
    save(d);
    setEmber(heatScale(), false);
    var msg, mood;
    if(delta>=2){ msg=t('learn_up'); mood='celebration'; }
    else if(delta<=-2){ msg=t('learn_down'); mood='bienveillance'; }
    else { msg=t('learn_even'); mood='encouragement'; }
    if(window.MDExercise){
      MDExercise.after('braise',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{predit:predit,ressenti:ressenti,delta:delta},
        debrief:{mood:mood, lines:[msg]}, title:t('title'), stats:[{label:L==='en'?'predicted':'prédit',value:predit},{label:L==='en'?'felt':'ressenti',value:ressenti}],
        nav:{ primary:{label:t('again')}, secondary:{label:t('see_map'), onClick:showMap} },
        onClose:function(){ window.__mdAvant=null; t0=Date.now(); stepPick(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('braise',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ predit:predit, ressenti:ressenti, delta:delta } }); }
  }

  // Carte des récompenses
  function showMap(){
    var d=braiseData(); var arr=Object.keys(d.braise.cards).map(function(k){ var m=d.braise.cards[k]; return {k:k,avg:m.sum/m.n,n:m.n}; });
    arr.sort(function(a,b){ return b.avg-a.avg; }); arr=arr.slice(0,8);
    var rows = arr.length? arr.map(function(r){ return '<div class="row"><span>'+r.k+'</span><b>'+r.avg.toFixed(1)+'</b></div>'; }).join('')
      : '<div class="row"><span>'+t('map_empty')+'</span></div>';
    setEmber(heatScale(), false);
    var total = d.braise.total||0;
    var plural = L==='en' ? (total>1?'s':'') : (total>1?'s':'');
    var mapSub = L==='en'
      ? ('What lights you up most, based on you. '+total+' pleasure'+plural+' savoured.')
      : ('Ce qui te rallume le plus, d\u2019après toi. '+total+' plaisir'+plural+' savouré'+plural+'.');
    body.innerHTML='<p class="game-q">'+t('map_title')+'</p><p class="game-sub">'+mapSub+'</p>'+
      '<div class="br-map"><h3>'+t('map_top')+'</h3>'+rows+'</div>'+
      '<button class="game-cta" id="br-back2">'+t('map_relight')+'</button>';
    document.getElementById('br-back2').addEventListener('click', function(){ t0=Date.now(); stepPick(); });
  }

  function resumePending(p){
    chosen=[p.label, p.cat]; predit=p.predit;
    body.innerHTML='<p class="game-step">'+t('resume_label')+'</p><p class="br-chosen">'+p.label+'</p>'+
      '<p class="game-q">'+t('resume_q')+'</p>'+
      '<button class="game-cta" id="br-resume-yes">'+t('resume_yes')+'</button>'+
      '<button class="br-alt" id="br-resume-new">'+t('resume_no')+'</button>';
    document.getElementById('br-resume-yes').addEventListener('click', function(){ clearPending(); stepEngage(); });
    document.getElementById('br-resume-new').addEventListener('click', function(){ clearPending(); stepPick(); });
  }

  function begin(){
    t0=Date.now();
    var pending=getPending();
    if(pending){ resumePending(pending); return; }
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'motivation', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; stepPick(); } });
    } else { stepPick(); }
  }
  document.getElementById('br-showmap').addEventListener('click', showMap);
  setEmber(heatScale(), false);
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
  try{ MDCore.init({page:'braise',section:'equilibre'}); }catch(e){}
})();
