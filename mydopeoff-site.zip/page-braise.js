/* MyDope Off — page-braise.js
   Logique de braise, extraite du script inline de braise.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  // ---- Deck généreux de micro-plaisirs naturels, gratuits ----
  var CATS={ sens:{n:'Sens',c:'#D5A84A'}, corps:{n:'Corps',c:'#7A8F72'}, nature:{n:'Nature',c:'#69889A'},
             lien:{n:'Lien',c:'#C7765C'}, creer:{n:'Créer',c:'#B08BA5'}, calme:{n:'Calme',c:'#8FA98C'}, neuf:{n:'Nouveau',c:'#C79A5C'} };
  var DECK=[
    ['Une douche bien chaude, sentir l\u2019eau','sens'],
    ['Le soleil sur ton visage, 2 minutes','sens'],
    ['Ta chanson préférée, à fond','sens'],
    ['Boire un café ou un thé, lentement','sens'],
    ['Sentir une odeur que tu aimes','sens'],
    ['Un pull ou un plaid tout doux','sens'],
    ['Goûter un carré de chocolat, les yeux fermés','sens'],
    ['Écouter la pluie ou le vent','sens'],
    ['T\u2019étirer longuement, comme un chat','corps'],
    ['Marcher 10 minutes dehors','corps'],
    ['Danser sur une chanson, seul·e','corps'],
    ['Quelques pompes ou squats','corps'],
    ['Monter les escaliers à fond','corps'],
    ['Un peu de vélo','corps'],
    ['Respirer profondément une minute','corps'],
    ['Regarder le ciel et les nuages','nature'],
    ['Observer un coucher de soleil','nature'],
    ['Poser la main sur l\u2019écorce d\u2019un arbre','nature'],
    ['Écouter les oiseaux','nature'],
    ['Regarder de l\u2019eau qui coule','nature'],
    ['T\u2019asseoir dans un parc','nature'],
    ['Mettre les pieds nus dans l\u2019herbe','nature'],
    ['Envoyer un message gentil à quelqu\u2019un','lien'],
    ['Appeler un·e proche','lien'],
    ['Caresser un animal','lien'],
    ['Faire un vrai câlin','lien'],
    ['Dire merci à quelqu\u2019un, sincèrement','lien'],
    ['Complimenter quelqu\u2019un','lien'],
    ['Sourire à un inconnu','lien'],
    ['Gribouiller ou dessiner','creer'],
    ['Écrire trois lignes, n\u2019importe lesquelles','creer'],
    ['Chanter à tue-tête','creer'],
    ['Cuisiner un truc simple','creer'],
    ['Prendre une photo de quelque chose de beau','creer'],
    ['Jouer d\u2019un instrument','creer'],
    ['Ranger un petit coin','creer'],
    ['Finir une petite tâche que tu repousses','creer'],
    ['Lire quelques pages','calme'],
    ['Un moment sans téléphone','calme'],
    ['Allumer une bougie','calme'],
    ['Regarder de vieilles photos heureuses','calme'],
    ['Une courte sieste','calme'],
    ['Te préparer un vrai bon repas','calme'],
    ['Te coucher tôt ce soir','calme'],
    ['Fermer les yeux et ne rien faire, 3 min','calme'],
    ['Prendre un chemin différent','neuf'],
    ['Goûter un aliment que tu ne connais pas','neuf'],
    ['Écouter un morceau tout nouveau','neuf'],
    ['Réarranger un meuble','neuf'],
    ['Apprendre un mot dans une autre langue','neuf'],
    ['Découvrir un lieu à côté de chez toi','neuf']
  ];
  var LVL=[ {t:'Presque rien',v:1}, {t:'Un peu',v:3}, {t:'Pas mal',v:5}, {t:'Beaucoup',v:7}, {t:'Énorme',v:9} ];

  var ember=document.getElementById('br-ember'), body=document.getElementById('br-body');
  var chosen=null, predit=0, ressenti=0, t0=0, savorTimer=null;

  var PENDING_KEY='mdBraisePending';
  function savePending(){ try{ localStorage.setItem(PENDING_KEY, JSON.stringify({label:chosen[0], cat:chosen[1], predit:predit, day:new Date().toDateString()})); }catch(e){} }
  function clearPending(){ try{ localStorage.removeItem(PENDING_KEY); }catch(e){} }
  function getPending(){
    try{
      var p=JSON.parse(localStorage.getItem(PENDING_KEY)||'null');
      if(p && p.day===new Date().toDateString()) return p;
      if(p) clearPending(); // périmé (jour différent) : nettoyage silencieux
    }catch(e){}
    return null;
  }

  function store(){ try{ return (window.MDData&&MDData.read&&MDData.read())||{}; }catch(e){ return {}; } }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function braiseData(){ var d=store(); d.braise=d.braise||{cards:{},total:0,heat:0}; return d; }

  function setEmber(scale, live){ ember.style.transform='scale('+scale+')'; ember.classList.toggle('live',!!live); }
  function heatScale(){ var d=braiseData(); return Math.min(1.25, 0.7 + (d.braise.heat||0)*0.012); }

  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;} return a; }

  // 1) ANTICIPER — tirer 3 cartes, choisir
  function stepPick(){
    setEmber(heatScale(), false);
    var hand=shuffle(DECK).slice(0,3);
    var html='<p class="game-step">1 · Anticiper</p><p class="game-q">Lequel te tente le plus, là ?</p>'+
      '<p class="game-sub">Écoute ton élan — même léger. C\u2019est ta motivation qui se réveille.</p><div class="br-cards">';
    hand.forEach(function(c,i){ var cat=CATS[c[1]];
      html+='<button class="br-card" data-i="'+i+'" style="--cc:'+cat.c+';--c:'+cat.c+'"><span class="cdot"></span><span>'+c[0]+'</span><span class="ctag">'+cat.n+'</span></button>'; });
    html+='</div><button class="game-cta-link" id="br-reroll">Autres propositions</button>';
    body.innerHTML=html;
    body.querySelectorAll('[data-i]').forEach(function(b){ b.addEventListener('click',function(){ chosen=hand[parseInt(b.getAttribute('data-i'),10)]; stepPredict(); }); });
    document.getElementById('br-reroll').addEventListener('click', stepPick);
  }

  // 2) PRÉDIRE
  function stepPredict(){
    var html='<p class="game-step">2 · Anticiper</p><p class="br-chosen">'+chosen[0]+'</p>'+
      '<p class="game-q">Ça te ferait du bien à combien ?</p><p class="game-sub">Ta prédiction, sans réfléchir trop.</p><div class="br-scale">';
    LVL.forEach(function(l){ html+='<button class="br-lvl" data-v="'+l.v+'" style="--lc:'+CATS[chosen[1]].c+'"><span class="ld"></span><span>'+l.t+'</span></button>'; });
    html+='</div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-v]').forEach(function(b){ b.addEventListener('click',function(){ predit=parseInt(b.getAttribute('data-v'),10); stepEngage(); }); });
  }

  // 3) AGIR
  function stepEngage(){
    body.innerHTML='<p class="game-step">3 · Agir</p><p class="br-chosen">'+chosen[0]+'</p>'+
      '<p class="game-q">Vas-y — pour de vrai.</p>'+
      '<p class="game-sub">Fais-le maintenant si tu peux. Sinon, revis-le intensément en tête : ton cerveau y répond presque pareil.</p>'+
      '<button class="game-cta" id="br-did">C\u2019est fait — on savoure</button>'+
      '<button class="br-alt" id="br-later">Je le garde pour aujourd\u2019hui</button>';
    document.getElementById('br-did').addEventListener('click', stepSavor);
    document.getElementById('br-later').addEventListener('click', function(){
      savePending();
      body.innerHTML='<p class="game-q">Gardé au chaud.</p><p class="game-sub">« '+chosen[0]+' » — offre-toi ça dans la journée. Reviens sur cette page, tu pourras reprendre exactement là où tu t\u2019es arrêté·e.</p>'+
        '<button class="game-cta" id="br-end2">Terminer</button>';
      document.getElementById('br-end2').addEventListener('click', function(){ location.href='fiches.html'; });
    });
  }

  // 4) SAVOURER — 30 s, braise qui respire
  function stepSavor(){
    setEmber(Math.max(heatScale(),0.95), true);
    var prompts=['Revois l\u2019image… où étais-tu ?','Un son, une odeur qui va avec…','Une sensation sur ta peau…','Le meilleur instant — reste dessus…','Laisse la chaleur se diffuser…'];
    try{
      var vals = window.MDData ? MDData.getValeurs() : [];
      if (vals.length){ var v = vals[Math.floor(Math.random()*vals.length)]; prompts.push('Ça touche peut-être un peu à « '+v+' », à ta façon…'); }
    }catch(e){}
    var i=0, secs=30;
    body.innerHTML='<p class="game-step">4 · Savourer</p><p class="game-q">Ferme presque les yeux, 30 secondes.</p>'+
      '<p class="br-prompt" id="br-prompt">'+prompts[0]+'</p><p class="br-count" id="br-count">30</p>'+
      '<button class="game-cta" id="br-done" style="display:none">J\u2019ai savouré</button>';
    var pr=document.getElementById('br-prompt'), ct=document.getElementById('br-count'), dn=document.getElementById('br-done');
    savorTimer=setInterval(function(){
      secs--; ct.textContent=secs>0?secs:'';
      if(secs%6===0){ i=(i+1)%prompts.length; pr.textContent=prompts[i]; }
      if(secs<=15) dn.style.display='block';
      if(secs<=0){ clearInterval(savorTimer); pr.textContent='Doucement, reviens.'; dn.style.display='block'; }
    },1000);
    dn.addEventListener('click', function(){ clearInterval(savorTimer); stepRate(); });
  }

  // 5) NOTER le ressenti
  function stepRate(){
    var html='<p class="game-step">Savourer</p><p class="game-q">À combien tu le ressens, là ?</p><div class="br-scale">';
    LVL.forEach(function(l){ html+='<button class="br-lvl" data-v="'+l.v+'" style="--lc:'+CATS[chosen[1]].c+'"><span class="ld"></span><span>'+l.t+'</span></button>'; });
    html+='</div>';
    body.innerHTML=html;
    body.querySelectorAll('[data-v]').forEach(function(b){ b.addEventListener('click',function(){ ressenti=parseInt(b.getAttribute('data-v'),10); stepLearn(); }); });
  }

  // 6) APPRENDRE — erreur de prédiction + persistance
  function stepLearn(){
    var d=braiseData(); var delta=ressenti-predit;
    d.braise.heat=(d.braise.heat||0)+ressenti; d.braise.total=(d.braise.total||0)+1;
    var key=chosen[0]; var m=d.braise.cards[key]||{n:0,sum:0}; m.n++; m.sum+=ressenti; d.braise.cards[key]=m;
    save(d);
    setEmber(heatScale(), false);
    var msg, mood;
    if(delta>=2){ msg='Belle surprise — ton cerveau vient d\u2019enregistrer que ça vaut le coup, plus que prévu.'; mood='celebration'; }
    else if(delta<=-2){ msg='Un peu moins fort qu\u2019attendu, et c\u2019est ok. Le plaisir se ré-entraîne — chaque essai compte.'; mood='bienveillance'; }
    else { msg='Juste. Tu réapprends à lire ce qui te fait du bien, avec de plus en plus de précision.'; mood='encouragement'; }
    if(window.MDExercise){
      MDExercise.after('braise',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{predit:predit,ressenti:ressenti,delta:delta},
        debrief:{mood:mood, lines:[msg]}, title:'Braise', stats:[{label:'prédit',value:predit},{label:'ressenti',value:ressenti}],
        nav:{ primary:{label:'Encore un plaisir'}, secondary:{label:'Voir ma carte des plaisirs', onClick:showMap} },
        onClose:function(){ window.__mdAvant=null; t0=Date.now(); stepPick(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('braise',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ predit:predit, ressenti:ressenti, delta:delta } }); }
  }

  // Carte des récompenses
  function showMap(){
    var d=braiseData(); var arr=Object.keys(d.braise.cards).map(function(k){ var m=d.braise.cards[k]; return {k:k,avg:m.sum/m.n,n:m.n}; });
    arr.sort(function(a,b){ return b.avg-a.avg; }); arr=arr.slice(0,8);
    var rows = arr.length? arr.map(function(r){ return '<div class="row"><span>'+r.k+'</span><b>'+r.avg.toFixed(1)+'</b></div>'; }).join('')
      : '<div class="row"><span>Ta carte se remplira à chaque plaisir savouré.</span></div>';
    setEmber(heatScale(), false);
    body.innerHTML='<p class="game-q">Ta carte des plaisirs</p><p class="game-sub">Ce qui te rallume le plus, d\u2019après toi. '+(d.braise.total||0)+' plaisir'+((d.braise.total||0)>1?'s':'')+' savouré'+((d.braise.total||0)>1?'s':'')+'.</p>'+
      '<div class="br-map"><h3>Top de tes récompenses naturelles</h3>'+rows+'</div>'+
      '<button class="game-cta" id="br-back2">Raviver la braise</button>';
    document.getElementById('br-back2').addEventListener('click', function(){ t0=Date.now(); stepPick(); });
  }

  function resumePending(p){
    chosen=[p.label, p.cat]; predit=p.predit;
    body.innerHTML='<p class="game-step">Gardé pour aujourd\u2019hui</p><p class="br-chosen">'+p.label+'</p>'+
      '<p class="game-q">Envie de le savourer maintenant\u00a0?</p>'+
      '<button class="game-cta" id="br-resume-yes">Oui, on y va</button>'+
      '<button class="br-alt" id="br-resume-new">Non, choisir autre chose</button>';
    document.getElementById('br-resume-yes').addEventListener('click', function(){ clearPending(); stepEngage(); });
    document.getElementById('br-resume-new').addEventListener('click', function(){ clearPending(); stepPick(); });
  }

  function begin(){
    t0=Date.now();
    var pending=getPending();
    if(pending){ resumePending(pending); return; }
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'motivation', title:'Braise',
        lines:['Choisis un petit plaisir simple qui te tente.',
               'Fais-le pour de vrai (ou revis-le intensément), puis savoure-le 30 secondes.',
               'Note ce que tu ressens : la braise grandit, ta carte des plaisirs se dessine.'],
        why:'La dopamine gouverne surtout la MOTIVATION vers les récompenses (pas le plaisir lui-même). En anticipant, en agissant puis en savourant de vrais petits plaisirs, tu réentra\u00eenes ton syst\u00e8me de r\u00e9compense \u00e0 r\u00e9pondre \u00e0 la vie sans substance (d\u2019apr\u00e8s le Positive Affect Treatment).',
        onStart:function(avant){ window.__mdAvant=avant; stepPick(); } });
    } else { stepPick(); }
  }
  document.getElementById('br-showmap').addEventListener('click', showMap);
  setEmber(heatScale(), false);
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
  try{ MDCore.init({page:'braise',section:'equilibre'}); }catch(e){}
})();
