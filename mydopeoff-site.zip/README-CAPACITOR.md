# MyDope Off — pont vers iOS et Android (Capacitor)

Ce dossier contient tout ce qu'il faut pour transformer le site statique en projets
Xcode et Android Studio réels. Ce que ce scaffold **ne fait pas** : il ne produit pas
une app finale, signée, publiable — ça demande des outils et des comptes que cet
environnement n'a pas (voir « Ce qu'il reste à faire » plus bas).

## Ce qui est prêt

- `package.json` — dépendances Capacitor (core, cli, ios, android)
- `capacitor.config.json` — configuration (nom, couleurs, id d'app)
- `build-www.js` — copie le site dans `www/` en excluant les fichiers de dev,
  exactement comme le zip de livraison habituel
- `.gitignore` — pour ne jamais versionner `node_modules/`, `www/`, `ios/`, `android/`

## Étapes suivantes (sur ta machine, pas ici)

Cet environnement n'a ni Xcode (Mac uniquement) ni Android Studio ni la possibilité
d'ouvrir un simulateur — ces commandes sont à lancer chez toi.

### 1. Installer les dépendances
```bash
npm install
```

### 2. Générer le contenu web et ajouter les plateformes
```bash
npm run build:www
npx cap add ios
npx cap add android
```
Ça crée deux nouveaux dossiers, `ios/` et `android/` — les vrais projets natifs.

### 3. Ouvrir dans les IDE natifs
```bash
npm run cap:ios       # ouvre Xcode (nécessite un Mac)
npm run cap:android   # ouvre Android Studio
```

### 4. À chaque modification du site
```bash
npm run cap:sync
```
Recopie `www/` et synchronise les deux projets natifs.

## Avant de songer aux stores — à vérifier et décider toi-même

- **`appId`** dans `capacitor.config.json` est un placeholder (`com.mydopeoff.app`).
  C'est un identifiant **définitif** une fois publié sur un store — ne le change plus
  après la première soumission. Vérifie que ce nom de domaine/paquet t'appartient
  vraiment ou choisis-en un que tu contrôles.
- **Icônes et splash screens natifs** : Capacitor a besoin de jeux d'icônes à des
  tailles spécifiques par plateforme (pas juste `icon-512.png`). Le plugin
  `@capacitor/assets` peut les générer automatiquement à partir d'une image source
  haute résolution — à lancer chez toi (`npx @capacitor/assets generate`).
- **Permissions natives** : si tu gardes le gyroscope du Labyrinthe, iOS/Android
  demandent des déclarations de permission spécifiques dans les projets natifs
  générés (`Info.plist` / `AndroidManifest.xml`) — Capacitor les ajoute en partie,
  mais vérifie-les avant soumission.

## Ce que je ne peux pas faire depuis cet environnement

- **Compte développeur Apple** (99 $/an) et **Google Play Console** (25 $, une fois) —
  identité réelle requise, je ne peux pas les créer à ta place.
- **Xcode** tourne uniquement sur Mac — je n'ai accès à aucune machine Apple ici.
- **Signature de certificats** et **soumission aux stores** — étapes humaines, chez
  les équipes de revue Apple/Google, hors de mon contrôle.

Ce scaffold te fait gagner l'étape de configuration initiale — le reste se joue sur
ta machine, avec les comptes développeur en ta possession.
