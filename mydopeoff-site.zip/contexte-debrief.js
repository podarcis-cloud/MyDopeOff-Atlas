/* MyDope Off — contexte-debrief.js
   ============================================================================
   Contexte d'accompagnement pour les débriefs de fin d'exercice.

   RÈGLE FONDATRICE, qui commande tout le reste :
   ce module sert à CHOISIR quoi dire, jamais à RENVOYER des données à la personne.
   Aucune phrase produite à partir d'ici ne contient de chiffre, de fréquence, de
   comparaison avec une période précédente ni d'évolution. « Tu as consommé quatre fois
   cette semaine » serait un compteur — donc un jugement déguisé, et un dispositif
   cassable (interdit explicite du chapitre 40).

   DEUXIÈME RÈGLE : le silence est un état valide.
   Si le journal est vide ou trop peu rempli, AUCUNE branche contextuelle n'est activée
   et le pool générique s'applique. Un produit qui devinerait à partir de trois entrées
   se tromperait souvent, et se tromper sur ce terrain coûte plus cher que ne rien dire.

   TROISIÈME RÈGLE : aucune direction n'est supposée souhaitable (zieloffen).
   Le contexte ne distingue jamais « bonne » et « mauvaise » période. Il distingue des
   situations qui appellent des mots différents — ce qui n'est pas la même chose.

   Sortie : { usage, intensite, bilan, sensible } — chaque champ pouvant valoir null,
   ce qui signifie « on ne sait pas », et se traite comme tel.
   ============================================================================ */
window.MDContexteDebrief = (function () {
  'use strict';

  var JOUR = 86400000;

  function lire() {
    try { return JSON.parse(localStorage.getItem('ctc_v6')) || {}; } catch (e) { return {}; }
  }

  /* Seuil de branchement. En dessous, on ne sait rien d'utile : trois entrées peuvent
     aussi bien décrire quelqu'un qui note tout depuis trois jours que quelqu'un qui a
     noté trois fois en six mois. */
  var MIN_ENTREES = 6;
  var MIN_JOURS = 14;

  function contexte() {
    var d = lire();
    var out = { usage: null, intensite: null, bilan: null, sensible: false };

    var entries = Array.isArray(d.entries) ? d.entries : [];
    var now = Date.now();

    /* --- Le journal est-il assez rempli pour dire quoi que ce soit ? --- */
    var datees = entries.filter(function (e) { return e && e.date; });
    if (datees.length >= MIN_ENTREES) {
      var dates = datees.map(function (e) { return new Date(e.date + 'T00:00:00').getTime(); })
                        .filter(function (t) { return !isNaN(t); });
      var etendue = dates.length ? (Math.max.apply(null, dates) - Math.min.apply(null, dates)) / JOUR : 0;
      if (etendue >= MIN_JOURS) {
        /* `usage` décrit une FRÉQUENCE DE NOTATION, pas une quantité consommée, et ne
           sert qu'à choisir le registre : on ne parle pas de la même façon à quelqu'un
           qui vient tous les jours et à quelqu'un qui passe de temps en temps. */
        var joursAvecConso = {};
        datees.forEach(function (e) {
          if ((Number(e.level) || 0) > 0) joursAvecConso[e.date] = true;
        });
        var nbJours = Object.keys(joursAvecConso).length;
        var ratio = nbJours / Math.max(etendue, 1);
        out.usage = ratio >= 0.5 ? 'frequent' : (ratio >= 0.15 ? 'regulier' : 'espace');

        /* `intensite` : la semaine écoulée a-t-elle été plus chargée que d'habitude ?
           Sert uniquement à ne pas proposer un ton léger un jour lourd. Jamais affiché. */
        var recents = datees.filter(function (e) {
          var t = new Date(e.date + 'T00:00:00').getTime();
          return !isNaN(t) && (now - t) <= 7 * JOUR && (Number(e.level) || 0) > 0;
        }).length;
        var moyHebdo = nbJours / Math.max(etendue / 7, 1);
        if (recents === 0) out.intensite = 'calme';
        else if (recents > moyHebdo * 1.5) out.intensite = 'charge';
        else out.intensite = 'habituel';
      }
    }

    /* --- Dernier bilan, s'il est récent --- */
    var sessions = (Array.isArray(d.sessions) ? d.sessions : [])
      .filter(function (x) { return x && x.type === 'q' && x.date; })
      .sort(function (a, b) { return b.date - a.date; });
    if (sessions.length && (now - sessions[0].date) <= 21 * JOUR) {
      var s0 = sessions[0];
      out.bilan = { id: s0.id, score: s0.score };
      /* Un bilan récent ayant déclenché le filet de soutien change ce qu'il est décent
         de dire après un exercice : on ne fait pas d'humour ce jour-là. */
      if (s0.id === 'mood2' && s0.score > 5) out.sensible = true;
      if (s0.id === 'wellbeing' && s0.score <= 7) out.sensible = true;
      if (s0.id === 'loneliness' && s0.score > 5) out.sensible = true;
    }
    return out;
  }

  return { contexte: contexte, MIN_ENTREES: MIN_ENTREES, MIN_JOURS: MIN_JOURS };
})();
