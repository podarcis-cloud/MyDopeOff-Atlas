/* MyDope Off — alertes-data.js
   ============================================================================
   Alertes substances. Fichier statique, livré avec le site : aucune requête réseau n'est
   jamais émise depuis l'appareil de la personne (01_MANIFESTO, 44_CAPTATION_DONNEES_OUVERTES).
   Généré par la moulinette hors ligne (tools/captation-alertes.js), puis RELU À LA MAIN.

   Cinq règles de contenu, non négociables (ch. 44) :
     1. Jamais d'alerte sans `geste` — un résultat brut est un échec.
     2. Jamais d'alerte sans `source_nom` + `source_url` affichés.
     3. Jamais d'alerte sans date visible — une alerte non datée est pire qu'aucune alerte.
     4. `perime_le` obligatoire — une alerte de 2024 affichée en 2026 détruit la crédibilité.
     5. `gravite` ne colore RIEN. Elle ordonne l'affichage, jamais la teinte
        (20_DESIGN_SYSTEM : interdiction absolue de la couleur de sévérité).

   Le format porte le mensonge du marché, pas le tort de la personne : « X vendu comme Y ».
   ============================================================================ */
window.MD_ALERTES = [

  {
    id: 'alerte-2026-07-pmma-ecstasy-at',
    date: '2026-07-31', capte_le: '2026-08-11', perime_le: '2026-11-30',
    regions: ['DE', 'LU', 'BE', 'FR', 'CH', 'IT'],
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'Ecstasy / MDMA', annonce_en: 'Ecstasy / MDMA', reel_fr: 'PMMA', reel_en: 'PMMA',
    substances: ['MDMA', 'Ecstasy'],
    titre_fr: 'PMMA vendu comme ecstasy',
    titre_en: 'PMMA sold as ecstasy',
    corps_fr: "Des comprimés vendus comme ecstasy contenaient du PMMA à la place du MDMA attendu, d’autres de la N-éthylpentédrone ou une substance non identifiée. Repéré en Autriche fin juillet 2026, sur du drug checking en salle et mobile.",
    corps_en: "Tablets sold as ecstasy contained PMMA instead of the expected MDMA; others held N-ethylpentedrone or an unidentified substance. Found in Austria in late July 2026, through fixed-site and mobile drug checking.",
    geste_fr: "Le PMMA monte beaucoup plus lentement que la MDMA : c’est ce délai qui tue, parce qu’il pousse à reprendre une dose. Si rien ne vient, attendre — au minimum deux heures avant d’envisager quoi que ce soit. Un quart de comprimé pour commencer. Jamais seul·e.",
    geste_en: "PMMA comes up far more slowly than MDMA — that delay is what kills, because it pushes people to redose. If nothing happens, wait: two hours minimum before considering anything. Start with a quarter tablet. Never alone.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  },

  {
    id: 'alerte-2026-04-nitazenes-heroine',
    date: '2026-04-20', capte_le: '2026-08-11', perime_le: '2026-12-31',
    regions: null,
    gravite: 'critique', format: 'contamination',
    annonce_fr: 'Héroïne', annonce_en: 'Heroin', reel_fr: 'Héroïne + nitazènes', reel_en: 'Heroin + nitazenes',
    substances: ['Héroïne', 'Opioïdes'],
    titre_fr: 'Nitazènes dans de l’héroïne',
    titre_en: 'Nitazenes in heroin',
    corps_fr: "Un échantillon remis comme héroïne contenait, en plus de l’héroïne, deux nitazènes non encore identifiés. Les nitazènes sont des opioïdes de synthèse dont certains dépassent largement le fentanyl en puissance.",
    corps_en: "A sample handed in as heroin contained, alongside heroin, two as-yet unidentified nitazenes. Nitazenes are synthetic opioids, some far more potent than fentanyl.",
    geste_fr: "Une dose test bien plus petite que d’habitude, et attendre. Garder de la naloxone à portée : elle agit sur les nitazènes, mais il faut souvent plusieurs doses. Ne pas consommer seul·e — et si personne n’est là, une ligne d’accompagnement à distance existe.",
    geste_en: "Take a much smaller test dose than usual, and wait. Keep naloxone within reach: it does work on nitazenes, but often takes several doses. Don’t use alone — and if nobody’s around, remote support lines exist.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  },

  {
    id: 'alerte-2026-oxycodone-contrefaite-fr',
    date: '2026-06-15', capte_le: '2026-08-11', perime_le: '2027-01-31',
    regions: ['FR', 'IT', 'PT'],
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'Oxycodone (comprimés)', annonce_en: 'Oxycodone (tablets)', reel_fr: 'Nitazènes', reel_en: 'Nitazenes',
    substances: ['Opioïdes', 'Oxycodone'],
    titre_fr: 'Comprimés d’oxycodone contrefaits contenant des nitazènes',
    titre_en: 'Counterfeit oxycodone tablets containing nitazenes',
    corps_fr: "Des comprimés présentés comme de l’oxycodone pharmaceutique contenaient en réalité des nitazènes. Première alerte nationale française, avec des cas comparables signalés en Italie et au Portugal. Un comprimé qui ressemble à un médicament n’en est pas un.",
    corps_en: "Tablets passed off as pharmaceutical oxycodone in fact contained nitazenes. This was France’s first national alert, with comparable cases reported in Italy and Portugal. A tablet that looks like a medicine isn’t one.",
    geste_fr: "Hors pharmacie, l’apparence d’un comprimé ne dit rien de son contenu. Réduire fortement la dose, ne jamais mélanger avec de l’alcool ou des benzodiazépines, avoir de la naloxone et quelqu’un à côté.",
    geste_en: "Outside a pharmacy, a tablet’s appearance tells you nothing about what’s in it. Cut the dose sharply, never mix with alcohol or benzodiazepines, keep naloxone and someone with you.",
    source_nom: 'Toxicologie Analytique & Clinique (alerte nationale, France)',
    source_url: 'https://www.sciencedirect.com/science/article/pii/S2352007825001684'
  },

  {
    id: 'alerte-2026-08-cathinones-ch',
    date: '2026-08-07', capte_le: '2026-08-11', perime_le: '2026-11-30',
    regions: ['CH', 'FR', 'DE', 'IT'],
    gravite: 'eleve', format: 'vendu_comme',
    annonce_fr: '3-MMC / 4-MMC', annonce_en: '3-MMC / 4-MMC', reel_fr: 'Autres cathinones', reel_en: 'Other cathinones',
    substances: ['3-MMC', 'Cathinones', 'Méphédrone'],
    titre_fr: 'Cathinones vendues les unes pour les autres',
    titre_en: 'Cathinones sold as one another',
    corps_fr: "Le drug checking suisse retrouve rarement la cathinone annoncée : de la N-éthylpentédrone vendue comme 3-MMC, du 4-CMC vendu comme MDMA, du 2-MMC vendu comme 4-MMC, et plusieurs mélanges de trois cathinones différentes dans un même échantillon.",
    corps_en: "Swiss drug checking rarely finds the cathinone that was advertised: N-ethylpentedrone sold as 3-MMC, 4-CMC sold as MDMA, 2-MMC sold as 4-MMC, and several samples mixing three different cathinones at once.",
    geste_fr: "Ces molécules n’ont ni la même puissance ni la même durée : une dose habituelle de 3-MMC peut être bien trop forte pour ce qu’il y a réellement dans le sachet. Commencer très bas, espacer largement les reprises, et boire de l’eau sans excès.",
    geste_en: "These molecules differ in potency and duration: a usual 3-MMC dose can be far too much for what’s actually in the bag. Start very low, leave long gaps between redoses, and drink water without overdoing it.",
    source_nom: 'Saferparty / DIZ Zurich', source_url: 'https://www.saferparty.ch/de/infos/drugchecking/warnungen'
  },

  {
    id: 'alerte-2026-1t-lsd',
    date: '2026-07-24', capte_le: '2026-08-11', perime_le: '2026-11-30',
    regions: ['CH', 'DE', 'FR', 'BE'],
    gravite: 'information', format: 'vendu_comme',
    annonce_fr: 'LSD', annonce_en: 'LSD', reel_fr: '1T-LSD', reel_en: '1T-LSD',
    substances: ['LSD', 'Psychédéliques'],
    titre_fr: '1T-LSD vendu comme LSD',
    titre_en: '1T-LSD sold as LSD',
    corps_fr: "Des buvards vendus comme LSD contenaient du 1T-LSD, une molécule apparentée dont le dosage et la montée ne se comportent pas exactement pareil. Ce n’est pas la même chose, même si l’effet ressemble.",
    corps_en: "Blotters sold as LSD contained 1T-LSD, a related molecule whose dosing and onset don’t behave in quite the same way. It isn’t the same thing, even if the effect resembles it.",
    geste_fr: "Traiter un buvard inconnu comme un produit inconnu : demi-dose, et attendre au moins deux heures avant de juger. Prévoir de quoi ne rien avoir à faire le lendemain.",
    geste_en: "Treat an unknown blotter as an unknown drug: half a dose, and wait at least two hours before judging. Plan to have nothing to do the next day.",
    source_nom: 'Saferparty / DIZ Zurich', source_url: 'https://www.saferparty.ch/de/infos/drugchecking/warnungen'
  },

  {
    id: 'alerte-2026-orphines-europe',
    date: '2026-06-09', capte_le: '2026-08-12', perime_le: '2027-02-28',
    regions: null,
    gravite: 'critique', format: 'contamination',
    annonce_fr: 'Héroïne, faux médicaments', annonce_en: 'Heroin, fake medicines', reel_fr: 'Orphines (cychlorphine, spirochlorphine)', reel_en: 'Orphines (cychlorphine, spirochlorphine)',
    substances: ['Opioïdes', 'Héroïne', 'Orphines'],
    titre_fr: 'Une nouvelle famille d’opioïdes remplace les nitazènes',
    titre_en: 'A new opioid family is replacing nitazenes',
    corps_fr: "La Chine a interdit l’ensemble des nitazènes en juillet 2025. Le marché européen s’est déplacé vers les « orphines », proches du brorphine. Entre juin 2024 et janvier 2026, cinq États ont signalé des intoxications aiguës et 18 décès avec exposition confirmée, surtout à la cychlorphine. L’agence européenne a ouvert des évaluations au printemps 2026 : on connaît encore mal ces molécules.",
    corps_en: "China banned all nitazenes in July 2025. The European market shifted to “orphines”, close relatives of brorphine. Between June 2024 and January 2026, five countries reported acute poisonings and 18 confirmed deaths, mostly involving cychlorphine. The European agency opened reviews in spring 2026: little is known about these molecules yet.",
    geste_fr: "Le risque principal est le même que pour tous les opioïdes puissants : la respiration qui ralentit puis s’arrête. La naloxone agit, mais il en faut souvent plusieurs doses. Dose test très réduite, jamais seul·e, et quelqu’un qui sait reconnaître une respiration qui faiblit.",
    geste_en: "The main risk is the same as with any potent opioid: breathing slows, then stops. Naloxone works, but several doses are often needed. Take a much smaller test dose, never alone, with someone who can spot breathing getting weaker.",
    source_nom: 'EUDA — Rapport européen sur les drogues 2026',
    source_url: 'https://www.euda.europa.eu/publications/european-drug-report/2026/drug-situation-in-europe-up-to-2026_en'
  },

  {
    id: 'alerte-2026-faux-medicaments-nitazenes',
    date: '2026-06-09', capte_le: '2026-08-12', perime_le: '2027-02-28',
    regions: null,
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'Oxycodone, diazépam, Xanax', annonce_en: 'Oxycodone, diazepam, Xanax', reel_fr: 'Nitazènes', reel_en: 'Nitazenes',
    substances: ['Opioïdes', 'Benzodiazépines', 'Oxycodone', 'Diazépam'],
    titre_fr: 'Faux médicaments contenant des nitazènes, partout en Europe',
    titre_en: 'Fake medicines containing nitazenes, across Europe',
    corps_fr: "Des comprimés imitant l’oxycodone ou le diazépam contiennent des nitazènes. Dix pays ont saisi plus de 50 000 comprimés en 2024, contre 23 000 en 2023 et 380 en 2022. L’agence européenne s’inquiète particulièrement de leur circulation auprès de personnes sans tolérance aux opioïdes.",
    corps_en: "Tablets mimicking oxycodone or diazepam contain nitazenes. Ten countries seized more than 50,000 tablets in 2024, up from 23,000 in 2023 and 380 in 2022. The European agency is especially concerned about them reaching people with no opioid tolerance.",
    geste_fr: "Un comprimé acheté hors pharmacie ne dit rien de son contenu, même avec le bon logo et la bonne rainure. Si tu cherchais une benzodiazépine, tu peux te retrouver avec un opioïde très puissant — et l’alcool ou un autre calmant par-dessus rend l’arrêt respiratoire beaucoup plus probable. Naloxone à portée, quelqu’un à côté.",
    geste_en: "A tablet bought outside a pharmacy tells you nothing about its contents, logo and score line included. If you were after a benzodiazepine you may end up with a very potent opioid — and alcohol or another downer on top makes respiratory arrest far more likely. Keep naloxone nearby, and someone with you.",
    source_nom: 'EUDA — Nouveaux risques sanitaires, juin 2026',
    source_url: 'https://www.euda.europa.eu/news/2026/new-health-risks-europeans-fast-moving-drug-market_en'
  },

  {
    id: 'alerte-2026-4aco-met-psilocybine',
    date: '2026-01-15', capte_le: '2026-08-12', perime_le: '2026-12-31',
    regions: ['CH', 'FR', 'DE', 'BE', 'AT'],
    gravite: 'eleve', format: 'vendu_comme',
    annonce_fr: 'Psilocybine / champignons', annonce_en: 'Psilocybin / mushrooms', reel_fr: '4-AcO-MET ou 4-HO-MET', reel_en: '4-AcO-MET or 4-HO-MET',
    substances: ['Psilocybine', 'Psychédéliques', 'Champignons'],
    titre_fr: 'Molécules de synthèse vendues comme psilocybine',
    titre_en: 'Synthetic molecules sold as psilocybin',
    corps_fr: "Le drug checking suisse a retrouvé du 4-AcO-MET et du 4-HO-MET dans des produits vendus comme psilocybine. Ce sont des tryptamines de synthèse : proches, mais ni la même durée ni le même dosage, et bien moins documentées.",
    corps_en: "Swiss drug checking found 4-AcO-MET and 4-HO-MET in products sold as psilocybin. These are synthetic tryptamines: related, but neither the same duration nor the same dosing, and far less documented.",
    geste_fr: "Une dose « habituelle » de champignons n’a aucun sens pour une poudre de synthèse. Commencer très bas, attendre au moins deux heures avant d’envisager quoi que ce soit, et prévoir une présence rassurante. Rien à faire le lendemain.",
    geste_en: "A “usual” mushroom dose means nothing for a synthetic powder. Start very low, wait at least two hours before considering anything more, and have a reassuring presence around. Nothing planned for the next day.",
    source_nom: 'Infodrog — Nouvelles substances psychoactives en Suisse',
    source_url: 'https://www.infodrog.ch/files/content/schadensminderung_fr/Nouvelles-substances-psychoactives-en-Suisse_Rapport-2025_infodrog.pdf'
  },

  {
    id: 'alerte-2026-alpha-phip',
    date: '2026-01-15', capte_le: '2026-08-12', perime_le: '2026-12-31',
    regions: ['CH', 'FR', 'DE', 'BE', 'AT'],
    gravite: 'eleve', format: 'vendu_comme',
    annonce_fr: 'MDMA ou 2C-B', annonce_en: 'MDMA or 2C-B', reel_fr: 'α-PHiP', reel_en: 'α-PHiP',
    substances: ['MDMA', '2C-B', 'Cathinones'],
    titre_fr: 'α-PHiP vendu comme MDMA ou 2C-B',
    titre_en: 'α-PHiP sold as MDMA or 2C-B',
    corps_fr: "L’α-PHiP, une cathinone de la famille de la pyrovalérone, a été retrouvée plusieurs fois dans des échantillons vendus comme MDMA ou 2C-B — ou non déclarés du tout. Ce n’est pas du tout la même chose : effet stimulant long, envie de reprendre, sommeil très perturbé.",
    corps_en: "α-PHiP, a cathinone from the pyrovalerone family, has turned up repeatedly in samples sold as MDMA or 2C-B — or not declared at all. It behaves quite differently: long stimulant effect, strong urge to redose, badly disrupted sleep.",
    geste_fr: "Si la montée ne ressemble pas à ce que tu attendais et que l’effet dure beaucoup plus longtemps, ne reprends pas : c’est précisément le moment où ces molécules poussent à en reprendre. Boire sans excès, prévoir une nuit blanche possible.",
    geste_en: "If the come-up doesn’t feel like what you expected and the effect lasts much longer, don’t redose: that’s exactly when these molecules push people to take more. Drink water without overdoing it, and expect a possible sleepless night.",
    source_nom: 'Infodrog — Nouvelles substances psychoactives en Suisse',
    source_url: 'https://www.infodrog.ch/files/content/schadensminderung_fr/Nouvelles-substances-psychoactives-en-Suisse_Rapport-2025_infodrog.pdf'
  },

  {
    id: 'alerte-2026-comprimes-tres-dosés',
    date: '2026-08-07', capte_le: '2026-08-12', perime_le: '2026-11-30',
    regions: ['CH', 'DE', 'AT', 'FR', 'BE'],
    gravite: 'eleve', format: 'dosage',
    annonce_fr: 'Ecstasy', annonce_en: 'Ecstasy', reel_fr: 'Ecstasy très fortement dosé', reel_en: 'Very high-dose ecstasy',
    substances: ['MDMA', 'Ecstasy'],
    titre_fr: 'Comprimés d’ecstasy très fortement dosés',
    titre_en: 'Very high-dose ecstasy tablets',
    corps_fr: "Les services d’analyse germanophones publient régulièrement des avertissements sur des comprimés dépassant largement les doses habituelles. Le dosage ne se voit ni à la taille, ni au logo, ni à la couleur — deux comprimés identiques peuvent contenir du simple au triple.",
    corps_en: "German-speaking drug checking services regularly publish warnings about tablets well above usual doses. Dose can’t be read from size, logo or colour — two identical-looking tablets can differ threefold.",
    geste_fr: "Un quart ou un demi pour commencer, et deux heures d’attente avant d’envisager plus. Le risque monte fortement avec la chaleur et l’effort : des pauses, de l’eau sans excès, et quelqu’un qui sait que tu as pris quelque chose.",
    geste_en: "Start with a quarter or a half, and wait two hours before considering more. Risk climbs sharply with heat and exertion: take breaks, drink water without overdoing it, and make sure someone knows you’ve taken something.",
    source_nom: 'Saferparty / Mindzone',
    source_url: 'https://mindzone.info/aktuelles/substanz-drogen-warnungen/'
  },

  {
    id: 'alerte-2026-faux-xanax-metonitazene',
    date: '2026-04-20', capte_le: '2026-08-16', perime_le: '2027-02-28',
    regions: ['DE', 'CH', 'AT', 'FR', 'BE', 'LU'],
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'Xanax (alprazolam)', annonce_en: 'Xanax (alprazolam)',
    reel_fr: 'Métonitazène, oxycodone', reel_en: 'Metonitazene, oxycodone',
    substances: ['Benzodiazépines', 'Xanax', 'Alprazolam', 'Opioïdes'],
    titre_fr: 'Faux Xanax vendus en ligne, contenant des opioïdes',
    titre_en: 'Fake Xanax sold online, containing opioids',
    corps_fr: "Des comprimés achetés sur des boutiques en ligne germanophones ne contiennent pas d’alprazolam mais un mélange d’oxycodone, de métonitazène et de N,N-diméthylaminoétazène. Le métonitazène a une puissance comparable à celle du fentanyl. Les comprimés sont visuellement indiscernables des vrais, marque imprimée comprise, et correspondent à un signalement suisse de mars 2026.",
    corps_en: "Tablets bought from German-language online shops contain no alprazolam, but a mix of oxycodone, metonitazene and N,N-dimethylaminoetazene. Metonitazene is comparable in potency to fentanyl. The tablets are visually indistinguishable from the real thing, brand imprint included, and match a Swiss report from March 2026.",
    geste_fr: "Le risque est maximal ici parce que personne ne s’attend à un opioïde : quelqu’un qui cherche un calmant n’a aucune tolérance, et une dose minime suffit à arrêter la respiration. Un comprimé commandé en ligne ne se vérifie pas à l’œil. Si tu en as, ne le prends pas seul·e, garde de la naloxone à portée, et surtout pas d’alcool ni d’autre calmant par-dessus.",
    geste_en: "The risk peaks here because nobody expects an opioid: someone looking for a sedative has no tolerance, and a tiny dose can stop breathing. A tablet ordered online can’t be checked by eye. If you have some, don’t take it alone, keep naloxone within reach, and absolutely no alcohol or other downer on top.",
    source_nom: 'NEWS / IFT München · CHU de Fribourg · BfArM',
    source_url: 'https://mindzone.info/aktuelles/aktuelle-news-warnmeldung-achtung-gefaelschte-xanax-tablette-mit-hochpotenten-opioiden/'
  },

  {
    id: 'alerte-2026-cannabis-synthetiques',
    date: '2026-07-31', capte_le: '2026-08-16', perime_le: '2026-12-31',
    regions: ['AT', 'DE', 'CH', 'FR', 'BE'],
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'Cannabis, herbe', annonce_en: 'Cannabis, weed',
    reel_fr: 'Cannabinoïdes de synthèse', reel_en: 'Synthetic cannabinoids',
    substances: ['Cannabis', 'THC', 'Cannabinoïdes'],
    titre_fr: 'Cannabinoïdes de synthèse dans de l’herbe',
    titre_en: 'Synthetic cannabinoids in herbal cannabis',
    corps_fr: "Un échantillon remis comme cannabis contenait quatre cannabinoïdes de synthèse : MDMB-INACA, ADB-4en-PINACA, MDMB-4en-PINACA et 5F-MDMB-PINACA. Ces molécules n’ont rien à voir avec le THC — elles sont bien plus puissantes, agissent différemment, et provoquent régulièrement crises d’angoisse aiguës, vomissements, convulsions et pertes de connaissance.",
    corps_en: "A sample handed in as cannabis contained four synthetic cannabinoids: MDMB-INACA, ADB-4en-PINACA, MDMB-4en-PINACA and 5F-MDMB-PINACA. These molecules have nothing to do with THC — far more potent, acting differently, and regularly causing acute panic, vomiting, seizures and loss of consciousness.",
    geste_fr: "Ça ne se voit pas, ça ne se sent pas, et l’odeur ne dit rien. Le signal le plus fiable est l’effet lui-même : une montée brutale, très différente de d’habitude, doit faire arrêter tout de suite. Une bouffée pour tester une herbe inconnue, en étant assis·e et accompagné·e, vaut mieux qu’un joint entier.",
    geste_en: "It can’t be seen or smelled, and the smell tells you nothing. The most reliable signal is the effect itself: a sudden onset, very different from usual, means stop straight away. One puff to test unfamiliar weed, sitting down and with someone around, beats a whole joint.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  },

  {
    id: 'alerte-2026-gbl-vendu-ghb',
    date: '2026-06-30', capte_le: '2026-08-16', perime_le: '2026-12-31',
    regions: ['AT', 'DE', 'CH', 'FR', 'BE', 'NL'],
    gravite: 'critique', format: 'vendu_comme',
    annonce_fr: 'GHB', annonce_en: 'GHB',
    reel_fr: 'GBL', reel_en: 'GBL',
    substances: ['GHB', 'GBL', 'Chemsex'],
    titre_fr: 'Du GBL vendu comme du GHB',
    titre_en: 'GBL sold as GHB',
    corps_fr: "Un échantillon remis comme GHB ne contenait que du GBL. Le corps transforme le GBL en GHB, mais à volume égal il est nettement plus fort — la même dose en millilitres tape environ deux fois plus. L’effet arrive aussi plus vite.",
    corps_en: "A sample handed in as GHB contained only GBL. The body converts GBL into GHB, but volume for volume it’s markedly stronger — the same dose in millilitres hits around twice as hard. It also comes on faster.",
    geste_fr: "C’est le produit où la marge entre la dose qui fait effet et celle qui endort profondément est la plus étroite, et cette confusion la réduit encore. Si tu ne sais pas lequel des deux tu as, compte de moitié et attends. Seringue graduée, heure de chaque prise notée, deux heures d’écart, jamais avec de l’alcool.",
    geste_en: "This is the substance with the narrowest gap between the dose that works and the dose that knocks you out, and this mix-up narrows it further. If you don’t know which of the two you have, halve it and wait. Graduated syringe, time of each dose written down, two hours apart, never with alcohol.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  },

  {
    id: 'alerte-2026-tusi-melange',
    date: '2026-07-31', capte_le: '2026-08-16', perime_le: '2026-12-31',
    regions: ['AT', 'DE', 'CH', 'FR', 'BE', 'ES'],
    gravite: 'eleve', format: 'vendu_comme',
    annonce_fr: 'Tusi, cocaïne rose', annonce_en: 'Tusi, pink cocaine',
    reel_fr: 'MDMA, kétamine, caféine, 2C-B', reel_en: 'MDMA, ketamine, caffeine, 2C-B',
    substances: ['Tusi', '2C-B', 'MDMA', 'Kétamine'],
    titre_fr: 'Tusi : quatre substances dans la même poudre',
    titre_en: 'Tusi: four substances in one powder',
    corps_fr: "Une poudre vendue comme tusi contenait à la fois de la MDMA, de la kétamine, de la caféine, du 2C-B et une substance non identifiée. Le tusi n’est pas une molécule mais un mélange, et sa composition change d’un lot à l’autre — impossible de doser quoi que ce soit à partir de l’expérience précédente.",
    corps_en: "A powder sold as tusi contained MDMA, ketamine, caffeine, 2C-B and an unidentified substance all at once. Tusi isn’t one molecule but a mixture, and its make-up changes batch to batch — so nothing can be dosed from last time’s experience.",
    geste_fr: "Un mélange de stimulant, de dissociatif et de psychédélique dans une même prise rend les effets imprévisibles, et empêche de savoir ce qui monte. Commence très bas, attends longtemps, et ne rajoute rien d’autre par-dessus. La kétamine présente rend aussi la chute plus brutale que prévu — prévois un endroit où t’asseoir.",
    geste_en: "A stimulant, a dissociative and a psychedelic in one dose make effects unpredictable, and make it impossible to tell what’s coming up. Start very low, wait a long time, and add nothing on top. The ketamine in it also makes the drop sharper than expected — have somewhere to sit down.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  },

  {
    id: 'alerte-2026-procaine-cocaine',
    date: '2026-07-31', capte_le: '2026-08-16', perime_le: '2026-11-30',
    regions: ['AT', 'DE', 'CH', 'FR', 'BE'],
    gravite: 'information', format: 'vendu_comme',
    annonce_fr: 'Cocaïne', annonce_en: 'Cocaine',
    reel_fr: 'Procaïne seule', reel_en: 'Procaine only',
    substances: ['Cocaïne'],
    titre_fr: 'Procaïne vendue comme cocaïne',
    titre_en: 'Procaine sold as cocaine',
    corps_fr: "Un échantillon remis comme cocaïne ne contenait que de la procaïne, un anesthésique local. Elle engourdit les gencives exactement comme la cocaïne — c’est précisément pour ça qu’elle sert de produit de coupe, et le test du goût ne permet pas de faire la différence.",
    corps_en: "A sample handed in as cocaine contained only procaine, a local anaesthetic. It numbs the gums exactly like cocaine — which is precisely why it’s used as a cutting agent, and why the taste test can’t tell them apart.",
    geste_fr: "Le risque n’est pas la procaïne elle-même mais ce qui suit : ne rien sentir pousse à reprendre encore et encore, et si le lot suivant contient de la vraie cocaïne, la dose accumulée devient forte d’un coup. Si « ça ne fait rien », attends plutôt que d’enchaîner.",
    geste_en: "The risk isn’t procaine itself but what follows: feeling nothing pushes people to redose again and again, and if the next batch does contain real cocaine, the accumulated dose lands hard all at once. If “it’s doing nothing”, wait rather than keep going.",
    source_nom: 'checkit! Vienne', source_url: 'https://checkit.wien/en/warnungen/'
  }

];
