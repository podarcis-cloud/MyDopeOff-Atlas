/* MyDope Off — page-patience.js
   Logique de patience, extraite du script inline de patience.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var SEEDS=6, MAXV=12, TAU=3.4, CAP=11; // secondes max de croissance
  var GENERIC_FUTURE=[
    'Imagine un jour précis, dans quelques semaines. Il est 19h. Où es-tu ? Qui est avec toi ? Qu\u2019est-ce qui a changé ?',
    'Un souvenir qui n\u2019existe pas encore : toi, dans un mois, en train de repenser à aujourd\u2019hui. Qu\u2019est-ce que ce toi-là aimerait pouvoir se dire ?',
    'Ferme les yeux deux secondes. Vois un lieu précis où tu aimerais être dans six mois. C\u2019est pour ce lieu-là que cette graine pousse.',
    'Pas « plus tard » dans l\u2019abstrait — un jour précis, une heure précise. À quoi il ressemble, ce jour-là, si celui-ci se passe bien ?'
  ];

  function personalValues(){
    return window.MDData ? MDData.getValeurs() : [];
  }
  function hasLetters(){
    try{ return (window.MDData ? MDData.getSessions() : []).some(function(s){ return s.type==='lettre'; }); }catch(e){ return false; }
  }
  var usedFuture = [];
  function pickFuture(){
    var pool = GENERIC_FUTURE.slice();
    var vals = personalValues();
    if (vals.length){
      var v = vals[Math.floor(Math.random()*vals.length)];
      pool.push('Tu as choisi \u00ab '+v+' \u00bb comme une des choses qui comptent pour toi. Repense à un moment précis, récent, où ça s\u2019est vu.');
      pool.push('Dans un mois, à quoi ressemblerait une journée où \u00ab '+v+' \u00bb prend toute la place qu\u2019elle mérite ?');
    }
    if (hasLetters()) pool.push('Tu as déjà écrit à ton futur toi. C\u2019est lui ou elle qui attend cette récolte \u2014 pas juste « plus tard » dans le vide.');
    var candidates = pool.filter(function(p){ return usedFuture.indexOf(p)===-1; });
    if (!candidates.length) candidates = pool;
    var pick = candidates[Math.floor(Math.random()*candidates.length)];
    usedFuture.push(pick);
    return pick;
  }
  var body=document.getElementById('pt-body');
  var seed=0, harvest=0, waits=[], hadPrompt=[], t0=0, raf=0, growStart=0, current=0, running=false;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function valAt(t){ return 1 + (MAXV-1)*(1-Math.exp(-t/TAU)); }

  function grow(){
    var stem=document.getElementById('pt-stem'), fruit=document.getElementById('pt-fruit'), val=document.getElementById('pt-val'), btn=document.getElementById('pt-harvest'), cap=document.getElementById('pt-cap');
    if(!running) return;
    var t=Math.min(CAP,(Date.now()-growStart)/1000);
    current=valAt(t);
    var frac=(current-1)/(MAXV-1);
    if(stem) stem.style.height=(20+frac*150)+'px';
    if(fruit){ fruit.style.bottom=(16+20+frac*150-30)+'px'; fruit.style.transform='translate(-50%,50%) scale('+(0.5+frac*0.6)+')'; }
    if(val) val.textContent='+'+Math.round(current);
    var maxed = frac>=0.94;
    if(btn) btn.textContent='Cueillir  (+'+Math.round(current)+(maxed?' · maximum atteint':'')+')';
    if(cap) cap.textContent = maxed ? 'La graine a fini de grandir — inutile d\u2019attendre plus.' : ('Grandit jusqu\u2019à +'+MAXV+' environ, puis plafonne.');
    raf=requestAnimationFrame(grow);
  }

  function plant(){
    running=true; growStart=Date.now(); current=1;
    var showFuture = (seed%2===1); // une graine sur deux, à partir de la 2e
    hadPrompt.push(showFuture);
    body.innerHTML='<p class="game-step">Graine '+(seed+1)+' / '+SEEDS+'</p>'+
      '<div class="pt-stage"><div class="pt-soil"></div><div class="pt-stem" id="pt-stem"></div>'+
      '<div class="pt-fruit" id="pt-fruit"><span class="pt-val" id="pt-val">+1</span></div></div>'+
      '<p class="pt-cap" id="pt-cap">Grandit jusqu\u2019\u00e0 +'+MAXV+' environ, puis plafonne.</p>'+
      (showFuture?'<div class="pt-future">'+pickFuture()+'</div>':'')+
      '<button class="pt-harvest" id="pt-harvest">Cueillir  (+1)</button>'+
      '<p class="pt-seeds">Récolte totale : '+harvest+'</p>';
    document.getElementById('pt-harvest').addEventListener('click', function(){
      running=false; cancelAnimationFrame(raf);
      var t=Math.min(CAP,(Date.now()-growStart)/1000); waits.push(t);
      harvest+=Math.round(current); seed++;
      if(seed>=SEEDS) finish(); else transition();
    });
    raf=requestAnimationFrame(grow);
  }

  function transition(){
    var late = waits[waits.length-1] >= 5;
    body.innerHTML='<p class="game-q">'+(late?'Belle patience.':'Cueillie.')+'</p>'+
      '<p class="game-sub">'+(late?'Tu as laissé la vie grandir. +'+Math.round(current)+' récoltés.':'+'+Math.round(current)+' récoltés. La prochaine, tu peux attendre un peu plus ?')+'</p>'+
      '<button class="game-cta" id="pt-next">Graine suivante</button>';
    document.getElementById('pt-next').addEventListener('click', plant);
  }

  function finish(){
    var avg=waits.reduce(function(a,b){return a+b;},0)/waits.length;
    var idx=Math.round(avg/CAP*100); // indice de patience 0-100
    var withP=[], withoutP=[];
    waits.forEach(function(w,i){ (hadPrompt[i]?withP:withoutP).push(w); });
    var avgWith = withP.length ? withP.reduce(function(a,b){return a+b;},0)/withP.length : null;
    var avgWithout = withoutP.length ? withoutP.reduce(function(a,b){return a+b;},0)/withoutP.length : null;
    var insight=null;
    if (avgWith!=null && avgWithout!=null){
      var diff = avgWith - avgWithout;
      if (diff >= 0.6) insight='Tu as tenu en moyenne '+diff.toFixed(1)+' s de plus sur les graines avec une pensée du futur \u2014 pas un hasard, c\u2019est un effet documenté.';
      else if (diff <= -0.6) insight='Curieusement, tu as tenu un peu moins longtemps sur les graines avec une pensée du futur cette fois \u2014 ça arrive, retente pour voir si ça se confirme.';
    }
    var d=store(); d.patience=d.patience||{best:0,parties:0}; d.patience.parties++; if(idx>d.patience.best)d.patience.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('patience',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{recolte:harvest,indice:idx,attenteMoy:Math.round(avg*10)/10,attenteAvecPensee:avgWith?Math.round(avgWith*10)/10:null,attenteSansPensee:avgWithout?Math.round(avgWithout*10)/10:null},
        title:'Patience', stats:[{label:'récolte',value:harvest},{label:'indice de patience',value:idx+'/100'}], note:insight,
        nav:{ primary:{label:'Rejouer'}, secondary:{label:'Retour au labo'} },
        onClose:function(){ window.__mdAvant=null; seed=0;harvest=0;waits=[];hadPrompt=[];usedFuture=[];t0=Date.now();plant(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('patience',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ recolte:harvest, indice:idx, attenteMoy:Math.round(avg*10)/10 } }); }
  }

  function begin(){
    seed=0;harvest=0;waits=[];hadPrompt=[];usedFuture=[];t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:'Patience',
        lines:['Une graine pousse toute seule, et sa récolte grandit avec le temps.',
               'Tu peux la cueillir quand tu veux — mais plus tu attends, plus elle vaut.',
               'Une graine sur deux t\u2019invite à penser à ton futur pendant que tu patientes. Six graines à faire pousser.'],
        why:'Préférer une récompense imm\u00e9diate \u00e0 une plus grande plus tard (le « delay discounting ») est un moteur central de l\u2019addiction. Se projeter concr\u00e8tement dans son futur pendant l\u2019attente (la « pens\u00e9e \u00e9pisodique du futur ») r\u00e9duit mesurablement cette impulsivit\u00e9 \u2014 c\u2019est l\u2019un des leviers les mieux \u00e9tablis en recherche sur l\u2019addiction (Bickel et al.).',
        onStart:function(avant){ window.__mdAvant=avant; plant(); } });
    } else { plant(); }
  }
  try{ MDCore.init({page:'patience',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
