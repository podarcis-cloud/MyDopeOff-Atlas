/* MyDope Off — page-patience.js
   Logique de patience, extraite du script inline de patience.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var SEEDS=6, MAXV=12, TAU=3.4, CAP=11; // secondes max de croissance
  var GENERIC_FUTURE_FR=[
    'Imagine un jour précis, dans quelques semaines. Il est 19h. Où es-tu ? Qui est avec toi ? Qu\u2019est-ce qui a changé ?',
    'Un souvenir qui n\u2019existe pas encore : toi, dans un mois, en train de repenser à aujourd\u2019hui. Qu\u2019est-ce que ce toi-là aimerait pouvoir se dire ?',
    'Ferme les yeux deux secondes. Vois un lieu précis où tu aimerais être dans six mois. C\u2019est pour ce lieu-là que cette graine pousse.',
    'Pas « plus tard » dans l\u2019abstrait — un jour précis, une heure précise. À quoi il ressemble, ce jour-là, si celui-ci se passe bien ?'
  ];
  var GENERIC_FUTURE_EN=[
    'Picture a specific day, a few weeks from now. It\u2019s 7pm. Where are you? Who\u2019s with you? What\u2019s changed?',
    'A memory that doesn\u2019t exist yet: you, a month from now, thinking back to today. What would that future you like to be able to say?',
    'Close your eyes for two seconds. See a specific place you\u2019d like to be in six months. This seed is growing for that place.',
    'Not "later" in the abstract — a specific day, a specific time. What does that day look like, if this one goes well?'
  ];
  var GENERIC_FUTURE = L==='en' ? GENERIC_FUTURE_EN : GENERIC_FUTURE_FR;

  var T = {
    val_future:{fr:'Tu as choisi \u00ab {v} \u00bb comme une des choses qui comptent pour toi. Repense à un moment précis, récent, où ça s\u2019est vu.',
      en:'You chose "{v}" as one of the things that matter to you. Think back to a specific, recent moment where that showed.'},
    val_future2:{fr:'Dans un mois, à quoi ressemblerait une journée où \u00ab {v} \u00bb prend toute la place qu\u2019elle mérite ?',
      en:'A month from now, what would a day look like where "{v}" gets all the space it deserves?'},
    letter_future:{fr:'Tu as déjà écrit à ton futur toi. C\u2019est lui ou elle qui attend cette récolte \u2014 pas juste « plus tard » dans le vide.',
      en:'You\u2019ve already written to your future self. It\u2019s them who\u2019s waiting for this harvest \u2014 not just some vague "later".'},
    seed_step:{fr:'Graine ',en:'Seed '},
    grows_to:{fr:'Grandit jusqu\u2019à +',en:'Grows up to +'},
    then_caps:{fr:' environ, puis plafonne.',en:', then caps.'},
    finished_growing:{fr:'La graine a fini de grandir — inutile d\u2019attendre plus.',en:'The seed has finished growing — no point waiting longer.'},
    harvest_btn:{fr:'Cueillir  (+',en:'Harvest  (+'},
    max_reached:{fr:' · maximum atteint)',en:' · maximum reached)'},
    close_paren:{fr:')',en:')'},
    total_harvest:{fr:'Récolte totale : ',en:'Total harvest: '},
    nice_patience:{fr:'Belle patience.',en:'Nice patience.'},
    harvested:{fr:'Cueillie.',en:'Harvested.'},
    let_grow:{fr:'Tu as laissé la vie grandir. +',en:'You let it grow. +'},
    collected:{fr:' récoltés.',en:' collected.'},
    collected_more:{fr:' récoltés. La prochaine, tu peux attendre un peu plus ?',en:' collected. Next one, can you wait a little longer?'},
    next_seed:{fr:'Graine suivante',en:'Next seed'},
    insight_more:{fr:'Tu as tenu en moyenne {d} s de plus sur les graines avec une pensée du futur \u2014 pas un hasard, c\u2019est un effet documenté.',
      en:'You held on {d}s longer on average for seeds with a future thought \u2014 not a coincidence, it\u2019s a documented effect.'},
    insight_less:{fr:'Curieusement, tu as tenu un peu moins longtemps sur les graines avec une pensée du futur cette fois \u2014 ça arrive, retente pour voir si ça se confirme.',
      en:'Curiously, you held on a bit less this time on seeds with a future thought \u2014 that happens, try again to see if it holds up.'},
    title:{fr:'Patience',en:'Patience'},
    stat_harvest:{fr:'récolte',en:'harvest'},
    stat_index:{fr:'indice de patience',en:'patience index'},
    replay:{fr:'Rejouer',en:'Replay'},
    back_labo:{fr:'Retour au labo',en:'Back to Lab'},
    rules_l1:{fr:'Une graine pousse toute seule, et sa récolte grandit avec le temps.',en:'A seed grows on its own, and its harvest grows with time.'},
    rules_l2:{fr:'Tu peux la cueillir quand tu veux — mais plus tu attends, plus elle vaut.',en:'You can harvest it whenever you want — but the longer you wait, the more it\u2019s worth.'},
    rules_l3:{fr:'Une graine sur deux t\u2019invite à penser à ton futur pendant que tu patientes. Six graines à faire pousser.',en:'Every other seed invites you to think about your future while you wait. Six seeds to grow.'},
    rules_why:{fr:'Préférer une récompense immédiate à une plus grande plus tard (le « delay discounting ») est un moteur central de l\u2019addiction. Se projeter concrètement dans son futur pendant l\u2019attente (la « pensée épisodique du futur ») réduit mesurablement cette impulsivité \u2014 c\u2019est l\u2019un des leviers les mieux établis en recherche sur l\u2019addiction (Bickel et al.).',
      en:'Preferring an immediate reward over a larger one later ("delay discounting") is a central driver of addiction. Vividly picturing your future while you wait ("episodic future thinking") measurably reduces this impulsivity \u2014 it\u2019s one of the best-established levers in addiction research (Bickel et al.).'}
  };
  function t(k, sub){ var e=T[k]; var s = e ? (L==='en'?e.en:e.fr) : k; if(sub){ Object.keys(sub).forEach(function(kk){ s=s.replace('{'+kk+'}', sub[kk]); }); } return s; }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'patience.title':    { fr: 'Patience', en: 'Patience' },
    'patience.subtitle': { fr: 'Ce qui grandit quand on sait attendre.', en: 'What grows when you know how to wait.' }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function personalValues(){
    return window.MDData ? MDData.getValeurs() : [];
  }
  function hasLetters(){
    try{ return (window.MDData ? MDData.getSessions() : []).some(function(s){ return s.type==='lettre'; }); }catch(e){ return false; }
  }
  var usedFuture = [];
  function pickFuture(){
    var pool = GENERIC_FUTURE.slice();
    var vals = personalValues();
    if (vals.length){
      var v = vals[Math.floor(Math.random()*vals.length)];
      pool.push(t('val_future',{v:v}));
      pool.push(t('val_future2',{v:v}));
    }
    if (hasLetters()) pool.push(t('letter_future'));
    var candidates = pool.filter(function(p){ return usedFuture.indexOf(p)===-1; });
    if (!candidates.length) candidates = pool;
    var pick = candidates[Math.floor(Math.random()*candidates.length)];
    usedFuture.push(pick);
    return pick;
  }
  var body=document.getElementById('pt-body');
  var seed=0, harvest=0, waits=[], hadPrompt=[], t0=0, raf=0, growStart=0, current=0, running=false;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function valAt(t){ return 1 + (MAXV-1)*(1-Math.exp(-t/TAU)); }

  function grow(){
    var stem=document.getElementById('pt-stem'), fruit=document.getElementById('pt-fruit'), val=document.getElementById('pt-val'), btn=document.getElementById('pt-harvest'), cap=document.getElementById('pt-cap');
    if(!running) return;
    var t2=Math.min(CAP,(Date.now()-growStart)/1000);
    current=valAt(t2);
    var frac=(current-1)/(MAXV-1);
    if(stem) stem.style.height=(20+frac*150)+'px';
    if(fruit){ fruit.style.bottom=(16+20+frac*150-30)+'px'; fruit.style.transform='translate(-50%,50%) scale('+(0.5+frac*0.6)+')'; }
    if(val) val.textContent='+'+Math.round(current);
    var maxed = frac>=0.94;
    if(btn) btn.textContent=t('harvest_btn')+Math.round(current)+(maxed?t('max_reached'):t('close_paren'));
    if(cap) cap.textContent = maxed ? t('finished_growing') : (t('grows_to')+MAXV+t('then_caps'));
    raf=requestAnimationFrame(grow);
  }

  function plant(){
    running=true; growStart=Date.now(); current=1;
    var showFuture = (seed%2===1); // une graine sur deux, à partir de la 2e
    hadPrompt.push(showFuture);
    body.innerHTML='<p class="game-step">'+t('seed_step')+(seed+1)+' / '+SEEDS+'</p>'+
      '<div class="pt-stage"><div class="pt-soil"></div><div class="pt-stem" id="pt-stem"></div>'+
      '<div class="pt-fruit" id="pt-fruit"><span class="pt-val" id="pt-val">+1</span></div></div>'+
      '<p class="pt-cap" id="pt-cap">'+t('grows_to')+MAXV+t('then_caps')+'</p>'+
      (showFuture?'<div class="pt-future">'+pickFuture()+'</div>':'')+
      '<button class="pt-harvest" id="pt-harvest">'+t('harvest_btn')+'1'+t('close_paren')+'</button>'+
      '<p class="pt-seeds">'+t('total_harvest')+harvest+'</p>';
    document.getElementById('pt-harvest').addEventListener('click', function(){
      running=false; cancelAnimationFrame(raf);
      var t2=Math.min(CAP,(Date.now()-growStart)/1000); waits.push(t2);
      harvest+=Math.round(current); seed++;
      if(seed>=SEEDS) finish(); else transition();
    });
    raf=requestAnimationFrame(grow);
  }

  function transition(){
    var late = waits[waits.length-1] >= 5;
    body.innerHTML='<p class="game-q">'+(late?t('nice_patience'):t('harvested'))+'</p>'+
      '<p class="game-sub">'+(late?t('let_grow')+Math.round(current)+t('collected'):'+'+Math.round(current)+t('collected_more'))+'</p>'+
      '<button class="game-cta" id="pt-next">'+t('next_seed')+'</button>';
    document.getElementById('pt-next').addEventListener('click', plant);
  }

  function finish(){
    var avg=waits.reduce(function(a,b){return a+b;},0)/waits.length;
    var idx=Math.round(avg/CAP*100); // indice de patience 0-100
    var withP=[], withoutP=[];
    waits.forEach(function(w,i){ (hadPrompt[i]?withP:withoutP).push(w); });
    var avgWith = withP.length ? withP.reduce(function(a,b){return a+b;},0)/withP.length : null;
    var avgWithout = withoutP.length ? withoutP.reduce(function(a,b){return a+b;},0)/withoutP.length : null;
    var insight=null;
    if (avgWith!=null && avgWithout!=null){
      var diff = avgWith - avgWithout;
      if (diff >= 0.6) insight=t('insight_more',{d:diff.toFixed(1)});
      else if (diff <= -0.6) insight=t('insight_less');
    }
    var d=store(); d.patience=d.patience||{best:0,parties:0}; d.patience.parties++; if(idx>d.patience.best)d.patience.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('patience',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{recolte:harvest,indice:idx,attenteMoy:Math.round(avg*10)/10,attenteAvecPensee:avgWith?Math.round(avgWith*10)/10:null,attenteSansPensee:avgWithout?Math.round(avgWithout*10)/10:null},
        title:t('title'), stats:[{label:t('stat_harvest'),value:harvest},{label:t('stat_index'),value:idx+'/100'}], note:insight,
        nav:{ primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose:function(){ window.__mdAvant=null; seed=0;harvest=0;waits=[];hadPrompt=[];usedFuture=[];t0=Date.now();plant(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('patience',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ recolte:harvest, indice:idx, attenteMoy:Math.round(avg*10)/10 } }); }
  }

  function begin(){
    seed=0;harvest=0;waits=[];hadPrompt=[];usedFuture=[];t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; plant(); } });
    } else { plant(); }
  }
  try{ MDCore.init({page:'patience',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
