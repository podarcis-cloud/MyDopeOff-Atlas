/* MyDope Off — verif-dates.js
   ============================================================================
   Date de dernière vérification factuelle, par dossier (C4.5).

   POURQUOI UN FICHIER UNIQUE
   Écrire la date dans chaque page voudrait dire douze modifications à chaque passe de
   veille — donc, en pratique, des dates qui ne bougent plus. Ici, une ligne à changer.

   POURQUOI ÇA COMPTE POUR LA PERSONNE
   Le marché change en mois, pas en années. Une information sans date ne permet pas de
   savoir si elle vaut encore. Afficher la date, y compris quand elle commence à dater,
   est une application de G14 : dire la limite de ce qu'on sait, au même endroit que ce
   qu'on affirme.

   PROTOCOLE
   Une date ne se met à jour qu'après une vérification réelle des sources (protocole 38,
   deux sources minimum). Changer la date sans avoir relu les sources serait pire que de
   laisser une date ancienne.
   ============================================================================ */
window.MD_VERIF = {
  'alcool.html':             '2026-08-12',
  'cannabis.html':           '2026-08-12',
  'cocaine.html':            '2026-08-12',
  'crack.html':              '2026-08-12',
  'ketamine.html':           '2026-08-12',
  'mdma.html':               '2026-08-12',
  'benzodiazepines.html':    '2026-08-12',
  'psychedeliques.html':     '2026-08-12',
  'nitreux.html':            '2026-08-12',
  'opioides-synthese.html':  '2026-08-12',
  'tabac-vapotage.html':     '2026-08-12',
  'polyconsommation.html':   '2026-08-12',
  'chemsex.html':            '2026-08-11',
  'grossesse.html':          '2026-08-11',
  'paws.html':               '2026-08-11',
  'audition.html':           '2026-08-11',
  'crise-psychedelique.html':'2026-08-12',
  'femmes.html':             '2026-08-12',
  'apres-une-pause.html':    '2026-08-12',
  'situations.html':         '2026-08-12'
};

(function () {
  'use strict';

  function lang() {
    try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; }
  }

  var T = {
    fr: { verif: 'Vérifié le', vieux: 'Ces informations n’ont pas été revues depuis plus de six mois — le marché, lui, a pu changer.' },
    en: { verif: 'Checked on', vieux: 'This hasn’t been reviewed for over six months — the market may well have moved on.' }
  };

  function lisible(iso, l) {
    try {
      return new Date(iso + 'T12:00:00').toLocaleDateString(l === 'en' ? 'en-GB' : 'fr-FR',
        { day: 'numeric', month: 'long', year: 'numeric' });
    } catch (e) { return iso; }
  }

  function monter() {
    var page = location.pathname.split('/').pop() || 'index.html';
    var date = window.MD_VERIF[page];
    if (!date) return;
    var cible = document.querySelector('.dossier .src:last-of-type') ||
                document.querySelector('.dossier');
    if (!cible) return;
    var l = lang(), t = T[l] || T.fr;

    /* Au-delà de six mois, le dossier dit lui-même qu'il vieillit. Une date affichée sans
       cet avertissement laisserait croire que « vérifié » vaut « à jour ». */
    var vieux = (Date.now() - new Date(date + 'T12:00:00').getTime()) > 183 * 864e5;

    var p = document.createElement('p');
    p.className = 'src verif-date';
    p.textContent = t.verif + ' ' + lisible(date, l) + '.' + (vieux ? ' ' + t.vieux : '');
    if (cible.classList.contains('src')) cible.parentNode.insertBefore(p, cible.nextSibling);
    else cible.appendChild(p);
  }

  /* Le montage ne dépend d'aucun ordre de chargement : selon les pages, ce script est
     inséré avant ou après core.js. On tente, puis on retente une fois au chargement
     complet — sur nitreux.html, l'insertion avant core.js faisait échouer silencieusement
     la première tentative. Bug vu au rendu, invisible en lisant le fichier. */
  function tenter() {
    if (document.querySelector('.verif-date')) return;
    monter();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tenter);
  else tenter();
  window.addEventListener('load', tenter);
})();
