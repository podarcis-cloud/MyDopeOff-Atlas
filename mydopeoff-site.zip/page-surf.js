/* MyDope Off — page-surf.js
   Logique de surf, extraite du script inline de surf.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var DURATION=70;
  var cv=document.getElementById('surf-canvas'), ctx=cv.getContext('2d');
  var W=cv.width,H=cv.height;
  var reduce=false; try{reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;}catch(e){}
  var COL={sky:'#F4F6EF',w1:'#9FB6C2',w2:'#69889A',w3:'#4E6B78',calm:'#7A8F72',tempt:'#C7765C'};
  try{var cs=getComputedStyle(document.body);
    COL.w2=cs.getPropertyValue('--fjord').trim()||COL.w2; COL.calm=cs.getPropertyValue('--sauge').trim()||COL.calm;
    COL.tempt=cs.getPropertyValue('--terra').trim()||COL.tempt;}catch(e){}
  var hero=new Image(); hero.src='surf-hero.png'; var heroReady=false; hero.onload=function(){heroReady=true;};
  var running=false,t0=0,raf=0,last=0,pts=0,py=0,touching=false,items=[],spawnT=0,flash=0;
  var TOL=0, offStreak=0, onWaveSamples=0, totalSamples=0, wipeouts=0, onWaveNow=true, hintOverride=0;

  function resize(){var w=cv.clientWidth||cv.parentNode.clientWidth;
    cv.width=Math.round(w); cv.height=Math.round(w*0.75); W=cv.width; H=cv.height; TOL=H*0.16; py=waveY(W*0.26,0.15,0); if(!running) draw(0);}
  window.addEventListener('resize',resize);
  function setY(e){var r=cv.getBoundingClientRect();var cy=(e.touches?e.touches[0].clientY:e.clientY)-r.top;
    py=Math.max(H*0.12,Math.min(H*0.82,cy*(H/r.height)));}
  cv.addEventListener('pointerdown',function(e){touching=true;setY(e);});
  cv.addEventListener('pointermove',function(e){if(touching)setY(e);});
  window.addEventListener('pointerup',function(){touching=false;});
  document.addEventListener('touchmove',function(e){if(running)e.preventDefault();},{passive:false});

  function ampAt(p){if(p<0.42)return p/0.42; if(p<0.58)return 1; return Math.max(0,1-(p-0.58)/0.42);}
  function waveY(x,p,ts){var amp=22+ampAt(p)*(H*0.22);var k=2*Math.PI/(W*0.95);var sp=reduce?0:ts*1.1;
    return H*0.5+Math.sin(x*k+sp)*amp*0.5+Math.sin(x*k*0.5-sp*0.7)*amp*0.5;}
  function phaseTxt(p){if(p<0.42)return 'La vague monte\u2026'; if(p<0.58)return 'La crête — tiens bon'; if(p<0.9)return 'Ça redescend'; return 'Presque passée';}

  function draw(ts){
    var p=running?Math.min(1,ts/DURATION):0.15;
    ctx.clearRect(0,0,W,H); ctx.fillStyle=COL.sky; ctx.fillRect(0,0,W,H);
    [{c:COL.w1,o:.35,dy:24},{c:COL.w2,o:.5,dy:6},{c:COL.w3,o:.3,dy:-14}].forEach(function(L){
      ctx.beginPath(); ctx.moveTo(0,H);
      for(var x=0;x<=W;x+=6) ctx.lineTo(x,waveY(x,p,ts)+L.dy);
      ctx.lineTo(W,H); ctx.closePath(); ctx.globalAlpha=L.o; ctx.fillStyle=L.c; ctx.fill(); ctx.globalAlpha=1;
    });
    items.forEach(function(it){
      ctx.beginPath(); ctx.arc(it.x,it.y,it.r,0,2*Math.PI);
      if(it.bad){ctx.fillStyle=COL.tempt;ctx.globalAlpha=.85;ctx.fill();ctx.globalAlpha=1;
        ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(it.x-5,it.y-5);ctx.lineTo(it.x+5,it.y+5);ctx.moveTo(it.x+5,it.y-5);ctx.lineTo(it.x-5,it.y+5);ctx.stroke();}
      else{ctx.fillStyle=COL.calm;ctx.globalAlpha=.5;ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle=COL.calm;ctx.lineWidth=2;ctx.stroke();}
    });
    var hx=W*0.26, hw=Math.min(96,W*0.24), hh=hw*(heroReady?hero.height/hero.width:0.74);
    if(!onWaveNow){ ctx.beginPath(); ctx.arc(hx,py,hw*0.42,0,2*Math.PI); ctx.strokeStyle=COL.tempt; ctx.lineWidth=3; ctx.globalAlpha=.7; ctx.stroke(); ctx.globalAlpha=1; }
    if(heroReady) ctx.drawImage(hero,hx-hw/2,py-hh*0.82,hw,hh);
    else{ctx.beginPath();ctx.arc(hx,py,16,0,2*Math.PI);ctx.fillStyle=COL.tempt;ctx.fill();}
    if(flash>0){ctx.fillStyle='rgba(199,118,92,'+(flash*0.25)+')';ctx.fillRect(0,0,W,H);flash-=0.06;}
    return {hx:hx,hr:Math.max(18,hw*0.28)};
  }

  function loop(ts){
    if(!running)return;
    if(!t0)t0=ts; if(!last)last=ts;
    var tsec=(ts-t0)/1000,dt=ts-last; last=ts; var p=Math.min(1,tsec/DURATION);
    spawnT-=dt;
    if(spawnT<=0){spawnT=620-ampAt(p)*260; var bad=Math.random()<(0.35+ampAt(p)*0.25);
      items.push({x:W+20,y:H*(0.2+Math.random()*0.6),r:bad?15:13,bad:bad,sp:0.10+ampAt(p)*0.08});}
    var h2=draw(tsec);
    var idealY=waveY(h2.hx,p,tsec), dist=Math.abs(py-idealY);
    onWaveNow = dist<=TOL;
    totalSamples++; if(onWaveNow) onWaveSamples++;
    if(onWaveNow){ offStreak=0; }
    else{
      offStreak+=dt;
      if(offStreak>=1200){
        offStreak=0; wipeouts++; pts=Math.max(0,pts-3); flash=1; hintOverride=1400;
        document.getElementById('surf-hint').textContent='Tu as d\u00e9croch\u00e9 \u2014 reviens vers la vague.';
      }
    }
    if(hintOverride>0){
      hintOverride-=dt;
      if(hintOverride<=0){ document.getElementById('surf-hint').textContent='Glisse le doigt pour rester sur la crête de la vague — attrape les bulles de calme (vertes), évite les remous (rouges).'; }
    }
    for(var i=items.length-1;i>=0;i--){var it=items[i]; it.x-=it.sp*dt;
      var dx=it.x-h2.hx,dy=it.y-py, d=Math.sqrt(dx*dx+dy*dy);
      if(d<h2.hr+it.r){ if(it.bad){pts=Math.max(0,pts-2);flash=1;} else {pts+=3;} items.splice(i,1); continue; }
      if(it.x<-30) items.splice(i,1);
    }
    document.getElementById('surf-pts').textContent=pts;
    var stabPct = totalSamples ? Math.round(onWaveSamples/totalSamples*100) : 100;
    var stabEl=document.getElementById('surf-stab');
    if(stabEl){ stabEl.textContent=stabPct+'%'; stabEl.style.color = stabPct>=70?'var(--sauge)':(stabPct>=40?'var(--ocre)':'var(--terra)'); }
    document.getElementById('surf-fill').style.width=Math.round(p*100)+'%';
    document.getElementById('surf-phase').textContent=phaseTxt(p);
    if(tsec>=DURATION){finish(tsec);return;}
    raf=requestAnimationFrame(loop);
  }
  function start(){running=true;t0=0;last=0;pts=0;items=[];spawnT=0;flash=0;
    offStreak=0;onWaveSamples=0;totalSamples=0;wipeouts=0;onWaveNow=true;hintOverride=0;
    document.getElementById('surf-start').style.display='none'; raf=requestAnimationFrame(loop);}
  function finish(tsec){
    running=false; cancelAnimationFrame(raf);
    document.getElementById('surf-phase').textContent='Vague passée';
    document.getElementById('surf-fill').style.width='100%';
    var btn=document.getElementById('surf-start'); btn.textContent='Rejouer'; btn.style.display='block';
    var stabilite = totalSamples ? Math.round(onWaveSamples/totalSamples*100) : 100;
    if(window.MDExercise){MDExercise.after('surf',{avant:window.__mdAvant,dureeSec:Math.round(tsec),meta:{serenite:pts,stabilite:stabilite,decrochages:wipeouts},
      title:'Surf de l\u2019envie', stats:[{label:'sérénité',value:pts},{label:'décrochages',value:wipeouts}],
      nav:{ primary:{label:'Rejouer'} },
      onClose:function(){window.__mdAvant=null; begin();}});}
    else if(window.MDData){MDData.logSession('surf',{dureeSec:Math.round(tsec),meta:{serenite:pts,stabilite:stabilite,decrochages:wipeouts}});}
  }
  function begin(){
    if(window.MDJeuHero){
      MDJeuHero.rules({mood:'respiration',title:'Surf de l\u2019envie',
        lines:['Glisse le doigt pour rester sur la crête de la vague — elle bouge, ton doigt la suit.',
               'T\u2019en écarter trop longtemps te fait décrocher : reviens dessus activement.',
               'Attrape les bulles de calme (vertes), évite les remous (rouges), en restant sur la vague.'],
        why:'Accompagner une envie sans y c\u00e9der, en restant activement pr\u00e9sent avec elle plut\u00f4t que de la subir passivement, entra\u00eene la tol\u00e9rance \u00e0 la d\u00e9tresse : le cerveau apprend qu\u2019une pulsion monte puis redescend toujours (urge surfing, Marlatt).',
        onStart:function(avant){ window.__mdAvant=avant; start(); }});
    } else { start(); }
  }
  document.getElementById('surf-start').addEventListener('click',begin);
  try{MDCore.init({page:'surf',section:'equilibre'});}catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
  resize();
})();
