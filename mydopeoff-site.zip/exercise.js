/* exercise.js — Logique de fin d'exercice (données), rendu délégué au compagnon.
   Journalise via MDData.logSession (séance normalisée), gère l'anti-répétition des débriefs,
   les trophées et l'apprentissage des recommandations. Le rendu visuel de l'écran de fin est
   entièrement porté par MDJeuHero.debrief() (jeu-hero.js) : même carte, même compagnon,
   même grammaire que l'écran de règles en début d'exercice — un seul composant, deux moments.
   Pas de jauge « et maintenant » : la mesure d'intensité ne vit que dans le bouton craving
   (scanner.js/urgence.js) — jamais en début ni en fin de jeu. `avant`, quand il est fourni,
   vient uniquement d'un scan craving récent (voir jeu-hero.js recentScan) et ne sert ici qu'à
   journaliser la séance et nuancer le ton du débrief (needsGrounding), pas à afficher un widget.
   100 % local. Expose window.MDExercise. */
window.MDExercise = (function () {

  function pickDebrief(type, avant, perf) {
    var bank = window.MDDebriefs || {};
    var pool = (bank[type] && bank[type].length) ? bank[type] : (bank._default || []);
    if (!pool.length) return { mood: 'encouragement', lines: ['Séance terminée. Beau moment pris pour toi.'], why: null };
    var GROUNDING = { bienveillance: 1, encouragement: 1, ecoute: 1, serenite: 1 };
    var needsGrounding = (avant != null && avant >= 7);
    try {
      var bilan = window.MDData && window.MDData.getBilanState ? window.MDData.getBilanState() : null;
      if (bilan) {
        var recentEnough = function (b) { return b && b.daysAgo <= 14; };
        if ((recentEnough(bilan.craving) && bilan.craving.improving === false) ||
            (recentEnough(bilan.wellbeing) && bilan.wellbeing.improving === false)) needsGrounding = true;
      }
    } catch (e) {}
    var candidates = pool;
    if (needsGrounding) {
      var grounded = pool.filter(function (p) { return GROUNDING[p.mood]; });
      if (grounded.length) candidates = grounded;
    }
    // perf (0..1, plus haut = meilleure performance CETTE partie) : n'affecte que les entrées
    // explicitement taguées perfBand ('low'|'mid'|'high') ; une entrée sans tag reste éligible
    // quel que soit le niveau — comportement inchangé pour les pools jamais tagués.
    if (perf != null) {
      var band = perf < 0.5 ? 'low' : (perf < 0.85 ? 'mid' : 'high');
      var perfOk = candidates.filter(function (p) { return !p.perfBand || p.perfBand === band; });
      if (perfOk.length) candidates = perfOk;
    }
    var lastKey = 'mdDebriefLast_' + type, last = null;
    try { last = localStorage.getItem(lastKey); } catch (e) {}
    if (candidates.length > 1 && last) {
      var filtered = candidates.filter(function (p) { return p.id !== last; });
      if (filtered.length) candidates = filtered;
    }
    var pick = candidates[Math.floor(Math.random() * candidates.length)];
    try { localStorage.setItem(lastKey, pick.id); } catch (e) {}
    return pick;
  }

  /* after(type, opts) : UN SEUL écran de fin — débrief mascotte thématique, récap optionnel,
     et deux actions (continuer / retour au labo). Le débrief est pioché automatiquement dans
     MDDebriefs[type] (variété quotidienne) ; `opts.debrief` reste accepté pour forcer un
     contenu explicite si besoin ponctuel. La séance est journalisée UNE SEULE FOIS, quel que
     soit le bouton choisi.

     opts = {
       avant, meta, axes, dureeSec,     // données de séance (log) ; avant = uniquement si scan craving récent
       perf,                            // 0..1 optionnel, performance CETTE partie (ex. justesse/100) ;
                                         // fait varier le message parmi les entrées taguées perfBand
       debrief:{mood,lines,why},        // optionnel : force le contenu au lieu de piocher
       title,                           // nom affiché de l'exercice (sinon générique)
       stats:[{label,value}], note,     // récap chiffré / insight ponctuel (optionnels)
       backHref,                        // destination du bouton « Retour au labo » (def. fiches.html)
       nav:{ primary:{label,onClick()}, secondary:{label,href,onClick()} },
       onClose()                        // compat : comportement du bouton PRINCIPAL si
                                         // nav.primary.onClick n'est pas fourni
     } */
  function after(type, opts) {
    opts = opts || {};
    var d = opts.debrief || pickDebrief(type, opts.avant, opts.perf);

    function logSession(proceed) {
      var fields = {};
      if (opts.meta) fields.meta = opts.meta;
      if (opts.axes) fields.axes = opts.axes;
      if (opts.dureeSec != null) fields.dureeSec = opts.dureeSec;
      if (opts.avant != null) fields.envieAvant = opts.avant;
      if (window.MDData && MDData.logSession) MDData.logSession(type, fields);

      function thenTrophies() {
        if (window.MDTrophies && MDTrophies.checkAndCelebrate) {
          try { MDTrophies.checkAndCelebrate(proceed); } catch (e) { proceed(); }
        } else { proceed(); }
      }
      var saveFailed = window.MDData && MDData.lastSaveOk && !MDData.lastSaveOk();
      if (saveFailed && window.MDCore && MDCore.warnNoSave) {
        try { MDCore.warnNoSave(thenTrophies); } catch (e) { thenTrophies(); }
      } else { thenTrophies(); }
    }

    if (!window.MDJeuHero || !MDJeuHero.debrief) {
      logSession();
      if (typeof opts.onClose === 'function') opts.onClose();
      return;
    }

    var userNav = opts.nav || {};
    MDJeuHero.debrief({
      mood: d.mood || 'encouragement',
      title: opts.title || null,
      lines: d.lines || ['Séance terminée. Beau moment pris pour toi.'],
      why: d.why || null,
      stats: opts.stats || null,
      note: opts.note || null,
      onPick: logSession,
      nav: {
        primary: {
          label: (userNav.primary && userNav.primary.label) || 'Continuer',
          onClick: function () {
            if (userNav.primary && typeof userNav.primary.onClick === 'function') userNav.primary.onClick();
            else if (typeof opts.onClose === 'function') opts.onClose();
          }
        },
        secondary: {
          label: (userNav.secondary && userNav.secondary.label) || 'Retour au labo',
          href: (userNav.secondary && userNav.secondary.href) || opts.backHref || 'fiches.html',
          onClick: (userNav.secondary && userNav.secondary.onClick) || null
        }
      }
    });
  }

  return { after: after };
})();
