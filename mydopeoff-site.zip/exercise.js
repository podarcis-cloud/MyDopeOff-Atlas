/* exercise.js — Mesure « envie avant / après » + récap, réutilisable par les exercices.
   Auto-contenu : injecte son propre DOM + styles (charte Atlas, couleurs en fallback pour
   les pages sans tokens.css). Boutons natifs <button> => tap fiable sur iOS.
   Journalise via MDData.logSession (séance normalisée). 100 % local. Expose window.MDExercise. */
window.MDExercise = (function () {
  var INJECTED = false;
  function inject() {
    if (INJECTED) return; INJECTED = true;
    var css =
      '.mdx-ov{position:fixed;inset:0;z-index:4000;display:flex;align-items:center;justify-content:center;' +
      'padding:22px;background:rgba(31,43,37,.55);backdrop-filter:blur(3px);font-family:var(--ui,Inter,system-ui,sans-serif)}' +
      '.mdx-card{background:var(--surface,#fff);color:var(--ink,#1F2B25);border:1px solid var(--line,#E2DCD0);' +
      'border-radius:18px;max-width:360px;width:100%;padding:22px 20px;box-shadow:0 18px 50px rgba(31,43,37,.25);text-align:center}' +
      '.mdx-q{font-family:var(--title,Newsreader,Georgia,serif);font-size:20px;line-height:1.25;margin:0 0 4px}' +
      '.mdx-sub{font-size:12.5px;color:var(--ink-2,#58635E);margin:0 0 16px}' +
      '.mdx-scale{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin-bottom:14px}' +
      '.mdx-n{min-width:38px;height:42px;flex:0 0 auto;border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);' +
      'color:var(--ink,#1F2B25);border-radius:11px;font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:16px;' +
      'font-weight:700;cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '.mdx-n:active{transform:scale(.94)}' +
      '.mdx-n.sel{background:var(--terra,#C7765C);border-color:var(--terra,#C7765C);color:#fff}' +
      '.mdx-skip{display:inline-block;margin-top:2px;background:none;border:none;color:var(--ink-2,#58635E);' +
      'font-size:13px;text-decoration:underline;cursor:pointer}' +
      '.mdx-delta{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:17px;margin:6px 0 10px}' +
      '.mdx-big{font-family:var(--title,Newsreader,Georgia,serif);font-size:30px;font-weight:700}' +
      '.mdx-down{color:var(--sauge,#7A8F72)} .mdx-up{color:var(--terra,#C7765C)} .mdx-flat{color:var(--ink-2,#58635E)}' +
      '.mdx-msg{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14.5px;color:var(--ink,#1F2B25);margin:0 0 16px}' +
      '.mdx-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;' +
      'font-family:var(--ui,Inter,sans-serif);font-weight:700;font-size:15px;padding:13px;cursor:pointer}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }
  function close(ov) { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); }

  /* Échelle 0–10. onPick(valeur|null). null = « passer ». */
  function scale(question, sub, onPick) {
    inject();
    var ov = document.createElement('div'); ov.className = 'mdx-ov';
    var card = document.createElement('div'); card.className = 'mdx-card';
    var q = document.createElement('p'); q.className = 'mdx-q'; q.textContent = question; card.appendChild(q);
    if (sub) { var s = document.createElement('p'); s.className = 'mdx-sub'; s.textContent = sub; card.appendChild(s); }
    var row = document.createElement('div'); row.className = 'mdx-scale';
    for (var i = 0; i <= 10; i++) {
      (function (n) {
        var b = document.createElement('button'); b.type = 'button'; b.className = 'mdx-n'; b.textContent = n;
        b.setAttribute('aria-label', 'Envie ' + n + ' sur 10');
        b.onclick = function () { close(ov); onPick(n); };
        row.appendChild(b);
      })(i);
    }
    card.appendChild(row);
    var skip = document.createElement('button'); skip.type = 'button'; skip.className = 'mdx-skip';
    skip.textContent = 'passer cette étape'; skip.onclick = function () { close(ov); onPick(null); };
    card.appendChild(skip);
    ov.appendChild(card); document.body.appendChild(ov);
  }

  function before(cb) {
    scale('Là, maintenant, l\u2019envie est à\u2026', '0 = aucune  ·  10 = irrésistible', function (v) { cb(v); });
  }

  /* after(type, {avant, meta, axes, dureeSec, onClose(apres,delta)}) :
     demande l'envie après, journalise la séance normalisée, montre le récap. */
  function after(type, opts) {
    opts = opts || {};
    scale('Et maintenant, l\u2019envie est à\u2026', '', function (apres) {
      var fields = {};
      if (opts.meta) fields.meta = opts.meta;
      if (opts.axes) fields.axes = opts.axes;
      if (opts.dureeSec != null) fields.dureeSec = opts.dureeSec;
      if (opts.avant != null) fields.envieAvant = opts.avant;
      if (apres != null) fields.envieApres = apres;
      if (window.MDData && MDData.logSession) MDData.logSession(type, fields);
      if (window.MDReco && window.__mdCravingType && opts.avant != null && apres != null) {
        var dn = (opts.avant - apres) / Math.max(1, opts.avant);
        window.MDReco.learn(window.__mdCravingType, type, dn); window.__mdCravingType = null;
      }
      var delta = (opts.avant != null && apres != null) ? (opts.avant - apres) : null;
      recap(opts.avant, apres, delta, function () { if (typeof opts.onClose === 'function') opts.onClose(apres, delta); });
    });
  }

  function recap(avant, apres, delta, onGo) {
    inject();
    var ov = document.createElement('div'); ov.className = 'mdx-ov';
    var card = document.createElement('div'); card.className = 'mdx-card';
    var title = document.createElement('p'); title.className = 'mdx-q'; title.textContent = 'Séance terminée'; card.appendChild(title);
    if (avant != null && apres != null) {
      var d = document.createElement('p'); d.className = 'mdx-delta';
      var cls = delta > 0 ? 'mdx-down' : (delta < 0 ? 'mdx-up' : 'mdx-flat');
      var arrow = delta > 0 ? '\u25BC' : (delta < 0 ? '\u25B2' : '\u2192');
      d.innerHTML = 'Ton envie : <span class="mdx-big">' + avant + '</span> \u2192 <span class="mdx-big">' + apres +
        '</span><br><span class="' + cls + '">' + arrow + ' ' + (delta > 0 ? '\u2212' + delta : (delta < 0 ? '+' + (-delta) : 'stable')) + '</span>';
      card.appendChild(d);
      var msg = document.createElement('p'); msg.className = 'mdx-msg';
      msg.textContent = delta > 0 ? 'L\u2019envie est retombée. Tu viens de t\u2019entraîner à la traverser.'
        : (delta < 0 ? 'Pas grave : l\u2019important, c\u2019est d\u2019avoir pris un moment pour toi.'
          : 'Tu as tenu le cap. Chaque passage compte.');
      card.appendChild(msg);
    } else {
      var m2 = document.createElement('p'); m2.className = 'mdx-msg'; m2.textContent = 'Séance enregistrée. Beau moment pris pour toi.'; card.appendChild(m2);
    }
    var go = document.createElement('button'); go.type = 'button'; go.className = 'mdx-go'; go.textContent = 'Continuer';
    go.onclick = function () { close(ov); if (typeof onGo === 'function') onGo(); };
    card.appendChild(go); ov.appendChild(card); document.body.appendChild(ov);
  }

  return { before: before, after: after, scale: scale, recap: recap };
})();
/* Helper : mesurer l'envie AVANT puis lancer l'exercice (ou réutiliser l'envie d'un scan récent). */
window.mdBefore = function (proceed) {
  try {
    var sc = JSON.parse(sessionStorage.getItem('mdScan') || 'null');
    if (sc && sc.envie != null && (Date.now() - (sc.ts || 0)) < 600000) {
      window.__mdAvant = sc.envie; window.__mdCravingType = sc.type || null;
      sessionStorage.removeItem('mdScan');
      if (typeof proceed === 'function') proceed(); return;
    }
  } catch (e) { }
  window.MDExercise.before(function (v) { window.__mdAvant = v; if (typeof proceed === 'function') proceed(); });
};
