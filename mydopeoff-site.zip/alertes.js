/* MyDope Off — alertes.js
   ============================================================================
   Moteur d'alertes. Un seul, pour les trois usages : page dédiée, encart en fiche
   substance, bandeau d'accueil. Voir 44_CAPTATION_DONNEES_OUVERTES.md.

   Ce que ce moteur ne fait jamais :
     · aucune requête réseau — les données sont livrées avec le site ;
     · aucune couleur de gravité — `gravite` ordonne, ne teinte pas (20_DESIGN_SYSTEM) ;
     · aucune interruption — le bandeau d'accueil se ferme et ne revient pas de la session,
       et rien ne s'affiche par-dessus un contenu en cours (44 : ne jamais interrompre
       quelqu'un pendant un craving) ;
     · aucune alerte périmée — la péremption est vérifiée à chaque affichage, pas à la
       génération : le site peut rester des mois sur un téléphone sans être rouvert.
   ============================================================================ */
window.MDAlertes = (function () {
  'use strict';

  var ferme = false;   // bandeau fermé — portée page, rien n'est écrit sur disque

  function lang() {
    try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; }
  }
  function L(a, champ) { return a[champ + '_' + lang()] || a[champ + '_fr'] || ''; }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function region() {
    try {
      var st = JSON.parse(localStorage.getItem('ctc_v6')) || {};
      return (st.user && st.user.region) || null;
    } catch (e) { return null; }
  }

  var ORDRE = { critique: 0, eleve: 1, information: 2 };

  /* Alertes valides aujourd'hui, pour la région de la personne.
     `regions: null` = concerne tout le monde. Une alerte d'une autre région n'est pas
     masquée par erreur : elle est simplement hors de son périmètre déclaré. */
  function actives(opts) {
    opts = opts || {};
    var today = new Date().toISOString().slice(0, 10);
    var reg = opts.region || region();
    var src = window.MD_ALERTES || [];
    var out = src.filter(function (a) {
      if (!a || !a.perime_le || a.perime_le < today) return false;
      if (a.regions && reg && a.regions.indexOf(reg) === -1) return false;
      if (opts.substance) {
        var s = (a.substances || []).join(' ').toLowerCase();
        if (s.indexOf(String(opts.substance).toLowerCase()) === -1) return false;
      }
      return true;
    });
    /* `|| 9` serait un piège ici : ORDRE['critique'] vaut 0, et 0 || 9 donne 9 —
       les alertes les plus graves se retrouveraient en bas de liste. Vérifié au rendu. */
    function rang(g) { return (g in ORDRE) ? ORDRE[g] : 9; }
    out.sort(function (x, y) {
      var d = rang(x.gravite) - rang(y.gravite);
      return d !== 0 ? d : (y.date || '').localeCompare(x.date || '');
    });
    return out;
  }

  function dateLisible(iso) {
    try {
      var d = new Date(iso + 'T12:00:00');
      return d.toLocaleDateString(lang() === 'en' ? 'en-GB' : 'fr-FR',
        { day: 'numeric', month: 'long', year: 'numeric' });
    } catch (e) { return iso; }
  }

  var T = {
    vendu:   { fr: 'vendu comme', en: 'sold as' },
    geste:   { fr: 'Ce que tu peux faire', en: 'What you can do' },
    repere:  { fr: 'Repéré le', en: 'Reported on' },
    source:  { fr: 'Source', en: 'Source' },
    jusqua:  { fr: 'Valable jusqu’au', en: 'Valid until' },
    voir:    { fr: 'Voir les alertes en cours', en: 'See current alerts' },
    fermer:  { fr: 'Fermer', en: 'Close' },
    bandeau: { fr: 'Une alerte concerne ta région', en: 'An alert covers your region' },
    aucune:  { fr: 'Aucune alerte en cours pour ta région.', en: 'No current alert for your region.' },
    aucune_d:{ fr: 'Ça ne veut pas dire que tout est sûr — seulement que rien n’a été signalé et vérifié récemment. Ce qui circule change plus vite que ce qu’on peut en savoir.',
               en: 'That doesn’t mean everything is safe — only that nothing has been reported and verified recently. What circulates changes faster than anyone can track it.' }
  };
  function t(k) { return T[k][lang()] || T[k].fr; }

  /* Carte d'alerte. Structure fixe : ce qui circule → ce que ça change → le geste →
     la provenance. Aucune de ces quatre parties n'est optionnelle. */
  function html(a) {
    var entete = (a.format === 'vendu_comme' && a.reel && a.annonce)
      ? '<p class="alerte-fmt"><b>' + esc(a.reel) + '</b> ' + esc(t('vendu')) + ' <b>' + esc(a.annonce) + '</b></p>'
      : '';
    return '<article class="alerte">' +
      '<h3>' + esc(L(a, 'titre')) + '</h3>' +
      entete +
      '<p>' + esc(L(a, 'corps')) + '</p>' +
      '<div class="alerte-geste"><b>' + esc(t('geste')) + '</b><br>' + esc(L(a, 'geste')) + '</div>' +
      '<p class="alerte-src">' + esc(t('repere')) + ' ' + esc(dateLisible(a.date)) + ' · ' +
        esc(t('source')) + ' : <a href="' + esc(a.source_url) + '" target="_blank" rel="noopener">' +
        esc(a.source_nom) + '</a> · ' + esc(t('jusqua')) + ' ' + esc(dateLisible(a.perime_le)) +
      '</p>' +
      '</article>';
  }

  /* Liste complète — page dédiée. */
  function renderListe(cible, opts) {
    if (!cible) return 0;
    var list = actives(opts);
    if (!list.length) {
      cible.innerHTML = '<div class="alerte alerte-vide"><h3>' + esc(t('aucune')) + '</h3><p>' +
        esc(t('aucune_d')) + '</p></div>';
      return 0;
    }
    cible.innerHTML = list.map(html).join('');
    return list.length;
  }

  /* Encart en fiche substance — seulement les alertes qui concernent cette substance. */
  function renderFiche(cible, substance) {
    if (!cible) return 0;
    var list = actives({ substance: substance });
    if (!list.length) { cible.innerHTML = ''; return 0; }
    cible.innerHTML = list.map(html).join('');
    return list.length;
  }

  /* La mascotte porte l'alerte sur l'écran d'accueil, à la place d'un bandeau encadré.
     Motif (ch. 23) : l'intensité doit décrire une PROXIMITÉ, jamais une alarme. Quelqu'un
     qui te mentionne quelque chose est de la proximité ; un panneau bordé est de la
     signalétique institutionnelle.

     Deux garde-fous, parce que la mascotte ne doit pas devenir celle qui annonce les
     mauvaises nouvelles — la personne finirait par redouter sa bulle :
       · elle MENTIONNE, elle ne développe pas : une phrase, le détail est à un clic ;
       · elle donne le GESTE, pas seulement l'avertissement. C'est ce qui sépare un
         compagnon d'un crieur public.
     Humeur `clarification` : une alerte est un éclaircissement sur le marché, pas un
     drame. Aucune humeur d'inquiétude n'est utilisée ici. */
  var TM = {
    fr: 'Quelque chose circule en ce moment près de chez toi — {titre}. Deux minutes de lecture, avec ce que tu peux en faire.',
    en: 'Something is going around near you right now — {titre}. Two minutes to read, with what you can do about it.'
  };

  function mascotte() {
    var list = actives().filter(function (a) { return a.gravite === 'critique'; });
    if (!list.length) return null;
    /* Le titre est inséré tel quel. Une mise en minuscule automatique produirait « pMMA »
       ou « nitazènes » là où la molécule s'écrit PMMA — vu au rendu, invisible à la lecture
       du code. La phrase est donc construite pour accueillir une majuscule. */
    return {
      mood: 'clarification',
      text: (TM[lang()] || TM.fr).replace('{titre}', L(list[0], 'titre')),
      href: 'alertes.html',
      key: 'alerte-' + list[0].id,
      duration: 0
    };
  }

  /* Bandeau encadré — conservé pour les pages sans mascotte. Fermable, jamais rappelé
     dans la même page. Il annonce, il n'explique pas. */
  function renderBandeau(cible) {
    if (!cible || ferme) return 0;
    var list = actives().filter(function (a) { return a.gravite === 'critique'; });
    if (!list.length) return 0;
    var a = list[0];
    var box = document.createElement('div');
    box.className = 'alerte-bandeau';
    box.innerHTML =
      '<button type="button" class="alerte-x" aria-label="' + esc(t('fermer')) + '">×</button>' +
      '<p class="ab-h">' + esc(t('bandeau')) + '</p>' +
      '<p class="ab-t">' + esc(L(a, 'titre')) + '</p>' +
      '<p><a href="alertes.html">' + esc(t('voir')) + ' →</a></p>';
    box.querySelector('.alerte-x').addEventListener('click', function () {
      ferme = true;
      if (box.parentNode) box.parentNode.removeChild(box);
    });
    cible.appendChild(box);
    return list.length;
  }

  function compte() { return actives().length; }

  /* ---------------------------------------------------------------------------
     Actualités de fond. Ordre d'affichage imposé : ce qui change pour la personne
     AVANT la position du produit. Une prise de position qui passerait devant
     l'information pratique ferait de la personne l'instrument d'un combat — c'est
     exactement le registre que le champ reproche au militantisme (ASUD, ch. 40).
     --------------------------------------------------------------------------- */
  var TA = {
    change:   { fr: 'Ce que ça change pour toi', en: 'What this changes for you' },
    position: { fr: 'Ce qu’on en pense',         en: 'Where we stand' },
    sources:  { fr: 'Sources',                   en: 'Sources' }
  };

  function actus(opts) {
    opts = opts || {};
    var today = new Date().toISOString().slice(0, 10);
    var reg = opts.region || region();
    return (window.MD_ACTUS || []).filter(function (a) {
      if (!a || !a.perime_le || a.perime_le < today) return false;
      if (a.regions && reg && a.regions.indexOf(reg) === -1) return false;
      return true;
    }).sort(function (x, y) { return (y.date || '').localeCompare(x.date || ''); });
  }

  function htmlActu(a) {
    var src = (a.sources || []).map(function (s) {
      return '<a href="' + esc(s.url) + '" target="_blank" rel="noopener">' + esc(s.nom) + '</a>';
    }).join(' · ');
    return '<article class="actu">' +
      '<h3>' + esc(L(a, 'titre')) + '</h3>' +
      '<p>' + esc(L(a, 'corps')) + '</p>' +
      '<div class="actu-change"><b>' + esc(TA.change[lang()] || TA.change.fr) + '</b><br>' +
        esc(L(a, 'change')) + '</div>' +
      (L(a, 'position') ? '<div class="actu-pos"><b>' + esc(TA.position[lang()] || TA.position.fr) +
        '</b><br>' + esc(L(a, 'position')) + '</div>' : '') +
      '<p class="alerte-src">' + esc(dateLisible(a.date)) + ' · ' +
        esc(TA.sources[lang()] || TA.sources.fr) + ' : ' + src + '</p>' +
      '</article>';
  }

  function renderActus(cible) {
    if (!cible) return 0;
    var list = actus();
    cible.innerHTML = list.map(htmlActu).join('');
    return list.length;
  }

  /* ---------------------------------------------------------------------------
     Répertoire des structures. Le champ `type` gouverne l'affichage : orienter vers un
     observatoire de plaidoyer quelqu'un qui cherche un accueil est l'erreur que l'audit
     international a nommée. `plaidoyer` n'est donc jamais proposé comme lieu où aller.
     --------------------------------------------------------------------------- */
  var FAMILLES = {
    analyse:   { fr: 'Faire analyser un produit',        en: 'Get a substance tested' },
    festif:    { fr: 'En soirée, en festival',           en: 'At parties and festivals' },
    bas_seuil: { fr: 'Être accueilli sans condition',    en: 'Somewhere that takes you as you are' },
    pairs:     { fr: 'Parler à des personnes concernées', en: 'Talk to people who’ve been there' },
    soin:      { fr: 'Entrer dans un parcours de soin',  en: 'Start a care pathway' },
    info:      { fr: 'S’informer',                       en: 'Read up' },
    plaidoyer: { fr: 'Observer et documenter',           en: 'Monitoring and advocacy' }
  };
  var ORDRE_FAM = ['analyse', 'bas_seuil', 'festif', 'pairs', 'soin', 'info', 'plaidoyer'];

  function structures(opts) {
    opts = opts || {};
    var src = window.MD_ANNUAIRE || [];
    var reg = opts.region || region();
    return src.filter(function (o) {
      if (opts.type && o.type !== opts.type) return false;
      /* `pays: null` = structure internationale, pertinente partout. Une structure d'un
         autre pays n'est pas cachée : elle est simplement classée après les locales. */
      if (opts.locales && reg && o.pays && o.pays !== reg) return false;
      return true;
    }).sort(function (x, y) {
      var lx = (x.pays === reg) ? 0 : (x.pays ? 2 : 1);
      var ly = (y.pays === reg) ? 0 : (y.pays ? 2 : 1);
      return lx - ly;
    });
  }

  function htmlStructure(o) {
    var drapeau = o.pays ? '<span class="ann-pays">' + esc(o.pays) + '</span>' : '';
    return '<a class="ann-item" href="' + esc(o.url) + '" target="_blank" rel="noopener">' +
      '<span class="ann-nom">' + esc(o.nom) + '</span>' + drapeau +
      '<span class="ann-note">' + esc(L(o, 'note')) + '</span></a>';
  }

  function renderAnnuaire(cible) {
    if (!cible) return 0;
    var tout = structures(), n = 0, html = '';
    ORDRE_FAM.forEach(function (f) {
      var list = tout.filter(function (o) { return o.type === f; });
      if (!list.length) return;
      n += list.length;
      html += '<h2 class="ann-fam">' + esc(FAMILLES[f][lang()] || FAMILLES[f].fr) + '</h2>' +
              '<div class="ann-groupe">' + list.map(htmlStructure).join('') + '</div>';
    });
    cible.innerHTML = html;
    return n;
  }

  /* Auto-montage : toute page portant #alertes-fiche[data-substance] reçoit ses alertes,
     sans code spécifique par fiche. Ajouter une fiche = ajouter le conteneur, rien d'autre. */
  function auto() {
    var el = document.getElementById('alertes-fiche');
    if (el) renderFiche(el, el.getAttribute('data-substance'));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', auto);
  else auto();

  return {
    actives: actives, renderListe: renderListe, renderFiche: renderFiche,
    renderBandeau: renderBandeau, compte: compte,
    structures: structures, renderAnnuaire: renderAnnuaire, mascotte: mascotte,
    actus: actus, renderActus: renderActus
  };
})();
