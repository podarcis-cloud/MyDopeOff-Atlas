/* ============================================================================
   MyDope Off — regions.js
   COUCHE DE DONNÉES RÉGIONALISÉE (source unique).
   Régions : BE · FR · CH · CA(QC) · LU · DE · GB · NL · ES · PT · IT · MA · DZ · TN · US · AU · IE · SN · CI · CM · CD  (extension progressive).

   Contient, par région :
     emergency  : numéros d'urgence + lignes d'écoute/info (tel cliquables)
     centres    : structures de soin / RDR
     groupes    : groupes d'entraide
     testing    : services d'analyse de produit (drug-checking)
     naloxone   : accès à la naloxone (anti-overdose opioïde)
     legal      : statut légal (cannabis, autres drogues, conduite, bon samaritain)
     tips       : conseils locaux

   MULTILINGUE : les numéros/URL/labels sont neutres. Les CHAÎNES descriptives
   (desc, tips, legal.summary) restent en FR (source de vérité) et sont traduites
   via window.MD_RDR_I18N (voir rdr-i18n.js), comme l'architecture existante.

   ⚠️ DONNÉES LÉGALES vérifiées 2026-06 — ELLES CHANGENT. Chaque bloc `legal`
   porte `verifie_le`. À revérifier au moins 1×/an. Information éducative,
   ne remplace pas un conseil juridique.
   Sources légales : EUDA/EMCDDA, lois nationales, panoramas 2026 (cannabis).
   ============================================================================ */
(function (global) {
  'use strict';

  // Enum de statut (l'UI peut colorer/traduire) :
  // 'illegal' | 'decriminalise' | 'tolere' | 'legal' | 'medical'
  var LEGAL = { ILLEGAL:'illegal', DECRIM:'decriminalise', TOLERE:'tolere', LEGAL:'legal', MEDICAL:'medical' };

  var REGIONS = {

    BE: {
      code:'BE', label:'Belgique', flag:'', lang:'fr', emergencyMain:'112',
      emergency:[
        { name:'Urgences médicales', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre Antipoisons', tel:'070 245 245', desc:'Overdose, intoxication — 24h/24', kind:'poison' },
        { name:'Télé-Accueil', tel:'107', desc:'Écoute psychologique gratuite — 24h/24', kind:'ecoute' },
        { name:'Drogues Info (Infor-Drogues)', tel:'02 227 52 52', desc:'Info, aide, orientation — anonyme', kind:'drogue' },
        { name:'Centre de Prévention du Suicide', tel:'0800 32 123', desc:'Crise suicidaire — 24h/24', kind:'suicide' }
      ],
      centres:[
        { name:'Modus Vivendi', desc:'Testing & RDR festif — Bruxelles', url:'modusvivendi-be.org' },
        { name:'Projet Lama', desc:'Addictions & santé mentale, sans liste d\u2019attente — BXL', url:'projetlama.be' },
        { name:'MASS Bruxelles', desc:'Maison d\u2019Accueil Socio-Sanitaire', url:'mass-bxl.be' },
        { name:'CAP Fly / Citadelle', desc:'Ambulatoire assuétudes — Liège', url:'' },
        { name:'Free Clinic', desc:'Consultations bas seuil — Anvers/BXL', url:'freeclinic.be' }
      ],
      groupes:[
        { name:'Narcotiques Anonymes', url:'na.org/fr', desc:'Réunions hebdomadaires' },
        { name:'Alcooliques Anonymes BE', url:'aa-fr.be', desc:'Partout en Belgique' },
        { name:'SMART Recovery', url:'smartrecovery.org', desc:'Approche cognitivo-comportementale' }
      ],
      testing:[ { name:'Modus Vivendi', desc:'Analyse de substances gratuite et confidentielle', url:'modusvivendi-be.org' } ],
      naloxone:{ access:'Sans ordonnance dans de nombreuses pharmacies ; kits via services RDR.', form:'Narcan nasal / Prenoxad injection' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Possession ≤ 3 g (adulte) : tolérance/priorité basse, amende possible. Pas de vente légale.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales. Salles de consommation à moindre risque limitées.' },
        conduite:'Test salivaire au volant ; tolérance zéro pour les stupéfiants.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée, mais la non-assistance à personne en danger est punissable : appeler les secours protège.'
      },
      tips:[
        'La consultation chez le généraliste (DMG) facilite l\u2019accès remboursé à l\u2019addictologie.',
        'Naloxone (Narcan) disponible sans ordonnance dans beaucoup de pharmacies.',
        'Modus Vivendi propose du testing gratuit et confidentiel.'
      ]
    },

    FR: {
      code:'FR', label:'France', flag:'', lang:'fr', emergencyMain:'15',
      emergency:[
        { name:'SAMU', tel:'15', desc:'Urgences médicales', kind:'urgence' },
        { name:'Urgences (UE)', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre Antipoison', tel:'01 40 05 48 48', desc:'Intoxication, overdose', kind:'poison' },
        { name:'Drogues Info Service', tel:'0800 23 13 13', desc:'Gratuit, anonyme — 7j/7', kind:'drogue' },
        { name:'Alcool Info Service', tel:'0980 980 930', desc:'Accompagnement alcool', kind:'drogue' },
        { name:'Num. National Prévention Suicide', tel:'3114', desc:'24h/24, gratuit', kind:'suicide' }
      ],
      centres:[
        { name:'CSAPA', desc:'Soin, accompagnement, prévention en addictologie', url:'federationaddictions.fr' },
        { name:'CAARUD', desc:'Accueil & réduction des risques', url:'federationaddictions.fr' },
        { name:'Techno+', desc:'RDR & testing en milieu festif', url:'technoplus.org' },
        { name:'Fédération Addictions', desc:'Annuaire de professionnels', url:'federationaddictions.fr' }
      ],
      groupes:[
        { name:'NA France', url:'narcotiques-anonymes.fr', desc:'Narcotiques Anonymes' },
        { name:'AA France', url:'alcooliques-anonymes.fr', desc:'Alcooliques Anonymes' },
        { name:'Al-Anon France', url:'al-anon-alateen.fr', desc:'Pour les proches' }
      ],
      testing:[ { name:'Techno+ / CAARUD', desc:'Analyse de produit (festivals, permanences)', url:'technoplus.org' } ],
      naloxone:{ access:'Disponible (Nalscue/Prenoxad) ; kits via CAARUD et médecins.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal. Usage = amende forfaitaire délictuelle 200 €. Cannabis médical : cadre restreint.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Stupéfiants illégaux. Quelques dispositifs RDR (salles de consommation expérimentales).' },
        conduite:'Test salivaire ; tolérance zéro : tout dépistage positif est une infraction.',
        bonSamaritain:'Pas de loi « bon samaritain » drogue dédiée ; la non-assistance à personne en danger est un délit : appeler le 15/112 est protégé dans son principe.'
      },
      tips:[
        'Mon Soutien Psy : séances de psychologue remboursées sur prescription.',
        'Le médecin généraliste peut prescrire méthadone ou buprénorphine.',
        'Drogues Info Service : 0 800 23 13 13, gratuit et anonyme.'
      ]
    },

    CH: {
      code:'CH', label:'Suisse', flag:'', lang:'fr', emergencyMain:'144',
      emergency:[
        { name:'Urgences médicales', tel:'144', desc:'Ambulance', kind:'urgence' },
        { name:'Tox Info Suisse', tel:'145', desc:'Intoxications — 24h/24', kind:'poison' },
        { name:'La Main Tendue', tel:'143', desc:'Écoute psychologique — 24h/24', kind:'ecoute' },
        { name:'Pro Juventute', tel:'147', desc:'Aide aux jeunes', kind:'ecoute' }
      ],
      centres:[
        { name:'Fondation Phénix', desc:'Traitement ambulatoire — Genève', url:'phenix.ch' },
        { name:'ARUD', desc:'Traitement des dépendances — Zurich', url:'arud.ch' },
        { name:'Addiction Suisse', desc:'Prévention & information nationale', url:'addictionsuisse.ch' }
      ],
      groupes:[
        { name:'NA Suisse Romande', url:'na.org/fr', desc:'Narcotiques Anonymes' },
        { name:'AA Suisse', url:'aasri.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'DIZ / Nuit blanche ? / Saferparty', desc:'Drug-checking (Zurich, Berne, Genève…)', url:'saferparty.ch' } ],
      naloxone:{ access:'Disponible en pharmacie ; programmes take-home.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Possession ≤ 10 g décriminalisée (amende d\u2019ordre). Projets pilotes de vente légale encadrée à Bâle, Berne, Genève, Zurich. Médical sur ordonnance.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales. Salles de consommation légales (Berne, Bâle, Zurich, Genève).' },
        conduite:'Test salivaire ; tolérance zéro pour les stupéfiants au volant.',
        bonSamaritain:'Devoir d\u2019assistance ; appeler les secours est attendu et protégé dans son principe.'
      },
      tips:[
        'La LAMal couvre les soins en addictologie.',
        'Salles de consommation à moindre risque dans plusieurs villes.',
        'Drug-checking disponible (Saferparty, DIZ).'
      ]
    },

    CA: {
      code:'CA', label:'Canada (QC)', flag:'', lang:'fr', emergencyMain:'911',
      emergency:[
        { name:'Urgences', tel:'911', desc:'Toutes urgences', kind:'urgence' },
        { name:'Centre antipoison du Québec', tel:'1 800 463-5060', desc:'Intoxications — 24h/24', kind:'poison' },
        { name:'Drogue : aide et référence', tel:'1 800 265-2626', desc:'Gratuit — 24h/24', kind:'drogue' },
        { name:'Ligne prévention du suicide', tel:'1 866 277-3553', desc:'1 866 APPELLE — 24h/24', kind:'suicide' }
      ],
      centres:[
        { name:'GRIP Montréal', desc:'RDR & analyse de substances', url:'gripmontreal.org' },
        { name:'CRAN', desc:'Réadaptation en dépendances — Montréal', url:'cran.qc.ca' },
        { name:'Portage', desc:'Résidentiel & communautaire', url:'portage.ca' }
      ],
      groupes:[
        { name:'NA Québec', url:'naquebec.org', desc:'Narcotiques Anonymes' },
        { name:'AA Montréal', url:'aa-quebec.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'GRIP Montréal', desc:'Analyse de substances (bandelettes fentanyl, spectro)', url:'gripmontreal.org' } ],
      naloxone:{ access:'Gratuite en pharmacie (carte RAMQ) ; trousses take-home.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.LEGAL, summary:'Légal (récréatif) — 21 ans au Québec. Achat via SQDC. Possession publique ≤ 30 g.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales (essais de décriminalisation hors QC).' },
        conduite:'Tolérance très basse ; dépistage salivaire au volant.',
        bonSamaritain:'Loi sur les bons samaritains secourant les victimes de surdose : protège de poursuites pour simple possession quand on appelle le 911.'
      },
      tips:[
        'Naloxone gratuite en pharmacie sur présentation de la carte RAMQ.',
        'GRIP Montréal : analyse de substances et bandelettes fentanyl.',
        'Les CLSC offrent des services en dépendances.'
      ]
    },

    LU: {
      code:'LU', label:'Luxembourg', flag:'', lang:'fr', emergencyMain:'112',
      emergency:[
        { name:'Urgences', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'SOS Détresse', tel:'45 45 45', desc:'Écoute psychologique — 24h/24', kind:'ecoute' }
      ],
      centres:[
        { name:'JDH', desc:'Jugend- an Drogenhëllef — Luxembourg-Ville', url:'jdh.lu' },
        { name:'Abrigado', desc:'Centre de jour / drop-in & salle de consommation', url:'jdh.lu' },
        { name:'CePT', desc:'Prévention des toxicomanies', url:'cept.lu' }
      ],
      groupes:[ { name:'NA Luxembourg', url:'na.org', desc:'Narcotiques Anonymes' } ],
      testing:[ { name:'CePT / JDH', desc:'Information & orientation RDR', url:'cept.lu' } ],
      naloxone:{ access:'Programmes take-home via services spécialisés.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.TOLERE, summary:'Possession ≤ 3 g tolérée (amende réduite) ; culture jusqu\u2019à 4 plants/foyer en privé. Pas de vente ni de clubs.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales ; dispositifs RDR (Abrigado).' },
        conduite:'Test salivaire ; tolérance zéro au volant.',
        bonSamaritain:'Devoir de porter secours ; appeler le 112 est attendu et protégé dans son principe.'
      },
      tips:[
        'La CNS rembourse les soins en addictologie.',
        'JDH : consultation anonyme sans rendez-vous ; Abrigado pour la RDR.'
      ]
    },

    DE: {
      code:'DE', label:'Allemagne', flag:'', lang:'de', emergencyMain:'112',
      emergency:[
        { name:'Urgences (Notruf)', tel:'112', desc:'Toutes urgences médicales', kind:'urgence' },
        { name:'Sucht & Drogen Hotline', tel:'01806 313031', desc:'Écoute & orientation addiction (BIÖG)', kind:'drogue' },
        { name:'Telefonseelsorge', tel:'0800 111 0111', desc:'Écoute psychologique — 24h/24, gratuit', kind:'ecoute' },
        { name:'Giftnotruf Berlin', tel:'030 19240', desc:'Intoxication, overdose', kind:'poison' }
      ],
      centres:[
        { name:'Drogennotdienst Berlin', desc:'Aide bas seuil, conseil, sur place/chat/tél', url:'drogennotdienst.de' },
        { name:'Salles de consommation', desc:'Localisation des Drogenkonsumräume en Allemagne', url:'drogenkonsumraum.net' },
        { name:'DHS', desc:'Annuaire national des services addiction', url:'dhs.de' }
      ],
      groupes:[
        { name:'Narcotics Anonymous DE', url:'narcotics-anonymous.de', desc:'Réunions dans tout le pays' },
        { name:'Anonyme Alkoholiker', url:'anonyme-alkoholiker.de', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Drug-checking (Berlin, Thuringe…)', desc:'Programmes régionaux ; couverture variable selon le Land', url:'drugchecking.berlin' } ],
      naloxone:{ access:'Programmes take-home (Berlin, Rhénanie-du-Nord-Westphalie, Bavière, Sarre) via services spécialisés.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.LEGAL, summary:'Légalisé (loi CanG, avril 2024) : possession privée jusqu\u2019\u00e0 50 g, 3 plants, clubs de culture associatifs (Anbauvereinigungen). Pas de vente commerciale libre.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres drogues illégales (BtMG). Salles de consommation légales dans plusieurs Länder.' },
        conduite:'Seuil THC de 3,5 ng/mL au volant ; alcool et stupéfiants dépistés. Sanctions en cas de dépassement.',
        bonSamaritain:'Devoir d\u2019assistance (Unterlassene Hilfeleistung, §323c) : appeler le 112 est attendu et protégé dans son principe.'
      },
      tips:[
        'La plupart des Länder remboursent les soins addiction via l\u2019assurance maladie.',
        'drogenkonsumraum.net recense les salles de consommation à moindre risque.',
        'La naloxone take-home se développe : renseigne-toi auprès des services locaux.'
      ]
    },

    NL: {
      code:'NL', label:'Pays-Bas', flag:'', lang:'en', emergencyMain:'112',
      emergency:[
        { name:'Urgences (Alarmnummer)', tel:'112', desc:'Toutes urgences médicales', kind:'urgence' },
        { name:'Jellinek (ligne info)', tel:'088 505 1220', desc:'Info & conseil alcool/drogues', kind:'drogue' },
        { name:'113 Zelfmoordpreventie', tel:'113', desc:'Prévention du suicide — 24h/24', kind:'suicide' }
      ],
      centres:[
        { name:'Jellinek', desc:'Soin addiction & prévention (Amsterdam et région)', url:'jellinek.nl' },
        { name:'Unity', desc:'RDR en milieu festif, pair-à-pair', url:'unity.nl' },
        { name:'Brijder / Trimbos', desc:'Soin addiction & institut national', url:'trimbos.nl' }
      ],
      groupes:[
        { name:'NA Nederland', url:'na-holland.nl', desc:'Narcotiques Anonymes' },
        { name:'AA Nederland', url:'aa-nederland.nl', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'DIMS (réseau national)', desc:'Analyse de produit anonyme, ~30 points (Jellinek, GGD). Gratuit hors Amsterdam.', url:'jellinek.nl' } ],
      naloxone:{ access:'Disponible via services spécialisés et certains médecins.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.TOLERE, summary:'Techniquement illégal mais toléré (gedoogbeleid) : vente en coffeeshop et possession \u2264 5 g non poursuivies. Expérience publique de filière légale en cours.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'« Drogues dures » illégales ; l\u2019usage n\u2019est pas poursuivi. RDR et drug-checking bien établis.' },
        conduite:'Seuils légaux par substance ; dépistage salivaire/sanguin. Ne pas conduire après usage.',
        bonSamaritain:'Aux urgences, les médecins ne préviennent pas la police : sois honnête sur ce que tu as pris pour être bien soigné·e.'
      },
      tips:[
        'La puissance des produits achetés sur place peut être bien plus élevée qu\u2019ailleurs : commence bas.',
        'Le drug-checking DIMS est anonyme et sans poursuites.',
        'Ignore les vendeurs de rue : produits souvent faux ou dangereux.'
      ]
    },

    GB: {
      code:'GB', label:'Royaume-Uni', flag:'', lang:'en', emergencyMain:'999',
      emergency:[
        { name:'Urgences', tel:'999', desc:'Toutes urgences (ambulance)', kind:'urgence' },
        { name:'NHS 111', tel:'111', desc:'Conseil santé non vital — 24h/24', kind:'urgence' },
        { name:'Talk to FRANK', tel:'0300 123 6600', desc:'Conseil drogues confidentiel — 24h/24', kind:'drogue' },
        { name:'Release', tel:'020 7324 2989', desc:'Conseil spécialisé drogues & droit', kind:'drogue' },
        { name:'Samaritans', tel:'116 123', desc:'Écoute, détresse — 24h/24', kind:'ecoute' }
      ],
      centres:[
        { name:'Talk to FRANK', desc:'Info drogues & annuaire de services locaux', url:'talktofrank.com' },
        { name:'Release', desc:'Conseil confidentiel drogues & loi', url:'release.org.uk' },
        { name:'With You / Turning Point', desc:'Services de soin addiction locaux', url:'wearewithyou.org.uk' }
      ],
      groupes:[
        { name:'UK Narcotics Anonymous', url:'ukna.org', desc:'Narcotiques Anonymes' },
        { name:'Alcoholics Anonymous GB', url:'alcoholics-anonymous.org.uk', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Drug-checking (festivals) & test strips', desc:'Bandelettes fentanyl/nitazènes/xylazine via services RDR (ex. Release Hub, Londres). Couverture limitée.', url:'release.org.uk' } ],
      naloxone:{ access:'Fournie sans ordonnance par les services drogues et de nombreuses pharmacies.', form:'Spray nasal (Nyxoid) / Prenoxad injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (Classe B, Misuse of Drugs Act 1971). Cannabis médical sur prescription spécialiste, accès très restreint.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Stupéfiants illégaux (classes A/B/C). Pas de salle de consommation officielle en Angleterre ; une existe à Glasgow (Écosse).' },
        conduite:'Seuils légaux par substance ; dépistage salivaire. Conduire sous influence est une infraction.',
        bonSamaritain:'Pas de loi « bon samaritain » drogue dédiée ; appelle le 999 sans hésiter en cas d\u2019overdose.'
      },
      tips:[
        'Naloxone gratuite dans les services drogues : garde-en si tu es concerné·e par les opioïdes.',
        'Opioïdes de synthèse (nitazènes) en hausse : les test strips peuvent aider.',
        'Talk to FRANK oriente vers les services de ta région.'
      ]
    },

    ES: {
      code:'ES', label:'Espagne', flag:'', lang:'es', emergencyMain:'112',
      emergency:[
        { name:'Urgences', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Energy Control (info)', tel:'', desc:'Info & réduction des risques (contact via site)', kind:'drogue' },
        { name:'Teléfono de la Esperanza', tel:'717 003 717', desc:'Écoute psychologique — 24h/24', kind:'ecoute' }
      ],
      centres:[
        { name:'Energy Control / ABD', desc:'RDR, info & analyse de produit — Barcelone, Madrid, Baléares', url:'energycontrol.org' },
        { name:'Cruz Roja / Médecins du monde', desc:'Programmes bas seuil selon région', url:'' },
        { name:'Plan Nacional sobre Drogas', desc:'Annuaire officiel des services par région', url:'pnsd.sanidad.gob.es' }
      ],
      groupes:[
        { name:'Narcóticos Anónimos España', url:'na-esp.org', desc:'Narcotiques Anonymes' },
        { name:'Alcohólicos Anónimos España', url:'alcoholicos-anonimos.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Energy Control', desc:'Analyse de produit (sur place festivals + envoi postal + service international)', url:'energycontrol.org' } ],
      naloxone:{ access:'Disponible via centres spécialisés et hôpitaux ; formulation injectable la plus courante.', form:'Injectable (spray nasal moins répandu)' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.TOLERE, summary:'Usage et culture privés tolérés (non poursuivis en espace privé) ; usage/possession en lieu public reste une infraction administrative (amende). Clubs cannabiques dans une zone grise juridique.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Consommation en public sanctionnée administrativement (loi sur la sécurité citoyenne) ; trafic pénalement poursuivi.' },
        conduite:'Dépistage salivaire pour stupéfiants ; tolérance zéro de fait pour la plupart des substances.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée ; appelle le 112 sans hésiter en cas d\u2019overdose.'
      },
      tips:[
        'Energy Control propose un service d\u2019analyse même par courrier, y compris pour les non-résidents.',
        'La consommation en lieu public expose à une amende administrative, même si l\u2019usage privé est toléré.',
        'Les centres de RDR varient beaucoup selon la région (compétence transférée aux communautés autonomes).'
      ]
    },

    PT: {
      code:'PT', label:'Portugal', flag:'', lang:'en', emergencyMain:'112',
      emergency:[
        { name:'Urgências', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Linha VIDA — SOS Droga', tel:'1414', desc:'Info, écoute, orientation — lun-ven 10h-20h', kind:'drogue' },
        { name:'Narcóticos Anónimos', tel:'800 202 013', desc:'Ligne d\u2019entraide', kind:'drogue' }
      ],
      centres:[
        { name:'SICAD', desc:'Service public national — pilotage des politiques addictions', url:'sicad.pt' },
        { name:'CDT (Comissão de Dissuasão)', desc:'Commission de dissuasion — 1 par district, orientation plutôt que sanction pénale', url:'sicad.pt' },
        { name:'CAD (Centros de Atendimento)', desc:'Centres de soin et d\u2019accompagnement addictions', url:'sicad.pt' }
      ],
      groupes:[
        { name:'Narcóticos Anónimos PT', url:'na.org.pt', desc:'Narcotiques Anonymes' },
        { name:'Famílias Anónimas', desc:'Soutien aux proches', url:'' }
      ],
      testing:[ { name:'Check!n (festivals)', desc:'Analyse de produit en milieu festif, programme historique cofinancé par l\u2019État', url:'' } ],
      naloxone:{ access:'Disponible via CAD et pharmacies participantes ; formulation injectable la plus répandue.', form:'Injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Toutes drogues décriminalisées pour usage personnel (Loi 30/2000) : possession \u2264 10 jours de consommation moyenne = infraction administrative, pas pénale. Orientation vers une CDT, pas un tribunal.' },
        autres:{ status:LEGAL.DECRIM, summary:'Même cadre que le cannabis : usage personnel décriminalisé, trafic reste pénalement poursuivi.' },
        conduite:'Dépistage salivaire pour stupéfiants ; pas de seuil légal, toute trace détectée est sanctionnée.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée ; le cadre de décriminalisation encourage à appeler le 112 sans crainte de poursuite pour usage personnel.'
      },
      tips:[
        'La décriminalisation ne veut pas dire légal : la police confisque et oriente vers une CDT, qui privilégie l\u2019accompagnement.',
        'Linha VIDA (1414) est gratuite, anonyme et confidentielle.',
        'Le trafic reste pénalement poursuivi, même si l\u2019usage personnel ne l\u2019est pas.'
      ]
    },

    IT: {
      code:'IT', label:'Italie', flag:'', lang:'en', emergencyMain:'112',
      emergency:[
        { name:'Emergenza unica', tel:'112', desc:'Toutes urgences', kind:'urgence' },
        { name:'Telefono Verde Droga (ISS)', tel:'800 186070', desc:'Info & orientation officielle — lun-ven 10h-16h', kind:'drogue' }
      ],
      centres:[
        { name:'Ser.D (Servizi per le Dipendenze)', desc:'Réseau public territorial de soin des addictions', url:'' },
        { name:'Istituto Superiore di Sanità', desc:'Référence nationale, alertes sur nouvelles substances', url:'iss.it' }
      ],
      groupes:[
        { name:'Narcotici Anonimi Italia', url:'na-italia.it', desc:'Narcotiques Anonymes' },
        { name:'Alcolisti Anonimi Italia', url:'alcolisti-anonimi.it', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Services locaux limités', desc:'Le drug-checking existe ponctuellement (associations locales, festivals) mais n\u2019est pas généralisé comme en Espagne/Pays-Bas.', url:'' } ],
      naloxone:{ access:'Disponible sans ordonnance en pharmacie (statut OTC).', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.DECRIM, summary:'Possession pour usage personnel décriminalisée (sanctions administratives : suspension permis/papiers, orientation soins) ; vente et culture restent pénalement poursuivies. Le « cannabis light » (CBD/chanvre) a été reclassé stupéfiant en 2025 : à éviter totalement.' },
        autres:{ status:LEGAL.DECRIM, summary:'Même logique que le cannabis pour l\u2019usage personnel (DPR 309/1990) ; le trafic reste sévèrement puni (6 à 20 ans).' },
        conduite:'Tolérance zéro : toute trace détectée de stupéfiant au volant est une infraction, sans seuil.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée ; appelle le 112 en cas d\u2019urgence.'
      },
      tips:[
        'Le CBD/chanvre est désormais classé stupéfiant : n\u2019en transporte pas, même légal ailleurs.',
        'La frontière entre usage personnel et trafic est floue et laissée à l\u2019appréciation policière — reste prudent·e sur les quantités.',
        'La naloxone est en vente libre en pharmacie : simple à te procurer si concerné·e.'
      ]
    },

    MA: {
      code:'MA', label:'Maroc', flag:'', lang:'fr', emergencyMain:'19',
      emergency:[
        { name:'Police (zones urbaines)', tel:'19', desc:'Aussi joignable au 112 depuis un portable', kind:'urgence' },
        { name:'Gendarmerie Royale', tel:'177', desc:'Zones rurales et autoroutes', kind:'urgence' },
        { name:'Protection civile / SAMU', tel:'15', desc:'Pompiers, ambulance (150 depuis un portable)', kind:'urgence' },
        { name:'Allo SAMU / soutien psychologique', tel:'141', desc:'Détresse psychologique, prévention suicide — 24h/24', kind:'ecoute' },
        { name:'Centre Antipoison et de Pharmacovigilance', tel:'0801 000 180', desc:'Intoxication, overdose — 24h/24', kind:'poison' }
      ],
      centres:[
        { name:'Centre National de Prévention et de Recherche en Toxicomanie', desc:'Référence nationale (Pr. Jallal Toufiq), Casablanca', url:'' },
        { name:'Hôpitaux publics (services psychiatrie/addictologie)', desc:'Prise en charge selon les CHU des grandes villes', url:'' }
      ],
      groupes:[ { name:'Narcotiques Anonymes Maroc', url:'na-maroc.org', desc:'Réunions dans les grandes villes' } ],
      testing:[],
      naloxone:{ access:'Aucune information fiable de programme national de naloxone à large échelle trouvée ; disponibilité en pharmacie non confirmée.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Usage récréatif illégal (Dahir n\u00b0 1-73-282, 1974) : 2 mois à 1 an de prison + amende. Depuis 2021 (loi 13-21), un cadre légal existe pour la culture/production à des fins médicales, pharmaceutiques et industrielles — l\u2019usage personnel récréatif reste, lui, pénalement sanctionné.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Autres stupéfiants strictement illégaux, poursuites pénales.' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée ; le cadre reste répressif — cette réalité doit être connue avant d\u2019appeler les secours en cas de consommation.'
      },
      tips:[
        'Le cadre légal reste répressif pour l\u2019usage personnel, y compris pour le cannabis, malgré la loi 2021 sur la production licite.',
        'En cas d\u2019urgence vitale, la priorité reste d\u2019appeler les secours (15/150/141) malgré le contexte légal.',
        'Les services de réduction des risques dédiés (testing, naloxone) ne sont pas documentés de façon fiable au Maroc à ce jour.'
      ]
    },

    DZ: {
      code:'DZ', label:'Algérie', flag:'', lang:'fr', emergencyMain:'14',
      emergency:[
        { name:'Protection civile (pompiers, ambulance)', tel:'14', desc:'Aussi 1021 selon zone', kind:'urgence' },
        { name:'Police nationale', tel:'17', desc:'Aussi 1548 selon zone', kind:'urgence' },
        { name:'Gendarmerie nationale', tel:'1055', desc:'Zones rurales', kind:'urgence' },
        { name:'Centre antipoison (Alger)', tel:'021 97 98 98', desc:'Intoxication, overdose', kind:'poison' }
      ],
      centres:[
        { name:'ONLCDT', desc:'Office National de Lutte Contre la Drogue et la Toxicomanie — référence institutionnelle', url:'onlcdt.mjustice.gov.dz' },
        { name:'Centre de Bouchaoui (Alger)', desc:'Prise en charge jeunes consommateurs cannabis/drogues douces, méthode sans traitement chimique', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucune information fiable de programme national de naloxone trouvée.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (Loi 04-18). Usage personnel sanctionné pénalement ; trafic sévèrement puni.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Tous stupéfiants illégaux ; cadre pénal strict, forte priorité sécuritaire (saisies massives rapportées par l\u2019ONLCDT).' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée.'
      },
      tips:[
        'Le cadre légal est strictement répressif ; la prise en charge sanitaire (hors urgence vitale) passe surtout par les structures hospitalières publiques.',
        'L\u2019ONLCDT est la référence officielle, mais la réduction des risques (testing, naloxone) n\u2019est pas documentée à l\u2019échelle nationale.',
        'En cas d\u2019urgence vitale (overdose), la priorité reste d\u2019appeler le 14, quel que soit le contexte légal.'
      ]
    },

    TN: {
      code:'TN', label:'Tunisie', flag:'', lang:'fr', emergencyMain:'190',
      emergency:[
        { name:'SAMU (secours médicaux)', tel:'190', desc:'Numéro national unique', kind:'urgence' },
        { name:'Police secours', tel:'197', desc:'Numéro national unique', kind:'urgence' },
        { name:'Protection civile', tel:'198', desc:'Pompiers, secours', kind:'urgence' },
        { name:'Garde nationale', tel:'193', desc:'Zones rurales', kind:'urgence' }
      ],
      centres:[
        { name:'ATUPRET', desc:'Association tunisienne de prévention contre la toxicomanie — centre d\u2019accueil jeunes, Tunis', url:'' },
        { name:'Centre « Aide et Écoute » (Sfax)', desc:'Service résidentiel de sevrage, capacité limitée', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucune information fiable de disponibilité en pharmacie ou de programme national trouvée.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (Loi 92-52, dite « loi 52 ») : peines pouvant aller jusqu\u2019à 5 ans de prison, y compris pour un premier usage. Réforme allégeant les peines débattue depuis des années mais jamais pleinement adoptée.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Même loi 52, cadre extrêmement répressif pour l\u2019ensemble des stupéfiants ; pas de circonstances atténuantes prévues par le texte.' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée ; la loi 52 est reconnue, y compris par des associations locales, comme dissuadant de demander de l\u2019aide.'
      },
      tips:[
        'La loi 52 prévoit des peines parmi les plus sévères de la région pour le simple usage — c\u2019est un facteur reconnu de non-recours aux soins.',
        'Les structures de prise en charge existent mais restent rares et à capacité limitée (ex. Sfax).',
        'En cas d\u2019urgence vitale, la priorité reste d\u2019appeler le 190, quel que soit le contexte légal.'
      ]
    },

    US: {
      code:'US', label:'États-Unis', flag:'', lang:'en', emergencyMain:'911',
      emergency:[
        { name:'Urgences', tel:'911', desc:'Toutes urgences', kind:'urgence' },
        { name:'988 Suicide & Crisis Lifeline', tel:'988', desc:'Détresse psy, suicide, aussi pour les questions de conso — 24h/24', kind:'ecoute' },
        { name:'SAMHSA National Helpline', tel:'1-800-662-4357', desc:'Orientation traitement, gratuit et confidentiel — 24h/24 (FR/EN)', kind:'drogue' }
      ],
      centres:[
        { name:'SAMHSA / FindTreatment.gov', desc:'Annuaire national officiel des structures de soin addiction', url:'findtreatment.gov' },
        { name:'Services locaux', desc:'La réduction des risques (testing, seringues, salles de conso) varie énormément d\u2019un État à l\u2019autre', url:'' }
      ],
      groupes:[
        { name:'Narcotics Anonymous USA', url:'na.org', desc:'Narcotiques Anonymes' },
        { name:'Alcoholics Anonymous USA', url:'aa.org', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Bandelettes fentanyl/xylazine', desc:'Légales dans la plupart des États ; depuis avril 2026 les fonds fédéraux ne financent plus leur distribution publique (coupe SAMHSA), mais des programmes d\u2019État/locaux continuent.', url:'' } ],
      naloxone:{ access:'Narcan en vente libre (sans ordonnance) dans la plupart des pharmacies, dans tout le pays.', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal au niveau fédéral (stupéfiant de l\u2019annexe I), mais légal à usage récréatif dans une vingtaine d\u2019États + DC, et médical dans bien plus. Une procédure de reclassement fédéral est en cours (2026) sans être aboutie. Vérifie systématiquement la loi de l\u2019État où tu te trouves.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Illégal au niveau fédéral ; l\u2019application et les peines varient énormément selon l\u2019État (certains ont dépénalisé la possession personnelle, la plupart non).' },
        conduite:'Seuil d\u2019alcoolémie 0,08 % dans 49 États + DC, 0,05 % dans l\u2019Utah ; tolérance zéro pour les moins de 21 ans. Pas de seuil fédéral unique pour le cannabis/drogues au volant — certains États ont un seuil THC (ex. 5 ng/mL), d\u2019autres une approche « basée sur l\u2019effet » : ça varie fortement en traversant les frontières d\u2019État.',
        bonSamaritain:'Des lois « bon samaritain » existent dans la plupart des États (protection partielle contre des poursuites pour possession si tu appelles à l\u2019aide lors d\u2019une overdose), mais pas dans tous — et leur portée varie.'
      },
      tips:[
        'Le cadre légal change littéralement en traversant une frontière d\u2019État : ce qui est légal quelque part peut être un délit ailleurs.',
        'Le 988 couvre aussi les questions de consommation, pas seulement le risque suicidaire — n\u2019hésite pas à l\u2019utiliser.',
        'Les bandelettes de détection restent légales à posséder et utiliser presque partout, même si leur distribution publique a perdu son financement fédéral en 2026.'
      ]
    },

    AU: {
      code:'AU', label:'Australie', flag:'', lang:'en', emergencyMain:'000',
      emergency:[
        { name:'Urgences (Triple Zero)', tel:'000', desc:'Toutes urgences', kind:'urgence' },
        { name:'National Alcohol and Other Drugs Hotline', tel:'1800 250 015', desc:'Info, écoute, orientation — ADIS, 24h/24', kind:'drogue' }
      ],
      centres:[
        { name:'Alcohol and Drug Foundation', desc:'Référence nationale, info RDR', url:'adf.org.au' },
        { name:'Services de santé de l\u2019État', desc:'Programmes d\u2019échange de seringues, naloxone à emporter — l\u2019offre varie selon l\u2019État/territoire', url:'' }
      ],
      groupes:[
        { name:'Narcotics Anonymous Australia', url:'na.org.au', desc:'Narcotiques Anonymes' },
        { name:'Alcoholics Anonymous Australia', url:'aa.org.au', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Pill testing (Victoria + festivals)', desc:'Service fixe à Victoria (essai jusqu\u2019à mi-2026) + antennes mobiles dans plusieurs festivals ; couverture encore limitée et inégale selon l\u2019État.', url:'' } ],
      naloxone:{ access:'Gratuite via les programmes « take-home » en Nouvelle-Galles du Sud, Australie-Méridionale et Australie-Occidentale ; frais modique ailleurs. Aussi disponible gratuitement dans les programmes d\u2019échange de seringues (VIC, NSW, SA, TAS, WA).', form:'Spray nasal / injectable' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal dans la plupart des juridictions. Le Territoire de la Capitale (ACT) a décriminalisé l\u2019usage personnel depuis 2020 (\u2264 50 g, 2 plants) — ce n\u2019est pas une légalisation, et ça ne change rien à la conduite (voir ci-dessous).' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Toutes drogues illégales ; l\u2019application varie selon l\u2019État (cautions/déviation possibles pour petites quantités dans certains, comme NSW).' },
        conduite:'Alcool : 0,05 g/100mL pour permis complet, 0,00 pour apprenti/probatoire, partout dans le pays. Stupéfiants : tolérance zéro nationale — toute trace détectée au dépistage salivaire est une infraction, y compris pour le cannabis en ACT malgré la décriminalisation de la possession.',
        bonSamaritain:'Pas de loi « bon samaritain » dédiée ; les ambulanciers ne sont pas là pour signaler l\u2019usage à la police — appelle le 000 sans hésiter en cas d\u2019urgence.'
      },
      tips:[
        'Décriminalisé ne veut pas dire « ok pour conduire » : la tolérance zéro au volant s\u2019applique même là où la possession ne l\u2019est plus.',
        'Le pill testing se développe mais reste loin d\u2019être disponible partout — vérifie l\u2019offre locale avant de compter dessus.',
        'La naloxone est gratuite ou quasi gratuite selon l\u2019État : renseigne-toi localement.'
      ]
    },

    IE: {
      code:'IE', label:'Irlande', flag:'', lang:'en', emergencyMain:'999',
      emergency:[
        { name:'Urgences', tel:'999', desc:'Aussi joignable au 112', kind:'urgence' },
        { name:'HSE — drugs.ie', tel:'', desc:'Info, soutien, annuaire de services (contact via le site)', kind:'drogue' }
      ],
      centres:[
        { name:'HSE Addiction Services', desc:'Services publics de soin addiction', url:'drugs.ie' },
        { name:'SAIL', desc:'Association de terrain en réduction des risques, active depuis 30 ans', url:'' }
      ],
      groupes:[
        { name:'Narcotics Anonymous Ireland', url:'na-ireland.org', desc:'Narcotiques Anonymes' },
        { name:'Alcoholics Anonymous Ireland', url:'alcoholicsanonymous.ie', desc:'Alcooliques Anonymes' }
      ],
      testing:[ { name:'Drug checking (festivals, HSE)', desc:'Promu par le HSE lors de certains festivals d\u2019été ; encore limité, une extension est réclamée publiquement (2025-2026).', url:'' } ],
      naloxone:{ access:'Programme HSE de naloxone à emporter (seringue préremplie) en expansion — 6 944 unités fournies en 2024. Pas encore aussi généralisé qu\u2019au Royaume-Uni ou au Portugal.', form:'Injectable (préremplie)' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (Misuse of Drugs Act 1977). Une décriminalisation de l\u2019usage personnel est en discussion active (Stratégie nationale drogues 2026-2029, approche « santé d\u2019abord ») mais n\u2019est pas encore votée à ce jour — la possession reste une infraction pénale.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Même cadre que le cannabis ; la possession personnelle reste pénalement sanctionnée en l\u2019état actuel du droit, malgré le débat en cours sur une réforme.' },
        conduite:'Alcool : 50 mg/100mL pour permis complet, 20 mg/100mL pour apprenti·e/novice/conducteur·rice professionnel·le (quasi tolérance zéro). Stupéfiants : dépistage salivaire, tolérance zéro de fait.',
        bonSamaritain:'Aucune loi « bon samaritain » dédiée identifiée ; le 999/112 reste la priorité en cas d\u2019urgence.'
      },
      tips:[
        'La décriminalisation est débattue publiquement mais n\u2019est pas encore en vigueur : la possession reste, à ce jour, une infraction pénale.',
        'Le programme de naloxone à emporter grandit chaque année — renseigne-toi auprès du HSE ou de ton pharmacien.',
        'En cas de malaise après consommation, les Gardaí encouragent explicitement à appeler le 999/112 sans délai.'
      ]
    },

    SN: {
      code:'SN', label:'Sénégal', flag:'', lang:'fr', emergencyMain:'17',
      emergency:[
        { name:'Police secours', tel:'17', desc:'Toutes urgences sécuritaires', kind:'urgence' },
        { name:'SAMU national', tel:'1515', desc:'Urgences médicales, ambulances', kind:'urgence' },
        { name:'Sapeurs-pompiers', tel:'18', desc:'Incendie, accidents, secours', kind:'urgence' },
        { name:'Centre Antipoison (CHU Fann, Dakar)', tel:'', desc:'Intoxications — contacter via le CHU', kind:'poison' }
      ],
      centres:[
        { name:'CNLD / CILD', desc:'Comité National / Interministériel de Lutte contre la Drogue — référence institutionnelle', url:'cild.gouv.sn' },
        { name:'CEPIAD (Dakar)', desc:'Centre de prise en charge intégrée des addictions, dont substitution méthadone — rare sur le continent', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucun programme national de naloxone à large échelle documenté de façon fiable.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (Code des Drogues, loi 97-18 de 1997) : peines de 1 à 3 ans de prison et amende pour usage/détention selon les articles, bien plus lourdes pour la production/le trafic (5 à 10 ans). Le Sénégal est pourtant l\u2019un des principaux producteurs de cannabis d\u2019Afrique de l\u2019Ouest — usage répandu malgré la loi.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Cadre pénal strict pour l\u2019ensemble des stupéfiants ; le trafic est sévèrement puni (5 à 10 ans, amende jusqu\u2019au triple de la valeur saisie).' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée.'
      },
      tips:[
        'Le CEPIAD à Dakar est l\u2019un des rares centres du continent à proposer un traitement de substitution — une ressource notable si tu es concerné·e.',
        'Le cadre légal reste répressif ; en cas d\u2019urgence vitale, la priorité reste d\u2019appeler le 1515 ou le 17.',
        'La réduction des risques (testing, naloxone) n\u2019est pas documentée à l\u2019échelle nationale au-delà de Dakar.'
      ]
    },

    CI: {
      code:'CI', label:'Côte d\u2019Ivoire', flag:'', lang:'fr', emergencyMain:'185',
      emergency:[
        { name:'SAMU', tel:'185', desc:'Urgences médicales', kind:'urgence' },
        { name:'Sapeurs-pompiers', tel:'180', desc:'Incendie, accidents, secours', kind:'urgence' },
        { name:'Police secours', tel:'110', desc:'Aussi 111 et 170 selon zone', kind:'urgence' }
      ],
      centres:[
        { name:'CHU de Cocody (SAMU CI)', desc:'Coordination des urgences médicales, Abidjan', url:'' },
        { name:'Services publics de santé mentale/addictologie', desc:'Prise en charge selon les CHU régionaux', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucun programme national de naloxone à large échelle documenté de façon fiable.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal (loi 88-686 de 1988) : 1 à 5 ans de prison et amende (200 000 à 5 millions FCFA) pour détention/usage personnel.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Même cadre pénal pour l\u2019ensemble des stupéfiants ; tentative et association punies comme l\u2019infraction elle-même.' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée.'
      },
      tips:[
        'Le cadre légal est strictement répressif, y compris pour un usage personnel modeste.',
        'En cas d\u2019urgence vitale, la priorité reste d\u2019appeler le 185 (SAMU) ou le 180 (pompiers), quel que soit le contexte légal.',
        'La réduction des risques (testing, naloxone) n\u2019est pas documentée à l\u2019échelle nationale.'
      ]
    },

    CM: {
      code:'CM', label:'Cameroun', flag:'', lang:'fr', emergencyMain:'117',
      emergency:[
        { name:'Police', tel:'117', desc:'Depuis un mobile (17 depuis un fixe)', kind:'urgence' },
        { name:'Gendarmerie nationale', tel:'113', desc:'Depuis un mobile (13 depuis un fixe)', kind:'urgence' },
        { name:'Sapeurs-pompiers', tel:'118', desc:'Depuis un mobile (18 depuis un fixe)', kind:'urgence' },
        { name:'SAMU', tel:'119', desc:'Depuis un mobile (19 depuis un fixe) ; numéro unifié 112 en cours de déploiement national', kind:'urgence' }
      ],
      centres:[
        { name:'CNLD (Comité National de Lutte contre la Drogue)', desc:'Référence institutionnelle, Ministère de la Santé Publique', url:'' },
        { name:'Structures communautaires (ex. POSIAPUD)', desc:'Offre de proximité portée par des ONG locales, la politique RDR officielle reste encore limitée en moyens', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucun programme national de naloxone à large échelle documenté ; la réduction des risques reste, de l\u2019aveu même du CNLD, insuffisamment dotée en ressources.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal, malgré une culture et un usage social répandus dans plusieurs régions. Trafic important vers/depuis le Nigéria voisin.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Cadre pénal strict pour l\u2019ensemble des stupéfiants ; plan stratégique national de lutte 2024-2030 en cours de mise en \u0153uvre.' },
        conduite:'Pas de seuil légal publié de façon fiable pour les stupéfiants ; éviter totalement de conduire après consommation.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée.'
      },
      tips:[
        'Le numéro d\u2019urgence unifié 112 est en cours de déploiement : s\u2019il ne répond pas encore dans ta région, utilise les numéros spécifiques ci-dessus.',
        'La réduction des risques reste portée surtout par des associations locales plutôt que par une offre publique généralisée — le CNLD le reconnaît lui-même dans sa stratégie 2024-2030.',
        'En cas d\u2019urgence vitale, la priorité reste d\u2019appeler le 119/19, quel que soit le contexte légal.'
      ]
    },

    CD: {
      code:'CD', label:'RD Congo', flag:'', lang:'fr', emergencyMain:'122',
      emergency:[
        { name:'Numéro d\u2019urgence général', tel:'122', desc:'Cité comme numéro national, mais la couverture et la fiabilité varient fortement selon la ville/province — les grandes villes ont souvent leurs propres numéros de police (ex. Kinshasa). En cas de doute, le réflexe le plus fiable reste de te rendre directement à l\u2019hôpital ou au commissariat le plus proche.', kind:'urgence' }
      ],
      centres:[
        { name:'Comité National Interministériel de Lutte contre la Drogue et la Prévention du Crime', desc:'Référence institutionnelle nationale', url:'' },
        { name:'Hôpitaux publics provinciaux', desc:'Prise en charge selon les structures disponibles localement', url:'' }
      ],
      groupes:[],
      testing:[],
      naloxone:{ access:'Aucune information fiable de disponibilité trouvée.', form:'' },
      legal:{
        verifie_le:'2026-06',
        cannabis:{ status:LEGAL.ILLEGAL, summary:'Illégal depuis un décret de 1917 sur le chanvre (culture, vente, transport, détention, consommation), jamais modifié depuis. La consommation reste néanmoins répandue, notamment à Kinshasa.' },
        autres:{ status:LEGAL.ILLEGAL, summary:'Trafic et consommation prohibés ; l\u2019application de la loi est décrite comme inégale selon les sources juridiques disponibles.' },
        conduite:'Aucune donnée fiable trouvée sur un seuil légal de conduite sous stupéfiants.',
        bonSamaritain:'Aucune loi « bon samaritain » identifiée.'
      },
      tips:[
        'Il n\u2019existe pas de numéro d\u2019urgence national unique confirmé et fiable : mieux vaut repérer à l\u2019avance l\u2019hôpital et le commissariat les plus proches de l\u2019endroit où tu te trouves.',
        'Le cadre légal reste répressif et ancien (texte de 1917 jamais mis à jour) ; la réduction des risques n\u2019est pas documentée à l\u2019échelle nationale.',
        'En cas d\u2019urgence vitale, se rendre directement à la structure de santé la plus proche reste souvent plus rapide qu\u2019un appel téléphonique.'
      ]
    }

  };

  /* ---- Données routières détaillées (alcoolémie, stupéfiants, sanctions) ----
     Vérifié 2026-06. Sources : codes de la route nationaux, Touteleurope,
     LegiPermis, services gouvernementaux. Éducatif, pas un conseil juridique. */
  var ROADSIDE = {
    BE: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,22 mg/L air expiré)',
      alcoolNovice:'0,5 g/L — pas de seuil abaissé pour les novices',
      drogues:'Tolérance zéro : toute trace de stupéfiant = infraction. Dépistage salivaire.',
      refus:'Refuser le dépistage est sanctionné comme un test positif.',
      sanction:'Amende, déchéance du droit de conduire, voire prison selon le taux/récidive.',
      sources:'Code de la route belge (réforme sécurité routière 2025).' },
    FR: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,2 g/L (permis probatoire, AAC, transport en commun) — quasi zéro',
      drogues:'Tolérance zéro : la moindre trace est un délit. Test salivaire, confirmation sanguine.',
      refus:'Refus = délit (jusqu’à 9 000 €, 6 points, 2 ans de prison).',
      sanction:'≥ 0,8 g/L : délit, jusqu’à 4 500 € et 2 ans. Cumul alcool+drogue (loi 11 juillet 2025) : jusqu’à 15 000 € et 5 ans.',
      sources:'Code de la route (L235-1/2), arrêté 13/12/2016, lois 9 & 11 juillet 2025.' },
    CH: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,1 g/L (permis à l’essai, pros, moniteurs) — tolérance quasi nulle',
      drogues:'Tolérance zéro pour les stupéfiants. Dépistage salivaire, prise de sang.',
      refus:'Refus assimilé à un résultat positif ; sanctions lourdes.',
      sanction:'Amende, retrait de permis (durée selon gravité), prison possible.',
      sources:'Loi fédérale sur la circulation routière (LCR/OCR).' },
    CA: { verifie_le:'2026-06',
      alcoolGeneral:'0,08 (80 mg/100 mL) = infraction criminelle ; 0,05–0,08 = sanctions provinciales',
      alcoolNovice:'Zéro alcool : conducteurs ≤ 21 ans et permis d’apprenti/probatoire (Québec)',
      drogues:'THC ≥ 2 ng/mL = infraction (≥ 5 ng/mL aggravée). Autres drogues : tolérance/impairment.',
      refus:'Refus du test = infraction criminelle, peines équivalentes à la conduite avec facultés affaiblies.',
      sanction:'Suspension immédiate, amende, casier criminel possible dès la 1re infraction.',
      sources:'Code criminel (C-46), Code de la sécurité routière du Québec.' },
    LU: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,2 g/L (permis < 2 ans, professionnels)',
      drogues:'Tolérance zéro pour les stupéfiants. Dépistage salivaire.',
      refus:'Refus sanctionné comme un test positif.',
      sanction:'Amende, retrait de permis, prison selon le taux/récidive.',
      sources:'Code de la route luxembourgeois.' },
    DE: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,0 g/L (permis < 2 ans ou conducteur < 21 ans)',
      drogues:'Seuil THC de 3,5 ng/mL de sérum ; autres stupéfiants dépistés. Test salivaire/sanguin.',
      refus:'Refus du test conduit à une prise de sang ordonnée et à des sanctions.',
      sanction:'Amende, points en Flensburg, interdiction de conduire ; prison aux taux élevés/récidive.',
      sources:'StVG / StVO ; réforme cannabis 2024 (seuil THC).' },
    NL: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,22 mg/L air expiré)',
      alcoolNovice:'0,2 g/L (permis < 5 ans)',
      drogues:'Seuils légaux définis par substance ; dépistage salivaire puis sanguin.',
      refus:'Refus du test est une infraction ; permis pouvant être déclaré invalide.',
      sanction:'Amende, stage obligatoire (LEMA), suspension selon le taux.',
      sources:'Wegenverkeerswet ; CBR 2025.' },
    GB: { verifie_le:'2026-06',
      alcoolGeneral:'0,8 g/L Angleterre/Galles/Irlande du Nord (0,35 mg/L air) ; 0,5 g/L en Écosse',
      alcoolNovice:'Pas de seuil abaissé pour les novices (0,2 g/L pour les professionnels)',
      drogues:'Seuils légaux par substance (« drug driving ») ; dépistage salivaire au bord de la route.',
      refus:'Refuser de fournir un échantillon est une infraction pénale, peines proches de la conduite en état d\u2019ivresse.',
      sanction:'Amende, points, interdiction de conduire, prison possible.',
      sources:'Road Traffic Act 1988.' },
    ES: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L (0,25 mg/L air expiré)',
      alcoolNovice:'0,3 g/L (permis < 2 ans, professionnels)',
      drogues:'Dépistage salivaire ; tolérance zéro de fait pour cannabis, cocaïne, opiacés, amphétamines.',
      refus:'Refus du test assimilé à une infraction pénale (délit).',
      sanction:'Amende, retrait de points, suspension de permis ; prison possible en cas de taux élevé/récidive.',
      sources:'Reglamento General de Circulación ; DGT.' },
    PT: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L',
      alcoolNovice:'0,2 g/L (permis < 3 ans)',
      drogues:'Dépistage salivaire ; tolérance zéro pour les stupéfiants au volant.',
      refus:'Refus du test sanctionné comme une infraction grave.',
      sanction:'Amende, suspension du permis ; peines pénales au-delà de certains seuils.',
      sources:'Código da Estrada.' },
    IT: { verifie_le:'2026-06',
      alcoolGeneral:'0,5 g/L',
      alcoolNovice:'0,0 g/L (permis < 3 ans ou conducteurs professionnels)',
      drogues:'Tolérance zéro : toute trace détectée de stupéfiant est une infraction, sans seuil.',
      refus:'Refus du test assimilé à une conduite sous stupéfiants avérée.',
      sanction:'Amende, suspension de permis, véhicule saisi, prison possible en cas de récidive/accident.',
      sources:'Codice della Strada.' },
    US: { verifie_le:'2026-06',
      alcoolGeneral:'0,08 % dans 49 États + DC ; 0,05 % dans l\u2019Utah',
      alcoolNovice:'Tolérance zéro (< 21 ans) dans la plupart des États',
      drogues:'Pas de seuil fédéral unique. Certains États fixent un seuil THC (ex. 5 ng/mL), d\u2019autres une approche basée sur l\u2019effet constaté — ça varie fortement d\u2019un État à l\u2019autre.',
      refus:'Généralement traité comme une infraction distincte (« implied consent laws »), avec suspension automatique du permis dans la plupart des États.',
      sanction:'Amende, suspension de permis, parfois installation obligatoire d\u2019un éthylotest anti-démarrage ; peines plus lourdes en cas de récidive.',
      sources:'NHTSA ; législations propres à chaque État.' },
    AU: { verifie_le:'2026-06',
      alcoolGeneral:'0,05 g/100mL pour permis complet, partout dans le pays',
      alcoolNovice:'0,00 (apprenti·e, permis probatoire P1/P2)',
      drogues:'Tolérance zéro nationale : toute trace détectée (dépistage salivaire) est une infraction, y compris pour le cannabis là où la possession est décriminalisée (ACT).',
      refus:'Infraction pénale à part entière, sanctionnée comme un résultat positif.',
      sanction:'Amende, suspension/annulation de permis, éthylotest anti-démarrage souvent obligatoire ; prison possible pour les taux élevés ou la récidive.',
      sources:'Législations des États/territoires ; National Road Safety Strategy.' },
    IE: { verifie_le:'2026-06',
      alcoolGeneral:'50 mg/100mL (0,05 %) pour permis complet',
      alcoolNovice:'20 mg/100mL (0,02 %) pour apprenti·e, novice (< 2 ans) et conducteur·rice professionnel·le',
      drogues:'Dépistage salivaire (Mandatory Intoxication Test) ; tolérance zéro de fait pour les stupéfiants.',
      refus:'Infraction distincte, entraîne une arrestation et une suspension.',
      sanction:'Amende (jusqu\u2019à 5 000 €), disqualification de 3 mois à plusieurs années selon le taux, prison possible jusqu\u2019à 6 mois pour les cas les plus graves.',
      sources:'Road Traffic Acts 2010-2024 ; Road Safety Authority (RSA).' }
  };
  Object.keys(ROADSIDE).forEach(function(c){ if (REGIONS[c]) REGIONS[c].roadside = ROADSIDE[c]; });

  // ---- API ----
  var ORDER = ['BE','FR','CH','CA','LU','DE','GB','NL','ES','PT','IT','MA','DZ','TN','US','AU','IE','SN','CI','CM','CD'];
  function get(code){ return REGIONS[code] || REGIONS.BE; }
  function list(){ return ORDER.map(function(c){ return REGIONS[c]; }); }
  function exists(code){ return !!REGIONS[code]; }
  function telHref(tel){ return 'tel:' + String(tel).replace(/[^+0-9]/g,''); }

  var LABELS_EN = {
    BE:'Belgium', FR:'France', CH:'Switzerland', CA:'Canada (QC)', LU:'Luxembourg',
    DE:'Germany', GB:'United Kingdom', NL:'Netherlands', ES:'Spain', PT:'Portugal',
    IT:'Italy', MA:'Morocco', DZ:'Algeria', TN:'Tunisia', US:'United States',
    AU:'Australia', IE:'Ireland', SN:'Senegal', CI:'C\u00f4te d\u2019Ivoire', CM:'Cameroon', CD:'DR Congo'
  };
  function currentLang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  /* labelOf(r) : nom de pays affichable dans la langue courante — r peut être un objet
     région (avec .code) ou directement un code ('BE'). Ne modifie jamais r.label
     lui-même (source de vérité FR), pour ne rien casser côté data. */
  function labelOf(r){
    var code = (r && typeof r === 'object') ? r.code : r;
    if (currentLang() === 'en' && LABELS_EN[code]) return LABELS_EN[code];
    return (r && typeof r === 'object') ? r.label : (REGIONS[code] ? REGIONS[code].label : code);
  }

  global.MD_REGIONS = REGIONS;
  global.MD_LEGAL_STATUS = LEGAL;
  global.MDRegions = { get:get, list:list, exists:exists, order:ORDER, telHref:telHref, labelOf:labelOf };
})(window);
