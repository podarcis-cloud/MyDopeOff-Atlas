/* MyDope Off — page-tetris.js
   Scripts inline de tetris.html regroupés ici pour permettre une CSP stricte
   (script-src 'self'). Contenu inchangé, ordre d'origine préservé. */

/* MyDope Off — socle commun (nav, profil, logo) */
window.LUCIDE = (function () {

  const KEY = 'ctc_v6';
  const LANG_KEY = 'mydopeoff_lang';
  const LANGS = ['fr', 'en'];
  const LANG_NAMES = { fr: 'Français', en: 'English' };

  /* ============================================================
     I18N — dictionnaire du "cadre" (UI partagée).
     Pour traduire le contenu (fiches) plus tard : remplir
     window.LUCIDE_FICHES_I18N (voir docs en bas) — aucune
     modification d'architecture nécessaire.
     ============================================================ */
  const DICT = {
    // Navigation
    'nav.home':        { fr: 'Accueil',      en: 'Home' },
    'nav.tracking':    { fr: 'Suivi conso',  en: 'Tracking' },
    'nav.substances':  { fr: 'Substances',   en: 'Substances' },
    'nav.protocols':   { fr: 'Protocoles',   en: 'Protocols' },
    'nav.rdr':         { fr: 'RDR',          en: 'Harm red.' },
    // Commun
    'common.back':     { fr: 'Accueil',      en: 'Home' },
    'common.back_prev':{ fr: 'Retour',       en: 'Back' },
    'common.close':    { fr: 'Fermer',       en: 'Close' },
    'common.save':     { fr: 'Enregistrer',  en: 'Save' },
    'common.cancel':   { fr: 'Annuler',      en: 'Cancel' },
    'common.add':      { fr: 'Ajouter',      en: 'Add' },
    'common.delete':   { fr: 'Supprimer',    en: 'Delete' },
    'common.search':   { fr: 'Rechercher…',  en: 'Search…' },
    'common.language': { fr: 'Langue',       en: 'Language' },
    // Accueil
    'home.intro':      { fr: "Ici, tu n'es pas un dossier : tu gardes les commandes. MyDope Off t'aide à comprendre les substances, mesurer ta consommation et couper la boucle quand tu le décides — sans jugement, sans compte, tout reste sur ton appareil.",
                         en: "Here you're not a case file — you stay in control. MyDope Off helps you understand substances, track your use and break the loop when you decide — no judgement, no account, everything stays on your device." },
    'home.spaces':     { fr: 'Les 5 espaces', en: 'The 5 spaces' },
    'home.welcome':    { fr: 'Bienvenue',    en: 'Welcome' },
    'home.welcome_sub':{ fr: 'Commence par tenir ton journal dans Suivi conso.',
                         en: 'Start by keeping your journal in Tracking.' },
    'home.tile_track': { fr: 'Journal, coûts, détection, objectifs',
                         en: 'Journal, costs, detection, goals' },
    'home.tile_subs':  { fr: '270 fiches, interactions, risques',
                         en: '270 substances, interactions, risks' },
    'home.tile_proto': { fr: 'Exercices et jeux anti-craving',
                         en: 'Anti-craving exercises and games' },
    'home.tile_rdr':   { fr: 'Urgences, centres, conseils',
                         en: 'Emergencies, centres, advice' },
    'home.edit_info':  { fr: 'Modifier mes infos', en: 'Edit my info' },
    'home.support':    { fr: 'Soutenir le projet', en: 'Support the project' },
    'home.guide_link': { fr: 'Guide d\'utilisation', en: 'User guide' },
    // Suivi
    'track.title':     { fr: 'Suivi conso',  en: 'Tracking' },
    'track.tab_board': { fr: 'Tableau',      en: 'Board' },
    'track.tab_journal':{ fr: 'Journal',     en: 'Journal' },
    'track.tab_costs': { fr: 'Coûts',        en: 'Costs' },
    'track.tab_goals': { fr: 'Objectifs',    en: 'Goals' },
    // RDR / interactions génériques
    'inter.title':     { fr: "Vérificateur d'interactions", en: 'Interaction checker' },
    'inter.analyze':   { fr: 'Analyser les interactions', en: 'Check interactions' },
    // Inscription (1er lancement)
    'reg.sub':         { fr: "Ici, tu gardes les commandes. Comprendre, mesurer, couper la boucle — tes données restent sur ton appareil.",
                         en: "Here, you stay in control. Understand, track, break the loop — your data stays on your device." },
    'reg.name':        { fr: 'Prénom ou pseudo', en: 'First name or nickname' },
    'reg.name_ph':     { fr: 'Ton prénom', en: 'Your name' },
    'reg.age':         { fr: 'Âge', en: 'Age' },
    'reg.region':      { fr: 'Région', en: 'Region' },
    'reg.enter':       { fr: 'Entrer', en: 'Enter' },
    'reg.back_home':   { fr: "← Revenir à l'accueil", en: '← Back to home' },
    'reg.note':        { fr: 'Aucun compte · aucune inscription en ligne · 100 % local',
                         en: 'No account · no online sign-up · 100% local' },
    'reg.choose_lang': { fr: 'Choisis ta langue', en: 'Choose your language' },
    // Consentement
    'consent.title':   { fr: 'Avant de commencer', en: 'Before you start' },
    'consent.p1':      { fr: "MyDope Off est un outil de <b>réduction des risques</b> à visée éducative. Il ne remplace ni un avis médical, ni un traitement, ni un service d'urgence.",
                         en: "MyDope Off is an educational <b>harm-reduction</b> tool. It does not replace medical advice, treatment, or emergency services." },
    'consent.p2':      { fr: "Les informations sur les substances, interactions et durées de détection sont des <b>estimations</b> qui varient selon chaque personne. En cas d'urgence, appelle le 112.",
                         en: "Information on substances, interactions and detection times are <b>estimates</b> that vary from person to person. In an emergency, call 112." },
    'consent.p3':      { fr: "Tes données restent uniquement sur cet appareil. Si tu vides le cache, elles disparaissent.",
                         en: "Your data stays only on this device. If you clear the cache, it's gone." },
    'consent.ok':      { fr: "J'ai compris", en: 'I understand' },
    // Suivi conso — détail
    'tr.day':          { fr: 'Journée', en: 'Day' },
    'tr.edit_entry':   { fr: "Modifier l'entrée", en: 'Edit entry' },
    'tr.date':         { fr: 'Date', en: 'Date' },
    'tr.substance':    { fr: 'Substance', en: 'Substance' },
    'tr.substance_search': { fr: 'Substance (recherche dans les fiches)', en: 'Substance (search the database)' },
    'tr.intensity':    { fr: 'Intensité', en: 'Intensity' },
    'tr.note':         { fr: 'Note', en: 'Note' },
    'tr.note_ph':      { fr: 'Contexte, ressenti…', en: 'Context, feelings…' },
    'tr.cost':         { fr: 'Coût (€)', en: 'Cost (€)' },
    'tr.sober':        { fr: 'Sobre', en: 'Sober' },
    'tr.light':        { fr: 'Léger', en: 'Light' },
    'tr.moderate':     { fr: 'Modéré', en: 'Moderate' },
    'tr.intense':      { fr: 'Intensif', en: 'Intense' },
    'tr.add_entry':    { fr: 'Ajouter une entrée', en: 'Add entry' },
    'tr.add_to_day':   { fr: 'Ajouter à ce jour', en: 'Add to this day' },
    'tr.add_entry_btn':{ fr: "Ajouter l'entrée", en: 'Add the entry' },
    'tr.day_sober':    { fr: 'Journée sobre', en: 'Sober day' },
    'tr.sobers':       { fr: 'Sobres', en: 'Sober' },
    'tr.logged':       { fr: 'Journalisés', en: 'Logged' },
    'tr.intenses':     { fr: 'Intenses', en: 'Intense' },
    'tr.cal_hint':     { fr: "30 derniers jours · touche un jour pour l'éditer", en: 'Last 30 days · tap a day to edit' },
    'tr.new_goal':     { fr: 'Nouvel objectif', en: 'New goal' },
    'tr.create_goal':  { fr: "Créer l'objectif", en: 'Create goal' },
    'tr.goal_type':    { fr: "Type d'objectif", en: 'Goal type' },
    'tr.goal_reduce':  { fr: "Réduction d'une substance", en: 'Reduce a substance' },
    'tr.goal_streak':  { fr: 'Jours consécutifs sobres', en: 'Consecutive sober days' },
    'tr.goal_max_week':{ fr: 'Maximum de prises / semaine (toutes substances)', en: 'Max uses / week (all substances)' },
    'tr.goal_no_heavy':{ fr: 'Aucune séance intensive', en: 'No intense sessions' },
    'tr.per_day':      { fr: 'par jour', en: 'per day' },
    'tr.per_week':     { fr: 'par semaine', en: 'per week' },
    'tr.per_month':    { fr: 'par mois', en: 'per month' },
    'tr.per_sub':      { fr: 'Par substance · 30 jours', en: 'Per substance · 30 days' },
    'tr.lottery':      { fr: 'Ta cagnotte potentielle', en: 'Reverse lottery' },
    'tr.lottery_sub':  { fr: 'Ce que ça représente autrement. Pas pour culpabiliser — juste pour voir ce que tu pourrais récupérer.', en: "What it could be instead. Not to guilt-trip — just to see what you could get back." },
    'tr.proj_annual':  { fr: 'Projection annuelle', en: 'Annual projection' },
    'tr.cost_empty':   { fr: 'Renseigne un coût dans tes entrées pour voir les projections.', en: 'Add a cost to your entries to see projections.' },
    'tr.cost_note':    { fr: 'Seules les entrées avec un coût renseigné sont comptabilisées.', en: 'Only entries with a cost are counted.' },
    'tr.record':       { fr: 'Record', en: 'Record' },
    'tr.del_confirm':  { fr: 'Supprimer cette entrée ?', en: 'Delete this entry?' },
    'tr.max':          { fr: 'maximum', en: 'maximum' },
    'tr.empty':        { fr: 'Vide', en: 'Empty' },
    'tr.cons_8w':      { fr: 'Consommations · 8 semaines', en: 'Use · 8 weeks' },
    'tr.subs_30d':     { fr: 'Substances · 30 jours', en: 'Substances · 30 days' },
    'tr.mark_sober':   { fr: "Marquer aujourd'hui sobre", en: 'Mark today sober' },
    'tr.history':      { fr: 'Historique', en: 'History' },
    'tr.limit_set':    { fr: 'Limite que tu te fixes', en: 'Limit you set' },
    'tr.target_num':   { fr: 'Cible (nombre)', en: 'Target (number)' },
    'tr.sub_ph':       { fr: 'ex. Tabac, Alcool, Cannabis…', en: 'e.g. Tobacco, Alcohol, Cannabis…' },
    // Guide
    'gd.title':        { fr: 'Bien utiliser MyDope Off', en: 'Getting the most from MyDope Off' },
    'gd.intro':        { fr: "MyDope Off rassemble des informations scientifiques et des outils pour comprendre les substances et réduire les risques. Tout fonctionne hors-ligne et reste sur ton téléphone.",
                         en: "MyDope Off gathers scientific information and tools to understand substances and reduce risks. Everything works offline and stays on your phone." },
    'gd.spaces':       { fr: 'Les cinq espaces', en: 'The five spaces' },
    'gd.subs_desc':    { fr: "270 fiches détaillées et le vérificateur d'interactions. Cherche une substance pour voir risques, durée et précautions.",
                         en: "270 detailed entries and the interaction checker. Search a substance to see risks, duration and precautions." },
    'gd.ex_desc':      { fr: "Des tâches visuelles courtes (labyrinthe, etc.) qui aident à faire retomber une envie pressante en quelques minutes.",
                         en: "Short visual tasks (maze, etc.) that help a pressing urge subside within minutes." },
    'gd.track_desc':   { fr: "Ton journal, tes coûts, tes objectifs, et la durée de détection estimée par test.",
                         en: "Your journal, your costs, your goals, and the estimated detection time per test." },
    'gd.rdr_desc':     { fr: "Réduction des risques : numéros d'urgence, centres et bonnes pratiques.",
                         en: "Harm reduction: emergency numbers, centres and best practices." },
    'gd.journal_title':{ fr: 'Tenir ton journal en 3 gestes', en: 'Keep your journal in 3 steps' },
    'gd.j1_t':         { fr: 'Ajouter une entrée', en: 'Add an entry' },
    'gd.j1_d':         { fr: 'Suivi › Journal', en: 'Tracking › Journal' },
    'gd.j2_t':         { fr: 'Plusieurs entrées le même jour', en: 'Several entries the same day' },
    'gd.j2_d':         { fr: "Sur une journée déjà présente, touche « Ajouter à ce jour ». Tu peux empiler autant d'entrées que nécessaire sur la même date.",
                         en: "On a day already logged, tap \"Add to this day\". You can stack as many entries as needed on the same date." },
    'gd.j3_t':         { fr: 'Modifier ou supprimer', en: 'Edit or delete' },
    'gd.j3_d':         { fr: "Touche une entrée pour la rouvrir et la corriger, ou la croix pour la supprimer. Depuis le calendrier, touche un jour pour l'éditer directement.",
                         en: "Tap an entry to reopen and fix it, or the cross to delete it. From the calendar, tap a day to edit it directly." },
    'gd.detect_title': { fr: 'Comprendre la détection', en: 'Understanding detection' },
    'gd.detect_intro': { fr: "Quand tu choisis une substance, MyDope Off estime la fenêtre de détection selon trois types de test :",
                         en: "When you pick a substance, MyDope Off estimates the detection window for three test types:" },
    'gd.saliva':       { fr: 'Salive', en: 'Saliva' },
    'gd.saliva_d':     { fr: "Test oral rapide — fenêtre courte, reflète l'usage récent.", en: "Quick oral test — short window, reflects recent use." },
    'gd.urine':        { fr: 'Urine', en: 'Urine' },
    'gd.urine_d':      { fr: "Le plus répandu — fenêtre la plus longue, surtout en usage régulier.", en: "Most common — longest window, especially with regular use." },
    'gd.blood':        { fr: 'Sang', en: 'Blood' },
    'gd.blood_d':      { fr: "Fenêtre la plus courte — mais la plus précise sur le moment.", en: "Shortest window — but the most accurate in the moment." },
    'gd.ctrl_title':   { fr: 'Contrôles routiers', en: 'Roadside checks' },
    'gd.ctrl_desc':    { fr: "Une page dédiée explique comment se déroulent les contrôles alcool et stupéfiants au volant, les seuils légaux, et pourquoi la seule façon fiable de les passer est de ne pas conduire après avoir consommé.",
                         en: "A dedicated page explains how alcohol and drug roadside checks work, the legal limits, and why the only reliable way to pass them is not to drive after using." },
    'gd.ctrl_link_t':  { fr: 'Alcool, stupéfiants et conduite', en: 'Alcohol, drugs and driving' },
    'gd.ctrl_link_d':  { fr: "Déroulé, seuils, sanctions, comment vraiment l'éviter", en: "Process, limits, penalties, how to really avoid it" },
    'gd.lex_title':    { fr: 'Lexique réduction des risques', en: 'Harm-reduction glossary' },
    'gd.lex_intro':    { fr: "Les termes scientifiques et le jargon que tu croises dans l'app et autour du sujet, expliqués simplement. Touche un mot pour dérouler.",
                         en: "The scientific terms and jargon you meet in the app and around the topic, explained simply. Tap a word to expand." },
    'gd.lex_note':     { fr: "Ce lexique est pédagogique et simplifié. Il ne remplace pas un avis médical.", en: "This glossary is educational and simplified. It does not replace medical advice." },
    'gd.data_title':   { fr: 'Tes données', en: 'Your data' },
    'gd.support':      { fr: 'Soutenir le projet', en: 'Support the project' },
    'gd.lex_search':   { fr: 'Rechercher un terme…', en: 'Search a term…' },
    'gd.lex_empty':    { fr: 'Aucun terme ne correspond.', en: 'No matching term.' },
    // Page Substances (psychochecker) — interface
    'ps.subtag':       { fr: '270 substances', en: '270 substances' },
    'ps.checker_intro':{ fr: 'Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Enter 2 or 3 substances — every pair will be analysed.' },
    'ps.recognized':   { fr: 'Noms reconnus : Valium, Xanax, Coke, MDMA, Éthanol…', en: 'Recognised names: Valium, Xanax, Coke, MDMA, Ethanol…' },
    'ps.sub1':         { fr: 'Substance 1', en: 'Substance 1' },
    'ps.sub2':         { fr: 'Substance 2', en: 'Substance 2' },
    'ps.sub3':         { fr: 'Substance 3 (optionnel)', en: 'Substance 3 (optional)' },
    'ps.analyze':      { fr: 'Analyser les interactions', en: 'Check interactions' },
    'ps.result_empty': { fr: 'Saisir au moins 2 substances pour voir les interactions documentées.', en: 'Enter at least 2 substances to see documented interactions.' },
    'ps.tab_classic':  { fr: 'Substances classiques', en: 'Classic substances' },
    'ps.tab_canna':    { fr: 'Cannabinoïdes', en: 'Cannabinoids' },
    'ps.search':       { fr: 'Rechercher…', en: 'Search…' },
    'ps.all_classes':  { fr: 'Toutes classes', en: 'All classes' },
    'ps.cl_stimulant': { fr: 'Stimulant', en: 'Stimulant' },
    'ps.cl_depressant':{ fr: 'Dépresseur', en: 'Depressant' },
    'ps.cl_opioid':    { fr: 'Opioïde', en: 'Opioid' },
    'ps.cl_psyche':    { fr: 'Psychédélique', en: 'Psychedelic' },
    'ps.cl_dissoc':    { fr: 'Dissociatif', en: 'Dissociative' },
    'ps.cl_enta':      { fr: 'Entactogène', en: 'Entactogen' },
    'ps.addiction':    { fr: 'Addiction', en: 'Addiction' },
    'ps.effects':      { fr: 'Effets', en: 'Effects' },
    'ps.dose':         { fr: 'Dosage', en: 'Dosage' },
    'ps.duration':     { fr: 'Durée', en: 'Duration' },
    'ps.dose_low':     { fr: 'Faible', en: 'Low' },
    'ps.dose_mod':     { fr: 'Modéré', en: 'Moderate' },
    'ps.dose_high':    { fr: 'Fort', en: 'Strong' },
    'ps.danger_label': { fr: 'Danger', en: 'Risk' },
    'ps.no_result':    { fr: 'Aucun résultat', en: 'No results' },
    'ps.count_subs':   { fr: '{n} substances', en: '{n} substances' },
    'ps.testimony':    { fr: 'Témoignage', en: 'Report' },
    'ps.info':         { fr: 'Info', en: 'Info' },
    'ps.none_found':   { fr: 'Aucune substance trouvée.', en: 'No substance found.' },
    'ps.footer':       { fr: 'Réduction des risques', en: 'Harm reduction' },
    // Jeux (maze + tetris)
    'gm.back':         { fr: 'Retour', en: 'Back' },
    'gm.maze_title':   { fr: 'Labyrinthe', en: 'Maze' },
    'gm.maze_intro':   { fr: "12 niveaux · Incline le téléphone pour déplacer la bille jusqu'à la cible.", en: "12 levels · Tilt your phone to roll the ball to the target." },
    'gm.ready_round':  { fr: 'Prêt pour la manche ?', en: 'Ready for the round?' },
    'gm.maze_ready_d': { fr: 'La bille apparaît en haut à gauche. La cible rouge est en bas à droite.', en: 'The ball starts top-left. The red target is bottom-right.' },
    'gm.gyro_wait':    { fr: 'Gyro en attente…', en: 'Gyro waiting…' },
    'gm.give_up':      { fr: 'Abandonner', en: 'Give up' },
    'gm.level':        { fr: 'Niveau', en: 'Level' },
    'gm.time':         { fr: 'Temps', en: 'Time' },
    'gm.penalties':    { fr: 'Pénalités', en: 'Penalties' },
    'gm.score':        { fr: 'Score', en: 'Score' },
    'gm.gyro_on':      { fr: 'Gyro actif', en: 'Gyro on' },
    'gm.hold_move':    { fr: 'Maintiens pour déplacer la bille', en: 'Hold to move the ball' },
    'gm.round':        { fr: 'Manche', en: 'Round' },
    'gm.next_level':   { fr: 'Niveau suivant →', en: 'Next level →' },
    'gm.restart':      { fr: 'Recommencer depuis le début', en: 'Restart from the beginning' },
    'gm.maze_done':    { fr: 'Labyrinthe complété !', en: 'Maze completed!' },
    'gm.maze_done_d':  { fr: 'Tu as activé cervelet, cortex pariétal et système vestibulaire.', en: 'You activated the cerebellum, parietal cortex and vestibular system.' },
    'gm.replay':       { fr: 'Rejouer', en: 'Play again' },
    'gm.home':         { fr: "Retour à l'accueil", en: 'Back to home' },
    'gm.start':        { fr: 'Commencer', en: 'Start' },
    'gm.ready':        { fr: 'Prêt ?', en: 'Ready?' },
    'gm.tetris_title': { fr: 'Tetris anti-craving', en: 'Anti-craving Tetris' },
    'gm.tetris_intro': { fr: "Complète des lignes pendant 3 minutes. Chaque palier de 10 lignes accélère la chute. L'objectif n'est pas le score : c'est d'occuper ton esprit.", en: "Clear lines for 3 minutes. Every 10 lines speeds up the fall. The goal isn't the score — it's to occupy your mind." },
    'gm.lines':        { fr: 'Lignes', en: 'Lines' },
    'gm.urge':         { fr: "Intensité de l'envie", en: 'Urge intensity' },
    'gm.tetris_ctrl':  { fr: 'Glisse sur la grille : ← → déplacer · tap = pivoter · ↓ chute rapide', en: 'Swipe on the grid: ← → move · tap = rotate · ↓ fast drop' }
  };

  function lang() {
    let l = null;
    try { l = localStorage.getItem(LANG_KEY); } catch (e) {}
    return (l && LANGS.indexOf(l) !== -1) ? l : 'fr';
  }

  function setLang(l) {
    if (LANGS.indexOf(l) === -1) return;
    try { localStorage.setItem(LANG_KEY, l); } catch (e) {}
    applyI18n();
    document.documentElement.setAttribute('lang', l);
    // notifier les pages qui ont du contenu dynamique à re-rendre
    document.dispatchEvent(new CustomEvent('langchange', { detail: { lang: l } }));
  }

  function t(keyOrObj, vars) {
    const l = lang();
    let s;
    if (keyOrObj && typeof keyOrObj === 'object') {
      // objet {fr,en,es,de} fourni directement
      s = keyOrObj[l] || keyOrObj.fr || '';
    } else {
      const entry = DICT[keyOrObj];
      s = entry ? (entry[l] || entry.fr) : keyOrObj;
    }
    if (vars) Object.keys(vars).forEach(k => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }

  /* Traduit tous les éléments porteurs d'attributs i18n */
  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      if (DICT[k]) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const k = el.getAttribute('data-i18n-html');
      if (DICT[k]) el.innerHTML = t(k);
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const k = el.getAttribute('data-i18n-ph');
      if (DICT[k]) el.setAttribute('placeholder', t(k));
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const k = el.getAttribute('data-i18n-aria');
      if (DICT[k]) el.setAttribute('aria-label', t(k));
    });
    // re-render nav (libellés traduits)
    const navEl = document.querySelector('.bottom-nav');
    if (navEl && navEl.getAttribute('data-page') !== null) {
      navEl.outerHTML = renderNav(navEl.getAttribute('data-page') || '');
    }
  }

  /* Sélecteur de langue : remplit tout [data-langselect] */
  function renderLangSelect() {
    document.querySelectorAll('[data-langselect]').forEach(host => {
      const cur = lang();
      host.innerHTML = '<div class="lang-select" style="display:inline-flex;gap:4px;background:var(--soft,#FBF8F1);padding:4px;border-radius:11px;">' +
        LANGS.map(l => '<button type="button" data-setlang="' + l + '" style="border:none;cursor:pointer;font-family:var(--font-editorial,Atkinson Hyperlegible Next,sans-serif);font-weight:var(--w-bold,700);font-size:var(--fs-xs,12px);padding:6px 11px;border-radius:8px;background:' +
          (l === cur ? 'var(--surface)' : 'transparent') + ';color:' + (l === cur ? 'var(--foret)' : 'var(--ink-2)') +
          (l === cur ? ';box-shadow:0 1px 3px rgba(31,43,37,.08)' : '') + ';">' + l.toUpperCase() + '</button>').join('') +
        '</div>';
      host.querySelectorAll('[data-setlang]').forEach(b => {
        b.addEventListener('click', () => { setLang(b.getAttribute('data-setlang')); renderLangSelect(); });
      });
    });
  }

  function user() {
    try { return (JSON.parse(localStorage.getItem(KEY)) || {}).user || null; }
    catch (e) { return null; }
  }

  function qs() {
    const u = user();
    if (!u || !u.name) return '';
    return '';
  }

  function link(href) {
    const q = qs();
    if (!q) return href;
    const i = href.indexOf('#');
    return i === -1 ? href + q : href.slice(0, i) + q + href.slice(i);
  }

  function logoSVG(size, mono) {
    size = size || 32;
    const ring = mono ? '#fff' : '#33463E';
    const bar  = mono ? '#fff' : '#1F2B25';
    return '<svg viewBox="0 0 48 48" width="' + size + '" height="' + size + '" fill="none" aria-label="MyDope Off">' +
      '<path d="M15.2 13.6a14 14 0 1 0 17.6 0" stroke="' + ring + '" stroke-width="5" stroke-linecap="round"/>' +
      '<line x1="24" y1="6" x2="24" y2="22" stroke="' + bar + '" stroke-width="5" stroke-linecap="round"/>' +
      '</svg>';
  }

  function appIcon(size) {
    size = size || 56;
    return '<span style="display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;border-radius:' + Math.round(size * .28) + 'px;background:linear-gradient(140deg,#33463E,#283A31);box-shadow:0 6px 18px rgba(51,70,62,.28);">' +
      logoSVG(Math.round(size * .56), true) + '</span>';
  }

  function wordmark() {
    return '<span style="font-family:var(--font-editorial,Atkinson Hyperlegible Next,sans-serif);font-weight:var(--w-medium,800);letter-spacing:var(--ls-title,-.02em);color:var(--ink,#1F2B25);white-space:nowrap;">MyDope <b style="color:var(--foret,#33463E);font-weight:var(--w-medium,800);">Off</b></span>';
  }

  /* Navigation — libellés via clés i18n */
  const NAV = [
    { k: 'index', href: 'index.html', tkey: 'nav.home',
      icon: '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { k: 'suivi', href: 'suivi.html', tkey: 'nav.tracking',
      icon: '<path d="M22 7L13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>' },
    { k: 'psychochecker', href: 'psychochecker.html', tkey: 'nav.substances',
      icon: '<path d="M11 11m-8 0a8 8 0 1 0 16 0 8 8 0 1 0-16 0"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' },
    { k: 'fiches', href: 'fiches.html', tkey: 'nav.protocols',
      icon: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
    { k: 'rdr', href: 'rdr.html', tkey: 'nav.rdr',
      icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
  ];

  function renderNav(active){ return window.MDNav ? MDNav.render(active||'') : ''; }

  function init(opts) {
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());

    document.querySelectorAll('[data-logo]').forEach(el => {
      el.innerHTML = logoSVG(parseInt(el.getAttribute('data-logo')) || 32, el.hasAttribute('data-mono'));
    });
    document.querySelectorAll('[data-appicon]').forEach(el => {
      el.innerHTML = appIcon(parseInt(el.getAttribute('data-appicon')) || 56);
    });
    document.querySelectorAll('[data-wordmark]').forEach(el => { el.innerHTML = wordmark(); });

    const nav = document.querySelector('[data-nav]');
    if (nav) if (nav && window.MDNav) nav.outerHTML = renderNav(opts.page || '');

    document.querySelectorAll('[data-go]').forEach(a => {
      a.setAttribute('href', link(a.getAttribute('data-go')));
    });

    document.querySelectorAll('[data-back]').forEach(b => {
      b.addEventListener('click', () => {
        if (window.history.length > 1 && document.referrer && document.referrer.indexOf(location.origin) === 0) {
          window.history.back();
        } else {
          location.href = link('index.html');
        }
      });
    });

    applyI18n();
    renderLangSelect();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  return { user, qs, link, logoSVG, appIcon, wordmark, renderNav, init,
           t, lang, setLang, applyI18n, renderLangSelect, LANGS, LANG_NAMES, DICT };
})();

/* ---- bloc suivant ---- */

function goBack(){ location.href=(window.LUCIDE?LUCIDE.link('fiches.html'):'fiches.html'); }
/* Le bouton retour de l'écran de fin était câblé par un attribut onclick inline, retiré pour
   permettre une CSP stricte. Le bouton principal (#ov-btn), lui, reçoit déjà son gestionnaire
   dynamiquement (b.onclick = btnFn), ce qui reste autorisé sous CSP. */
document.addEventListener('DOMContentLoaded', function(){
  var b2 = document.getElementById('ov-btn2');
  if (b2) b2.addEventListener('click', function(){ goBack(); });
});

const COLS=10, ROWS=20;
const cv=document.getElementById('board'), ctx=cv.getContext('2d');
const CELL=cv.width/COLS;
const PIECES=[
  [[1,1,1,1]],            // I
  [[1,1],[1,1]],          // O
  [[0,1,0],[1,1,1]],      // T
  [[0,1,1],[1,1,0]],      // S
  [[1,1,0],[0,1,1]],      // Z
  [[1,0,0],[1,1,1]],      // J
  [[0,0,1],[1,1,1]]       // L
];
const COLORS=['#69889A','#D5A84A','#C7765C','#7A8F72','#CBA8A0','#33463E','#9FB0A6'];

let board, piece, pieceX, pieceY, pieceType;
let score=0, lines=0, level=1, startLevel=1;
let running=false, paused=false, dropTimer=null, secTimer=null, secondsLeft=180;
let dropInterval=800;

function newBoard(){ return Array.from({length:ROWS},()=>Array(COLS).fill(0)); }
function speedFor(lv){ return Math.max(200, 800 - (lv-1)*45); }

function spawn(){
  const t=Math.floor(Math.random()*PIECES.length);
  piece=PIECES[t].map(r=>r.slice()); pieceType=t;
  pieceX=Math.floor((COLS-piece[0].length)/2); pieceY=0;
  if(!valid(piece,pieceX,pieceY)){ endGame(true); }
}
function valid(shape,ox,oy){
  for(let r=0;r<shape.length;r++)for(let c=0;c<shape[r].length;c++){
    if(!shape[r][c])continue;
    const nx=ox+c, ny=oy+r;
    if(nx<0||nx>=COLS||ny>=ROWS)return false;
    if(ny>=0&&board[ny][nx])return false;
  }
  return true;
}
function rotate(){
  if(!running||paused)return;
  const rot=piece[0].map((_,i)=>piece.map(row=>row[i]).reverse());
  if(valid(rot,pieceX,pieceY))piece=rot;
  else if(valid(rot,pieceX-1,pieceY)){piece=rot;pieceX--;}
  else if(valid(rot,pieceX+1,pieceY)){piece=rot;pieceX++;}
  draw();
}
function move(dir){ if(!running||paused)return; if(valid(piece,pieceX+dir,pieceY))pieceX+=dir; draw(); }
function softDrop(){ if(!running||paused)return; if(valid(piece,pieceX,pieceY+1)){pieceY++;score++;updateStats();} else lock(); draw(); }
function hardDrop(){ if(!running||paused)return; while(valid(piece,pieceX,pieceY+1)){pieceY++;score+=2;} lock(); }
function lock(){
  for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
    if(piece[r][c]&&pieceY+r>=0)board[pieceY+r][pieceX+c]=pieceType+1;
  clearLines(); spawn(); updateStats(); draw();
}
function clearLines(){
  let cleared=0;
  for(let r=ROWS-1;r>=0;r--){ if(board[r].every(c=>c)){ board.splice(r,1); board.unshift(Array(COLS).fill(0)); cleared++; r++; } }
  if(cleared){
    score+=[0,100,300,500,800][cleared]*level;
    lines+=cleared;
    if(cleared===4 && window.MDCompagnon){ try{ MDCompagnon.toast({mood:'celebration', text:'TETRIS ! Quatre lignes d\u2019un coup — magnifique.', duration:2600}); }catch(e){} }
    const nl=startLevel+Math.floor(lines/10);
    if(nl!==level){ level=nl; dropInterval=speedFor(level); restartDrop(); flashLevel(); }
    updateCraving();
  }
}
function flashLevel(){
  const el=document.getElementById('stat-level');
  el.style.transition='transform .15s'; el.style.transform='scale(1.4)'; el.style.color='var(--teal,#69889A)';
  setTimeout(()=>{el.style.transform='';el.style.color='';},220);
}
function updateStats(){
  document.getElementById('stat-score').textContent=score;
  document.getElementById('stat-lines').textContent=lines;
  document.getElementById('stat-level').textContent=level;
}
function updateCraving(){
  const pct=Math.max(0,100-Math.min(100,lines*4));
  document.getElementById('craving-fill').style.width=pct+'%';
  document.getElementById('craving-pct').textContent=pct+'%';
}
function draw(){
  ctx.fillStyle='#FBF8F1'; ctx.fillRect(0,0,cv.width,cv.height);
  ctx.strokeStyle='rgba(31,43,37,.06)';
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)ctx.strokeRect(c*CELL,r*CELL,CELL,CELL);
  if(!board)return;
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(board[r][c])dcell(c,r,COLORS[board[r][c]-1]);
  if(running&&piece){
    let gy=pieceY; while(valid(piece,pieceX,gy+1))gy++;
    if(gy!==pieceY)for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
      if(piece[r][c]){ctx.globalAlpha=.18;dcell(pieceX+c,gy+r,COLORS[pieceType]);ctx.globalAlpha=1;}
    for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
      if(piece[r][c]&&pieceY+r>=0)dcell(pieceX+c,pieceY+r,COLORS[pieceType]);
  }
}
function dcell(c,r,col){
  var x=c*CELL+1, y=r*CELL+1, s=CELL-2, rad=Math.max(2, CELL*0.20);
  ctx.fillStyle=col; ctx.beginPath();
  ctx.moveTo(x+rad,y); ctx.arcTo(x+s,y,x+s,y+s,rad); ctx.arcTo(x+s,y+s,x,y+s,rad);
  ctx.arcTo(x,y+s,x,y,rad); ctx.arcTo(x,y,x+s,y,rad); ctx.closePath(); ctx.fill();
}
function restartDrop(){
  if(dropTimer)clearInterval(dropTimer);
  dropTimer=setInterval(()=>{ if(!running||paused)return;
    if(valid(piece,pieceX,pieceY+1))pieceY++; else lock(); draw();
  },dropInterval);
}
function startTimer(){
  if(secTimer)clearInterval(secTimer);
  updateTime();
  secTimer=setInterval(()=>{ if(paused)return; secondsLeft--; updateTime(); if(secondsLeft<=0)finishSession(); },1000);
}
function updateTime(){
  const m=Math.floor(secondsLeft/60), s=secondsLeft%60;
  document.getElementById('stat-time').textContent=m+':'+String(s).padStart(2,'0');
}
function beginRound(){
  board=newBoard(); running=true; paused=false;
  dropInterval=speedFor(level); updateStats(); updateCraving();
  spawn(); draw(); restartDrop(); startTimer();
  document.getElementById('overlay').classList.remove('on');
  document.getElementById('ov-btn2').style.display='none';
}
function tetrisBegin(){
  if(window.MDJeuHero){
    MDJeuHero.rules({mood:'concentration', title:LUCIDE.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
      lines:[LUCIDE.t({fr:'Complète des lignes en déplaçant et en tournant les pièces.',en:'Clear lines by moving and rotating the pieces.'}),
             LUCIDE.t({fr:'Chaque palier de 10 lignes accélère la chute — pendant 3 minutes.',en:'Every 10 lines speeds up the fall — for 3 minutes.'}),
             LUCIDE.t({fr:"L'objectif n'est pas le score : c'est d'occuper ton esprit.",en:"The goal isn't the score: it's to occupy your mind."})],
      why:LUCIDE.t({fr:"Manipuler des formes visuospatiales sature la mémoire de travail utilisée par le craving : l'imagerie de l'envie s'estompe (paradigme Tetris, Oxford 2015).",
                    en:"Manipulating visuospatial shapes saturates the working memory used by craving: the mental imagery of the urge fades (Tetris paradigm, Oxford 2015)."}),
      onStart:function(avant){ window.__mdAvant=avant; startGame(); }});
  } else { startGame(); }
}
function startGame(){ score=0; lines=0; level=1; startLevel=1; secondsLeft=180; beginRound(); }
function nextLevel(){ startLevel=level+1; level=startLevel; secondsLeft=180; beginRound(); }
function togglePause(){
  if(!running)return;
  paused=!paused;
  const ov=document.getElementById('overlay');
  if(paused){ setOverlay(LUCIDE.t({fr:'Pause',en:'Pause'}),LUCIDE.t({fr:'Reprends quand tu veux.',en:'Resume whenever you want.'}),LUCIDE.t({fr:'Reprendre',en:'Resume'}),togglePause,true); }
  else ov.classList.remove('on');
}
function setOverlay(title,text,btnLabel,btnFn,hideBack){
  document.getElementById('ov-title').textContent=title;
  document.getElementById('ov-text').textContent=text;
  const b=document.getElementById('ov-btn'); b.textContent=btnLabel; b.onclick=btnFn;
  document.getElementById('ov-btn2').style.display=hideBack?'none':'block';
  document.getElementById('overlay').classList.add('on');
}
function finishSession(){
  running=false; clearInterval(dropTimer); clearInterval(secTimer);
  var r=saveSession();
  if(window.MDExercise) MDExercise.after('tetris',{avant:window.__mdAvant, meta:{lines:lines,score:score,level:level},
    title:LUCIDE.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
    stats:[{label:LUCIDE.t({fr:'lignes',en:'lines'}),value:lines},{label:LUCIDE.t({fr:'score',en:'score'}),value:score},{label:LUCIDE.t({fr:'niveau',en:'level'}),value:level}],
    nav:{ primary:{label:LUCIDE.t({fr:'Niveau suivant',en:'Next level'})} },
    onClose:function(){ nextLevel(); }});
}
function endGame(){
  running=false; clearInterval(dropTimer); clearInterval(secTimer);
  var r=saveSession();
  if(window.MDExercise) MDExercise.after('tetris',{avant:window.__mdAvant, meta:{lines:lines,score:score,level:level},
    title:LUCIDE.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
    stats:[{label:LUCIDE.t({fr:'lignes',en:'lines'}),value:lines},{label:LUCIDE.t({fr:'score',en:'score'}),value:score},{label:LUCIDE.t({fr:'niveau',en:'level'}),value:level}],
    nav:{ primary:{label:LUCIDE.t({fr:'Rejouer',en:'Replay'})} },
    onClose:function(){ window.__mdAvant=null; startGame(); }});
}
function saveSession(){
  var best=lines, isRec=false;
  try{
    const k='ctc_v6_suivi'; const d=JSON.parse(localStorage.getItem(k))||{entries:[],goals:[]};
    d.sessions=d.sessions||[];
    var prev=d.sessions.filter(function(x){return x.type==='tetris';}).reduce(function(m,x){return Math.max(m,x.lines||0);},0);
    d.sessions.push({type:'tetris',score:score,lines:lines,level:level,date:Date.now()});
    localStorage.setItem(k,JSON.stringify(d));
    best=Math.max(prev,lines); isRec=lines>prev && lines>0;
  }catch(e){}
  return {best:best,isRecord:isRec};
}

/* boutons : maintien = répétition */
function hold(id,fn,rep){
  const el=document.getElementById(id); let iv=null,to=null;
  const start=e=>{ e.preventDefault(); fn();
    if(rep){ to=setTimeout(()=>{ iv=setInterval(fn,70); },220); } };
  const stop=()=>{ clearTimeout(to); clearInterval(iv); };
  el.addEventListener('pointerdown',start);
  el.addEventListener('pointerup',stop);
  el.addEventListener('pointerleave',stop);
  el.addEventListener('pointercancel',stop);
}
hold('btn-left',()=>move(-1),true);
hold('btn-right',()=>move(1),true);
hold('btn-soft',softDrop,true);
document.getElementById('btn-rotate').addEventListener('pointerdown',e=>{e.preventDefault();rotate();});
document.getElementById('btn-hard').addEventListener('pointerdown',e=>{e.preventDefault();hardDrop();});
document.getElementById('btn-pause').addEventListener('pointerdown',e=>{e.preventDefault();togglePause();});

/* swipe sur le canvas */
let sx,sy,st,moved;
cv.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;st=Date.now();moved=false;});
cv.addEventListener('pointermove',e=>{
  if(!running||paused)return;
  const dx=e.clientX-sx;
  if(Math.abs(dx)>=CELL){ move(dx>0?1:-1); sx=e.clientX; moved=true; }
});
cv.addEventListener('pointerup',e=>{
  if(!running||paused)return;
  const dx=e.clientX-sx, dy=e.clientY-sy, dt=Date.now()-st;
  if(!moved&&Math.abs(dx)<12&&Math.abs(dy)<12&&dt<260){ rotate(); return; }
  if(dy>40&&Math.abs(dy)>Math.abs(dx)){ hardDrop(); }
});

/* Anti-scroll parasite : bloque le défilement uniquement sur le canvas (où se font les gestes
   de swipe), pas sur toute la page — les boutons de contrôle restent atteignables par scroll. */
cv.addEventListener('touchmove', function(e){ if(running && !paused) e.preventDefault(); }, {passive:false});

document.addEventListener('keydown',e=>{
  const m={ArrowLeft:()=>move(-1),ArrowRight:()=>move(1),ArrowDown:softDrop,ArrowUp:rotate,' ':hardDrop,p:togglePause};
  if(m[e.key]){ e.preventDefault(); m[e.key](); }
});

draw();
LUCIDE.init({page:'fiches'});
if(window.LUCIDE){LUCIDE.applyI18n();document.addEventListener('langchange',function(){LUCIDE.applyI18n();});}
tetrisBegin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page

/* ---- bloc suivant ---- */

try{MDCore.init({page:'tetris',section:'equilibre'});}catch(e){}
