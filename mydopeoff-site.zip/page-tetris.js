/* MyDope Off — page-tetris.js
   Scripts inline de tetris.html regroupés ici pour permettre une CSP stricte
   (script-src 'self'). Contenu inchangé, ordre d'origine préservé. */


/* ---- bloc suivant ---- */

function goBack(){ location.href=(window.MDCore?MDCore.link('fiches.html'):'fiches.html'); }
/* Le bouton retour de l'écran de fin était câblé par un attribut onclick inline, retiré pour
   permettre une CSP stricte. Le bouton principal (#ov-btn), lui, reçoit déjà son gestionnaire
   dynamiquement (b.onclick = btnFn), ce qui reste autorisé sous CSP. */
document.addEventListener('DOMContentLoaded', function(){
  var b2 = document.getElementById('ov-btn2');
  if (b2) b2.addEventListener('click', function(){ goBack(); });
});

const COLS=10, ROWS=20;
const cv=document.getElementById('board'), ctx=cv.getContext('2d');
const CELL=cv.width/COLS;
const PIECES=[
  [[1,1,1,1]],            // I
  [[1,1],[1,1]],          // O
  [[0,1,0],[1,1,1]],      // T
  [[0,1,1],[1,1,0]],      // S
  [[1,1,0],[0,1,1]],      // Z
  [[1,0,0],[1,1,1]],      // J
  [[0,0,1],[1,1,1]]       // L
];
const COLORS=['#69889A','#D5A84A','#C7765C','#7A8F72','#CBA8A0','#33463E','#9FB0A6'];

let board, piece, pieceX, pieceY, pieceType;
let score=0, lines=0, level=1, startLevel=1;
let running=false, paused=false, dropTimer=null, secTimer=null, secondsLeft=180;
let dropInterval=800;

function newBoard(){ return Array.from({length:ROWS},()=>Array(COLS).fill(0)); }
function speedFor(lv){ return Math.max(200, 800 - (lv-1)*45); }

function spawn(){
  const t=Math.floor(Math.random()*PIECES.length);
  piece=PIECES[t].map(r=>r.slice()); pieceType=t;
  pieceX=Math.floor((COLS-piece[0].length)/2); pieceY=0;
  if(!valid(piece,pieceX,pieceY)){ endGame(true); }
}
function valid(shape,ox,oy){
  for(let r=0;r<shape.length;r++)for(let c=0;c<shape[r].length;c++){
    if(!shape[r][c])continue;
    const nx=ox+c, ny=oy+r;
    if(nx<0||nx>=COLS||ny>=ROWS)return false;
    if(ny>=0&&board[ny][nx])return false;
  }
  return true;
}
function rotate(){
  if(!running||paused)return;
  const rot=piece[0].map((_,i)=>piece.map(row=>row[i]).reverse());
  if(valid(rot,pieceX,pieceY))piece=rot;
  else if(valid(rot,pieceX-1,pieceY)){piece=rot;pieceX--;}
  else if(valid(rot,pieceX+1,pieceY)){piece=rot;pieceX++;}
  draw();
}
function move(dir){ if(!running||paused)return; if(valid(piece,pieceX+dir,pieceY))pieceX+=dir; draw(); }
function softDrop(){ if(!running||paused)return; if(valid(piece,pieceX,pieceY+1)){pieceY++;score++;updateStats();} else lock(); draw(); }
function hardDrop(){ if(!running||paused)return; while(valid(piece,pieceX,pieceY+1)){pieceY++;score+=2;} lock(); }
function lock(){
  for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
    if(piece[r][c]&&pieceY+r>=0)board[pieceY+r][pieceX+c]=pieceType+1;
  clearLines(); spawn(); updateStats(); draw();
}
function clearLines(){
  let cleared=0;
  for(let r=ROWS-1;r>=0;r--){ if(board[r].every(c=>c)){ board.splice(r,1); board.unshift(Array(COLS).fill(0)); cleared++; r++; } }
  if(cleared){
    score+=[0,100,300,500,800][cleared]*level;
    lines+=cleared;
    if(cleared===4 && window.MDCompagnon){ try{ MDCompagnon.toast({mood:'celebration', text:'TETRIS ! Quatre lignes d\u2019un coup — magnifique.', duration:2600}); }catch(e){} }
    const nl=startLevel+Math.floor(lines/10);
    if(nl!==level){ level=nl; dropInterval=speedFor(level); restartDrop(); flashLevel(); }
    updateCraving();
  }
}
function flashLevel(){
  const el=document.getElementById('stat-level');
  el.style.transition='transform .15s'; el.style.transform='scale(1.4)'; el.style.color='var(--teal,#69889A)';
  setTimeout(()=>{el.style.transform='';el.style.color='';},220);
}
function updateStats(){
  document.getElementById('stat-score').textContent=score;
  document.getElementById('stat-lines').textContent=lines;
  document.getElementById('stat-level').textContent=level;
}
function updateCraving(){
  const pct=Math.max(0,100-Math.min(100,lines*4));
  document.getElementById('craving-fill').style.width=pct+'%';
  document.getElementById('craving-pct').textContent=pct+'%';
}
function draw(){
  ctx.fillStyle='#FBF8F1'; ctx.fillRect(0,0,cv.width,cv.height);
  ctx.strokeStyle='rgba(31,43,37,.06)';
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)ctx.strokeRect(c*CELL,r*CELL,CELL,CELL);
  if(!board)return;
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(board[r][c])dcell(c,r,COLORS[board[r][c]-1]);
  if(running&&piece){
    let gy=pieceY; while(valid(piece,pieceX,gy+1))gy++;
    if(gy!==pieceY)for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
      if(piece[r][c]){ctx.globalAlpha=.18;dcell(pieceX+c,gy+r,COLORS[pieceType]);ctx.globalAlpha=1;}
    for(let r=0;r<piece.length;r++)for(let c=0;c<piece[r].length;c++)
      if(piece[r][c]&&pieceY+r>=0)dcell(pieceX+c,pieceY+r,COLORS[pieceType]);
  }
}
function dcell(c,r,col){
  var x=c*CELL+1, y=r*CELL+1, s=CELL-2, rad=Math.max(2, CELL*0.20);
  ctx.fillStyle=col; ctx.beginPath();
  ctx.moveTo(x+rad,y); ctx.arcTo(x+s,y,x+s,y+s,rad); ctx.arcTo(x+s,y+s,x,y+s,rad);
  ctx.arcTo(x,y+s,x,y,rad); ctx.arcTo(x,y,x+s,y,rad); ctx.closePath(); ctx.fill();
}
function restartDrop(){
  if(dropTimer)clearInterval(dropTimer);
  dropTimer=setInterval(()=>{ if(!running||paused)return;
    if(valid(piece,pieceX,pieceY+1))pieceY++; else lock(); draw();
  },dropInterval);
}
function startTimer(){
  if(secTimer)clearInterval(secTimer);
  updateTime();
  secTimer=setInterval(()=>{ if(paused)return; secondsLeft--; updateTime(); if(secondsLeft<=0)finishSession(); },1000);
}
function updateTime(){
  const m=Math.floor(secondsLeft/60), s=secondsLeft%60;
  document.getElementById('stat-time').textContent=m+':'+String(s).padStart(2,'0');
}
function beginRound(){
  board=newBoard(); running=true; paused=false;
  dropInterval=speedFor(level); updateStats(); updateCraving();
  spawn(); draw(); restartDrop(); startTimer();
  document.getElementById('overlay').classList.remove('on');
  document.getElementById('ov-btn2').style.display='none';
}
function tetrisBegin(){
  if(window.MDJeuHero){
    MDJeuHero.rules({mood:'concentration', title:MDCore.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
      lines:[MDCore.t({fr:'Complète des lignes en déplaçant et en tournant les pièces.',en:'Clear lines by moving and rotating the pieces.'}),
             MDCore.t({fr:'Chaque palier de 10 lignes accélère la chute — pendant 3 minutes.',en:'Every 10 lines speeds up the fall — for 3 minutes.'}),
             MDCore.t({fr:"L'objectif est d'occuper ton esprit, pas de faire un score.",en:"The goal is to occupy your mind, not to score."})],
      why:MDCore.t({fr:"Manipuler des formes visuospatiales sature la mémoire de travail utilisée par le craving : l'imagerie de l'envie s'estompe (paradigme Tetris, Oxford 2015).",
                    en:"Manipulating visuospatial shapes saturates the working memory used by craving: the mental imagery of the urge fades (Tetris paradigm, Oxford 2015)."}),
      onStart:function(avant){ window.__mdAvant=avant; startGame(); }});
  } else { startGame(); }
}
function startGame(){ score=0; lines=0; level=1; startLevel=1; secondsLeft=180; beginRound(); }
function nextLevel(){ startLevel=level+1; level=startLevel; secondsLeft=180; beginRound(); }
function togglePause(){
  if(!running)return;
  paused=!paused;
  const ov=document.getElementById('overlay');
  if(paused){ setOverlay(MDCore.t({fr:'Pause',en:'Pause'}),MDCore.t({fr:'Reprends quand tu veux.',en:'Resume whenever you want.'}),MDCore.t({fr:'Reprendre',en:'Resume'}),togglePause,true); }
  else ov.classList.remove('on');
}
function setOverlay(title,text,btnLabel,btnFn,hideBack){
  document.getElementById('ov-title').textContent=title;
  document.getElementById('ov-text').textContent=text;
  const b=document.getElementById('ov-btn'); b.textContent=btnLabel; b.onclick=btnFn;
  document.getElementById('ov-btn2').style.display=hideBack?'none':'block';
  document.getElementById('overlay').classList.add('on');
}
function finishSession(){
  running=false; clearInterval(dropTimer); clearInterval(secTimer);
  var r=saveSession();
  if(window.MDExercise) MDExercise.after('tetris',{avant:window.__mdAvant, meta:{lines:lines,score:score,level:level},
    title:MDCore.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
    stats:[{label:MDCore.t({fr:'lignes',en:'lines'}),value:lines},{label:MDCore.t({fr:'score',en:'score'}),value:score},{label:MDCore.t({fr:'niveau',en:'level'}),value:level}],
    nav:{ primary:{label:MDCore.t({fr:'Niveau suivant',en:'Next level'})} },
    onClose:function(){ nextLevel(); }});
}
function endGame(){
  running=false; clearInterval(dropTimer); clearInterval(secTimer);
  var r=saveSession();
  if(window.MDExercise) MDExercise.after('tetris',{avant:window.__mdAvant, meta:{lines:lines,score:score,level:level},
    title:MDCore.t({fr:'Tetris anti-craving',en:'Anti-craving Tetris'}),
    stats:[{label:MDCore.t({fr:'lignes',en:'lines'}),value:lines},{label:MDCore.t({fr:'score',en:'score'}),value:score},{label:MDCore.t({fr:'niveau',en:'level'}),value:level}],
    nav:{ primary:{label:MDCore.t({fr:'Rejouer',en:'Replay'})} },
    onClose:function(){ window.__mdAvant=null; startGame(); }});
}
function saveSession(){
  var best=lines, isRec=false;
  try{
    const k='ctc_v6_suivi'; const d=JSON.parse(localStorage.getItem(k))||{entries:[],goals:[]};
    d.sessions=d.sessions||[];
    var prev=d.sessions.filter(function(x){return x.type==='tetris';}).reduce(function(m,x){return Math.max(m,x.lines||0);},0);
    d.sessions.push({type:'tetris',score:score,lines:lines,level:level,date:Date.now()});
    localStorage.setItem(k,JSON.stringify(d));
    best=Math.max(prev,lines); isRec=lines>prev && lines>0;
  }catch(e){}
  return {best:best,isRecord:isRec};
}

/* boutons : maintien = répétition */
function hold(id,fn,rep){
  const el=document.getElementById(id); let iv=null,to=null;
  const start=e=>{ e.preventDefault(); fn();
    if(rep){ to=setTimeout(()=>{ iv=setInterval(fn,70); },220); } };
  const stop=()=>{ clearTimeout(to); clearInterval(iv); };
  el.addEventListener('pointerdown',start);
  el.addEventListener('pointerup',stop);
  el.addEventListener('pointerleave',stop);
  el.addEventListener('pointercancel',stop);
}
hold('btn-left',()=>move(-1),true);
hold('btn-right',()=>move(1),true);
hold('btn-soft',softDrop,true);
document.getElementById('btn-rotate').addEventListener('pointerdown',e=>{e.preventDefault();rotate();});
document.getElementById('btn-hard').addEventListener('pointerdown',e=>{e.preventDefault();hardDrop();});
document.getElementById('btn-pause').addEventListener('pointerdown',e=>{e.preventDefault();togglePause();});

/* swipe sur le canvas */
let sx,sy,st,moved;
cv.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;st=Date.now();moved=false;});
cv.addEventListener('pointermove',e=>{
  if(!running||paused)return;
  const dx=e.clientX-sx;
  if(Math.abs(dx)>=CELL){ move(dx>0?1:-1); sx=e.clientX; moved=true; }
});
cv.addEventListener('pointerup',e=>{
  if(!running||paused)return;
  const dx=e.clientX-sx, dy=e.clientY-sy, dt=Date.now()-st;
  if(!moved&&Math.abs(dx)<12&&Math.abs(dy)<12&&dt<260){ rotate(); return; }
  if(dy>40&&Math.abs(dy)>Math.abs(dx)){ hardDrop(); }
});

/* Anti-scroll parasite : bloque le défilement uniquement sur le canvas (où se font les gestes
   de swipe), pas sur toute la page — les boutons de contrôle restent atteignables par scroll. */
cv.addEventListener('touchmove', function(e){ if(running && !paused) e.preventDefault(); }, {passive:false});

document.addEventListener('keydown',e=>{
  const m={ArrowLeft:()=>move(-1),ArrowRight:()=>move(1),ArrowDown:softDrop,ArrowUp:rotate,' ':hardDrop,p:togglePause};
  if(m[e.key]){ e.preventDefault(); m[e.key](); }
});

draw();

if(window.MDCore){MDCore.applyI18n();document.addEventListener('langchange',function(){MDCore.applyI18n();});}
tetrisBegin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page

/* ---- bloc suivant ---- */

try{MDCore.init({page:'tetris',section:'equilibre'});}catch(e){}
