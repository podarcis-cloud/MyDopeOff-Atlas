/* MyDope Off — fiches substances ajoutées via la page d'administration.
   Ce fichier est (re)généré par admin.html → « Exporter pour le dépôt ».
   Dépose-le à la racine du dépôt pour rendre les fiches permanentes pour tous.
   Format : window.MD_CUSTOM_FICHES = [{nom, categories[], addiction, effets[],
            dosage{faible,modere,fort}, duree, tripReport, description, aliases[],
            source, verifie_le}] */
window.MD_CUSTOM_FICHES = [];
