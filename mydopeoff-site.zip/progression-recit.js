/* progression-recit.js — la mascotte reflète le chemin parcouru, en phrases, pas en tableau.
   Jamais de score global, jamais de comparaison — une lecture narrative des données déjà
   existantes (axes, valeurs, bilans, sessions). Construit le sentiment de capacité d'agir,
   pas juste une ambiance : chaque phrase s'appuie sur une donnée réelle ou ne s'affiche pas. */
(function () {
  'use strict';

  var AXES_LABELS = { inhib: 'du contrôle inhibiteur', emo: 'de la résilience émotionnelle', attn: 'de l\u2019attention', envies: 'de la gestion des envies', stab: 'de la stabilité comportementale' };

  function read() { try { return window.MDData ? window.MDData.getCtc() : JSON.parse(localStorage.getItem('ctc_v6') || '{}'); } catch (e) { return {}; } }
  function joursActifs(ss) { var d = {}; ss.forEach(function (s) { d[Math.floor((s.date || 0) / 86400000)] = 1; }); return Object.keys(d).length; }

  function buildRecit() {
    var o = read();
    var sessions = (window.MDData ? window.MDData.getSessions() : (Array.isArray(o.sessions) ? o.sessions : []));
    var axes = (o.parcours && o.parcours.axes) || {};
    var valeurs = (window.MDData && window.MDData.getValeurs) ? window.MDData.getValeurs() : [];
    var days = joursActifs(sessions);
    var bits = [];

    // 1. Ouverture — jamais la même selon l'ancienneté réelle
    if (sessions.length === 0) {
      bits.push('Il n\u2019y a encore rien à raconter — et c\u2019est exactement là qu\u2019il faut être pour commencer.');
      return bits;
    } else if (days === 1) {
      bits.push('Une première trace, aujourd\u2019hui. Le reste s\u2019écrit à partir de là.');
    } else {
      bits.push('Tu es revenu·e sur ' + days + ' jours différents \u2014 sans routine imposée, sans série à ne pas casser.');
    }

    // 2. L'axe le plus avancé, nommé précisément (jamais un chiffre seul)
    var topKey = null, topVal = -1;
    Object.keys(AXES_LABELS).forEach(function (k) {
      if ((axes[k] || 0) > topVal) { topVal = axes[k] || 0; topKey = k; }
    });
    if (topKey && topVal >= 15) {
      bits.push('C\u2019est du côté ' + AXES_LABELS[topKey] + ' que le chemin est le plus visible pour l\u2019instant.');
    }

    // 3. Une valeur personnelle, si elle existe, réintégrée au récit
    if (valeurs.length) {
      bits.push('Tu as dit que « ' + valeurs[Math.floor(Math.random() * valeurs.length)] + ' » comptait pour toi \u2014 ça reste le fil derrière tout ce qui précède.');
    }

    // 4. Tendance récente si un bilan existe, sans jamais dramatiser une baisse
    try {
      var bs = window.MDData && window.MDData.getBilanState ? window.MDData.getBilanState() : null;
      if (bs && bs.craving && bs.craving.daysAgo != null && bs.craving.daysAgo <= 14) {
        if (bs.craving.improving) bits.push('Le dernier point que tu as fait sur l\u2019envie montre une tendance qui s\u2019apaise \u2014 pas un hasard isolé.');
        else bits.push('Le dernier point que tu as fait est resté stable \u2014 ni un recul, ni un signal d\u2019alarme, juste où tu en es.');
      }
    } catch (e) { }

    // 5. Motif d'usage — le type d'exercice le plus pratiqué, sans jamais comparer à personne d'autre
    var KNOWN_TYPES = { tetris:1, maze:1, breathe:1, surf:1, echo:1, braise:1, filtre:1, patience:1, virage:1, dualtask:1, elan:1, inhib:1, antisabotage:1, lettre:1 };
    var counts = {};
    sessions.forEach(function (s) { if (s.type && KNOWN_TYPES[s.type]) counts[s.type] = (counts[s.type] || 0) + 1; });
    var topType = null, topCount = 0;
    Object.keys(counts).forEach(function (k) { if (counts[k] > topCount) { topCount = counts[k]; topType = k; } });
    if (topType && topCount >= 3) {
      bits.push('C\u2019est vers ' + humanExerciseName(topType) + ' que tu reviens le plus souvent \u2014 il y a sûrement une raison, même si elle n\u2019a pas besoin d\u2019être formulée.');
    }

    // 6. Clôture — jamais un score, toujours ramené à l'acte de revenir
    bits.push('Rien de tout ça n\u2019est un score à battre. C\u2019est ce qui s\u2019est passé, parce que tu es revenu·e.');

    return bits;
  }

  function humanExerciseName(type) {
    var names = { tetris: 'Tetris', maze: 'Labyrinthe', breathe: 'Souffle', surf: 'Surf', echo: '\u00c9cho', braise: 'Braise', filtre: 'Filtre', patience: 'Patience', virage: 'Virage', dualtask: 'Double t\u00e2che', elan: '\u00c9lan', inhib: 'Contr\u00f4le du frein', antisabotage: 'Plan anti-sabotage', lettre: 'la lettre au futur toi' };
    return names[type] || type;
  }

  function injectCSS() {
    if (document.getElementById('pr-css')) return;
    var s = document.createElement('style'); s.id = 'pr-css';
    s.textContent =
      '.pr-ov{z-index:var(--z-modal-1,3800);align-items:flex-start;justify-content:center;padding:20px;background:rgba(31,43,37,.55);backdrop-filter:blur(3px)}' +
      '.pr-card{position:relative;max-width:400px;width:100%;border-radius:22px;padding:22px 20px;margin:auto;box-shadow:0 22px 60px rgba(31,43,37,.3)}' +
      '.pr-hero{display:flex;justify-content:center;margin-bottom:10px}' +
      '.pr-title{font-family:var(--font-editorial);font-size:var(--fs-h3);text-align:center;margin:0 0 14px;color:var(--ink)}' +
      '.pr-bit{font-family:var(--font-human);font-size:var(--fs-ui);line-height:var(--lh-normal);color:var(--ink);margin:0 0 12px}' +
      '.pr-go{width:100%;border:none;border-radius:14px;background:var(--foret);color:#fff;font-weight:var(--w-bold);font-size:var(--fs-ui);padding:13px;cursor:pointer;margin-top:8px}';
    document.head.appendChild(s);
  }

  function open() {
    injectCSS();
    var bits = buildRecit();
    var days = 0;
    try { var s = (window.MDData ? window.MDData.getSessions() : []); days = joursActifs(s); } catch (e) {}
    var mood = days >= 5 ? 'horizon' : 'introspection';
    var ov = document.createElement('div'); ov.className = 'pr-ov md-ov';
    var av = window.MDCompagnon && window.MDCompagnon.avatarHTML ? window.MDCompagnon.avatarHTML(mood, { size: 56 }) : '';
    ov.innerHTML =
      '<div class="pr-card md-card">' +
        '<div class="pr-hero">' + av + '</div>' +
        '<p class="pr-title">Ton chemin, tel qu\u2019il est</p>' +
        bits.map(function (b) { return '<p class="pr-bit">' + b + '</p>'; }).join('') +
        '<button type="button" class="pr-go" data-act="close">Fermer</button>' +
      '</div>';
    document.body.appendChild(ov);
    ov.querySelector('[data-act="close"]').addEventListener('click', function () { ov.remove(); });
  }

  window.MDProgressionRecit = { open: open, buildRecit: buildRecit };
})();
