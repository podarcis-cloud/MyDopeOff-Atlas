/* MyDope Off — backup.js (v2)
   Sauvegarde / restauration locale COMPLÈTE (anti-perte). Aucune donnée ne sort
   de l'appareil : on exporte un fichier .json (réglages + suivi + objectifs +
   parcours + bilans depuis localStorage, ET les lettres vidéo/audio depuis
   IndexedDB), que la personne garde dans ses Fichiers et peut réimporter
   (autre navigateur, cache vidé, navigation privée, nouveau téléphone…). */
(function(){
  'use strict';

  /* ---- helpers binaire <-> base64 ---- */
  function abToB64(ab){
    var bytes=new Uint8Array(ab), bin='', chunk=0x8000;
    for(var i=0;i<bytes.length;i+=chunk){ bin+=String.fromCharCode.apply(null, bytes.subarray(i, i+chunk)); }
    return btoa(bin);
  }
  function b64ToAb(b64){
    var bin=atob(b64), len=bin.length, bytes=new Uint8Array(len);
    for(var i=0;i<len;i++) bytes[i]=bin.charCodeAt(i);
    return bytes.buffer;
  }
  function blobToAb(b){ return b.arrayBuffer ? b.arrayBuffer() : new Promise(function(res,rej){ var fr=new FileReader(); fr.onload=function(){res(fr.result);}; fr.onerror=function(){rej(fr.error);}; fr.readAsArrayBuffer(b); }); }

  /* ---- IndexedDB lettres (mdletters / letters) ---- */
  function openDB(){ return new Promise(function(res,rej){ try{ var r=indexedDB.open('mdletters',1); r.onupgradeneeded=function(){ var d=r.result; if(!d.objectStoreNames.contains('letters')) d.createObjectStore('letters',{keyPath:'id'}); }; r.onsuccess=function(){res(r.result);}; r.onerror=function(){rej(r.error);}; }catch(e){ rej(e); } }); }
  function readLetters(){
    return openDB().then(function(d){ return new Promise(function(res){
      try{ var rq=d.transaction('letters','readonly').objectStore('letters').getAll(); rq.onsuccess=function(){res(rq.result||[]);}; rq.onerror=function(){res([]);}; }
      catch(e){ res([]); }
    }); }).catch(function(){ return []; });
  }
  function writeLetters(list){
    if(!list || !list.length) return Promise.resolve();
    return openDB().then(function(d){ return new Promise(function(res){
      var tx=d.transaction('letters','readwrite'), st=tx.objectStore('letters');
      list.forEach(function(rec){ try{ st.put(rec); }catch(e){} });
      tx.oncomplete=function(){res();}; tx.onerror=function(){res();}; tx.onabort=function(){res();};
    }); }).catch(function(){});
  }

  /* ---- EXPORT ---- */
  function gatherStore(){ var s={}; try{ for(var i=0;i<localStorage.length;i++){ var k=localStorage.key(i); s[k]=localStorage.getItem(k); } }catch(e){} return s; }

  function exportData(done){
    var data={ _app:'MyDopeOff', _v:2, _date:new Date().toISOString(), store:gatherStore(), letters:[] };
    readLetters().then(function(recs){
      var jobs=recs.map(function(rec){
        var meta={ id:rec.id, date:rec.date, kind:rec.kind, text:rec.text||'', mime:rec.mime||'' };
        var src = rec.data ? Promise.resolve(rec.data) : (rec.blob ? blobToAb(rec.blob) : Promise.resolve(null));
        return src.then(function(ab){ if(ab){ try{ meta.dataB64=abToB64(ab); }catch(e){} } return meta; });
      });
      return Promise.all(jobs);
    }).then(function(letters){
      data.letters=letters||[];
      var blob=new Blob([JSON.stringify(data)],{type:'application/json'});
      var d=new Date(); function p(n){return (n<10?'0':'')+n;}
      var name='mydopeoff-sauvegarde-'+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'-'+p(d.getHours())+p(d.getMinutes())+'.json';
      var url=URL.createObjectURL(blob), a=document.createElement('a');
      a.href=url; a.download=name; a.rel='noopener'; document.body.appendChild(a); a.click();
      setTimeout(function(){ a.remove(); URL.revokeObjectURL(url); },1500);
      done && done(true, (data.letters||[]).length);
    }).catch(function(){ done && done(false,0); });
  }

  /* ---- IMPORT ---- */
  function importData(file, done){
    var r=new FileReader();
    r.onload=function(){
      try{
        var o=JSON.parse(r.result);
        var store=(o && typeof o.store==='object') ? o.store : o;
        if(!store || typeof store!=='object') throw 0;
        Object.keys(store).forEach(function(k){ try{ localStorage.setItem(k, store[k]); }catch(e){} });
        var letters=(o && o.letters && o.letters.length) ? o.letters.map(function(m){
          var rec={ id:m.id, date:m.date, kind:m.kind, text:m.text||'', mime:m.mime||'' };
          if(m.dataB64){ try{ rec.data=b64ToAb(m.dataB64); }catch(e){} }
          return rec;
        }) : [];
        writeLetters(letters).then(function(){ done && done(true); });
      }catch(e){ done && done(false); }
    };
    r.onerror=function(){ done && done(false); };
    r.readAsText(file);
  }

  function confirmAndImport(file){
    if(!window.confirm('Restaurer cette sauvegarde ? Tes données actuelles sur cet appareil seront remplacées.')) return;
    importData(file, function(ok){
      if(ok){ window.alert('Données restaurées. La page va se recharger.'); location.reload(); }
      else { window.alert('Fichier de sauvegarde invalide.'); }
    });
  }

  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    var ex=document.getElementById('bk-export');
    if(ex) ex.addEventListener('click', function(){
      ex.disabled=true; ex.textContent='Préparation…';
      exportData(function(ok,nL){
        ex.disabled=false;
        ex.textContent = ok ? ('✓ Sauvegardé'+(nL?(' ('+nL+' lettre'+(nL>1?'s':'')+')'):'')) : '✗ Échec — réessaie';
        setTimeout(function(){ ex.textContent='⬇ Sauvegarder mes données'; }, 2600);
      });
    });
    var imp=document.getElementById('bk-import'), f=document.getElementById('bk-file');
    if(imp && f){ imp.addEventListener('click', function(){ f.value=''; f.click(); }); f.addEventListener('change', function(){ if(f.files && f.files[0]) confirmAndImport(f.files[0]); }); }
  });

  window.MDBackup={ exportData:exportData, importData:importData };
})();
