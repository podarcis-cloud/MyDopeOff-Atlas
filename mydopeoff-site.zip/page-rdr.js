/* MyDope Off — logique de page : rdr.html (externalisée pour CSP script-src 'self') */
/* Libellés propres à cette page (centralisés -> fusionnés dans MD_DICT). */
(function(){
  var T = {
    'rdr.title':{fr:'RDR & urgences',en:'Harm reduction & emergencies'},
    'rdr.tab_emerg':{fr:'Urgences',en:'Emergencies'},
    'rdr.tab_rdr':{fr:'RDR',en:'Harm red.'},
    'rdr.tab_centres':{fr:'Centres',en:'Centres'},
    'rdr.tab_legal':{fr:'Légal',en:'Legal'},
    'rdr.controls_t':{fr:'Alcool, stupéfiants & conduite',en:'Alcohol, drugs & driving'},
    'rdr.controls_d':{fr:"Ce que vérifie un contrôle, durées de détection, comment l'éviter vraiment.",en:'What a stop checks, detection times, how to actually avoid it.'},
    'rdr.sec_overdose':{fr:'Overdose — réagir',en:'Overdose — act'},
    'rdr.od_t':{fr:"Protocole : suspicion d'overdose",en:'Protocol: suspected overdose'},
    'rdr.nalox_t':{fr:'Naloxone (anti-overdose opioïde)',en:'Naloxone (opioid overdose)'},
    'rdr.nalox_d':{fr:"Inverse une overdose opioïde en 2–5 min. Sans effet sur l'alcool, les benzos ou la xylazine — l'administrer quand même et appeler les secours.",en:'Reverses an opioid overdose in 2–5 min. No effect on alcohol, benzos or xylazine — give it anyway and call emergency services.'},
    'rdr.sec_principles':{fr:'Principes fondamentaux',en:'Core principles'},
    'rdr.p1_t':{fr:'Jamais consommer seul·e',en:'Never use alone'},
    'rdr.p1_d':{fr:'Préviens une personne de confiance. En cas de malaise, il faut quelqu\u2019un sur place.',en:'Tell someone you trust. If something goes wrong, you need someone there.'},
    'rdr.p2_t':{fr:'Commencer bas, aller lentement',en:'Start low, go slow'},
    'rdr.p2_d':{fr:'Pureté inconnue : dose test de 10–20 %, attendre la montée (≥ 90 min en oral) avant de redoser.',en:'Unknown purity: test dose of 10–20%, wait for onset (≥ 90 min oral) before re-dosing.'},
    'rdr.p3_t':{fr:'Faire analyser son produit',en:'Get your drugs checked'},
    'rdr.p3_d':{fr:"Les services d'analyse identifient la substance et alertent sur les lots dangereux. Voir l'onglet Centres.",en:'Drug-checking services identify the substance and flag dangerous batches. See the Centres tab.'},
    'rdr.p4_t':{fr:'Jamais mélanger sans vérifier',en:'Never mix without checking'},
    'rdr.p4_d':{fr:'Alcool + opioïde/benzo, GHB + alcool, IMAO + sérotoninergique = combinaisons mortelles. Vérifie dans le PSYCHOchecker.',en:'Alcohol + opioid/benzo, GHB + alcohol, MAOI + serotonergic = deadly combos. Check the PSYCHOchecker.'},
    'rdr.p5_t':{fr:'Sevrage alcool & benzodiazépines',en:'Alcohol & benzo withdrawal'},
    'rdr.p5_d':{fr:'Ne JAMAIS arrêter brutalement seul·e : le sevrage peut provoquer convulsions et delirium potentiellement mortels. Arrêt encadré médicalement.',en:'NEVER stop abruptly alone: withdrawal can cause seizures and delirium that may be fatal. Taper under medical supervision.'},
    'rdr.ai_note':{fr:"Assistant IA : bientôt. Pour protéger ta vie privée, l'assistant ne s'activera qu'à travers un relais sécurisé — aucune donnée envoyée à un tiers sans ton accord, aucune clé dans l'application.",en:'AI assistant: coming soon. To protect your privacy it will only run through a secure relay — no data sent to a third party without your consent, no key in the app.'},
    'rdr.legal_disclaimer':{fr:"Information éducative, pas un conseil juridique. Les lois évoluent : vérifie la date et confirme auprès d'une source officielle.",en:'Educational info, not legal advice. Laws change: check the date and confirm with an official source.'},
    'rdr.sec_emerg':{fr:'Urgences',en:'Emergencies'},
    'rdr.sec_allnum':{fr:'Tous les numéros',en:'All numbers'},
    'rdr.sec_advice':{fr:'Conseils locaux',en:'Local tips'},
    'rdr.sec_centres':{fr:'Centres spécialisés',en:'Specialised centres'},
    'rdr.sec_testing':{fr:"Analyse de produit",en:'Drug-checking'},
    'rdr.sec_groups':{fr:"Groupes d'entraide",en:'Support groups'},
    'rdr.leg_cannabis':{fr:'Cannabis',en:'Cannabis'},
    'rdr.leg_other':{fr:'Autres drogues',en:'Other drugs'},
    'rdr.leg_driving':{fr:'Au volant',en:'Driving'},
    'rdr.leg_samaritan':{fr:'Appeler les secours',en:'Calling for help'},
    'rdr.verified':{fr:'Vérifié',en:'Verified'},
    'od.s1':{fr:'1. Appelle le {n} (urgences) immédiatement.',en:'1. Call {n} (emergency) immediately.'},
    'od.s2':{fr:'2. Mets la personne en Position Latérale de Sécurité (PLS).',en:'2. Put the person in the recovery position.'},
    'od.s3':{fr:'3. Surveille la respiration ; parle-lui, stimule-la.',en:'3. Monitor breathing; talk to and stimulate them.'},
    'od.s4':{fr:'4. Si opioïde possible : naloxone (nasale ou IM), même en cas de doute.',en:'4. If opioids possible: naloxone (nasal or IM), even if unsure.'},
    'od.s5':{fr:'5. Ne laisse jamais la personne seule jusqu\u2019aux secours.',en:'5. Never leave the person alone until help arrives.'}
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k]=T[k]; });
})();

MDCore.init({ page:'rdr' });

/* ---- Rendu régionalisé (lit regions.js + langue courante) ---- */
var esc = function(s){ return String(s).replace(/[&<>"]/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m];}); };
var T = function(k,v){ return MDCore.t(k,v); };
// Traduction des descriptions régionales si rdr-i18n.js présent (sinon FR source)
function trDesc(s){
  try{ var d=(window.LUCIDE_RDR_I18N||{})[MDCore.lang()]; return (d&&d.desc&&d.desc[s])?d.desc[s]:s; }catch(e){ return s; }
}
var current = MDCore.regionCode();

function regionBtns(hostId, onPick){
  document.getElementById(hostId).innerHTML = MDRegions.list().map(function(r){
    return '<button class="rbtn'+(r.code===current?' active':'')+'" data-rc="'+r.code+'" aria-pressed="'+(r.code===current)+'">'+esc(r.label)+'</button>';
  }).join('');
  document.querySelectorAll('#'+hostId+' [data-rc]').forEach(function(b){
    b.addEventListener('click', function(){ current=b.getAttribute('data-rc'); renderAll(); });
  });
}

function renderUrgences(){
  var r = MDRegions.get(current);
  var top = r.emergency.slice(0,2);
  var h = '<div class="emergency-banner"><div class="e-label">'+T('rdr.sec_emerg')+' — '+esc(r.label)+'</div>'
        + '<div class="e-grid">'
        + top.map(function(u,i){ return '<a class="e-num'+(i===0?' urg':'')+'" href="'+MDRegions.telHref(u.tel)+'"><span class="e-n">'+esc(u.tel)+'</span><span class="e-nl">'+esc(trDesc(u.name))+'</span></a>'; }).join('')
        + '</div></div>';
  h += '<div class="section-label">'+T('rdr.sec_allnum')+'</div>';
  r.emergency.forEach(function(u){
    h += '<div class="rdr-item"><div><div class="rdr-name">'+esc(trDesc(u.name))+'</div><div class="rdr-desc">'+esc(trDesc(u.desc))+'</div></div>'
       + '<a class="rdr-tel" href="'+MDRegions.telHref(u.tel)+'">'+esc(u.tel)+'</a></div>';
  });
  h += '<div class="section-label">'+T('rdr.sec_advice')+'</div>';
  r.tips.forEach(function(t){ h += '<div class="notice" style="margin-top:8px">'+esc(trDesc(t))+'</div>'; });
  document.getElementById('urg-content').innerHTML = h;
}

function renderCentres(){
  var r = MDRegions.get(current), h='';
  var lignes = (r.emergency||[]).filter(function(u){ return ['ecoute','drogue','suicide'].indexOf(u.kind)>=0; });
  if(lignes.length){
    h += '<div class="section-label">Lignes d\u2019\u00e9coute &amp; aide</div>';
    lignes.forEach(function(u){
      h += '<div class="rdr-item"><div><div class="rdr-name">'+esc(trDesc(u.name))+'</div><div class="rdr-desc">'+esc(trDesc(u.desc))+'</div></div>'
         + '<a class="rdr-tel" href="'+MDRegions.telHref(u.tel)+'">'+esc(u.tel)+'</a></div>';
    });
  }
  h += '<div class="section-label">'+T('rdr.sec_centres')+'</div>';
  r.centres.forEach(function(c){ h += resItem(c); });
  if(r.testing&&r.testing.length){ h += '<div class="section-label">'+T('rdr.sec_testing')+'</div>'; r.testing.forEach(function(c){ h+=resItem(c); }); }
  h += '<div class="section-label">'+T('rdr.sec_groups')+'</div>';
  r.groupes.forEach(function(g){ h += resItem(g); });
  document.getElementById('res-content').innerHTML = h;
}
function resItem(c){
  var link = c.url ? '<a class="rdr-url" href="https://'+esc(c.url)+'" target="_blank" rel="noopener">'+esc(c.url)+' ↗</a>' : '';
  return '<div class="rdr-item"><div><div class="rdr-name">'+esc(c.name)+'</div><div class="rdr-desc">'+esc(trDesc(c.desc))+'</div></div>'+link+'</div>';
}

function renderLegal(){
  var r = MDRegions.get(current), L=r.legal;
  function row(labelKey, status, text){
    var pill = status ? '<span class="legal-pill '+status+'">'+status.replace('decriminalise','décrim.')+'</span>' : '';
    return '<div class="legal-row">'+pill+'<div><div class="rdr-name">'+T(labelKey)+'</div><div class="harm-text">'+esc(text)+'</div></div></div>';
  }
  var h = '<div class="card">';
  h += row('rdr.leg_cannabis', L.cannabis.status, L.cannabis.summary);
  h += row('rdr.leg_other',    L.autres.status,   L.autres.summary);
  h += row('rdr.leg_driving',  null,              L.conduite);
  h += row('rdr.leg_samaritan',null,              L.bonSamaritain);
  h += '</div>';
  h += '<div class="legal-date" style="margin-top:8px">'+T('rdr.verified')+' : '+esc(L.verifie_le)+'</div>';
  document.getElementById('leg-content').innerHTML = h;
}

function renderNalox(){
  var r = MDRegions.get(current);
  document.getElementById('nalox-region').innerHTML = '<b>'+esc(r.label)+'</b> — '+esc(trDesc(r.naloxone.access))+' ('+esc(r.naloxone.form)+').';
}
function renderOD(){
  var r = MDRegions.get(current);
  document.getElementById('od-steps').innerHTML =
    [T('od.s1',{n:r.emergencyMain}),T('od.s2'),T('od.s3'),T('od.s4'),T('od.s5')].map(esc).join('<br>');
}

function renderAll(){
  ['urg-region-btns','res-region-btns','leg-region-btns'].forEach(function(id){ regionBtns(id); });
  renderUrgences(); renderCentres(); renderLegal(); renderNalox(); renderOD();
  (function(){ var m=/[?&]tab=([a-z]+)/.exec(location.search); if(m){ var b=document.querySelector('.tab-btn[data-tab="'+m[1]+'"]'); if(b) b.click(); } })();
}

/* Onglets */
document.querySelectorAll('.tab-btn').forEach(function(btn){
  btn.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
    document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
    btn.classList.add('active'); btn.setAttribute('aria-selected','true');
    document.getElementById('tab-'+btn.getAttribute('data-tab')).classList.add('active');
  });
});

document.addEventListener('langchange', renderAll);
renderAll();
