/* MyDope Off — logique de page : rdr.html (externalisée pour CSP script-src 'self') */
/* Libellés propres à cette page (centralisés -> fusionnés dans MD_DICT). */
(function(){
  var T = {
    'rdr.title':{fr:'Réflexes',en:'Reflexes'},
    'rdr.sub':{fr:'Urgences, prévention et réduction des risques.',en:'Emergencies, prevention and harm reduction.'},
    'rdr.tab_emerg':{fr:'SOS',en:'SOS'},
    'rdr.tab_rdr':{fr:'RDR',en:'Harm red.'},
    'rdr.tab_centres':{fr:'Centres',en:'Centres'},
    'rdr.tab_legal':{fr:'Légal',en:'Legal'},
    'rdr.tab_doc':{fr:'Doc',en:'Docs'},
    'rdr.doc_env_t':{fr:'Environnement & nature — comprendre & se protéger',en:'Environment & nature — understand & protect yourself'},
    'rdr.doc_env_d':{fr:'Pourquoi le lieu de consommation compte autant que la substance, et ce que change un changement de décor.',en:'Why the place where someone uses matters as much as the substance, and what a change of setting can do.'},
    'rdr.controls_t':{fr:'Alcool, stupéfiants & conduite',en:'Alcohol, drugs & driving'},
    'rdr.controls_d':{fr:"Ce que vérifie un contrôle, durées de détection, comment l'éviter vraiment.",en:'What a stop checks, detection times, how to actually avoid it.'},
    'rdr.sec_overdose':{fr:'Overdose — réagir',en:'Overdose — act'},
    'rdr.od_t':{fr:"Protocole : suspicion d'overdose",en:'Protocol: suspected overdose'},
    'rdr.nalox_t':{fr:'Naloxone (anti-overdose opioïde)',en:'Naloxone (opioid overdose)'},
    'rdr.nalox_d':{fr:"Inverse une overdose opioïde en 2–5 min. Sans effet sur l'alcool, les benzos ou la xylazine — l'administrer quand même et appeler les secours.",en:'Reverses an opioid overdose in 2–5 min. No effect on alcohol, benzos or xylazine — give it anyway and call emergency services.'},
    'rdr.sec_principles':{fr:'Principes fondamentaux',en:'Core principles'},
    'rdr.p1_t':{fr:'Jamais consommer seul·e',en:'Never use alone'},
    'rdr.p1_d':{fr:'Préviens une personne de confiance. En cas de malaise, il faut quelqu\u2019un sur place.',en:'Tell someone you trust. If something goes wrong, you need someone there.'},
    'rdr.p2_t':{fr:'Commencer bas, aller lentement',en:'Start low, go slow'},
    'rdr.p2_d':{fr:'Pureté inconnue : dose test de 10–20 %, attendre la montée (≥ 90 min en oral) avant de redoser.',en:'Unknown purity: test dose of 10–20%, wait for onset (≥ 90 min oral) before re-dosing.'},
    'rdr.p3_t':{fr:'Faire analyser son produit',en:'Get your drugs checked'},
    'rdr.p3_d':{fr:"Les services d'analyse identifient la substance et alertent sur les lots dangereux. Voir l'onglet Centres.",en:'Drug-checking services identify the substance and flag dangerous batches. See the Centres tab.'},
    'rdr.p4_t':{fr:'Jamais mélanger sans vérifier',en:'Never mix without checking'},
    'rdr.p4_d':{fr:'Alcool + opioïde/benzo, GHB + alcool, IMAO + sérotoninergique = combinaisons mortelles. Vérifie dans le PSYCHOchecker.',en:'Alcohol + opioid/benzo, GHB + alcohol, MAOI + serotonergic = deadly combos. Check the PSYCHOchecker.'},
    'rdr.p5_t':{fr:'Sevrage alcool & benzodiazépines',en:'Alcohol & benzo withdrawal'},
    'rdr.p5_d':{fr:'Ne JAMAIS arrêter brutalement seul·e : le sevrage peut provoquer convulsions et delirium potentiellement mortels. Arrêt encadré médicalement.',en:'Never stop abruptly on your own: withdrawal can cause seizures and delirium that may be fatal. Taper under medical supervision.'},
    'rdr.ai_note':{fr:"Assistant IA : bientôt. Pour protéger ta vie privée, l'assistant ne s'activera qu'à travers un relais sécurisé — aucune donnée envoyée à un tiers sans ton accord, aucune clé dans l'application.",en:'AI assistant: coming soon. To protect your privacy it will only run through a secure relay — no data sent to a third party without your consent, no key in the app.'},
    'rdr.legal_disclaimer':{fr:"Information éducative, pas un conseil juridique. Les lois évoluent : vérifie la date et confirme auprès d'une source officielle.",en:'Educational info, not legal advice. Laws change: check the date and confirm with an official source.'},
    'rdr.sec_emerg':{fr:'Urgences',en:'Emergencies'},
    'rdr.region':{fr:'Pays / région',en:'Country / region'},
    'rdr.sec_allnum':{fr:'Tous les numéros',en:'All numbers'},
    'rdr.sec_advice':{fr:'Conseils locaux',en:'Local tips'},
    'rdr.sec_centres':{fr:'Centres spécialisés',en:'Specialised centres'},
    'rdr.sec_testing':{fr:"Analyse de produit",en:'Drug-checking'},
    'rdr.sec_groups':{fr:"Groupes d'entraide",en:'Support groups'},
    'rdr.leg_cannabis':{fr:'Cannabis',en:'Cannabis'},
    'rdr.leg_other':{fr:'Autres drogues',en:'Other drugs'},
    'rdr.leg_driving':{fr:'Au volant',en:'Driving'},
    'rdr.leg_samaritan':{fr:'Appeler les secours',en:'Calling for help'},
    'rdr.verified':{fr:'Vérifié',en:'Verified'},
    'od.s1':{fr:'1. Appelle le {n} (urgences) immédiatement.',en:'1. Call {n} (emergency) immediately.'},
    'od.s2':{fr:'2. Mets la personne en Position Latérale de Sécurité (PLS).',en:'2. Put the person in the recovery position.'},
    'od.s3':{fr:'3. Surveille la respiration ; parle-lui, stimule-la.',en:'3. Monitor breathing; talk to and stimulate them.'},
    'od.s4':{fr:'4. Si opioïde possible : naloxone (nasale ou IM), même en cas de doute.',en:'4. If opioids possible: naloxone (nasal or IM), even if unsure.'},
    'od.s5':{fr:'5. Ne laisse jamais la personne seule jusqu\u2019aux secours.',en:'5. Never leave the person alone until help arrives.'},
    'rdr.doc_alcool_t':{fr:'Alcool — comprendre & se protéger',en:'Alcohol — understand & protect yourself'},
    'rdr.doc_alcool_d':{fr:'La substance la plus consommée du pays. Un risque méconnu : le sevrage brutal non encadré.',en:'The most widely used substance in the country. An overlooked risk: unsupervised abrupt withdrawal.'},
    'rdr.doc_opioides_synthese_t':{fr:'Opioïdes de synthèse — comprendre & se protéger',en:'Synthetic opioids — understand & protect yourself'},
    'rdr.doc_opioides_synthese_d':{fr:'Fentanyl, nitazènes : ce qui monte en Europe, avant que ça ne devienne une crise.',en:"Fentanyl, nitazenes: what's rising in Europe, before it becomes a crisis."},
    'rdr.doc_benzodiazepines_t':{fr:'Benzodiazépines — comprendre & se protéger',en:'Benzodiazepines — understand & protect yourself'},
    'rdr.doc_benzodiazepines_d':{fr:'Prescrites par millions, mésusées en silence. Les nouvelles « designer benzos », classées en 2025.',en:'Prescribed by the million, misused in silence. The new "designer benzos", scheduled in 2025.'},
    'rdr.doc_cannabis_t':{fr:'Cannabis — comprendre & se protéger',en:'Cannabis — understand & protect yourself'},
    'rdr.doc_cannabis_d':{fr:'La teneur en THC a beaucoup changé. Comestibles, CBD : les nouveaux pièges.',en:'THC content has changed a lot. Edibles, CBD: the new traps.'},
    'rdr.doc_cocaine_t':{fr:'Cocaïne — comprendre & se protéger',en:'Cocaine — understand & protect yourself'},
    'rdr.doc_cocaine_d':{fr:"Usage qui a quintuplé en 20 ans. Le risque cardiaque, et l'absence de traitement médicamenteux.",en:'Use has quintupled in 20 years. The cardiac risk, and the lack of drug treatment.'},
    'rdr.doc_crack_t':{fr:'Crack — comprendre & se protéger',en:'Crack — understand & protect yourself'},
    'rdr.doc_crack_d':{fr:'Effets, risques, réduction des risques, aide.',en:'Effects, risks, harm reduction, help.'},
    'rdr.doc_mdma_t':{fr:'MDMA — comprendre & se protéger',en:'MDMA — understand & protect yourself'},
    'rdr.doc_mdma_d':{fr:'Drogue festive et molécule sérieusement étudiée en clinique : les risques réels, et le point recherche.',en:'Party drug and molecule seriously studied in clinical settings: the real risks, and the research angle.'},
    'rdr.doc_ketamine_t':{fr:'Kétamine — comprendre & se protéger',en:'Ketamine — understand & protect yourself'},
    'rdr.doc_ketamine_d':{fr:'Usage en hausse chez les jeunes : effets, risques, réduction des risques, aide.',en:'Rising use among young people: effects, risks, harm reduction, help.'},
    'rdr.doc_nitreux_t':{fr:"Protoxyde d'azote — comprendre & se protéger",en:'Nitrous oxide — understand & protect yourself'},
    'rdr.doc_nitreux_d':{fr:'Usage en forte hausse chez les jeunes : effets, risques, réduction des risques, aide.',en:'Sharply rising use among young people: effects, risks, harm reduction, help.'},
    'rdr.doc_tabac_vapotage_t':{fr:'Tabac & vapotage — comprendre & se protéger',en:'Tobacco & vaping — understand & protect yourself'},
    'rdr.doc_tabac_vapotage_d':{fr:'La puff a changé la donne chez les jeunes. Interdiction 2025, chiffres, réduction des risques.',en:'The disposable vape has changed the game for young people. 2025 ban, figures, harm reduction.'},
    'rdr.doc_psychedeliques_t':{fr:'Psychédéliques & micro-dosage — comprendre & se protéger',en:'Psychedelics & microdosing — understand & protect yourself'},
    'rdr.doc_psychedeliques_d':{fr:"Thérapie assistée, micro-dosage : ce que la recherche montre vraiment, et ce qu'elle ne montre pas.",en:"Assisted therapy, microdosing: what research really shows, and what it doesn't."},
    'rdr.doc_rechute_t':{fr:'Rechute — comprendre & se protéger',en:'Relapse — understand & protect yourself'},
    'rdr.doc_rechute_d':{fr:'La normaliser comme processus, et le point de sécurité le plus important : la tolérance qui chute.',en:'Normalising it as a process, and the most important safety point: dropping tolerance.'},
    'rdr.doc_autosabotage_t':{fr:'Auto-sabotage — comprendre & se protéger',en:'Self-sabotage — understand & protect yourself'},
    'rdr.doc_autosabotage_d':{fr:"D'où ça vient, le lien avec les conduites addictives, et un protocole concret.",en:'Where it comes from, the link to addictive behaviours, and a concrete protocol.'},
    'rdr.doc_rdr_vs_abstinence_t':{fr:'RDR vs abstinence — comprendre & se protéger',en:'Harm reduction vs abstinence — understand & protect yourself'},
    'rdr.doc_rdr_vs_abstinence_d':{fr:'Pourquoi cette app existe, étayé par les évaluations scientifiques indépendantes.',en:'Why this app exists, backed by independent scientific evaluations.'},    'rdr.doc_polyconsommation_t':{fr:'Polyconsommation — comprendre & se protéger',en:'Polydrug use — understand & protect yourself'},
    'rdr.doc_polyconsommation_d':{fr:"Le mélange, pas la substance seule : risque d'accident multiplié par 14 (alcool + cannabis).",en:'The mix, not a single substance: accident risk multiplied by 14 (alcohol + cannabis).'},
    'rdr.sniff_t':{fr:'Sniff',en:'Snorting'},
    'rdr.sniff_d':{fr:'Ton propre matériel, jamais partagé (hépatite C / VIH se transmettent par le sang sur les pailles). Écrase finement, alterne les narines, rince au sérum physiologique après. Évite les billets.',en:'Your own equipment, never shared (hepatitis C / HIV spread through blood on straws). Crush finely, alternate nostrils, rinse with saline afterwards. Avoid banknotes.'},
    'rdr.smoke_t':{fr:'Fumer / inhaler',en:'Smoking / inhaling'},
    'rdr.smoke_d':{fr:'Embout perso, ne partage pas pipe ou joint. Laisse refroidir la vapeur, évite les chasses répétées. Hydrate-toi : la fumée assèche et irrite.',en:"Your own mouthpiece, don't share a pipe or joint. Let vapour cool, avoid repeated hits. Stay hydrated: smoke dries and irritates."},
    'rdr.inject_t':{fr:'Injection',en:'Injecting'},
    'rdr.inject_d':{fr:"Matériel stérile à usage unique (programmes d'échange de seringues gratuits). Jamais de partage de seringue, cuillère, filtre ou eau. Filtre, désinfecte le point d'injection, tourne les sites. Teste toujours une petite dose d'abord.",en:'Sterile single-use equipment (free needle exchange programmes). Never share a syringe, spoon, filter or water. Filter, disinfect the injection site, rotate sites. Always test a small dose first.'},
    'rdr.oral_t':{fr:'Oral / gobelet (GHB, kétamine…)',en:'Oral / drink (GHB, ketamine…)'},
    'rdr.oral_d':{fr:"Garde TON verre, ne le laisse jamais sans surveillance. Pour le GHB : doser à la pipette/seringue graduée, écart d'au moins 2–3 h, jamais avec de l'alcool — la marge entre effet et coma est minuscule.",en:'Keep YOUR drink, never leave it unattended. For GHB: measure with a graduated pipette/syringe, space doses at least 2–3 h apart, never with alcohol — the margin between effect and coma is tiny.'},
    'rdr.temp_t':{fr:'Température &amp; hydratation',en:'Temperature &amp; hydration'},
    'rdr.temp_d':{fr:"Stimulants/MDMA en milieu festif : ~250–500 ml d'eau par heure si tu danses, pas plus (risque d'hyponatrémie). Fais des pauses au frais. Repère les signes de surchauffe : confusion, crampes, peau brûlante.",en:"Stimulants/MDMA in a party setting: ~250–500 ml of water per hour if you're dancing, no more (hyponatremia risk). Take breaks somewhere cool. Watch for overheating signs: confusion, cramps, hot skin."},
    'rdr.space_t':{fr:'Espacer pour protéger',en:'Space out to protect'},
    'rdr.space_d':{fr:'MDMA : maximum une fois toutes les 6–8 semaines (neurotoxicité). Kétamine : usage répété = vessie abîmée. Plus tu espaces, plus tu protèges ton cerveau et ton corps.',en:'MDMA: no more than once every 6–8 weeks (neurotoxicity). Ketamine: repeated use = bladder damage. The more you space it out, the more you protect your brain and body.'},
    'rdr.down_t':{fr:'La descente / récupération',en:'The comedown / recovery'},
    'rdr.down_d':{fr:'Sommeil, repas riches, magnésium et vitamine C peuvent aider après une session. Prévois un jour sans obligations. La déprime du lendemain est chimique et passagère — ne prends pas de décisions lourdes à ce moment-là.',en:"Sleep, hearty meals, magnesium and vitamin C can help after a session. Plan a day with no obligations. The next-day low is chemical and temporary — don't make big decisions at that point."},
    'rdr.setting_t':{fr:'Set &amp; setting',en:'Set &amp; setting'},
    'rdr.setting_d':{fr:"État d'esprit et environnement façonnent l'expérience, surtout avec les psychédéliques. Lieu sûr, personnes de confiance, pas de moment de crise émotionnelle. Garde un·e « sitter » sobre pour les hautes doses.",en:"Mindset and environment shape the experience, especially with psychedelics. Safe place, people you trust, not during an emotional crisis. Keep a sober 'sitter' for high doses."},
    'rdr.consent_t':{fr:'Consentement &amp; entourage',en:'Consent &amp; looking out for others'},
    'rdr.consent_d':{fr:'Personne ne « doit » consommer. Sous substance, le consentement reste indispensable et révocable. Veille sur les autres : un·e ami·e qui décroche, vomit allongé·e ou devient inconscient·e = urgence.',en:"No one 'has to' use. Under the influence, consent still matters and can still be withdrawn. Watch out for others: a friend who zones out, vomits while lying down, or becomes unconscious = emergency."},
    'rdr.sec_route':{fr:'Safer use — selon la voie',en:'Safer use — by route'},
    'rdr.sec_during':{fr:'Pendant &amp; après',en:'During &amp; after'},
    'rdr.sec_material':{fr:'Matériel &amp; contexte',en:'Equipment &amp; context'},
    'rdr.sec_listen':{fr:'Lignes d\u2019\u00e9coute &amp; aide',en:'Helplines &amp; support'},
    'rdr.decrim':{fr:'décrim.',en:'decrim.'}
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k]=T[k]; });
})();

MDCore.init({ page:'rdr' });

/* ---- Rendu régionalisé (lit regions.js + langue courante) ---- */
var esc = function(s){ return String(s).replace(/[&<>"]/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m];}); };
var T = function(k,v){ return MDCore.t(k,v); };
// Traduction des descriptions régionales si rdr-i18n.js présent (sinon FR source)
function trDesc(s){
  try{ var d=(window.MD_RDR_I18N||{})[MDCore.lang()]; return (d&&d.desc&&d.desc[s])?d.desc[s]:s; }catch(e){ return s; }
}
var current = MDCore.regionCode();

function regionBtns(hostId, onPick){
  var host = document.getElementById(hostId);
  if(!host) return;
  var opts = MDRegions.list().map(function(r){
    return '<option value="'+r.code+'"'+(r.code===current?' selected':'')+'>'+esc(MDRegions.labelOf(r))+'</option>';
  }).join('');
  host.innerHTML = '<label class="region-select-label" for="'+hostId+'-sel">'+T('rdr.region')+'</label>'
    + '<select class="region-select" id="'+hostId+'-sel" aria-label="'+esc(T('rdr.region'))+'">'+opts+'</select>';
  host.querySelector('select').addEventListener('change', function(){ current=this.value; renderAll(); });
}

function renderUrgences(){
  var r = MDRegions.get(current);
  var top = r.emergency.slice(0,2);
  var h = '<div class="emergency-banner"><div class="e-label">'+T('rdr.sec_emerg')+' — '+esc(MDRegions.labelOf(r))+'</div>'
        + '<div class="e-grid">'
        + top.map(function(u,i){ return '<a class="e-num'+(i===0?' urg':'')+'" href="'+MDRegions.telHref(u.tel)+'"><span class="e-n">'+esc(u.tel)+'</span><span class="e-nl">'+esc(trDesc(u.name))+'</span></a>'; }).join('')
        + '</div></div>';
  h += '<div class="section-label">'+T('rdr.sec_allnum')+'</div>';
  r.emergency.forEach(function(u){
    h += '<div class="rdr-item"><div><div class="rdr-name">'+esc(trDesc(u.name))+'</div><div class="rdr-desc">'+esc(trDesc(u.desc))+'</div></div>'
       + '<a class="rdr-tel" href="'+MDRegions.telHref(u.tel)+'">'+esc(u.tel)+'</a></div>';
  });
  h += '<div class="section-label">'+T('rdr.sec_advice')+'</div>';
  r.tips.forEach(function(t){ h += '<div class="notice" style="margin-top:8px">'+esc(trDesc(t))+'</div>'; });
  document.getElementById('urg-content').innerHTML = h;
}

function renderCentres(){
  var r = MDRegions.get(current), h='';
  var lignes = (r.emergency||[]).filter(function(u){ return ['ecoute','drogue','suicide'].indexOf(u.kind)>=0; });
  if(lignes.length){
    h += '<div class="section-label">'+T('rdr.sec_listen')+'</div>';
    lignes.forEach(function(u){
      h += '<div class="rdr-item"><div><div class="rdr-name">'+esc(trDesc(u.name))+'</div><div class="rdr-desc">'+esc(trDesc(u.desc))+'</div></div>'
         + '<a class="rdr-tel" href="'+MDRegions.telHref(u.tel)+'">'+esc(u.tel)+'</a></div>';
    });
  }
  h += '<div class="section-label">'+T('rdr.sec_centres')+'</div>';
  r.centres.forEach(function(c){ h += resItem(c); });
  if(r.testing&&r.testing.length){ h += '<div class="section-label">'+T('rdr.sec_testing')+'</div>'; r.testing.forEach(function(c){ h+=resItem(c); }); }
  h += '<div class="section-label">'+T('rdr.sec_groups')+'</div>';
  r.groupes.forEach(function(g){ h += resItem(g); });
  document.getElementById('res-content').innerHTML = h;
}
function resItem(c){
  var link = c.url ? '<a class="rdr-url" href="https://'+esc(c.url)+'" target="_blank" rel="noopener">'+esc(c.url)+' ↗</a>' : '';
  return '<div class="rdr-item"><div><div class="rdr-name">'+esc(c.name)+'</div><div class="rdr-desc">'+esc(trDesc(c.desc))+'</div></div>'+link+'</div>';
}

function renderLegal(){
  var r = MDRegions.get(current), L=r.legal;
  function row(labelKey, status, text){
    var pill = status ? '<span class="legal-pill '+status+'">'+status.replace('decriminalise',T('rdr.decrim'))+'</span>' : '';
    return '<div class="legal-row">'+pill+'<div><div class="rdr-name">'+T(labelKey)+'</div><div class="harm-text">'+esc(trDesc(text))+'</div></div></div>';
  }
  var h = '<div class="card">';
  h += row('rdr.leg_cannabis', L.cannabis.status, L.cannabis.summary);
  h += row('rdr.leg_other',    L.autres.status,   L.autres.summary);
  h += row('rdr.leg_driving',  null,              L.conduite);
  h += row('rdr.leg_samaritan',null,              L.bonSamaritain);
  h += '</div>';
  h += '<div class="legal-date" style="margin-top:8px">'+T('rdr.verified')+' : '+esc(L.verifie_le)+'</div>';
  document.getElementById('leg-content').innerHTML = h;
}

function renderNalox(){
  var r = MDRegions.get(current);
  document.getElementById('nalox-region').innerHTML = '<b>'+esc(MDRegions.labelOf(r))+'</b> — '+esc(trDesc(r.naloxone.access))+' ('+esc(r.naloxone.form)+').';
}
function renderOD(){
  var r = MDRegions.get(current);
  document.getElementById('od-steps').innerHTML =
    [T('od.s1',{n:r.emergencyMain}),T('od.s2'),T('od.s3'),T('od.s4'),T('od.s5')].map(esc).join('<br>');
}

function renderAll(){
  ['urg-region-btns','res-region-btns','leg-region-btns'].forEach(function(id){ regionBtns(id); });
  renderUrgences(); renderCentres(); renderLegal(); renderNalox(); renderOD();
  (function(){ var m=/[?&]tab=([a-z]+)/.exec(location.search); if(m){ var b=document.querySelector('.tab-btn[data-tab="'+m[1]+'"]'); if(b) b.click(); } })();
}

/* Onglets */
document.querySelectorAll('.tab-btn').forEach(function(btn){
  btn.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
    document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
    btn.classList.add('active'); btn.setAttribute('aria-selected','true');
    document.getElementById('tab-'+btn.getAttribute('data-tab')).classList.add('active');
  });
});

document.addEventListener('langchange', renderAll);
renderAll();
try{ if(window.MDPageIntro) MDPageIntro.init('rdr'); }catch(e){}
