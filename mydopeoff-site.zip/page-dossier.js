/* MyDope Off — page-dossier.js
   Initialisation commune aux 14 pages dossier (substances et mécanismes).

   Ces pages répétaient toutes les deux mêmes appels en script inline, ne différant que par
   l'identifiant de la page — lequel correspond exactement au nom du fichier. Un seul fichier
   externe suffit donc, et il rend possible ce qui ne l'était pas avec du script inline :
   appliquer une CSP stricte (script-src 'self') sur ces pages, comme sur le reste du site.

   Doit être chargé APRÈS core.js et dossier-guide.js, comme l'étaient les scripts inline. */
(function () {
  var id = (location.pathname.split('/').pop() || '').replace(/\.html$/, '');
  if (!id) return;

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    try { if (window.MDCore) MDCore.init({ page: id, section: 'securite' }); } catch (e) {}
    try { if (window.MDDossierGuide) MDDossierGuide.init(id); } catch (e) {}
  });
})();
