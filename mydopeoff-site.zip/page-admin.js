/* MyDope Off — page-admin.js · espace de maintenance (local, non sécurisé) */
(function () {
  'use strict';
  function $(id){ return document.getElementById(id); }
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function hash(str){ var h=5381,i=str.length; while(i) h=(h*33)^str.charCodeAt(--i); return (h>>>0).toString(36); }
  function download(name, text, type){
    var b=new Blob([text],{type:type||'text/plain;charset=utf-8'}), u=URL.createObjectURL(b), a=document.createElement('a');
    a.href=u; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(function(){ URL.revokeObjectURL(u); a.remove(); },120);
  }
  var FK='mdo_admin_fiches', CK='mdo_admin_code', STORE='ctc_v6';
  var MONTHS=['janv.','févr.','mars','avr.','mai','juin','juil.','août','sept.','oct.','nov.','déc.'];

  /* ---------- Porte d'accès ---------- */
  function setupGate(){
    var stored=null; try{ stored=localStorage.getItem(CK); }catch(e){}
    if(!stored){ $('gate-sub').textContent="Première connexion : choisis un code d'accès."; $('gate-go').textContent='Définir le code'; }
    function go(){
      var v=$('gate-code').value; if(!v){ return; }
      try{
        if(!stored){ localStorage.setItem(CK, hash(v)); unlock(); }
        else if(hash(v)===stored){ unlock(); }
        else { $('gate-hint').textContent="Code incorrect."; $('gate-code').value=''; }
      }catch(e){ unlock(); }
    }
    $('gate-go').addEventListener('click', go);
    $('gate-code').addEventListener('keydown', function(e){ if(e.key==='Enter') go(); });
  }
  function unlock(){ $('gate').style.display='none'; $('app').hidden=false; init(); }

  /* ---------- Fiches ---------- */
  function getFiches(){ try{ var a=JSON.parse(localStorage.getItem(FK)||'[]'); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
  function saveFiches(a){ try{ localStorage.setItem(FK, JSON.stringify(a)); }catch(e){} }
  function builtinCount(){ return (window.MD_SUBS_INDEX||[]).length; }
  function splitList(v){ return (v||'').split(/[\n,]/).map(function(x){return x.trim();}).filter(Boolean); }

  function readForm(){
    return {
      nom:$('a-nom').value.trim(),
      categories:splitList($('a-cat').value),
      addiction:$('a-add').value,
      effets:splitList($('a-effets').value),
      dosage:{faible:$('a-df').value.trim(),modere:$('a-dm').value.trim(),fort:$('a-dh').value.trim()},
      duree:$('a-duree').value.trim(),
      tripReport:$('a-trip').value.trim(),
      description:$('a-desc').value.trim(),
      aliases:splitList($('a-alias').value),
      source:$('a-src').value.trim(),
      verifie_le:$('a-ver').value,
      updated:new Date().toISOString().slice(0,10)
    };
  }
  function fillForm(f){
    $('a-nom').value=f.nom||''; $('a-cat').value=(f.categories||[]).join(', '); $('a-add').value=f.addiction||'Modéré';
    $('a-effets').value=(f.effets||[]).join('\n'); $('a-df').value=(f.dosage||{}).faible||''; $('a-dm').value=(f.dosage||{}).modere||'';
    $('a-dh').value=(f.dosage||{}).fort||''; $('a-duree').value=f.duree||''; $('a-trip').value=f.tripReport||'';
    $('a-desc').value=f.description||''; $('a-alias').value=(f.aliases||[]).join(', '); $('a-src').value=f.source||'';
    $('a-ver').value=f.verifie_le||''; $('a-edit').value=f.nom||'';
  }
  function clearForm(){ ['a-nom','a-cat','a-effets','a-df','a-dm','a-dh','a-duree','a-trip','a-desc','a-alias','a-src','a-ver','a-edit'].forEach(function(id){$(id).value='';}); $('a-add').value='Modéré'; renderPreview(); $('a-msg').textContent=''; }

  function tagClass(c){ c=(c||'').toLowerCase();
    if(/stimul/.test(c))return'stimulant'; if(/opio|nitaz/.test(c))return'opioide'; if(/psyché|psyche|lyserg|trypta/.test(c))return'psychedelique';
    if(/canna|noid/.test(c))return'cannabinoide'; if(/empatho|entacto/.test(c))return'entactogene'; if(/dépres|depres|benzo|sédat|gaba|alcool/.test(c))return'depresseur';
    if(/dissoc/.test(c))return'dissociatif'; return ''; }
  function cardHTML(f){
    var tg=(f.categories||[]).map(function(c){return '<span class="s-tag '+tagClass(c)+'">'+esc(c)+'</span>';}).join('');
    var D=f.dosage||{};
    function row(k,v){ return v? '<div class="s-row"><span class="s-key">'+k+'</span><span class="s-val">'+esc(v)+'</span></div>':''; }
    return '<div class="s-card"><div class="s-card-head"><div class="s-card-name">'+esc(f.nom||'—')+'</div><div class="s-tags">'+tg+'</div></div>'+
      '<div class="s-card-body">'+row('Addiction',f.addiction)+
      row('Dose',[D.faible&&('faible : '+D.faible),D.modere&&('modéré : '+D.modere),D.fort&&('fort : '+D.fort)].filter(Boolean).join(' · '))+
      row('Durée',f.duree)+row('Effets',(f.effets||[]).join(' · '))+row('Vécu',f.tripReport)+row('Info',f.description)+
      '</div><div class="s-footer">'+(f.source?('Source : '+esc(f.source)):'PSYCHOchecker RDR')+(f.verifie_le?(' · vérifié '+esc(f.verifie_le)):'')+'</div></div>';
  }
  function renderPreview(){ $('a-preview').innerHTML=cardHTML(readForm()); }

  function renderFichesList(){
    var fs=getFiches(); $('cust-count').textContent=fs.length;
    $('count-fiches').textContent='— '+builtinCount()+' intégrées + '+fs.length+' perso';
    if(!fs.length){ $('cust-list').innerHTML='<div class="card"><p class="muted" style="margin:0">Aucune fiche personnalisée pour l\'instant.</p></div>'; return; }
    $('cust-list').innerHTML=fs.map(function(f,i){
      var miss=(!f.source||!f.verifie_le)?' <span class="badge" style="background:var(--warn-50);color:var(--warn)">à vérifier</span>':'';
      return '<div class="list-row"><div style="flex:1"><div class="t">'+esc(f.nom)+miss+'</div><div class="s">'+esc((f.categories||[]).join(', '))+' · '+((f.aliases||[]).length)+' alias</div></div>'+
        '<button class="btn btn-sm btn-outline" data-edit="'+i+'">Éditer</button> <button class="btn btn-sm" data-del="'+i+'" style="background:var(--danger);color:#fff">Suppr.</button></div>';
    }).join('');
    $('cust-list').querySelectorAll('[data-edit]').forEach(function(b){ b.addEventListener('click',function(){ fillForm(getFiches()[+b.dataset.edit]); renderPreview(); window.scrollTo({top:0,behavior:'smooth'}); }); });
    $('cust-list').querySelectorAll('[data-del]').forEach(function(b){ b.addEventListener('click',function(){ var fs=getFiches(); var nom=fs[+b.dataset.del].nom; atlasConfirm({title:'Supprimer « '+nom+' » ?',confirmLabel:'Supprimer',danger:true}).then(function(ok){ if(ok){ fs.splice(+b.dataset.del,1); saveFiches(fs); renderFichesList(); renderReview(); atlasToast('Fiche supprimée','ok'); } }); }); });
  }

  function saveFiche(){
    var f=readForm();
    if(!f.nom){ $('a-msg').textContent='⚠ Le nom est requis.'; return; }
    if(!f.categories.length){ $('a-msg').textContent='⚠ Au moins une famille/catégorie.'; return; }
    var fs=getFiches(), editName=$('a-edit').value, idx=fs.findIndex(function(x){return x.nom.toLowerCase()===(editName||f.nom).toLowerCase();});
    if(idx>=0) fs[idx]=f; else fs.push(f);
    saveFiches(fs); $('a-msg').textContent='✅ Fiche enregistrée (locale). Pense à exporter pour le dépôt.'; clearForm(); renderFichesList(); renderReview();
  }

  function exportJS(){
    var fs=getFiches();
    var body=fs.map(function(f){ return '  '+JSON.stringify(f); }).join(',\n');
    var txt='/* MyDope Off — fiches personnalisées (généré par admin.html le '+new Date().toISOString().slice(0,10)+').\n'+
            '   Dépose ce fichier à la racine du dépôt pour rendre les fiches permanentes. */\n'+
            'window.MD_CUSTOM_FICHES = [\n'+body+'\n];\n';
    download('custom-substances.js', txt, 'text/javascript');
  }
  function exportJSON(){ download('mydopeoff-fiches.json', JSON.stringify(getFiches(),null,2), 'application/json'); }
  function importJSON(file){
    var r=new FileReader(); r.onload=function(){ try{ var a=JSON.parse(r.result); if(!Array.isArray(a)) throw 0;
      var fs=getFiches(); a.forEach(function(nf){ if(nf&&nf.nom){ var i=fs.findIndex(function(x){return x.nom.toLowerCase()===nf.nom.toLowerCase();}); if(i>=0)fs[i]=nf; else fs.push(nf); } });
      saveFiches(fs); renderFichesList(); renderReview(); atlasToast('Import terminé : '+a.length+' fiche(s).','ok'); }catch(e){ atlasToast('Fichier JSON invalide.','danger'); } };
    r.readAsText(file);
  }

  function fillCatList(){
    var set={}; (window.MD_SUBS_INDEX||[]).forEach(function(d){ if(d.f) set[d.f]=1; });
    ['stimulant','dépresseur','opioïde','psychédélique','dissociatif','entactogène','benzodiazépine','cannabinoïde','sédatif','naturel'].forEach(function(c){set[c]=1;});
    $('cat-list').innerHTML=Object.keys(set).sort().map(function(c){return '<option value="'+esc(c)+'">';}).join('');
  }

  /* ---------- Activité (locale) ---------- */
  function store(){ try{ return JSON.parse(localStorage.getItem(STORE))||{}; }catch(e){ return {}; } }
  function entries(){ var s=store(); return Array.isArray(s.entries)?s.entries:[]; }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  function renderActivity(){
    var es=entries(), s=store();
    var map={}; es.forEach(function(e){ if(e&&e.date) map[e.date]=e; });
    var today=new Date(); today.setHours(0,0,0,0); var streak=0,d=new Date(today);
    for(var i=0;i<400;i++){ if(map[iso(d)]){streak++;d.setDate(d.getDate()-1);}else break; }
    var spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    $('act-stats').innerHTML=
      '<div class="stat"><div class="n">'+(streak||Object.keys(map).length)+'</div><div class="l">Jours suivis</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">Entrées</div></div>'+
      '<div class="stat"><div class="n">≈ '+Math.round(spend)+' €</div><div class="l">Dépense</div></div>';
    // graphe 30j : nb d'entrées/jour (ici 0/1 par jour) coloré par niveau
    var start=new Date(today); start.setDate(start.getDate()-29);
    var bars='', W=320,H=90,bw=W/30;
    var COL=['#6FA06A','#E0AE3E','#DD8A4A','#B23A1E'];
    for(var j=0;j<30;j++){ var dd=new Date(start); dd.setDate(start.getDate()+j); var e=map[iso(dd)];
      var h=e?Math.max(8,((Number(e.level)||0)+1)/4*H):3; var col=e?COL[Math.max(0,Math.min(3,Number(e.level)||0))]:'#ECE6D8';
      bars+='<rect x="'+(j*bw+1)+'" y="'+(H-h)+'" width="'+(bw-2)+'" height="'+h+'" rx="2" fill="'+col+'"></rect>';
    }
    $('act-chart').innerHTML='<svg viewBox="0 0 '+W+' '+H+'" width="100%" height="110" preserveAspectRatio="none">'+bars+'</svg>';
    var u=s.user||{}; var dates=es.map(function(e){return e.date;}).filter(Boolean).sort();
    $('act-details').innerHTML=
      '<div class="s-row"><span class="s-key">Profil</span><span class="s-val">'+(u.name?esc(u.name):'—')+(u.region?(' · '+esc(u.region)):'')+(u.age?(' · '+esc(u.age)+' ans'):'')+'</span></div>'+
      '<div class="s-row"><span class="s-key">Objectif</span><span class="s-val">'+((s.goal&&s.goal.days)||14)+' jours</span></div>'+
      '<div class="s-row"><span class="s-key">Première entrée</span><span class="s-val">'+(dates[0]||'—')+'</span></div>'+
      '<div class="s-row"><span class="s-key">Dernière entrée</span><span class="s-val">'+(dates[dates.length-1]||'—')+'</span></div>';
  }

  /* ---------- Maintenance ---------- */
  function lsSize(){ var t=0,d={}; for(var k in localStorage){ if(!localStorage.hasOwnProperty(k))continue; var v=localStorage.getItem(k)||''; var b=(k.length+v.length); t+=b; d[k]=b; } return {total:t,detail:d}; }
  function renderStorage(){
    var z=lsSize(); var rows=Object.keys(z.detail).sort(function(a,b){return z.detail[b]-z.detail[a];}).map(function(k){
      return '<div class="s-row"><span class="s-key" style="flex:0 0 160px">'+esc(k)+'</span><span class="s-val">'+(z.detail[k]/1024).toFixed(1)+' Ko</span></div>'; }).join('');
    $('maint-storage').innerHTML='<b>Stockage local : '+(z.total/1024).toFixed(1)+' Ko</b>'+rows;
  }
  function backupExport(){ var all={}; for(var k in localStorage){ if(localStorage.hasOwnProperty(k)) all[k]=localStorage.getItem(k); } download('mydopeoff-backup-'+new Date().toISOString().slice(0,10)+'.json', JSON.stringify(all,null,2),'application/json'); }
  function backupImport(file){ var r=new FileReader(); r.onload=function(){ try{ var o=JSON.parse(r.result); if(typeof o!=='object')throw 0; atlasConfirm({title:'Restaurer cette sauvegarde ?',body:'Les clés existantes seront remplacées.',confirmLabel:'Restaurer'}).then(function(ok){ if(!ok) return; Object.keys(o).forEach(function(k){ localStorage.setItem(k,o[k]); }); atlasToast('Restauré — rechargement…','ok'); setTimeout(function(){ location.reload(); },900); }); }catch(e){ atlasToast('Sauvegarde invalide.','danger'); } }; r.readAsText(file); }
  function renderSW(){
    var info=[];
    if('serviceWorker' in navigator){ navigator.serviceWorker.getRegistration().then(function(reg){ info.push('Service worker : '+(reg?'actif':'inactif')); if(window.caches&&caches.keys){ caches.keys().then(function(keys){ $('sw-info').textContent='Service worker : '+(reg?'actif':'inactif')+' · caches : '+(keys.join(', ')||'aucun'); }); } else { $('sw-info').textContent=info.join(' '); } }); }
    else $('sw-info').textContent='Service worker non supporté.';
  }
  function swClear(){
    atlasConfirm({title:'Vider tous les caches et recharger ?',confirmLabel:'Vider'}).then(function(ok){ if(!ok) return;
      var p=[];
      if(window.caches&&caches.keys) p.push(caches.keys().then(function(ks){return Promise.all(ks.map(function(k){return caches.delete(k);}));}));
      if('serviceWorker' in navigator) p.push(navigator.serviceWorker.getRegistrations().then(function(rs){return Promise.all(rs.map(function(r){return r.unregister();}));}));
      Promise.all(p).then(function(){ location.reload(true); });
    });
  }
  function renderReview(){
    var fs=getFiches(), bad=fs.filter(function(f){return !f.source||!f.verifie_le;});
    var html='<div class="s-row"><span class="s-key">Fiches perso</span><span class="s-val">'+fs.length+'</span></div>'+
             '<div class="s-row"><span class="s-key">À compléter</span><span class="s-val">'+bad.length+' (source/vérif manquante)</span></div>';
    if(bad.length) html+='<p class="hint" style="margin-top:8px">'+bad.map(function(f){return esc(f.nom);}).join(', ')+'</p>';
    html+='<p class="hint" style="margin-top:10px">Rappel : faire relire les données médicales/légales par un·e professionnel·le avant diffusion large.</p>';
    $('review-list').innerHTML=html;
  }

  /* ---------- Onglets + init ---------- */
  function setupTabs(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.addEventListener('click',function(){
      document.querySelectorAll('.tab-btn').forEach(function(x){x.classList.remove('active');}); b.classList.add('active');
      var t=b.dataset.tab;
      document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.toggle('active', p.id==='tab-'+t); });
      if(t==='activite') renderActivity();
      if(t==='maint'){ renderStorage(); renderSW(); renderReview(); }
    }); });
  }
  function init(){
    if(window.MDCore) MDCore.init({ page:'admin', section:'accueil' });
    fillCatList(); renderFichesList(); renderPreview(); setupTabs();
    ['a-nom','a-cat','a-add','a-effets','a-df','a-dm','a-dh','a-duree','a-trip','a-desc','a-alias','a-src','a-ver'].forEach(function(id){ $(id).addEventListener('input', renderPreview); });
    $('a-save').addEventListener('click', saveFiche);
    $('a-reset').addEventListener('click', clearForm);
    $('exp-js').addEventListener('click', exportJS);
    $('exp-json').addEventListener('click', exportJSON);
    $('imp-json').addEventListener('click', function(){ $('imp-file').click(); });
    $('imp-file').addEventListener('change', function(e){ if(e.target.files[0]) importJSON(e.target.files[0]); });
    $('bk-export').addEventListener('click', backupExport);
    $('bk-import').addEventListener('click', function(){ $('bk-file').click(); });
    $('bk-file').addEventListener('change', function(e){ if(e.target.files[0]) backupImport(e.target.files[0]); });
    $('sw-clear').addEventListener('click', swClear);
    $('wipe').addEventListener('click', function(){ atlasConfirm({title:'Tout effacer sur cet appareil ?',body:'Profil, journal et fiches perso seront supprimés. Action irréversible.',confirmLabel:'Tout effacer',danger:true}).then(function(ok){ if(!ok) return; atlasConfirm({title:'Confirme une dernière fois.',confirmLabel:'Effacer définitivement',danger:true}).then(function(ok2){ if(!ok2) return; try{localStorage.clear();}catch(e){} location.reload(); }); }); });
  }

  ready(setupGate);
})();
