/* MyDope Off — page-admin.js · espace de maintenance (local, non sécurisé) */
(function () {
  'use strict';
  window.MD_DICT = window.MD_DICT || {};
  var STATIC_T = {
    'adm.badge': { fr: 'Admin', en: 'Admin' },
    'adm.site': { fr: '↩ Site', en: '↩ Site' },
    'adm.h1': { fr: 'Maintenance & activité', en: 'Maintenance & activity' },
    'adm.sub': { fr: 'Fiches substances · tableau de bord local · sauvegardes', en: 'Substance cards · local dashboard · backups' },
    'adm.notice_local': { fr: '<b>Privé &amp; local.</b> Les données affichées ici proviennent de <b>cet appareil</b> uniquement. Aucune statistique multi\u2011utilisateurs (le site ne piste personne).',
      en: '<b>Private &amp; local.</b> The data shown here comes from <b>this device</b> only. No cross-user statistics (the site doesn\u2019t track anyone).' },
    'adm.tab_fiches': { fr: 'Fiches', en: 'Cards' },
    'adm.tab_activite': { fr: 'Activité', en: 'Activity' },
    'adm.tab_maint': { fr: 'Maintenance', en: 'Maintenance' },
    'adm.add_edit': { fr: 'Ajouter / modifier une fiche', en: 'Add / edit a card' },
    'adm.f_name': { fr: 'Nom *', en: 'Name *' },
    'adm.f_cat': { fr: 'Familles / catégories (séparées par des virgules) *', en: 'Families / categories (comma-separated) *' },
    'adm.f_addict': { fr: 'Potentiel addictif', en: 'Addictive potential' },
    'adm.o_nul': { fr: 'Nul', en: 'None' },
    'adm.o_veryfaible': { fr: 'Très faible', en: 'Very low' },
    'adm.o_faible': { fr: 'Faible', en: 'Low' },
    'adm.o_modere': { fr: 'Modéré', en: 'Moderate' },
    'adm.o_eleve': { fr: 'Élevé', en: 'High' },
    'adm.o_veryeleve': { fr: 'Très élevé', en: 'Very high' },
    'adm.o_extreme': { fr: 'Extrême', en: 'Extreme' },
    'adm.f_duree': { fr: 'Durée', en: 'Duration' },
    'adm.f_effets': { fr: 'Effets (un par ligne)', en: 'Effects (one per line)' },
    'adm.f_dfaible': { fr: 'Dose faible', en: 'Low dose' },
    'adm.f_dmod': { fr: 'Dose modérée', en: 'Moderate dose' },
    'adm.f_dforte': { fr: 'Dose forte', en: 'High dose' },
    'adm.f_trip': { fr: 'Vécu / témoignage', en: 'Experience / testimonial' },
    'adm.f_desc': { fr: 'Info pharmacologique / RDR', en: 'Pharmacological / harm reduction info' },
    'adm.f_alias': { fr: 'Alias (séparés par des virgules)', en: 'Aliases (comma-separated)' },
    'adm.f_src': { fr: 'Source', en: 'Source' },
    'adm.f_ver': { fr: 'Vérifié le', en: 'Verified on' },
    'adm.reset': { fr: 'Vider', en: 'Clear' },
    'adm.save_card': { fr: 'Enregistrer la fiche', en: 'Save card' },
    'adm.preview': { fr: 'Aperçu', en: 'Preview' },
    'adm.export': { fr: 'Export', en: 'Export' },
    'adm.export_desc': { fr: 'Rends tes fiches permanentes pour tout le monde : exporte <code>custom-substances.js</code> et dépose-le à la racine du dépôt.',
      en: 'Make your cards permanent for everyone: export <code>custom-substances.js</code> and drop it in the root of the repo.' },
    'adm.export_js': { fr: '⬇ Exporter pour le dépôt (custom-substances.js)', en: '⬇ Export for the repo (custom-substances.js)' },
    'adm.export_json': { fr: 'Exporter (JSON)', en: 'Export (JSON)' },
    'adm.import_json': { fr: 'Importer (JSON)', en: 'Import (JSON)' },
    'adm.custom_cards': { fr: 'Fiches personnalisées', en: 'Custom cards' },
    'adm.activity_device': { fr: 'Activité de cet appareil', en: 'This device\u2019s activity' },
    'adm.entries_day': { fr: 'Entrées par jour — 30 derniers jours', en: 'Entries per day — last 30 days' },
    'adm.details': { fr: 'Détails', en: 'Details' },
    'adm.go_further': { fr: '<b>Aller plus loin (optionnel).</b> Pour des statistiques d\u2019usage agrégées et anonymes sans trahir la vie privée, on pourrait intégrer un compteur respectueux (ex. auto\u2011hébergé, sans cookies, agrégat seul). À décider ensemble — désactivé par défaut.',
      en: '<b>Going further (optional).</b> For aggregated, anonymous usage stats without compromising privacy, we could add a respectful counter (e.g. self-hosted, no cookies, aggregate only). To decide together — disabled by default.' },
    'adm.backup_title': { fr: 'Sauvegarde & données (cet appareil)', en: 'Backup & data (this device)' },
    'adm.backup_all': { fr: '⬇ Sauvegarder tout (JSON)', en: '⬇ Back up everything (JSON)' },
    'adm.restore': { fr: 'Restaurer (JSON)', en: 'Restore (JSON)' },
    'adm.cache_title': { fr: 'Cache & mise à jour', en: 'Cache & update' },
    'adm.clear_cache': { fr: 'Vider le cache & recharger', en: 'Clear cache & reload' },
    'adm.review_title': { fr: 'Revue des fiches (qualité)', en: 'Card review (quality)' },
    'adm.danger_zone': { fr: 'Zone sensible', en: 'Danger zone' },
    'adm.wipe_desc': { fr: 'Efface toutes les données de cet appareil (profil, journal, fiches perso). Irréversible.',
      en: 'Erases all data on this device (profile, journal, custom cards). Irreversible.' },
    'adm.wipe_btn': { fr: 'Tout effacer', en: 'Erase everything' },
    'adm.footer': { fr: '<b style="font-weight:var(--w-bold)">MyDope Off — Admin</b> · page non indexée, usage interne. Pense à incrémenter <code>CACHE</code> dans <code>sw.js</code> à chaque déploiement.',
      en: '<b style="font-weight:var(--w-bold)">MyDope Off — Admin</b> · unindexed page, internal use. Remember to bump <code>CACHE</code> in <code>sw.js</code> on every deploy.' }
  };
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var T = {
    builtin_perso:{fr:function(b,p){return '— '+b+' intégrées + '+p+' perso';}, en:function(b,p){return '— '+b+' built-in + '+p+' custom';}},
    no_custom_yet:{fr:'Aucune fiche personnalisée pour l\u2019instant.', en:'No custom cards yet.'},
    to_verify:{fr:'à vérifier', en:'to verify'},
    edit_btn:{fr:'Éditer', en:'Edit'},
    del_btn:{fr:'Suppr.', en:'Delete'},
    alias_count:{fr:function(n){return n+' alias';}, en:function(n){return n+' alias'+(n>1?'es':'');}},
    confirm_delete:{fr:function(n){return 'Supprimer \u00ab '+n+' \u00bb ?';}, en:function(n){return 'Delete "'+n+'"?';}},
    name_required:{fr:'⚠ Le nom est requis.', en:'⚠ Name is required.'},
    cat_required:{fr:'⚠ Au moins une famille/catégorie.', en:'⚠ At least one family/category.'},
    saved:{fr:'✅ Fiche enregistrée (locale). Pense à exporter pour le dépôt.', en:'✅ Card saved (local). Remember to export for the repo.'},
    import_done:{fr:function(n){return 'Import terminé : '+n+' fiche(s).';}, en:function(n){return 'Import complete: '+n+' card(s).';}},
    invalid_json:{fr:'Fichier JSON invalide.', en:'Invalid JSON file.'},
    days_streak:{fr:'Jours suivis', en:'Days tracked'},
    entries_lbl:{fr:'Entrées', en:'Entries'},
    spend_lbl:{fr:'Dépense', en:'Spend'},
    profile_lbl:{fr:'Profil', en:'Profile'},
    years_old:{fr:function(a){return ' · '+a+' ans';}, en:function(a){return ' · '+a+' y/o';}},
    goal_lbl:{fr:'Objectif', en:'Goal'},
    days_unit:{fr:function(n){return n+' jours';}, en:function(n){return n+' days';}},
    first_entry:{fr:'Première entrée', en:'First entry'},
    last_entry:{fr:'Dernière entrée', en:'Last entry'},
    local_storage:{fr:function(kb){return '<b>Stockage local : '+kb+' Ko</b>';}, en:function(kb){return '<b>Local storage: '+kb+' KB</b>';}},
    ko_unit:{fr:function(kb){return kb+' Ko';}, en:function(kb){return kb+' KB';}},
    confirm_restore:{fr:'Restaurer cette sauvegarde ? Les clés existantes seront remplacées.', en:'Restore this backup? Existing keys will be replaced.'},
    restored:{fr:'Restauré. La page va se recharger.', en:'Restored. The page will reload.'},
    invalid_backup:{fr:'Sauvegarde invalide.', en:'Invalid backup.'},
    sw_active:{fr:'actif', en:'active'},
    sw_inactive:{fr:'inactif', en:'inactive'},
    sw_label:{fr:function(s){return 'Service worker : '+s;}, en:function(s){return 'Service worker: '+s;}},
    sw_caches:{fr:function(s,c){return 'Service worker : '+s+' · caches : '+c;}, en:function(s,c){return 'Service worker: '+s+' · caches: '+c;}},
    none_lbl:{fr:'aucun', en:'none'},
    sw_unsupported:{fr:'Service worker non supporté.', en:'Service worker not supported.'},
    confirm_clear_cache:{fr:'Vider tous les caches et recharger ?', en:'Clear all caches and reload?'},
    custom_cards_lbl:{fr:'Fiches perso', en:'Custom cards'},
    to_complete_lbl:{fr:'À compléter', en:'To complete'},
    missing_src:{fr:function(n){return n+' (source/vérif manquante)';}, en:function(n){return n+' (missing source/verification)';}},
    review_reminder:{fr:'Rappel : faire relire les données médicales/légales par un\u00b7e professionnel\u00b7le avant diffusion large.',
      en:'Reminder: have medical/legal data reviewed by a professional before wide release.'},
    confirm_wipe1:{fr:'Tout effacer sur cet appareil ? Irréversible.', en:'Erase everything on this device? Irreversible.'},
    confirm_wipe2:{fr:'Confirme une dernière fois.', en:'Confirm one last time.'},
    addiction_lbl:{fr:'Addiction', en:'Addictive potential'},
    dose_lbl:{fr:'Dose', en:'Dose'},
    dose_low:{fr:function(v){return 'faible : '+v;}, en:function(v){return 'low: '+v;}},
    dose_mod:{fr:function(v){return 'modéré : '+v;}, en:function(v){return 'moderate: '+v;}},
    dose_high:{fr:function(v){return 'fort : '+v;}, en:function(v){return 'high: '+v;}},
    duration_lbl:{fr:'Durée', en:'Duration'},
    effects_lbl:{fr:'Effets', en:'Effects'},
    experience_lbl:{fr:'Vécu', en:'Experience'},
    info_lbl:{fr:'Info', en:'Info'},
    source_lbl:{fr:function(s){return 'Source : '+s;}, en:function(s){return 'Source: '+s;}},
    verified_lbl:{fr:function(d){return ' · vérifié '+d;}, en:function(d){return ' · verified '+d;}}
  };
  function t(k, a, b){ var e=T[k]; if(!e) return k; var v=lang()==='en'?e.en:e.fr; return (typeof v==='function')?v(a,b):v; }

  function $(id){ return document.getElementById(id); }
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function download(name, text, type){
    var b=new Blob([text],{type:type||'text/plain;charset=utf-8'}), u=URL.createObjectURL(b), a=document.createElement('a');
    a.href=u; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(function(){ URL.revokeObjectURL(u); a.remove(); },120);
  }
  var FK='mdo_admin_fiches', STORE='ctc_v6';

  /* ---------- Fiches ---------- */
  function getFiches(){ try{ var a=JSON.parse(localStorage.getItem(FK)||'[]'); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
  function saveFiches(a){ try{ localStorage.setItem(FK, JSON.stringify(a)); }catch(e){} }
  function builtinCount(){ return (window.MD_SUBS_INDEX||[]).length; }
  function splitList(v){ return (v||'').split(/[\n,]/).map(function(x){return x.trim();}).filter(Boolean); }

  function readForm(){
    return {
      nom:$('a-nom').value.trim(),
      categories:splitList($('a-cat').value),
      addiction:$('a-add').value,
      effets:splitList($('a-effets').value),
      dosage:{faible:$('a-df').value.trim(),modere:$('a-dm').value.trim(),fort:$('a-dh').value.trim()},
      duree:$('a-duree').value.trim(),
      tripReport:$('a-trip').value.trim(),
      description:$('a-desc').value.trim(),
      aliases:splitList($('a-alias').value),
      source:$('a-src').value.trim(),
      verifie_le:$('a-ver').value,
      updated:new Date().toISOString().slice(0,10)
    };
  }
  function fillForm(f){
    $('a-nom').value=f.nom||''; $('a-cat').value=(f.categories||[]).join(', '); $('a-add').value=f.addiction||'Modéré';
    $('a-effets').value=(f.effets||[]).join('\n'); $('a-df').value=(f.dosage||{}).faible||''; $('a-dm').value=(f.dosage||{}).modere||'';
    $('a-dh').value=(f.dosage||{}).fort||''; $('a-duree').value=f.duree||''; $('a-trip').value=f.tripReport||'';
    $('a-desc').value=f.description||''; $('a-alias').value=(f.aliases||[]).join(', '); $('a-src').value=f.source||'';
    $('a-ver').value=f.verifie_le||''; $('a-edit').value=f.nom||'';
  }
  function clearForm(){ ['a-nom','a-cat','a-effets','a-df','a-dm','a-dh','a-duree','a-trip','a-desc','a-alias','a-src','a-ver','a-edit'].forEach(function(id){$(id).value='';}); $('a-add').value='Modéré'; renderPreview(); $('a-msg').textContent=''; }

  function tagClass(c){ c=(c||'').toLowerCase();
    if(/stimul/.test(c))return'stimulant'; if(/opio|nitaz/.test(c))return'opioide'; if(/psyché|psyche|lyserg|trypta/.test(c))return'psychedelique';
    if(/canna|noid/.test(c))return'cannabinoide'; if(/empatho|entacto/.test(c))return'entactogene'; if(/dépres|depres|benzo|sédat|gaba|alcool/.test(c))return'depresseur';
    if(/dissoc/.test(c))return'dissociatif'; return ''; }
  function cardHTML(f){
    var tg=(f.categories||[]).map(function(c){return '<span class="s-tag '+tagClass(c)+'">'+esc(c)+'</span>';}).join('');
    var D=f.dosage||{};
    function row(k,v){ return v? '<div class="s-row"><span class="s-key">'+k+'</span><span class="s-val">'+esc(v)+'</span></div>':''; }
    return '<div class="s-card"><div class="s-card-head"><div class="s-card-name">'+esc(f.nom||'—')+'</div><div class="s-tags">'+tg+'</div></div>'+
      '<div class="s-card-body">'+row(t('addiction_lbl'),f.addiction)+
      row(t('dose_lbl'),[D.faible&&(t('dose_low',D.faible)),D.modere&&(t('dose_mod',D.modere)),D.fort&&(t('dose_high',D.fort))].filter(Boolean).join(' · '))+
      row(t('duration_lbl'),f.duree)+row(t('effects_lbl'),(f.effets||[]).join(' · '))+row(t('experience_lbl'),f.tripReport)+row(t('info_lbl'),f.description)+
      '</div><div class="s-footer">'+(f.source?(t('source_lbl',esc(f.source))):'PSYCHOchecker RDR')+(f.verifie_le?(t('verified_lbl',esc(f.verifie_le))):'')+'</div></div>';
  }
  function renderPreview(){ $('a-preview').innerHTML=cardHTML(readForm()); }

  function renderFichesList(){
    var fs=getFiches(); $('cust-count').textContent=fs.length;
    $('count-fiches').textContent=t('builtin_perso', builtinCount(), fs.length);
    if(!fs.length){ $('cust-list').innerHTML='<div class="card"><p class="muted" style="margin:0">'+t('no_custom_yet')+'</p></div>'; return; }
    $('cust-list').innerHTML=fs.map(function(f,i){
      var miss=(!f.source||!f.verifie_le)?' <span class="badge" style="background:var(--warn-50);color:var(--warn)">'+t('to_verify')+'</span>':'';
      return '<div class="list-row"><div style="flex:1"><div class="t">'+esc(f.nom)+miss+'</div><div class="s">'+esc((f.categories||[]).join(', '))+' · '+t('alias_count',(f.aliases||[]).length)+'</div></div>'+
        '<button class="btn btn-sm btn-outline" data-edit="'+i+'">'+t('edit_btn')+'</button> <button class="btn btn-sm" data-del="'+i+'" style="background:var(--danger);color:#fff">'+t('del_btn')+'</button></div>';
    }).join('');
    $('cust-list').querySelectorAll('[data-edit]').forEach(function(b){ b.addEventListener('click',function(){ fillForm(getFiches()[+b.dataset.edit]); renderPreview(); window.scrollTo({top:0,behavior:'smooth'}); }); });
    $('cust-list').querySelectorAll('[data-del]').forEach(function(b){ b.addEventListener('click',function(){ var fs=getFiches(); if(confirm(t('confirm_delete',fs[+b.dataset.del].nom))){ fs.splice(+b.dataset.del,1); saveFiches(fs); renderFichesList(); renderReview(); } }); });
  }

  function saveFiche(){
    var f=readForm();
    if(!f.nom){ $('a-msg').textContent=t('name_required'); return; }
    if(!f.categories.length){ $('a-msg').textContent=t('cat_required'); return; }
    var fs=getFiches(), editName=$('a-edit').value, idx=fs.findIndex(function(x){return x.nom.toLowerCase()===(editName||f.nom).toLowerCase();});
    if(idx>=0) fs[idx]=f; else fs.push(f);
    saveFiches(fs); $('a-msg').textContent=t('saved'); clearForm(); renderFichesList(); renderReview();
  }

  function exportJS(){
    var fs=getFiches();
    var body=fs.map(function(f){ return '  '+JSON.stringify(f); }).join(',\n');
    var txt='/* MyDope Off — fiches personnalisées (généré par admin.html le '+new Date().toISOString().slice(0,10)+').\n'+
            '   Dépose ce fichier à la racine du dépôt pour rendre les fiches permanentes. */\n'+
            'window.MD_CUSTOM_FICHES = [\n'+body+'\n];\n';
    download('custom-substances.js', txt, 'text/javascript');
  }
  function exportJSON(){ download('mydopeoff-fiches.json', JSON.stringify(getFiches(),null,2), 'application/json'); }
  function importJSON(file){
    var r=new FileReader(); r.onload=function(){ try{ var a=JSON.parse(r.result); if(!Array.isArray(a)) throw 0;
      var fs=getFiches(); a.forEach(function(nf){ if(nf&&nf.nom){ var i=fs.findIndex(function(x){return x.nom.toLowerCase()===nf.nom.toLowerCase();}); if(i>=0)fs[i]=nf; else fs.push(nf); } });
      saveFiches(fs); renderFichesList(); renderReview(); alert(t('import_done',a.length)); }catch(e){ alert(t('invalid_json')); } };
    r.readAsText(file);
  }

  function fillCatList(){
    var set={}; (window.MD_SUBS_INDEX||[]).forEach(function(d){ if(d.f) set[d.f]=1; });
    ['stimulant','dépresseur','opioïde','psychédélique','dissociatif','entactogène','benzodiazépine','cannabinoïde','sédatif','naturel'].forEach(function(c){set[c]=1;});
    $('cat-list').innerHTML=Object.keys(set).sort().map(function(c){return '<option value="'+esc(c)+'">';}).join('');
  }

  /* ---------- Activité (locale) ---------- */
  function store(){ try{ return JSON.parse(localStorage.getItem(STORE))||{}; }catch(e){ return {}; } }
  function entries(){ var s=store(); return Array.isArray(s.entries)?s.entries:[]; }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  function renderActivity(){
    var es=entries(), s=store();
    var map={}; es.forEach(function(e){ if(e&&e.date) map[e.date]=e; });
    /* Total de jours notés, jamais une série consécutive. Un compteur qui repart à zéro
       parce qu'on a sauté un jour punit le fait de ne pas avoir noté, et transforme un
       outil en dette. Interdiction explicite : aucune métrique cassable, aucune série,
       aucun compteur remis à zéro. */
    var joursNotes = Object.keys(map).length;
    var spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    $('act-stats').innerHTML=
      '<div class="stat"><div class="n">'+joursNotes+'</div><div class="l">'+t('days_streak')+'</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">'+t('entries_lbl')+'</div></div>'+
      '<div class="stat"><div class="n">≈ '+Math.round(spend)+' €</div><div class="l">'+t('spend_lbl')+'</div></div>';
    // graphe 30j : nb d'entrées/jour (ici 0/1 par jour) coloré par niveau
    var start=new Date(today); start.setDate(start.getDate()-29);
    var bars='', W=320,H=90,bw=W/30;
    var COL=['#6FA06A','#E0AE3E','#DD8A4A','#B23A1E'];
    for(var j=0;j<30;j++){ var dd=new Date(start); dd.setDate(start.getDate()+j); var e=map[iso(dd)];
      var h=e?Math.max(8,((Number(e.level)||0)+1)/4*H):3; var col=e?COL[Math.max(0,Math.min(3,Number(e.level)||0))]:'#ECE6D8';
      bars+='<rect x="'+(j*bw+1)+'" y="'+(H-h)+'" width="'+(bw-2)+'" height="'+h+'" rx="2" fill="'+col+'"></rect>';
    }
    $('act-chart').innerHTML='<svg viewBox="0 0 '+W+' '+H+'" width="100%" height="110" preserveAspectRatio="none">'+bars+'</svg>';
    var u=s.user||{}; var dates=es.map(function(e){return e.date;}).filter(Boolean).sort();
    $('act-details').innerHTML=
      '<div class="s-row"><span class="s-key">'+t('profile_lbl')+'</span><span class="s-val">'+(u.name?esc(u.name):'—')+(u.region?(' · '+esc(u.region)):'')+(u.age?t('years_old',esc(u.age)):'')+'</span></div>'+
      '<div class="s-row"><span class="s-key">'+t('goal_lbl')+'</span><span class="s-val">'+t('days_unit',(s.goal&&s.goal.days)||14)+'</span></div>'+
      '<div class="s-row"><span class="s-key">'+t('first_entry')+'</span><span class="s-val">'+(dates[0]||'—')+'</span></div>'+
      '<div class="s-row"><span class="s-key">'+t('last_entry')+'</span><span class="s-val">'+(dates[dates.length-1]||'—')+'</span></div>';
  }

  /* ---------- Maintenance ---------- */
  function lsSize(){ var tot=0,d={}; for(var k in localStorage){ if(!localStorage.hasOwnProperty(k))continue; var v=localStorage.getItem(k)||''; var b=(k.length+v.length); tot+=b; d[k]=b; } return {total:tot,detail:d}; }
  function renderStorage(){
    var z=lsSize(); var rows=Object.keys(z.detail).sort(function(a,b){return z.detail[b]-z.detail[a];}).map(function(k){
      return '<div class="s-row"><span class="s-key" style="flex:0 0 160px">'+esc(k)+'</span><span class="s-val">'+t('ko_unit',(z.detail[k]/1024).toFixed(1))+'</span></div>'; }).join('');
    $('maint-storage').innerHTML=t('local_storage',(z.total/1024).toFixed(1))+rows;
  }
  function backupExport(){ var all={}; for(var k in localStorage){ if(localStorage.hasOwnProperty(k)) all[k]=localStorage.getItem(k); } download('mydopeoff-backup-'+new Date().toISOString().slice(0,10)+'.json', JSON.stringify(all,null,2),'application/json'); }
  function backupImport(file){ var r=new FileReader(); r.onload=function(){ try{ var o=JSON.parse(r.result); if(typeof o!=='object')throw 0; if(confirm(t('confirm_restore'))){ Object.keys(o).forEach(function(k){ localStorage.setItem(k,o[k]); }); alert(t('restored')); location.reload(); } }catch(e){ alert(t('invalid_backup')); } }; r.readAsText(file); }
  function renderSW(){
    var info=[];
    if('serviceWorker' in navigator){ navigator.serviceWorker.getRegistration().then(function(reg){ var st=reg?t('sw_active'):t('sw_inactive'); info.push(t('sw_label',st)); if(window.caches&&caches.keys){ caches.keys().then(function(keys){ $('sw-info').textContent=t('sw_caches',st,(keys.join(', ')||t('none_lbl'))); }); } else { $('sw-info').textContent=info.join(' '); } }); }
    else $('sw-info').textContent=t('sw_unsupported');
  }
  function swClear(){
    if(!confirm(t('confirm_clear_cache'))) return;
    var p=[];
    if(window.caches&&caches.keys) p.push(caches.keys().then(function(ks){return Promise.all(ks.map(function(k){return caches.delete(k);}));}));
    if('serviceWorker' in navigator) p.push(navigator.serviceWorker.getRegistrations().then(function(rs){return Promise.all(rs.map(function(r){return r.unregister();}));}));
    Promise.all(p).then(function(){ location.reload(true); });
  }
  function renderReview(){
    var fs=getFiches(), bad=fs.filter(function(f){return !f.source||!f.verifie_le;});
    var html='<div class="s-row"><span class="s-key">'+t('custom_cards_lbl')+'</span><span class="s-val">'+fs.length+'</span></div>'+
             '<div class="s-row"><span class="s-key">'+t('to_complete_lbl')+'</span><span class="s-val">'+t('missing_src',bad.length)+'</span></div>';
    if(bad.length) html+='<p class="hint" style="margin-top:8px">'+bad.map(function(f){return esc(f.nom);}).join(', ')+'</p>';
    html+='<p class="hint" style="margin-top:10px">'+t('review_reminder')+'</p>';
    $('review-list').innerHTML=html;
  }

  /* ---------- Onglets + init ---------- */
  function setupTabs(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.addEventListener('click',function(){
      document.querySelectorAll('.tab-btn').forEach(function(x){x.classList.remove('active');}); b.classList.add('active');
      var tb=b.dataset.tab;
      document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.toggle('active', p.id==='tab-'+tb); });
      if(tb==='activite') renderActivity();
      if(tb==='maint'){ renderStorage(); renderSW(); renderReview(); }
    }); });
  }
  function init(){
    if(window.MDCore) MDCore.init({ page:'admin', section:'accueil' });
    fillCatList(); renderFichesList(); renderPreview(); setupTabs();
    ['a-nom','a-cat','a-add','a-effets','a-df','a-dm','a-dh','a-duree','a-trip','a-desc','a-alias','a-src','a-ver'].forEach(function(id){ $(id).addEventListener('input', renderPreview); });
    $('a-save').addEventListener('click', saveFiche);
    $('a-reset').addEventListener('click', clearForm);
    $('exp-js').addEventListener('click', exportJS);
    $('exp-json').addEventListener('click', exportJSON);
    $('imp-json').addEventListener('click', function(){ $('imp-file').click(); });
    $('imp-file').addEventListener('change', function(e){ if(e.target.files[0]) importJSON(e.target.files[0]); });
    $('bk-export').addEventListener('click', backupExport);
    $('bk-import').addEventListener('click', function(){ $('bk-file').click(); });
    $('bk-file').addEventListener('change', function(e){ if(e.target.files[0]) backupImport(e.target.files[0]); });
    $('sw-clear').addEventListener('click', swClear);
    $('wipe').addEventListener('click', function(){ if(confirm(t('confirm_wipe1'))&&confirm(t('confirm_wipe2'))){ try{localStorage.clear();}catch(e){} location.reload(); } });
  }

  ready(init);
})();
