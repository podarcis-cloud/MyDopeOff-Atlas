/* memoire-mascotte.js — un seul moteur de sélection pour toute la voix de la mascotte
   (anecdotes, réactions de débrief, révélations de dossier). Trois responsabilités :

   1. MÉMOIRE — se souvenir de ce qui a déjà été montré, à l'échelle de l'app entière,
      pas seulement d'une session. Sans ça, « non-redondant » est un vœu pieux.
   2. SCORE — même logique multi-signal que le moteur de recommandation d'exercice
      (scanner.js/M8) : région, état du bilan, valeurs personnelles, récence.
   3. SÉLECTION — un seul point d'entrée (`pick`) que tout le reste appelle, au lieu
      de logiques de tirage dispersées et incohérentes entre fichiers. */
(function () {
  'use strict';

  var KEY = 'mdMascotteMemoire';
  var HIST_MAX = 60; // par pool — assez pour éviter la redite sans grossir indéfiniment le stockage

  function readHist() {
    try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; }
  }
  function writeHist(h) {
    try { localStorage.setItem(KEY, JSON.stringify(h)); } catch (e) { }
  }

  /* Enregistre qu'un item a été montré — à appeler après chaque sélection retenue. */
  function recordShown(poolKey, itemId) {
    if (!itemId) return;
    var h = readHist();
    h[poolKey] = h[poolKey] || [];
    h[poolKey] = h[poolKey].filter(function (x) { return x !== itemId; }); // évite les doublons dans l'historique
    h[poolKey].unshift(itemId);
    if (h[poolKey].length > HIST_MAX) h[poolKey].length = HIST_MAX;
    writeHist(h);
  }

  /* Rang de récence d'un item (0 = montré à l'instant, Infinity = jamais montré).
     Sert de pénalité douce, pas d'exclusion brutale — un pool trop petit ne doit jamais
     produire un blocage total. */
  function recencyRank(poolKey, itemId) {
    var h = readHist();
    var arr = h[poolKey] || [];
    var idx = arr.indexOf(itemId);
    return idx === -1 ? Infinity : idx;
  }

  /* Contexte courant — les quatre signaux déjà présents ailleurs dans l'app,
     rassemblés ici une bonne fois pour toutes plutôt que redemandés partout. */
  function currentContext() {
    var region = null, valeurs = [], bilan = null;
    try { region = window.MDCore && MDCore.regionCode ? MDCore.regionCode() : null; } catch (e) { }
    try { valeurs = window.MDData && MDData.getValeurs ? MDData.getValeurs() : []; } catch (e) { }
    try { bilan = window.MDData && MDData.getBilanState ? MDData.getBilanState() : null; } catch (e) { }
    var needsGrounding = false;
    try {
      if (bilan) {
        if (bilan.craving && bilan.craving.daysAgo != null && bilan.craving.daysAgo <= 14 && bilan.craving.improving === false) needsGrounding = true;
        if (bilan.wellbeing && bilan.wellbeing.daysAgo != null && bilan.wellbeing.daysAgo <= 14 && bilan.wellbeing.improving === false) needsGrounding = true;
      }
    } catch (e) { }
    return { region: region, valeurs: valeurs, bilan: bilan, needsGrounding: needsGrounding };
  }

  /* Score un candidat (0..~2). Chaque item PEUT porter, selon le pool :
     - item.region (code pays) → bonus fort si ça correspond au contexte
     - item.mood → bonus si le mood est « apaisant » et que needsGrounding est vrai
     - item.tags (tableau de mots-clés) → bonus si un tag recoupe une valeur personnelle
     poolKey + item.id (ou item.t comme repli) servent à la pénalité de récence. */
  var GROUNDING_MOODS = { bienveillance: 1, encouragement: 1, ecoute: 1, serenite: 1 };

  function scoreItem(item, ctx, poolKey) {
    var score = 1;
    var id = item.id || item.t;

    if (item.region && ctx.region && item.region === ctx.region) score += 0.6;

    if (ctx.needsGrounding) {
      if (item.mood && GROUNDING_MOODS[item.mood]) score += 0.5;
      else score -= 0.15; // pas exclu, juste moins probable — jamais de trou si le pool est pauvre
    }

    if (item.tags && ctx.valeurs.length) {
      var hit = item.tags.some(function (tag) {
        return ctx.valeurs.some(function (v) { return v.toLowerCase() === String(tag).toLowerCase(); });
      });
      if (hit) score += 0.4;
    }

    var rank = recencyRank(poolKey, id);
    if (rank === 0) score -= 0.9;      // vient d'être montré — fortement découragé, jamais interdit
    else if (rank < 5) score -= 0.4;   // montré récemment — pénalité modérée
    // rank Infinity (jamais vu) ou ancien : aucune pénalité, léger avantage à la nouveauté
    if (rank === Infinity) score += 0.1;

    return score;
  }

  /* Point d'entrée unique. candidates = tableau d'items { id?, t, mood?, region?, tags? }.
     Retourne l'item choisi (tirage pondéré parmi les mieux notés, pas un simple argmax —
     pour ne pas devenir prévisible) et enregistre automatiquement le choix dans l'historique. */
  function pick(poolKey, candidates) {
    if (!candidates || !candidates.length) return null;
    var ctx = currentContext();
    var scored = candidates.map(function (it) { return { item: it, score: scoreItem(it, ctx, poolKey) }; });
    scored.sort(function (a, b) { return b.score - a.score; });

    // tirage pondéré parmi le tiers supérieur, pas systématiquement le meilleur score —
    // garde une vraie variété plutôt qu'un ordre figé
    var topN = Math.max(1, Math.ceil(scored.length / 3));
    var pool = scored.slice(0, topN);
    var totalWeight = pool.reduce(function (s, x) { return s + Math.max(0.05, x.score); }, 0);
    var r = Math.random() * totalWeight, acc = 0, chosen = pool[0].item;
    for (var i = 0; i < pool.length; i++) {
      acc += Math.max(0.05, pool[i].score);
      if (r <= acc) { chosen = pool[i].item; break; }
    }

    recordShown(poolKey, chosen.id || chosen.t);
    return chosen;
  }

  window.MDMascotteMemoire = { pick: pick, recordShown: recordShown, currentContext: currentContext };
})();
