/* MyDope Off — page-tolerance.js
   Dossier « Après une pause ». Seul besoin : MDCore.init() (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'tolerance', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
