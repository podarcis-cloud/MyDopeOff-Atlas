# MyDope Off

**Prévention, réduction des risques et accompagnement du changement de comportement — une application web légère, hors‑ligne et 100 % locale.**

MyDope Off aide à *comprendre les substances*, *mesurer sa consommation* et *réduire les risques*, sans compte, sans serveur et sans jugement. Toutes les données restent sur l'appareil de la personne. L'univers visuel — direction artistique **« Atlas — Lettre à ton futur toi »** — privilégie la confiance, la sérénité et l'autonomie plutôt qu'un registre médical ou administratif.

---

## ⚠️ Avertissement

- **Outil d'information et de réduction des risques. Ne remplace pas un avis médical, psychologique ou juridique.**
- En cas d'urgence : **112** (Europe) / **15** (SAMU, France). Les numéros et ressources varient selon la région (sélecteur intégré).
- **Version bêta.** Les contenus médicaux (détection, interactions) et juridiques (statuts légaux, seuils routiers) méritent une **relecture par des professionnel·les** (addictologue, pharmacien·ne, juriste) avant diffusion large. Des champs `source` et `verifie_le` sont prévus à cet effet dans les données.
- L'application ne fournit **aucun dosage d'usage** et n'encourage en rien la consommation.

---

## Fonctionnalités

- **Ta progression** — journal de consommation, **calendrier des 30 derniers jours** (lecture rapide : sans conso / léger / notable / non renseigné), dépenses estimées, objectifs personnels, courbe de jalons.
- **Comprendre les substances** — 270 fiches, **vérificateur d'interactions** (gravité = donnée structurée : *danger / attention / prudence / info*, jamais « safe » par défaut), **fenêtres de détection** sourcées (salive, urine, cheveux).
- **Souffler & gérer** — exercices anti‑craving (respiration, ancrage) et mini‑jeux.
- **Réduire les risques** — urgences cliquables, centres et associations, **statuts légaux et seuils routiers régionalisés** (BE, FR, CH, CA, LU).
- **Faire le point** — auto‑évaluations honnêtes, à son rythme.
- **Langues** — interface **FR / EN** (le contenu de fond — fiches, RDR, protocoles — est aujourd’hui en FR ; EN/ES/DE en cours). Le sélecteur n’affiche que les langues réellement disponibles.
- **PWA hors‑ligne** — installable, fonctionne sans réseau (service worker).

---

## Confidentialité & sécurité

- **Aucun compte, aucun serveur, aucun traceur.** Les données (profil, journal, objectifs) sont stockées **uniquement** dans le `localStorage` du navigateur.
- **Aucune donnée personnelle ne transite par l'URL** (pas de fuite via l'en‑tête `Referer`).
- **Content‑Security‑Policy** stricte sur les pages (`script-src 'self'`, pas de script inline), `referrer: no-referrer`.

---

## Accessibilité

- Objectif **WCAG 2.1 AA minimum, AAA quand c'est possible**. La lisibilité prime sur l'esthétique.
- Contrastes vérifiés : texte en encre/vert forêt (AAA) ; les teintes de section servent aux repères, illustrations et grands titres (variantes assombries `‑d` testées AA pour le texte).
- Police de contenu **Atkinson Hyperlegible Next** (pensée pour la lisibilité), respect de `prefers-reduced-motion`, cibles tactiles ≥ 44 px, focus visibles.

---

## Direction artistique — « Atlas — Lettre à ton futur toi »

**Atlas est la direction artistique — l'« édition » visuelle — de MyDope Off.** Le produit garde son nom (*MyDope Off*) ; Atlas en habille toute l'expérience : marque « enveloppe + chemin + feuille », signature *« Lettre à ton futur toi »*, palette écru/aquarelle et micro-animations. La bascule entre la marque « enveloppe » (défaut) et « sommet » se fait sur une ligne (`BRAND` dans `core.js`).

Atlas modernes, cartes illustrées, sérigraphie, affiches de parcs nationaux.

**Palette**

| Rôle | Hex |
|---|---|
| Ivoire chaud (fond) | `#F6EFE6` |
| Surface | `#FFFFFF` |
| Encre (texte) | `#1F2B25` |
| Vert forêt (marque) | `#23443D` |
| Bleu Fjord — *Progression* | `#5E8298` |
| Vert Sauge — *Substances* | `#6E8568` |
| Ocre solaire — *Équilibre* | `#C99A3E` |
| Terracotta — *Sécurité* | `#C46A50` |
| Rose minéral — *Faire le point* | `#C9A39A` |
| Orange Soutien (Ko‑fi) | `#EA6A1A` |

**Typographies** — Titres : *Newsreader* · Contenu : *Atkinson Hyperlegible Next* · Interface : *Inter*.
**Repère couleur par section** : chaque espace possède sa teinte (en‑tête, icône, onglet actif) pour savoir « où l'on se trouve ».

Le design system vit dans `tokens.css` (variables) et `components.css` (composants : calendrier, cartes territoires, progression, badges, alertes, échelle de gravité, formulaires, navigation…).

---

## Déploiement (GitHub Pages)

Le dépôt est **à plat** : tous les fichiers sont à la racine (aucun sous‑dossier requis), ce qui simplifie la mise en ligne.

1. Place tous les fichiers de l'archive à la **racine du dépôt**.
2. **Settings → Pages → Build and deployment → Source : _Deploy from a branch_**, branche `main`, dossier `/ (root)`.
3. Le site est publié sur `https://<utilisateur>.github.io/<dépôt>/` (respecter la **casse exacte** des noms de fichiers).
4. Le **service worker** exige **HTTPS** (fourni par GitHub Pages) — il ne fonctionne pas en `file://`.

Le fichier `.nojekyll` évite tout traitement Jekyll des fichiers statiques.

### Mettre à jour le site

Après chaque modification, **incrémente la version du cache** dans `sw.js` :

```js
const CACHE = 'mydopeoff-v51'; // v50 -> v51, etc.
```

Sans cela, le service worker peut continuer à servir l'ancienne version.

---

## Développement local

Le service worker et les `fetch` nécessitent un serveur HTTP (pas d'ouverture directe en `file://`) :

```bash
# Python 3
python3 -m http.server 8080
# puis ouvrir http://localhost:8080
```

---

## Structure du projet

```
index.html            Accueil (Atlas)
suivi.html            Ta progression + calendrier 30 jours
psychochecker.html    Substances + vérificateur d'interactions (270 fiches)
fiches.html           Souffler & gérer (exercices, anti-craving)
rdr.html              Réduire les risques (urgences, légal régionalisé)
controles.html        Contrôles routiers / légal
bilans.html           Faire le point (auto-évaluations)
inscription.html      Profil / paramètres
guide.html            Guide d'utilisation
soutenir.html         Soutenir le projet
maze.html, tetris.html  Mini-jeux

tokens.css            Design system — variables (palette, typo, sections)
components.css        Design system — composants + calendrier + compatibilité
core.js               Socle : logo, navigation, i18n, thème de section, PWA
i18n.js               Dictionnaire d'interface (FR/EN/ES/DE)
regions.js            Données régionalisées (urgences, légal, routier)
interactions-fix.js / interactions-data.js / substance-classes.js
detection-data.js     Fenêtres de détection sourcées
page-*.js             Logique par page
sw.js / manifest.json PWA
icon-*.png            Icônes (sommet & soleil)
```

---

## Soutenir le projet

MyDope Off est **gratuit et le restera**. Si l'outil t'est utile, tu peux soutenir son développement (lien Ko‑fi dans l'application).

---

## Licence & contenus

- **Code** : à préciser par le mainteneur (par ex. MIT). Pense à ajouter un fichier `LICENSE`.
- **Données médicales / légales** : à valider et créditer (champs `source` / `verifie_le`). Ne pas diffuser largement sans relecture experte.
- **Polices** : Newsreader, Atkinson Hyperlegible Next, Inter — via Google Fonts (licences SIL Open Font / propres à chaque police).

---

*MyDope Off — comprendre, mesurer, décider.*
