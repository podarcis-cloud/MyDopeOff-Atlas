/* MyDope Off — logique de page : controles.html (externalisée pour CSP script-src 'self') */
(function(){
  var T={
    'ctrl.topbar':{fr:'Conduite',en:'Driving'},
    'ctrl.badge_reflexes':{fr:'Réflexes',en:'Reflexes'},
    'ctrl.sub':{fr:"Ce qu'un contrôle vérifie — sans mythe ni astuce.",en:'What a stop actually checks — no myths, no tricks.'},
    'ctrl.eyebrow':{fr:'Réduction des risques',en:'Harm reduction'},
    'ctrl.h1':{fr:"Alcool, stupéfiants et conduite : ce qu'un contrôle vérifie",en:'Alcohol, drugs & driving: what a stop checks'},
    'ctrl.intro':{fr:"Comment se déroulent les contrôles, ce qu'ils détectent et combien de temps. Le seul moyen fiable de « passer » est de ne pas conduire après avoir consommé : aucune astuce ne supprime une substance déjà présente.",en:'How stops work, what they detect and for how long. The only reliable way to pass is not to drive after using: no trick removes a substance already in your body.'},
    'ctrl.essential_t':{fr:"L'essentiel",en:'The essentials'},
    'ctrl.essential_d':{fr:"Ni café, ni douche froide, ni spray « purifiant » n'effacent l'alcool ou les drogues de façon fiable. Seul le temps fait baisser l'alcoolémie (~0,10–0,15 g/L par heure). Pour les stupéfiants, conduire est interdit dès la moindre trace.",en:'Coffee, a cold shower or "detox" sprays do not reliably remove alcohol or drugs. Only time lowers blood alcohol (~0.015%/h). For drugs, driving is illegal at any detectable trace.'},
    'ctrl.legal_sec':{fr:'Seuils & règles dans ta région',en:'Limits & rules in your region'},
    'ctrl.how_sec':{fr:'Comment se passe un contrôle',en:'How a stop works'},
    'ctrl.how_p1':{fr:'Le contrôle peut être aléatoire. Deux temps : un dépistage rapide (éthylotest / test salivaire), puis si positif une analyse de confirmation (sang/salive) qui seule a valeur juridique.',en:'A stop can be random. Two steps: a quick screen (breathalyzer / oral swab), then if positive a confirmation test (blood/saliva) which alone has legal weight.'},
    'ctrl.how_p2':{fr:'Refuser le dépistage est sanctionné aussi lourdement qu\u2019un résultat positif. Demander la confirmation est un droit.',en:'Refusing the screen is punished as harshly as a positive result. Asking for confirmation is a right.'},
    'ctrl.peak':{fr:"Le pic d'alcoolémie arrive 30 min (à jeun) à 1 h (après repas) après le dernier verre : tu peux être plus alcoolisé en reprenant la route. Le seul calcul fiable, c'est le temps.",en:'Blood alcohol peaks 30–90 min after the last drink: you can be more impaired on the road than at the table. The only reliable math is time.'},
    'ctrl.saliva_sec':{fr:'Détection salivaire (indicative)',en:'Oral-fluid detection (indicative)'},
    'ctrl.saliva_note':{fr:'Fenêtres salivaires indicatives (usage unique). La détection dure bien plus longtemps dans l\u2019urine et le sang. Voir Suivi → Détection.',en:'Indicative oral-fluid windows (single use). Detection lasts far longer in urine and blood. See Tracking → Detection.'},
    'ctrl.spray':{fr:'Les sprays « purifiant » ne masquent au mieux le THC salivaire que très brièvement et sans fiabilité ; aucun effet sur l\u2019analyse sanguine. Compter dessus, c\u2019est risquer le délit.',en:'"Detox" sprays mask oral THC only briefly and unreliably; no effect on the blood test. Relying on them risks the offence.'},
    'ctrl.avoid_sec':{fr:"Comment vraiment éviter l'infraction",en:'How to actually avoid an offence'},
    'ctrl.avoid1':{fr:'Le plus sûr : zéro consommation avant de conduire.',en:'Safest: zero use before driving.'},
    'ctrl.avoid2':{fr:'Prévois le retour avant de consommer : conducteur sobre, VTC, transports, ou dormir sur place.',en:'Plan the way home before using: sober driver, rideshare, transit, or stay over.'},
    'ctrl.avoid3':{fr:'Après l\u2019alcool, laisse passer le temps d\u2019élimination réel (plusieurs heures) — rien d\u2019autre ne marche.',en:'After alcohol, let real elimination time pass (several hours) — nothing else works.'},
    'ctrl.avoid4':{fr:'Après une drogue, la détection dure plus longtemps que les effets : positif possible bien après te sentir « clair ».',en:'After a drug, detection outlasts the effects: you can test positive long after feeling clear.'},
    'ctrl.avoid5':{fr:'Sous médicament : vérifie les pictogrammes et demande au pharmacien.',en:'On medication: check the warning labels and ask your pharmacist.'},
    'ctrl.disclaimer':{fr:'Information éducative à jour début 2026, pas un conseil juridique. Les règles évoluent et varient selon les pays — vérifie la date et une source officielle.',en:'Educational info, current early 2026, not legal advice. Rules change and vary by country — check the date and an official source.'},
    'ctrl.l_alcohol':{fr:'Alcool (général)',en:'Alcohol (general)'},
    'ctrl.l_novice':{fr:'Novice / probatoire',en:'Novice / probationary'},
    'ctrl.l_drugs':{fr:'Stupéfiants',en:'Drugs'},
    'ctrl.l_refus':{fr:'Refus du test',en:'Refusing the test'},
    'ctrl.l_sanction':{fr:'Sanctions',en:'Penalties'},
    'ctrl.verified':{fr:'Vérifié',en:'Verified'},
    'ctrl.region':{fr:'Pays / région',en:'Country / region'},
    'ctrl.sources_lbl':{fr:'Sources :',en:'Sources:'}
  };
  window.MD_DICT=window.MD_DICT||{}; Object.keys(T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k]=T[k]; });
})();

MDCore.init({ page:'controles' });

var esc=function(s){return String(s).replace(/[&<>"]/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m];});};
var T=function(k){return MDCore.t(k);};
function trDesc(s){ try{ var d=(window.LUCIDE_RDR_I18N||{})[MDCore.lang()]; return (d&&d.desc&&d.desc[s])?d.desc[s]:s; }catch(e){ return s; } }
var current = MDCore.regionCode();

function regBtns(){
  var host = document.getElementById('reg-btns');
  var opts = MDRegions.list().map(function(r){
    return '<option value="'+r.code+'"'+(r.code===current?' selected':'')+'>'+esc(MDRegions.labelOf(r))+'</option>';
  }).join('');
  host.innerHTML = '<label class="region-select-label" for="reg-btns-sel">'+T('ctrl.region')+'</label>'
    + '<select class="region-select" id="reg-btns-sel" aria-label="'+esc(T('ctrl.region'))+'">'+opts+'</select>';
  host.querySelector('select').addEventListener('change', function(){ current=this.value; renderAll(); });
}
function legalRow(label,val){ return '<div class="legal-row"><div style="min-width:120px"><div class="rdr-name">'+label+'</div></div><div class="harm-text">'+esc(trDesc(val))+'</div></div>'; }
function renderLegal(){
  var r=MDRegions.get(current), rs=r.roadside||{}, lg=r.legal||{};
  var h='<div class="card"><div style="font-family:var(--font-editorial);font-weight:var(--w-bold,800);margin-bottom:6px">'+esc(MDRegions.labelOf(r))+'</div>';
  h+=legalRow(T('ctrl.l_alcohol'), rs.alcoolGeneral||'—');
  h+=legalRow(T('ctrl.l_novice'), rs.alcoolNovice||'—');
  h+=legalRow(T('ctrl.l_drugs'), rs.drogues||(lg.conduite||'—'));
  h+=legalRow(T('ctrl.l_refus'), rs.refus||'—');
  h+=legalRow(T('ctrl.l_sanction'), rs.sanction||'—');
  h+='</div>';
  document.getElementById('legal-block').innerHTML=h;
  document.getElementById('sources').textContent = (rs.sources?(T('ctrl.sources_lbl')+' '+rs.sources+' · '):'')+T('ctrl.verified')+' : '+(rs.verifie_le||lg.verifie_le||'');
}
function renderSaliva(){
  var want=['Cannabis','Cocaïne','MDMA','Amphétamine','Héroïne'];
  var rows = (window.MD_DETECTION||[]).filter(function(s){ return want.indexOf(s.nom)>-1; });
  document.getElementById('saliva-rows').innerHTML = rows.map(function(s){
    var max=s.sal[1], txt = max<24 ? (max+' h') : (Math.round(max/24*10)/10+' j');
    return '<div class="legal-row"><div style="min-width:120px"><div class="rdr-name">'+esc(s.nom)+'</div></div><div class="harm-text">~ '+esc(txt)+' (salive)</div></div>';
  }).join('');
}
function renderAll(){ regBtns(); renderLegal(); renderSaliva(); }
document.addEventListener('langchange', renderAll);
renderAll();
try{ if(window.MDPageIntro) MDPageIntro.init('controles'); }catch(e){}
