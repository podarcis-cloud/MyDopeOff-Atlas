/* MyDope Off — logique de page : controles.html (externalisée pour CSP script-src 'self') */
(function(){
  var T={
    'ctrl.topbar':{fr:'Conduite',en:'Driving',es:'Conducción',de:'Fahren'},
    'ctrl.eyebrow':{fr:'Réduction des risques',en:'Harm reduction',es:'Reducción de riesgos',de:'Risikominderung'},
    'ctrl.h1':{fr:"Alcool, stupéfiants et conduite : ce qu'un contrôle vérifie",en:'Alcohol, drugs & driving: what a stop checks',es:'Alcohol, drogas y conducción: qué comprueba un control',de:'Alkohol, Drogen & Fahren: was eine Kontrolle prüft'},
    'ctrl.intro':{fr:"Comment se déroulent les contrôles, ce qu'ils détectent et combien de temps. Le seul moyen fiable de « passer » est de ne pas conduire après avoir consommé : aucune astuce ne supprime une substance déjà présente.",en:'How stops work, what they detect and for how long. The only reliable way to pass is not to drive after using: no trick removes a substance already in your body.',es:'Cómo son los controles, qué detectan y cuánto tiempo. La única forma fiable de pasar es no conducir tras consumir: ningún truco elimina lo que ya está en tu cuerpo.',de:'Wie Kontrollen ablaufen, was sie erkennen und wie lange. Sicher bestehst du nur, wenn du nach Konsum nicht fährst: kein Trick entfernt eine bereits aufgenommene Substanz.'},
    'ctrl.essential_t':{fr:"L'essentiel",en:'The essentials',es:'Lo esencial',de:'Das Wesentliche'},
    'ctrl.essential_d':{fr:"Ni café, ni douche froide, ni spray « purifiant » n'effacent l'alcool ou les drogues de façon fiable. Seul le temps fait baisser l'alcoolémie (~0,10–0,15 g/L par heure). Pour les stupéfiants, conduire est interdit dès la moindre trace.",en:'Coffee, a cold shower or "detox" sprays do not reliably remove alcohol or drugs. Only time lowers blood alcohol (~0.015%/h). For drugs, driving is illegal at any detectable trace.',es:'Ni café, ni ducha fría, ni sprays "detox" eliminan de forma fiable el alcohol o las drogas. Solo el tiempo baja la tasa (~0,10–0,15 g/L por hora). Con drogas, conducir está prohibido ante cualquier resto.',de:'Kaffee, kalte Dusche oder "Detox"-Sprays entfernen Alkohol/Drogen nicht zuverlässig. Nur Zeit senkt den Promillewert (~0,1–0,15 g/L pro Stunde). Bei Drogen ist Fahren ab jeder Spur verboten.'},
    'ctrl.legal_sec':{fr:'Seuils & règles dans ta région',en:'Limits & rules in your region',es:'Límites y reglas en tu región',de:'Grenzwerte & Regeln in deiner Region'},
    'ctrl.how_sec':{fr:'Comment se passe un contrôle',en:'How a stop works',es:'Cómo es un control',de:'Ablauf einer Kontrolle'},
    'ctrl.how_p1':{fr:'Le contrôle peut être aléatoire. Deux temps : un dépistage rapide (éthylotest / test salivaire), puis si positif une analyse de confirmation (sang/salive) qui seule a valeur juridique.',en:'A stop can be random. Two steps: a quick screen (breathalyzer / oral swab), then if positive a confirmation test (blood/saliva) which alone has legal weight.',es:'El control puede ser aleatorio. Dos fases: prueba rápida (etilómetro / test salival) y, si da positivo, prueba de confirmación (sangre/saliva) con valor legal.',de:'Eine Kontrolle kann zufällig sein. Zwei Schritte: Schnelltest (Alkomat / Speicheltest), bei positivem Ergebnis ein Bestätigungstest (Blut/Speichel), nur dieser ist rechtsgültig.'},
    'ctrl.how_p2':{fr:'Refuser le dépistage est sanctionné aussi lourdement qu\u2019un résultat positif. Demander la confirmation est un droit.',en:'Refusing the screen is punished as harshly as a positive result. Asking for confirmation is a right.',es:'Negarse a la prueba se castiga igual que un positivo. Pedir la prueba de contraste es un derecho.',de:'Eine Verweigerung wird so hart bestraft wie ein positives Ergebnis. Die Bestätigung zu verlangen ist ein Recht.'},
    'ctrl.peak':{fr:"Le pic d'alcoolémie arrive 30 min (à jeun) à 1 h (après repas) après le dernier verre : tu peux être plus alcoolisé en reprenant la route. Le seul calcul fiable, c'est le temps.",en:'Blood alcohol peaks 30–90 min after the last drink: you can be more impaired on the road than at the table. The only reliable math is time.',es:'El alcohol llega a su pico 30–90 min tras la última copa: puedes ir más alcoholizado al volante que en la mesa. El único cálculo fiable es el tiempo.',de:'Der Alkoholpegel erreicht 30–90 Min nach dem letzten Glas seinen Höhepunkt: am Steuer kannst du stärker beeinträchtigt sein als am Tisch. Verlässlich ist nur Zeit.'},
    'ctrl.saliva_sec':{fr:'Détection salivaire (indicative)',en:'Oral-fluid detection (indicative)',es:'Detección salival (indicativa)',de:'Speichel-Nachweis (Richtwert)'},
    'ctrl.saliva_note':{fr:'Fenêtres salivaires indicatives (usage unique). La détection dure bien plus longtemps dans l\u2019urine et le sang. Voir Suivi → Détection.',en:'Indicative oral-fluid windows (single use). Detection lasts far longer in urine and blood. See Tracking → Detection.',es:'Ventanas salivales indicativas (uso único). La detección dura mucho más en orina y sangre. Ver Seguimiento → Detección.',de:'Richtwerte für Speichel (Einzelkonsum). In Urin und Blut viel länger nachweisbar. Siehe Tracking → Nachweis.'},
    'ctrl.spray':{fr:'Les sprays « purifiant » ne masquent au mieux le THC salivaire que très brièvement et sans fiabilité ; aucun effet sur l\u2019analyse sanguine. Compter dessus, c\u2019est risquer le délit.',en:'"Detox" sprays mask oral THC only briefly and unreliably; no effect on the blood test. Relying on them risks the offence.',es:'Los sprays "detox" enmascaran el THC salival solo brevemente y sin fiabilidad; sin efecto en el análisis de sangre. Confiar en ellos arriesga el delito.',de:'"Detox"-Sprays überdecken THC im Speichel nur kurz und unzuverlässig; keine Wirkung auf den Bluttest. Sich darauf zu verlassen riskiert die Straftat.'},
    'ctrl.avoid_sec':{fr:"Comment vraiment éviter l'infraction",en:'How to actually avoid an offence',es:'Cómo evitar de verdad la infracción',de:'So vermeidest du die Straftat wirklich'},
    'ctrl.avoid1':{fr:'Le plus sûr : zéro consommation avant de conduire.',en:'Safest: zero use before driving.',es:'Lo más seguro: cero consumo antes de conducir.',de:'Am sichersten: kein Konsum vor dem Fahren.'},
    'ctrl.avoid2':{fr:'Prévois le retour avant de consommer : conducteur sobre, VTC, transports, ou dormir sur place.',en:'Plan the way home before using: sober driver, rideshare, transit, or stay over.',es:'Planea la vuelta antes de consumir: conductor sobrio, VTC, transporte, o quédate.',de:'Heimweg vor dem Konsum planen: nüchterner Fahrer, Fahrdienst, ÖPNV oder übernachten.'},
    'ctrl.avoid3':{fr:'Après l\u2019alcool, laisse passer le temps d\u2019élimination réel (plusieurs heures) — rien d\u2019autre ne marche.',en:'After alcohol, let real elimination time pass (several hours) — nothing else works.',es:'Tras el alcohol, deja pasar el tiempo real de eliminación (varias horas) — nada más funciona.',de:'Nach Alkohol echte Abbauzeit abwarten (mehrere Stunden) — nichts anderes hilft.'},
    'ctrl.avoid4':{fr:'Après une drogue, la détection dure plus longtemps que les effets : positif possible bien après te sentir « clair ».',en:'After a drug, detection outlasts the effects: you can test positive long after feeling clear.',es:'Tras una droga, la detección dura más que los efectos: positivo posible mucho después de sentirte "claro".',de:'Nach einer Droge überdauert der Nachweis die Wirkung: positiv möglich, lange nachdem du dich "klar" fühlst.'},
    'ctrl.avoid5':{fr:'Sous médicament : vérifie les pictogrammes et demande au pharmacien.',en:'On medication: check the warning labels and ask your pharmacist.',es:'Con medicación: revisa los pictogramas y pregunta al farmacéutico.',de:'Bei Medikamenten: Warnhinweise prüfen und Apotheker fragen.'},
    'ctrl.disclaimer':{fr:'Information éducative à jour début 2026, pas un conseil juridique. Les règles évoluent et varient selon les pays — vérifie la date et une source officielle.',en:'Educational info, current early 2026, not legal advice. Rules change and vary by country — check the date and an official source.',es:'Información educativa, actualizada a inicios de 2026, no asesoría legal. Las reglas cambian y varían por país — revisa la fecha y una fuente oficial.',de:'Bildungsinfo, Stand Anfang 2026, keine Rechtsberatung. Regeln ändern sich und variieren je Land — Datum und offizielle Quelle prüfen.'},
    'ctrl.l_alcohol':{fr:'Alcool (général)',en:'Alcohol (general)',es:'Alcohol (general)',de:'Alkohol (allgemein)'},
    'ctrl.l_novice':{fr:'Novice / probatoire',en:'Novice / probationary',es:'Novel / probatorio',de:'Fahranfänger'},
    'ctrl.l_drugs':{fr:'Stupéfiants',en:'Drugs',es:'Drogas',de:'Drogen'},
    'ctrl.l_refus':{fr:'Refus du test',en:'Refusing the test',es:'Negarse a la prueba',de:'Test verweigern'},
    'ctrl.l_sanction':{fr:'Sanctions',en:'Penalties',es:'Sanciones',de:'Strafen'},
    'ctrl.verified':{fr:'Vérifié',en:'Verified',es:'Verificado',de:'Geprüft'}
  };
  window.MD_DICT=window.MD_DICT||{}; Object.keys(T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k]=T[k]; });
})();

MDCore.init({ page:'controles' });

var esc=function(s){return String(s).replace(/[&<>"]/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m];});};
var T=function(k){return MDCore.t(k);};
var current = MDCore.regionCode();

function regBtns(){
  document.getElementById('reg-btns').innerHTML = MDRegions.list().map(function(r){
    return '<button class="rbtn'+(r.code===current?' active':'')+'" data-rc="'+r.code+'" aria-pressed="'+(r.code===current)+'">'+esc(r.label)+'</button>';
  }).join('');
  document.querySelectorAll('#reg-btns [data-rc]').forEach(function(b){
    b.addEventListener('click',function(){ current=b.getAttribute('data-rc'); renderAll(); });
  });
}
function legalRow(label,val){ return '<div class="legal-row"><div style="min-width:120px"><div class="rdr-name">'+label+'</div></div><div class="harm-text">'+esc(val)+'</div></div>'; }
function renderLegal(){
  var r=MDRegions.get(current), rs=r.roadside||{}, lg=r.legal||{};
  var h='<div class="card"><div style="font-family:var(--disp);font-weight:800;margin-bottom:6px">'+esc(r.label)+'</div>';
  h+=legalRow(T('ctrl.l_alcohol'), rs.alcoolGeneral||'—');
  h+=legalRow(T('ctrl.l_novice'), rs.alcoolNovice||'—');
  h+=legalRow(T('ctrl.l_drugs'), rs.drogues||(lg.conduite||'—'));
  h+=legalRow(T('ctrl.l_refus'), rs.refus||'—');
  h+=legalRow(T('ctrl.l_sanction'), rs.sanction||'—');
  h+='</div>';
  document.getElementById('legal-block').innerHTML=h;
  document.getElementById('sources').textContent = (rs.sources?('Sources : '+rs.sources+' · '):'')+T('ctrl.verified')+' : '+(rs.verifie_le||lg.verifie_le||'');
}
function renderSaliva(){
  var want=['Cannabis','Cocaïne','MDMA','Amphétamine','Héroïne'];
  var rows = (window.MD_DETECTION||[]).filter(function(s){ return want.indexOf(s.nom)>-1; });
  document.getElementById('saliva-rows').innerHTML = rows.map(function(s){
    var max=s.sal[1], txt = max<24 ? (max+' h') : (Math.round(max/24*10)/10+' j');
    return '<div class="legal-row"><div style="min-width:120px"><div class="rdr-name">'+esc(s.nom)+'</div></div><div class="harm-text">~ '+esc(txt)+' (salive)</div></div>';
  }).join('');
}
function renderAll(){ regBtns(); renderLegal(); renderSaliva(); }
document.addEventListener('langchange', renderAll);
renderAll();
