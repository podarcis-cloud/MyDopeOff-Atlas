/* dossier-guide.js — la mascotte accueille et referme la lecture d'un dossier.
   Deux fonctions seulement (accueillir, réagir/orienter) — jamais un quiz noté,
   jamais de score : un « ce que tu retiens » proposé, pas vérifié. */
(function () {
  'use strict';

  var CONTENT = {
    'crack': {
      mood: 'concentration',
      intro: 'Ce sujet est chargé — je reste avec toi pendant la lecture, sans détour inutile.',
      reveal: 'La cocaïne fumée atteint le cerveau en quelques secondes seulement — le circuit apprend à réclamer la dose suivante avant même que le plaisir précédent ne soit retombé.',
      retain: ['Le craving devient le vrai moteur, pas le plaisir — un mécanisme neurologique, pas un manque de volonté.', 'Les ressources de réduction des risques existent, même en usage actif.']
    },
    'ketamine': {
      mood: 'concentration',
      intro: 'Une lecture technique — je simplifie au fil du texte.',
      reveal: 'Le « k-hole » (dissociation profonde) peut être vécu comme une expérience de mort imminente — angoissant, parfois traumatisant, même sans risque vital réel.',
      retain: ['La dissociation n\u2019élimine pas les autres risques (noyade, chute).', 'Une cystite interstitielle peut s\u2019installer en usage régulier.']
    },
    'nitreux': {
      mood: 'vigilance',
      intro: 'Court à lire, mais deux ou trois points changent vraiment la donne.',
      reveal: 'Sa très courte durée d\u2019action pousse à répéter rapidement les prises — c\u2019est ce rythme, plus que le produit seul, qui banalise l\u2019usage.',
      retain: ['Jamais inhaler directement d\u2019une cartouche pressurisée (gelures).', 'Jamais dans un sac fermé sur la tête (asphyxie).']
    },
    'opioides-synthese': {
      mood: 'vigilance',
      intro: 'Un sujet qui monte vite en Europe — je te donne les repères essentiels.',
      reveal: 'L\u2019Agence européenne des drogues a recensé 7 nouveaux opioïdes de synthèse rien qu\u2019en 2025 — certains des centaines de fois plus puissants que l\u2019héroïne.',
      retain: ['N\u2019importe quel produit peut être coupé au fentanyl, sans rien pour le signaler.', 'La naloxone ne fait jamais de mal, même en cas de doute.']
    },
    'alcool': {
      mood: 'vigilance',
      intro: 'La substance la plus banalisée du pays — et pas la moins risquée.',
      reveal: 'Sans encadrement médical, le delirium tremens a un taux de mortalité de 5 à 15 % — un des risques les moins connus de l\u2019alcool.',
      retain: ['Ne jamais arrêter brutalement une consommation ancienne et importante sans avis médical.', 'La réduction des risques n\u2019exige pas l\u2019abstinence totale.']
    },
    'cannabis': {
      mood: 'curiosite',
      intro: 'Le produit a changé plus vite que sa réputation — quelques repères à jour.',
      reveal: 'Un comestible met jusqu\u2019à deux heures à faire effet — le piège de surdosage le plus fréquent, même chez des consommateurs expérimentés.',
      retain: ['Attendre au moins deux heures avant de reprendre un comestible.', 'La teneur en THC a beaucoup augmenté en vingt ans.']
    },
    'cocaine': {
      mood: 'vigilance',
      intro: 'L\u2019image festive cache une réalité clinique assez différente.',
      reveal: 'Contrairement aux opioïdes ou à l\u2019alcool, aucun médicament n\u2019est à ce jour approuvé pour le trouble de l\u2019usage de cocaïne.',
      retain: ['Ne jamais associer cocaïne et alcool (cocaéthylène, plus toxique que les deux séparément).', 'Une douleur thoracique après usage est une urgence, pas un détail.']
    },
    'benzodiazepines': {
      mood: 'vigilance',
      intro: 'Prescrites par millions — un mésusage souvent passé sous silence.',
      reveal: 'Les nouvelles « designer benzodiazépines » agissent à des doses si faibles qu\u2019elles échappent souvent aux tests toxicologiques classiques.',
      retain: ['Jamais d\u2019arrêt brutal après plusieurs semaines de traitement.', 'Jamais associées à l\u2019alcool ou à un opioïde.']
    },
    'mdma': {
      mood: 'curiosite',
      intro: 'Drogue festive et molécule étudiée en clinique — les deux sont vrais.',
      reveal: 'Trop boire peut être aussi dangereux que pas assez : l\u2019hyponatrémie (excès d\u2019eau sans sels minéraux) provoque des convulsions, tout comme la déshydratation.',
      retain: ['S\u2019hydrater par petites gorgées régulières, pas en grande quantité d\u2019un coup.', 'Éviter absolument la combinaison avec des antidépresseurs.']
    },
    'tabac-vapotage': {
      mood: 'vigilance',
      intro: 'La puff a changé la donne chez les plus jeunes — vite, et récemment.',
      reveal: 'Environ un lycéen sur cinq a déjà expérimenté une puff — un produit interdit à la vente en France depuis 2025, mais qui circule encore.',
      retain: ['Un dispositif rechargeable à taux connu vaut mieux qu\u2019une puff jetable.', 'Chez un·e non-fumeur·se, ne jamais commencer reste la meilleure réduction des risques.']
    },
    'polyconsommation': {
      mood: 'vigilance',
      intro: 'Le danger vient souvent du mélange, pas d\u2019une seule substance.',
      reveal: 'Associer alcool et cannabis, même à doses modérées, multiplie le risque d\u2019accident de la route par 14 par rapport à la sobriété totale.',
      retain: ['Espacer les prises plutôt que les cumuler.', 'Ne jamais associer deux dépresseurs du système nerveux (alcool, benzodiazépines, opioïdes).']
    },
    'psychedeliques': {
      mood: 'clarification',
      retainMood: 'vigilance',
      intro: 'Beaucoup d\u2019enthousiasme, beaucoup d\u2019essais en cours \u2014 et un \u00e9cart inhabituel entre les deux.',
      reveal: 'Dans l\u2019essai le plus rigoureux sur le micro-dosage, les participants qui prenaient un placebo sans le savoir rapportaient exactement les m\u00eames b\u00e9n\u00e9fices que ceux qui prenaient la substance.',
      retain: ['Les r\u00e9sultats encourageants viennent de la th\u00e9rapie \u00e0 dose forte encadr\u00e9e, pas du micro-dosage \u2014 les deux ne se transposent pas.', 'Ant\u00e9c\u00e9dents psychotiques dans la famille, traitement s\u00e9rotoninergique en cours : deux contre-indications qui excluent des essais, donc invisibles dans les r\u00e9sultats publi\u00e9s.']
    },
    'rechute': {
      mood: 'bienveillance',
      intro: 'Un mot qui évoque une chute — la science décrit surtout un processus.',
      reveal: 'La tolérance diminue après une période d\u2019abstinence, même courte — reprendre à la dose habituelle peut provoquer une overdose dès la toute première reprise.',
      retain: ['En cas de reprise, commencer bien en dessous de la dose d\u2019avant l\u2019arrêt.', 'C\u2019est le sentiment de capacité à agir, pas la culpabilité, qui protège vraiment.']
    },
    'rdr-vs-abstinence': {
      mood: 'transmission',
      retainMood: 'choix-eclaire',
      intro: 'Pourquoi cette app existe, en quelques repères vérifiables.',
      reveal: 'L\u2019évaluation indépendante des salles de consommation parisiennes et strasbourgeoises n\u2019a trouvé aucune détérioration de la tranquillité publique qui leur soit imputable.',
      retain: ['La réduction des risques n\u2019exclut jamais l\u2019abstinence — elle ne l\u2019impose simplement pas comme condition de départ.', 'L\u2019accès aux services RDR reste sans condition préalable.']
    },
    'autosabotage': {
      mood: 'reflexion',
      intro: 'Un mécanisme documenté depuis plus de quarante ans — pas une faiblesse de caractère.',
      reveal: 'L\u2019étude fondatrice de l\u2019auto-handicap (1978) portait littéralement sur le choix d\u2019une substance comme stratégie pour protéger son estime de soi.',
      retain: ['Préparer sa réponse à l\u2019avance fonctionne mieux qu\u2019attendre un sursaut de volonté au moment critique.', 'La grande majorité des cas ne sont pas de la destruction volontaire, mais une stratégie mal ajustée.']
    }
  };

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  function injectCSS() {
    if (document.getElementById('dg-css')) return;
    var s = document.createElement('style'); s.id = 'dg-css';
    s.textContent =
      '.dg-reveal{border:1.5px dashed var(--terra);border-radius:14px;padding:13px 15px;margin:20px 0}' +
      '.dg-reveal summary{cursor:pointer;list-style:none;display:flex;gap:10px;align-items:center;font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--terra-d);font-size:var(--fs-sm)}' +
      '.dg-reveal summary::-webkit-details-marker{display:none}' +
      '.dg-reveal summary::after{content:"+";margin-left:auto;font-size:18px}' +
      '.dg-reveal[open] summary::after{content:"\u2212"}' +
      '.dg-reveal p{margin:10px 0 0;font-family:var(--font-human);font-size:var(--fs-sm);line-height:var(--lh-normal);color:var(--ink)}' +
      '.dg-retain{display:flex;gap:10px;align-items:flex-start;background:var(--bg-2);border-radius:14px;padding:13px 15px;margin:20px 0}' +
      '.dg-retain .txt p{margin:0 0 6px;font-family:var(--font-human);font-size:var(--fs-sm);color:var(--ink)}' +
      '.dg-retain ul{margin:6px 0 0;padding-left:18px}' +
      '.dg-retain li{font-family:var(--font-human);font-size:var(--fs-sm);color:var(--ink);line-height:var(--lh-normal);margin-bottom:4px}';
    document.head.appendChild(s);
  }

  function init(dossierId) {
    var data = CONTENT[dossierId];
    var wrap = document.querySelector('.dossier');
    if (!data || !wrap) return;
    injectCSS();

    var lede = wrap.querySelector('.lede') || wrap.querySelector('.notice');
    if (lede) {
      var introEl = document.createElement('div');
      introEl.className = 'dg-intro';
      introEl.innerHTML = (window.MDCompagnon ? MDCompagnon.avatarHTML(data.mood, { size: 'sm' }) : '') + '<p>' + esc(data.intro) + '</p>';
      lede.parentNode.insertBefore(introEl, lede.nextSibling);
    }

    var aideCard = Array.prototype.find.call(wrap.querySelectorAll('.card.rdr .tag'), function (t) {
      return t.textContent.indexOf('Se faire aider') >= 0;
    });
    var anchor = aideCard ? aideCard.closest('.card') : null;
    if (anchor) {
      var revealEl = document.createElement('details');
      revealEl.className = 'dg-reveal';
      revealEl.innerHTML = '<summary>Le saviez-vous ?</summary><p>' + esc(data.reveal) + '</p>';

      var retainEl = document.createElement('div');
      retainEl.className = 'dg-retain';
      retainEl.innerHTML = (window.MDCompagnon ? MDCompagnon.avatarHTML(data.retainMood || data.mood, { size: 'sm' }) : '') +
        '<div class="txt"><p>Si tu ne devais retenir que deux choses de ce dossier :</p>' +
        '<ul>' + data.retain.map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul></div>';

      anchor.parentNode.insertBefore(revealEl, anchor);
      anchor.parentNode.insertBefore(retainEl, anchor);
    }
  }

  window.MDDossierGuide = { init: init };
})();
