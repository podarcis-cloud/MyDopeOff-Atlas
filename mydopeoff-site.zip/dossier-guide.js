/* dossier-guide.js — la mascotte accueille et referme la lecture d'un dossier.
   Deux fonctions seulement (accueillir, réagir/orienter) — jamais un quiz noté,
   jamais de score : un « ce que tu retiens » proposé, pas vérifié. */
(function () {
  'use strict';

  var CONTENT = {
    'crack': {
      mood: 'concentration',
      intro: 'Ce sujet est chargé — je reste avec toi pendant la lecture, sans détour inutile.',
      reveal: 'La cocaïne fumée atteint le cerveau en quelques secondes seulement — le circuit apprend à réclamer la dose suivante avant même que le plaisir précédent ne soit retombé.',
      retain: ['Le craving devient le vrai moteur, pas le plaisir — un mécanisme neurologique, pas un manque de volonté.', 'Les ressources de réduction des risques existent, même en usage actif.']
    },
    'ketamine': {
      mood: 'concentration',
      intro: 'Une lecture technique — je simplifie au fil du texte.',
      reveal: 'Le « k-hole » (dissociation profonde) peut être vécu comme une expérience de mort imminente — angoissant, parfois traumatisant, même sans risque vital réel.',
      retain: ['La dissociation n\u2019élimine pas les autres risques (noyade, chute).', 'Une cystite interstitielle peut s\u2019installer en usage régulier.']
    },
    'nitreux': {
      mood: 'vigilance',
      intro: 'Court à lire, mais deux ou trois points changent vraiment la donne.',
      reveal: 'Sa très courte durée d\u2019action pousse à répéter rapidement les prises — c\u2019est ce rythme, plus que le produit seul, qui banalise l\u2019usage.',
      retain: ['Jamais inhaler directement d\u2019une cartouche pressurisée (gelures).', 'Jamais dans un sac fermé sur la tête (asphyxie).']
    },
    'opioides-synthese': {
      mood: 'vigilance',
      intro: 'Un sujet qui monte vite en Europe — je te donne les repères essentiels.',
      reveal: 'L\u2019Agence européenne des drogues a recensé 7 nouveaux opioïdes de synthèse rien qu\u2019en 2025 — certains des centaines de fois plus puissants que l\u2019héroïne.',
      retain: ['N\u2019importe quel produit peut être coupé au fentanyl, sans rien pour le signaler.', 'La naloxone ne fait jamais de mal, même en cas de doute.']
    },
    'alcool': {
      mood: 'vigilance',
      intro: 'La substance la plus banalisée du pays — et pas la moins risquée.',
      reveal: 'Sans encadrement médical, le delirium tremens a un taux de mortalité de 5 à 15 % — un des risques les moins connus de l\u2019alcool.',
      retain: ['Ne jamais arrêter brutalement une consommation ancienne et importante sans avis médical.', 'La réduction des risques n\u2019exige pas l\u2019abstinence totale.']
    },
    'cannabis': {
      mood: 'curiosite',
      intro: 'Le produit a changé plus vite que sa réputation — quelques repères à jour.',
      reveal: 'Un comestible met jusqu\u2019à deux heures à faire effet — le piège de surdosage le plus fréquent, même chez des consommateurs expérimentés.',
      retain: ['Attendre au moins deux heures avant de reprendre un comestible.', 'La teneur en THC a beaucoup augmenté en vingt ans.']
    },
    'cocaine': {
      mood: 'vigilance',
      intro: 'L\u2019image festive cache une réalité clinique assez différente.',
      reveal: 'Contrairement aux opioïdes ou à l\u2019alcool, aucun médicament n\u2019est à ce jour approuvé pour le trouble de l\u2019usage de cocaïne.',
      retain: ['Ne jamais associer cocaïne et alcool (cocaéthylène, plus toxique que les deux séparément).', 'Une douleur thoracique après usage est une urgence, pas un détail.']
    },
    'benzodiazepines': {
      mood: 'vigilance',
      intro: 'Prescrites par millions — un mésusage souvent passé sous silence.',
      reveal: 'Les nouvelles « designer benzodiazépines » agissent à des doses si faibles qu\u2019elles échappent souvent aux tests toxicologiques classiques.',
      retain: ['Jamais d\u2019arrêt brutal après plusieurs semaines de traitement.', 'Jamais associées à l\u2019alcool ou à un opioïde.']
    },
    'mdma': {
      mood: 'curiosite',
      intro: 'Drogue festive et molécule étudiée en clinique — les deux sont vrais.',
      reveal: 'Trop boire peut être aussi dangereux que pas assez : l\u2019hyponatrémie (excès d\u2019eau sans sels minéraux) provoque des convulsions, tout comme la déshydratation.',
      retain: ['S\u2019hydrater par petites gorgées régulières, pas en grande quantité d\u2019un coup.', 'Éviter absolument la combinaison avec des antidépresseurs.']
    },
    'tabac-vapotage': {
      mood: 'vigilance',
      intro: 'La puff a changé la donne chez les plus jeunes — vite, et récemment.',
      reveal: 'Environ un lycéen sur cinq a déjà expérimenté une puff — un produit interdit à la vente en France depuis 2025, mais qui circule encore.',
      retain: ['Un dispositif rechargeable à taux connu vaut mieux qu\u2019une puff jetable.', 'Chez un·e non-fumeur·se, ne jamais commencer reste la meilleure réduction des risques.']
    },
    'polyconsommation': {
      mood: 'vigilance',
      intro: 'Le danger vient souvent du mélange, pas d\u2019une seule substance.',
      reveal: 'Associer alcool et cannabis, même à doses modérées, multiplie le risque d\u2019accident de la route par 14 par rapport à la sobriété totale.',
      retain: ['Espacer les prises plutôt que les cumuler.', 'Ne jamais associer deux dépresseurs du système nerveux (alcool, benzodiazépines, opioïdes).']
    },
    'psychedeliques': {
      mood: 'clarification',
      retainMood: 'vigilance',
      intro: 'Beaucoup d\u2019enthousiasme, beaucoup d\u2019essais en cours \u2014 et un \u00e9cart inhabituel entre les deux.',
      reveal: 'Dans l\u2019essai le plus rigoureux sur le micro-dosage, les participants qui prenaient un placebo sans le savoir rapportaient exactement les m\u00eames b\u00e9n\u00e9fices que ceux qui prenaient la substance.',
      retain: ['Les r\u00e9sultats encourageants viennent de la th\u00e9rapie \u00e0 dose forte encadr\u00e9e, pas du micro-dosage \u2014 les deux ne se transposent pas.', 'Ant\u00e9c\u00e9dents psychotiques dans la famille, traitement s\u00e9rotoninergique en cours : deux contre-indications qui excluent des essais, donc invisibles dans les r\u00e9sultats publi\u00e9s.']
    },
    'rechute': {
      mood: 'bienveillance',
      intro: 'Un mot qui évoque une chute — la science décrit surtout un processus.',
      reveal: 'La tolérance diminue après une période d\u2019abstinence, même courte — reprendre à la dose habituelle peut provoquer une overdose dès la toute première reprise.',
      retain: ['En cas de reprise, commencer bien en dessous de la dose d\u2019avant l\u2019arrêt.', 'C\u2019est le sentiment de capacité à agir, pas la culpabilité, qui protège vraiment.']
    },
    'rdr-vs-abstinence': {
      mood: 'transmission',
      retainMood: 'choix-eclaire',
      intro: 'Pourquoi cette app existe, en quelques repères vérifiables.',
      reveal: 'L\u2019évaluation indépendante des salles de consommation parisiennes et strasbourgeoises n\u2019a trouvé aucune détérioration de la tranquillité publique qui leur soit imputable.',
      retain: ['La réduction des risques n\u2019exclut jamais l\u2019abstinence — elle ne l\u2019impose simplement pas comme condition de départ.', 'L\u2019accès aux services RDR reste sans condition préalable.']
    },
    'autosabotage': {
      mood: 'reflexion',
      intro: 'Un mécanisme documenté depuis plus de quarante ans — pas une faiblesse de caractère.',
      reveal: 'L\u2019étude fondatrice de l\u2019auto-handicap (1978) portait littéralement sur le choix d\u2019une substance comme stratégie pour protéger son estime de soi.',
      retain: ['Préparer sa réponse à l\u2019avance fonctionne mieux qu\u2019attendre un sursaut de volonté au moment critique.', 'La grande majorité des cas ne sont pas de la destruction volontaire, mais une stratégie mal ajustée.']
    },
    'environnement': {
      mood: 'ancrage',
      retainMood: 'horizon',
      intro: 'Le lieu où l\u2019on consomme n\u2019est jamais un simple décor \u2014 il fait partie du réflexe lui-même.',
      reveal: 'Chez les vétérans du Vietnam, changer de contexte a suffi à faire disparaître, pour environ 9 personnes sur 10, une dépendance à l\u2019héroïne jugée à l\u2019époque irréversible.',
      retain: ['Une résistance apprise dans un lieu reste largement liée à ce lieu \u2014 ce n\u2019est jamais un manque de volonté.', 'Changer de décor aide vraiment, mais ne remplace jamais un travail sur le stress et les émotions.']
    }
  };

/* Traductions anglaises du contenu injecté (intros mascotte, révélations, points à retenir).
     Le français reste dans DATA ci-dessus : c'est la version de référence. Ici seul l'anglais,
     comme dans dossiers-i18n.js — pas de duplication du texte source. */
  var EN = {
    'crack': { intro: 'This is a heavy subject — I will stay with you through the reading, without unnecessary detours.',
      reveal: 'Smoked cocaine reaches the brain in just seconds — the circuit learns to demand the next dose before the previous pleasure has even faded.',
      retain: ['Craving becomes the real driver, not pleasure — a neurological mechanism, not a lack of willpower.', 'Harm reduction resources exist, even during active use.'] },
    'ketamine': { intro: 'A technical read — I will simplify as we go.',
      reveal: 'The “k-hole” (deep dissociation) can be experienced as a near-death experience — distressing, sometimes traumatic, even with no real threat to life.',
      retain: ['Dissociation does not remove the other risks (drowning, falls).', 'Interstitial cystitis can set in with regular use.'] },
    'nitreux': { intro: 'A short read, but two or three points genuinely change things.',
      reveal: 'Its very short duration pushes people to redose quickly — it is that rhythm, more than the product alone, that makes the use seem trivial.',
      retain: ['Never inhale directly from a pressurised charger (frostbite).', 'Never inside a closed bag over the head (asphyxiation).'] },
    'opioides-synthese': { intro: 'A subject rising fast in Europe — here are the essential reference points.',
      reveal: 'The European Union Drugs Agency recorded 7 new synthetic opioids in 2025 alone — some hundreds of times more potent than heroin.',
      retain: ['Any product can be cut with fentanyl, with nothing to indicate it.', 'Naloxone never does harm, even when in doubt.'] },
    'alcool': { intro: 'The most normalised substance in the country — and not the least risky.',
      reveal: 'Without medical supervision, delirium tremens has a mortality rate of 5 to 15% — one of the least known risks of alcohol.',
      retain: ['Never stop a long-standing heavy intake abruptly without medical advice.', 'Harm reduction does not require total abstinence.'] },
    'cannabis': { intro: 'The product has changed faster than its reputation — a few up-to-date reference points.',
      reveal: 'An edible takes up to two hours to take effect — the most common overdose trap, even among experienced users.',
      retain: ['Wait at least two hours before taking more of an edible.', 'THC content has risen sharply over twenty years.'] },
    'cocaine': { intro: 'The party image hides a rather different clinical reality.',
      reveal: 'Unlike opioids or alcohol, no medication has been approved to date for cocaine use disorder.',
      retain: ['Never combine cocaine and alcohol (cocaethylene, more toxic than either alone).', 'Chest pain after use is an emergency, not a detail.'] },
    'benzodiazepines': { intro: 'Prescribed by the million — with misuse that often goes unspoken.',
      reveal: 'The new “designer benzodiazepines” act at doses so low that they often escape standard toxicology tests.',
      retain: ['Never stop abruptly after several weeks of treatment.', 'Never combine with alcohol or an opioid.'] },
    'mdma': { intro: 'A party drug and a molecule studied in the clinic — both are true.',
      reveal: 'Drinking too much can be as dangerous as drinking too little: hyponatraemia (excess water without mineral salts) causes seizures, just as dehydration does.',
      retain: ['Hydrate in small regular sips, not large amounts at once.', 'Absolutely avoid combining with antidepressants.'] },
    'tabac-vapotage': { intro: 'The puff has changed things for the youngest — fast, and recently.',
      reveal: 'Around one in five secondary school students has tried a puff — a product banned from sale in France since 2025, but still circulating.',
      retain: ['A refillable device with a known nicotine level beats a disposable puff.', 'For a non-smoker, never starting remains the best harm reduction.'] },
    'polyconsommation': { intro: 'The danger often comes from the mix, not from one substance alone.',
      reveal: 'Combining alcohol and cannabis, even at moderate doses, multiplies the risk of a road accident by 14 compared with complete sobriety.',
      retain: ['Space out doses rather than stacking them.', 'Never combine two central nervous system depressants (alcohol, benzodiazepines, opioids).'] },
    'psychedeliques': { intro: 'A great deal of enthusiasm, a great many trials under way — and an unusual gap between the two.',
      reveal: 'In the most rigorous trial on microdosing, participants unknowingly taking a placebo reported exactly the same benefits as those taking the substance.',
      retain: ['The encouraging results come from supervised high-dose therapy, not from microdosing — the two do not transfer.', 'Psychotic history in the family, or ongoing serotonergic treatment: two contraindications that exclude people from trials, and are therefore invisible in published results.'] },
    'rechute': { intro: 'A word that suggests a fall — science mostly describes a process.',
      reveal: 'Tolerance drops after a period of abstinence, even a short one — going back to the usual dose can cause an overdose on the very first return to use.',
      retain: ['If use resumes, start well below the dose from before stopping.', 'It is the sense of being able to act, not guilt, that genuinely protects.'] },
    'rdr-vs-abstinence': { intro: 'Why this app exists, in a few verifiable reference points.',
      reveal: 'The independent evaluation of the Paris and Strasbourg consumption rooms found no deterioration in public order attributable to them.',
      retain: ['Harm reduction never excludes abstinence — it simply does not impose it as a starting condition.', 'Access to harm reduction services remains free of preconditions.'] },
    'autosabotage': { intro: 'A mechanism documented for more than forty years — not a character flaw.',
      reveal: 'The founding study on self-handicapping (1978) was literally about choosing a substance as a strategy to protect self-esteem.',
      retain: ['Preparing your response in advance works better than waiting for a surge of willpower at the critical moment.', 'The vast majority of cases are not deliberate self-destruction, but a poorly adjusted strategy.'] },
    'environnement': { intro: 'The place where someone uses is never just a backdrop — it is part of the reflex itself.',
      reveal: 'Among Vietnam veterans, a change of context alone was enough to make a heroin dependence once thought irreversible disappear for roughly 9 out of 10 of them.',
      retain: ['Resistance learned in one place stays largely tied to that place — it is never a lack of willpower.', 'Changing the setting genuinely helps, but never replaces working on stress and emotions.'] }
  };
  var LBL = {
    fr: { reveal: 'Le saviez-vous ?', retain: 'Si tu ne devais retenir que deux choses de ce dossier :' },
    en: { reveal: 'Did you know?', retain: 'If you only remember two things from this file:' }
  };
  /* Langue effective : MDCore fait autorité s'il est déjà chargé, sinon l'attribut lang du
     document (que core.js tient à jour). Repli sur le français. */
  function lg(){
    try { if (window.MDCore && MDCore.lang) return MDCore.lang() === 'en' ? 'en' : 'fr'; } catch(e){}
    return (document.documentElement.getAttribute('lang') === 'en') ? 'en' : 'fr';
  }
  function loc(id, data){
    if (lg() !== 'en') return data;
    var e = EN[id];
    if (!e) return data;
    return { mood: data.mood, retainMood: data.retainMood, intro: e.intro || data.intro,
             reveal: e.reveal || data.reveal, retain: e.retain || data.retain };
  }

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  function injectCSS() {
    if (document.getElementById('dg-css')) return;
    var s = document.createElement('style'); s.id = 'dg-css';
    s.textContent =
      '.dg-reveal{border:1.5px dashed var(--terra);border-radius:14px;padding:13px 15px;margin:20px 0}' +
      '.dg-reveal summary{cursor:pointer;list-style:none;display:flex;gap:10px;align-items:center;font-family:var(--font-technical);font-weight:var(--w-bold);color:var(--terra-d);font-size:var(--fs-sm)}' +
      '.dg-reveal summary::-webkit-details-marker{display:none}' +
      '.dg-reveal summary::after{content:"+";margin-left:auto;font-size:18px}' +
      '.dg-reveal[open] summary::after{content:"\u2212"}' +
      '.dg-reveal p{margin:10px 0 0;font-family:var(--font-human);font-size:var(--fs-sm);line-height:var(--lh-normal);color:var(--ink)}' +
      '.dg-retain{display:flex;gap:10px;align-items:flex-start;background:var(--bg-2);border-radius:14px;padding:13px 15px;margin:20px 0}' +
      '.dg-retain .txt p{margin:0 0 6px;font-family:var(--font-human);font-size:var(--fs-sm);color:var(--ink)}' +
      '.dg-retain ul{margin:6px 0 0;padding-left:18px}' +
      '.dg-retain li{font-family:var(--font-human);font-size:var(--fs-sm);color:var(--ink);line-height:var(--lh-normal);margin-bottom:4px}';
    document.head.appendChild(s);
  }

  function init(dossierId) {
    var data = CONTENT[dossierId];
    var wrap = document.querySelector('.dossier');
    data = loc(dossierId, data);
    if (!data || !wrap) return;
    injectCSS();

    var lede = wrap.querySelector('.lede') || wrap.querySelector('.notice');
    if (lede) {
      var introEl = document.createElement('div');
      introEl.className = 'dg-intro';
      introEl.innerHTML = (window.MDCompagnon ? MDCompagnon.avatarHTML(data.mood, { size: 'sm' }) : '') + '<p>' + esc(data.intro) + '</p>';
      lede.parentNode.insertBefore(introEl, lede.nextSibling);
    }

    var aideCard = Array.prototype.find.call(wrap.querySelectorAll('.card.rdr .tag'), function (t) {
      return t.textContent.indexOf('Se faire aider') >= 0;
    });
    var anchor = aideCard ? aideCard.closest('.card') : null;
    if (anchor) {
      var revealEl = document.createElement('details');
      revealEl.className = 'dg-reveal';
      revealEl.innerHTML = '<summary>' + LBL[lg()].reveal + '</summary><p>' + esc(data.reveal) + '</p>';

      var retainEl = document.createElement('div');
      retainEl.className = 'dg-retain';
      retainEl.innerHTML = (window.MDCompagnon ? MDCompagnon.avatarHTML(data.retainMood || data.mood, { size: 'sm' }) : '') +
        '<div class="txt"><p>' + LBL[lg()].retain + '</p>' +
        '<ul>' + data.retain.map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul></div>';

      anchor.parentNode.insertBefore(revealEl, anchor);
      anchor.parentNode.insertBefore(retainEl, anchor);
    }
  }

  window.MDDossierGuide = { init: init };
})();
