/* MyDope Off — page-elan.js
   Logique de elan, extraite du script inline de elan.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var DURATION=65000, WIN_MS=1500, TOTAL_TARGET=26;
  var body=document.getElementById('el-body');

  var IMPULSION=['Maintenant','Tout de suite','C\u00e9der','Vite','Sans r\u00e9fl\u00e9chir','L\u2019envie','Le r\u00e9flexe','Craquer','Automatique','Encore un peu',
    'Juste cette fois','\u00c7a urge','L\u2019impulsion','Le manque','Sans attendre','Le besoin','Flancher','Se laisser aller','L\u2019urgence',
    'Ne plus r\u00e9sister','Baisser les bras','Plus fort que moi','Juste un peu','Sans h\u00e9siter','Rien d\u2019autre ne compte','Tout de suite ou jamais'];
  var VALEURS_DEFAUT=['Famille','Amiti\u00e9','Lien aux autres','Amour','Communaut\u00e9',
    'Sant\u00e9','Sommeil','Mouvement','Alimentation','\u00c9nergie',
    'Apprendre','Cr\u00e9ativit\u00e9','Travail qui a du sens','Curiosit\u00e9','Spiritualit\u00e9','Ambition',
    'Libert\u00e9','Aventure','Nature','Simplicit\u00e9','Voyage',
    'Honn\u00eatet\u00e9','S\u00e9r\u00e9nit\u00e9','Courage','Humour','Gratitude','Authenticit\u00e9',
    'Aider les autres','Justice','Environnement','G\u00e9n\u00e9rosit\u00e9','Engagement',
    'Repos','Jeu','Musique & art','Beaut\u00e9','Douceur'];

  function personalValues(){
    var v = window.MDData ? MDData.getValeurs() : [];
    return v.length ? v : VALEURS_DEFAUT;
  }

  var running=false, t0=0, endAt=0, trial=0, current=null, responded=false, stimT0=0;
  var pushHits=0, pushMiss=0, pushFalse=0, pullHits=0, pullMiss=0, pullFalse=0, rts=[];
  var startY=0, dragging=false, cardEl=null;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }

  function render(){
    body.innerHTML =
      '<div class="el-zone push" id="el-zone-push">\u2191 Repousser \u2014 l\u2019impulsion</div>'+
      '<div class="el-stage" id="el-stage"><div class="el-card" id="el-card"></div></div>'+
      '<div class="el-zone pull" id="el-zone-pull">\u2193 Attirer \u2014 ce qui compte</div>'+
      '<div class="el-hint" id="el-hint">Pr\u00eat\u2026</div>'+
      '<div class="game-hud"><span>Impulsions repouss\u00e9es : <b id="el-push-ok">0</b></span><span>Valeurs attir\u00e9es : <b id="el-pull-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="el-fill"></span></div>';
    wireDrag();
  }

  function wireDrag(){
    cardEl=document.getElementById('el-card');
    cardEl.addEventListener('pointerdown', function(e){ if(!current||responded) return; dragging=true; startY=e.clientY; cardEl.style.transition='none'; });
    window.addEventListener('pointermove', function(e){
      if(!dragging||!cardEl) return;
      var dy=e.clientY-startY;
      cardEl.style.transform='translateY('+dy+'px)'; cardEl.style.opacity=String(Math.max(.3,1-Math.abs(dy)/140));
    });
    window.addEventListener('pointerup', function(e){
      if(!dragging) return; dragging=false;
      if(!cardEl){ return; }
      cardEl.style.transition='transform .15s,opacity .15s';
      var dy=e.clientY-startY;
      if (dy<=-46) answer('push'); else if (dy>=46) answer('pull');
      else { cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1'; }
    });
    cardEl.addEventListener('touchmove', function(e){ if(dragging) e.preventDefault(); }, {passive:false});
  }

  function flashZone(id,ok){
    var z=document.getElementById(id); if(!z) return;
    z.classList.add(ok?'flash-ok':'flash-bad');
    setTimeout(function(){ z.classList.remove('flash-ok','flash-bad'); },320);
  }

  var trialTimer=null;

  function answer(dir){
    if (!current || responded) return;
    responded=true;
    clearTimeout(trialTimer);
    var correct = (dir==='push' && current.kind==='impulsion') || (dir==='pull' && current.kind==='valeur');
    var hint=document.getElementById('el-hint');
    if (correct){
      rts.push(Date.now()-stimT0);
      if (current.kind==='impulsion'){ pushHits++; } else { pullHits++; }
      flashZone(dir==='push'?'el-zone-push':'el-zone-pull', true);
      hint.textContent='Bien.'; hint.style.color='var(--sauge)';
      cardEl.style.transform='translateY('+(dir==='push'?'-160px':'160px')+')'; cardEl.style.opacity='0';
    } else {
      if (current.kind==='impulsion'){ pushFalse++; } else { pullFalse++; }
      flashZone(dir==='push'?'el-zone-push':'el-zone-pull', false);
      hint.textContent='Pas cette direction.'; hint.style.color='var(--terra)';
      cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1';
    }
    document.getElementById('el-push-ok').textContent=pushHits;
    document.getElementById('el-pull-ok').textContent=pullHits;
    advance();
  }

  function advance(){
    var remain=endAt-Date.now();
    var fillEl=document.getElementById('el-fill'); if(fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
    if (remain>300 && trial<TOTAL_TARGET) setTimeout(nextTrial,380); else if (running) finish();
  }

  function nextTrial(){
    if (!running) return;
    trial++;
    responded=false;
    var kind = Math.random()<0.5 ? 'impulsion':'valeur';
    var pool = kind==='impulsion' ? IMPULSION : personalValues();
    var word = pool[Math.floor(Math.random()*pool.length)];
    current = { kind:kind, word:word };
    cardEl = document.getElementById('el-card');
    if (cardEl){
      cardEl.className='el-card kind-'+kind;
      cardEl.textContent=word;
      cardEl.style.transition='none'; cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1';
    }
    document.getElementById('el-hint').style.color='var(--ink-2)';
    document.getElementById('el-hint').textContent='\u00a0';
    stimT0=Date.now();
    trialTimer=setTimeout(function(){
      if (!running || responded) return;
      if (current.kind==='impulsion') pushMiss++; else pullMiss++;
      var hint=document.getElementById('el-hint'); if(hint){ hint.textContent='Trop lent \u2014 au suivant.'; hint.style.color='var(--ink-2)'; }
      if (cardEl){ cardEl.style.transition='opacity .15s'; cardEl.style.opacity='0'; }
      advance();
    }, WIN_MS);
  }

  function finish(){
    running=false;
    var pushTotal=pushHits+pushMiss+pushFalse, pullTotal=pullHits+pullMiss+pullFalse;
    var pushAcc = pushTotal ? Math.round(pushHits/pushTotal*100) : 0;
    var pullAcc = pullTotal ? Math.round(pullHits/pullTotal*100) : 0;
    var rtMoyen = rts.length ? Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length) : 0;
    var indice = Math.round((pushAcc+pullAcc)/2);
    var d=store(); d.elan=d.elan||{best:0,parties:0}; d.elan.parties++; if(indice>d.elan.best)d.elan.best=indice; save(d);
    if (window.MDExercise){
      MDExercise.after('elan',{avant:window.__mdAvant,dureeSec:Math.round((Date.now()-t0)/1000),meta:{repousse:pushAcc,attire:pullAcc,rtMoyen:rtMoyen,indice:indice},
        title:'\u00c9lan', stats:[{label:'impulsions repoussées',value:pushAcc+'%'},{label:'valeurs attirées',value:pullAcc+'%'},{label:'indice de réflexe',value:indice+'/100'}],
        nav:{ primary:{label:'Rejouer'}, secondary:{label:'Retour au labo'} },
        onClose:function(){window.__mdAvant=null; begin();}});
    } else if (window.MDData&&MDData.logSession){
      MDData.logSession('elan',{dureeSec:Math.round((Date.now()-t0)/1000),meta:{repousse:pushAcc,attire:pullAcc,rtMoyen:rtMoyen,indice:indice}});
    }
  }

  function startRound(){
    trial=0; pushHits=0;pushMiss=0;pushFalse=0;pullHits=0;pullMiss=0;pullFalse=0;rts=[];
    running=true; t0=Date.now(); endAt=Date.now()+DURATION;
    render();
    nextTrial();
  }

  function begin(){
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'action', title:'\u00c9lan',
        lines:['Un mot appara\u00eet au centre.',
               'Impulsion (« Maintenant », « C\u00e9der »\u2026) : glisse-le vers le HAUT, tu le repousses.',
               'Valeur qui compte pour toi : glisse-le vers le BAS, tu l\u2019attires.'],
        why:'Ton cerveau associe une r\u00e9ponse motrice automatique \u2014 « approcher » \u2014 \u00e0 tout ce qui \u00e9voque le manque, souvent plus vite que ta r\u00e9flexion consciente. R\u00e9p\u00e9ter le geste inverse (repousser l\u2019impulsion, attirer tes valeurs) entra\u00eene cette association implicite \u00e0 s\u2019affaiblir \u2014 des essais cliniques montrent que \u00e7a r\u00e9duit le risque de rechute en compl\u00e9ment d\u2019un suivi (Wiers 2011).',
        onStart:function(avant){ window.__mdAvant=avant; startRound(); } });
    } else { startRound(); }
  }
  document.getElementById('el-start').addEventListener('click', begin);
  document.getElementById('el-skip').addEventListener('click', begin);
  try{ MDCore.init({page:'elan',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
