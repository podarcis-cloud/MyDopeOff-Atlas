/* MyDope Off — page-elan.js
   Logique de elan, extraite du script inline de elan.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var DURATION=65000, WIN_MS=1500, TOTAL_TARGET=26;
  var body=document.getElementById('el-body');

  var IMPULSION_FR=['Maintenant','Tout de suite','Céder','Vite','Sans réfléchir','L\u2019envie','Le réflexe','Craquer','Automatique','Encore un peu',
    'Juste cette fois','Ça urge','L\u2019impulsion','Le manque','Sans attendre','Le besoin','Flancher','Se laisser aller','L\u2019urgence',
    'Ne plus résister','Baisser les bras','Plus fort que moi','Juste un peu','Sans hésiter','Rien d\u2019autre ne compte','Tout de suite ou jamais'];
  var IMPULSION_EN=['Right now','Immediately','Give in','Fast','Without thinking','The urge','The reflex','Cave in','Automatic','Just a bit more',
    'Just this once','It\u2019s urgent','The impulse','The craving','Without waiting','The need','Give way','Let go','The urgency',
    'Stop resisting','Give up','Stronger than me','Just a little','Without hesitating','Nothing else matters','Now or never'];
  var IMPULSION = L==='en' ? IMPULSION_EN : IMPULSION_FR;

  var VALEURS_DEFAUT_FR=['Famille','Amitié','Lien aux autres','Amour','Communauté',
    'Santé','Sommeil','Mouvement','Alimentation','Énergie',
    'Apprendre','Créativité','Travail qui a du sens','Curiosité','Spiritualité','Ambition',
    'Liberté','Aventure','Nature','Simplicité','Voyage',
    'Honnêteté','Sérénité','Courage','Humour','Gratitude','Authenticité',
    'Aider les autres','Justice','Environnement','Générosité','Engagement',
    'Repos','Jeu','Musique & art','Beauté','Douceur'];
  var VALEURS_DEFAUT_EN=['Family','Friendship','Connection to others','Love','Community',
    'Health','Sleep','Movement','Food','Energy',
    'Learning','Creativity','Meaningful work','Curiosity','Spirituality','Ambition',
    'Freedom','Adventure','Nature','Simplicity','Travel',
    'Honesty','Serenity','Courage','Humour','Gratitude','Authenticity',
    'Helping others','Justice','Environment','Generosity','Commitment',
    'Rest','Play','Music & art','Beauty','Gentleness'];
  var VALEURS_DEFAUT = L==='en' ? VALEURS_DEFAUT_EN : VALEURS_DEFAUT_FR;

  var T = {
    zone_push:{fr:'\u2191 Repousser \u2014 l\u2019impulsion',en:'\u2191 Push away \u2014 the impulse'},
    zone_pull:{fr:'\u2193 Attirer \u2014 ce qui compte',en:'\u2193 Pull in \u2014 what matters'},
    ready:{fr:'Prêt\u2026',en:'Ready\u2026'},
    hud_push:{fr:'Impulsions repoussées : ',en:'Impulses pushed away: '},
    hud_pull:{fr:'Valeurs attirées : ',en:'Values pulled in: '},
    good:{fr:'Bien.',en:'Good.'},
    wrong_dir:{fr:'Pas cette direction.',en:'Not that direction.'},
    too_slow:{fr:'Trop lent \u2014 au suivant.',en:'Too slow \u2014 next one.'},
    title:{fr:'Élan',en:'Impulse'},
    stat_push:{fr:'impulsions repoussées',en:'impulses pushed away'},
    stat_pull:{fr:'valeurs attirées',en:'values pulled in'},
    stat_index:{fr:'indice de réflexe',en:'reflex index'},
    replay:{fr:'Rejouer',en:'Replay'},
    back_labo:{fr:'Retour au labo',en:'Back to Lab'},
    rules_l1:{fr:'Un mot apparaît au centre.',en:'A word appears in the centre.'},
    rules_l2:{fr:'Impulsion (« Maintenant », « Céder »\u2026) : glisse-le vers le HAUT, tu le repousses.',en:'Impulse ("Right now", "Give in"\u2026): swipe it UP, you push it away.'},
    rules_l3:{fr:'Valeur qui compte pour toi : glisse-le vers le BAS, tu l\u2019attires.',en:'A value that matters to you: swipe it DOWN, you pull it in.'},
    rules_why:{fr:'Ton cerveau associe une réponse motrice automatique \u2014 « approcher » \u2014 à tout ce qui évoque le manque, souvent plus vite que ta réflexion consciente. Répéter le geste inverse (repousser l\u2019impulsion, attirer tes valeurs) entraîne cette association implicite à s\u2019affaiblir \u2014 des essais cliniques montrent que ça réduit le risque de rechute en complément d\u2019un suivi (Wiers 2011).',
      en:'Your brain links an automatic motor response \u2014 "approach" \u2014 to anything evoking craving, often faster than your conscious thinking. Repeating the opposite gesture (pushing the impulse away, pulling your values in) trains that implicit association to weaken \u2014 clinical trials show this reduces relapse risk alongside standard treatment (Wiers 2011).'}
  };
  function t(k){ var e=T[k]; return e ? (L==='en'?e.en:e.fr) : k; }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'elan.title':    { fr: 'Élan', en: 'Impulse' },
    'elan.subtitle': { fr: 'Repousse l\u2019impulsion, attire ce qui compte pour toi.', en: 'Push the impulse away, pull in what matters to you.' },
    'elan.q_label':  { fr: 'Rediriger le geste', en: 'Redirect the gesture' },
    'elan.q_sub':    { fr: 'Un mot apparaît. S\u2019il parle d\u2019impulsion, repousse-le vers le haut. S\u2019il parle d\u2019une valeur qui compte pour toi, attire-le vers le bas.',
      en: 'A word appears. If it speaks of impulse, push it upward. If it speaks of a value that matters to you, pull it downward.' }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function personalValues(){
    var v = window.MDData ? MDData.getValeurs() : [];
    return v.length ? v : VALEURS_DEFAUT;
  }

  var running=false, t0=0, endAt=0, trial=0, current=null, responded=false, stimT0=0;
  var pushHits=0, pushMiss=0, pushFalse=0, pullHits=0, pullMiss=0, pullFalse=0, rts=[];
  var startY=0, dragging=false, cardEl=null;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }

  function render(){
    body.innerHTML =
      '<div class="el-zone push" id="el-zone-push">'+t('zone_push')+'</div>'+
      '<div class="el-stage" id="el-stage"><div class="el-card" id="el-card"></div></div>'+
      '<div class="el-zone pull" id="el-zone-pull">'+t('zone_pull')+'</div>'+
      '<div class="el-hint" id="el-hint">'+t('ready')+'</div>'+
      '<div class="game-hud"><span>'+t('hud_push')+'<b id="el-push-ok">0</b></span><span>'+t('hud_pull')+'<b id="el-pull-ok">0</b></span></div>'+
      '<div class="game-bar"><span id="el-fill"></span></div>';
    wireDrag();
  }

  function wireDrag(){
    cardEl=document.getElementById('el-card');
    cardEl.addEventListener('pointerdown', function(e){ if(!current||responded) return; dragging=true; startY=e.clientY; cardEl.style.transition='none'; });
    window.addEventListener('pointermove', function(e){
      if(!dragging||!cardEl) return;
      var dy=e.clientY-startY;
      cardEl.style.transform='translateY('+dy+'px)'; cardEl.style.opacity=String(Math.max(.3,1-Math.abs(dy)/140));
    });
    window.addEventListener('pointerup', function(e){
      if(!dragging) return; dragging=false;
      if(!cardEl){ return; }
      cardEl.style.transition='transform .15s,opacity .15s';
      var dy=e.clientY-startY;
      if (dy<=-46) answer('push'); else if (dy>=46) answer('pull');
      else { cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1'; }
    });
    cardEl.addEventListener('touchmove', function(e){ if(dragging) e.preventDefault(); }, {passive:false});
  }

  function flashZone(id,ok){
    var z=document.getElementById(id); if(!z) return;
    z.classList.add(ok?'flash-ok':'flash-bad');
    setTimeout(function(){ z.classList.remove('flash-ok','flash-bad'); },320);
  }

  var trialTimer=null;

  function answer(dir){
    if (!current || responded) return;
    responded=true;
    clearTimeout(trialTimer);
    var correct = (dir==='push' && current.kind==='impulsion') || (dir==='pull' && current.kind==='valeur');
    var hint=document.getElementById('el-hint');
    if (correct){
      rts.push(Date.now()-stimT0);
      if (current.kind==='impulsion'){ pushHits++; } else { pullHits++; }
      flashZone(dir==='push'?'el-zone-push':'el-zone-pull', true);
      hint.textContent=t('good'); hint.style.color='var(--sauge)';
      cardEl.style.transform='translateY('+(dir==='push'?'-160px':'160px')+')'; cardEl.style.opacity='0';
    } else {
      if (current.kind==='impulsion'){ pushFalse++; } else { pullFalse++; }
      flashZone(dir==='push'?'el-zone-push':'el-zone-pull', false);
      hint.textContent=t('wrong_dir'); hint.style.color='var(--terra)';
      cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1';
    }
    document.getElementById('el-push-ok').textContent=pushHits;
    document.getElementById('el-pull-ok').textContent=pullHits;
    advance();
  }

  function advance(){
    var remain=endAt-Date.now();
    var fillEl=document.getElementById('el-fill'); if(fillEl) fillEl.style.width=Math.round((1-Math.max(0,remain)/DURATION)*100)+'%';
    if (remain>300 && trial<TOTAL_TARGET) setTimeout(nextTrial,380); else if (running) finish();
  }

  function nextTrial(){
    if (!running) return;
    trial++;
    responded=false;
    var kind = Math.random()<0.5 ? 'impulsion':'valeur';
    var pool = kind==='impulsion' ? IMPULSION : personalValues();
    var word = pool[Math.floor(Math.random()*pool.length)];
    current = { kind:kind, word:word };
    cardEl = document.getElementById('el-card');
    if (cardEl){
      cardEl.className='el-card kind-'+kind;
      cardEl.textContent=word;
      cardEl.style.transition='none'; cardEl.style.transform='translateY(0)'; cardEl.style.opacity='1';
    }
    document.getElementById('el-hint').style.color='var(--ink-2)';
    document.getElementById('el-hint').textContent='\u00a0';
    stimT0=Date.now();
    trialTimer=setTimeout(function(){
      if (!running || responded) return;
      if (current.kind==='impulsion') pushMiss++; else pullMiss++;
      var hint=document.getElementById('el-hint'); if(hint){ hint.textContent=t('too_slow'); hint.style.color='var(--ink-2)'; }
      if (cardEl){ cardEl.style.transition='opacity .15s'; cardEl.style.opacity='0'; }
      advance();
    }, WIN_MS);
  }

  function finish(){
    running=false;
    var pushTotal=pushHits+pushMiss+pushFalse, pullTotal=pullHits+pullMiss+pullFalse;
    var pushAcc = pushTotal ? Math.round(pushHits/pushTotal*100) : 0;
    var pullAcc = pullTotal ? Math.round(pullHits/pullTotal*100) : 0;
    var rtMoyen = rts.length ? Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length) : 0;
    var indice = Math.round((pushAcc+pullAcc)/2);
    var d=store(); d.elan=d.elan||{best:0,parties:0}; d.elan.parties++; if(indice>d.elan.best)d.elan.best=indice; save(d);
    if (window.MDExercise){
      MDExercise.after('elan',{avant:window.__mdAvant,dureeSec:Math.round((Date.now()-t0)/1000),meta:{repousse:pushAcc,attire:pullAcc,rtMoyen:rtMoyen,indice:indice},
        title:t('title'), stats:[{label:t('stat_push'),value:pushAcc+'%'},{label:t('stat_pull'),value:pullAcc+'%'},{label:t('stat_index'),value:indice+'/100'}],
        nav:{ primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose:function(){window.__mdAvant=null; begin();}});
    } else if (window.MDData&&MDData.logSession){
      MDData.logSession('elan',{dureeSec:Math.round((Date.now()-t0)/1000),meta:{repousse:pushAcc,attire:pullAcc,rtMoyen:rtMoyen,indice:indice}});
    }
  }

  function startRound(){
    trial=0; pushHits=0;pushMiss=0;pushFalse=0;pullHits=0;pullMiss=0;pullFalse=0;rts=[];
    running=true; t0=Date.now(); endAt=Date.now()+DURATION;
    render();
    nextTrial();
  }

  function begin(){
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'action', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; startRound(); } });
    } else { startRound(); }
  }
  try{ MDCore.init({page:'elan',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
