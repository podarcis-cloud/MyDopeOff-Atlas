/* MyDope Off — page-suivi.js · « Ta progression »
   Entrées (localStorage ctc_v6.entries[]) :
     { date:'YYYY-MM-DD', level:0|1|2|3, substance, qty, cost:Number, note }
   level : 0 sans conso · 1 léger · 2 modéré · 3 notable
*/
(function () {
  'use strict';
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function save(s){ try { localStorage.setItem('ctc_v6', JSON.stringify(s)); } catch(e){} }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }
  function setEntries(arr){ var s=store(); s.entries=arr; save(s); }
  function goalDays(){ var s=store(); return (s.goal&&s.goal.days)||14; }
  function T(k,v){ return window.MDCore? MDCore.t(k,v):k; }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  var MONTHS=['janv.','févr.','mars','avr.','mai','juin','juil.','août','sept.','oct.','nov.','déc.'];
  var DOW=['L','M','M','J','V','S','D'], LV=['clean','low','mid','high'];

  function byDate(){ var m={}; entries().forEach(function(e){ if(e&&e.date)m[e.date]=e; }); return m; }
  function streak(map){ var d=new Date(); d.setHours(0,0,0,0); var n=0; for(var i=0;i<400;i++){ if(map[iso(d)]){n++;d.setDate(d.getDate()-1);}else break; } return n; }

  /* ---- rendus ---- */
  function renderStats(map){
    var host=document.getElementById('stats'); if(!host)return;
    var es=entries(), spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    host.innerHTML='<div class="stat"><div class="n">'+(streak(map)||Object.keys(map).length)+'</div><div class="l">'+T('suivi.st_days')+'</div></div>'+
      '<div class="stat"><div class="n">≈ '+Math.round(spend)+' €</div><div class="l">'+T('suivi.st_est')+'</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">'+T('suivi.st_entries')+'</div></div>';
  }
  function renderGoal(map){
    var cur=streak(map), goal=goalDays(), pct=Math.min(100,Math.round(cur/goal*100))||0, left=Math.max(0,goal-cur);
    var pe=document.getElementById('goal-pct'), bi=document.getElementById('goal-bar'), nt=document.getElementById('goal-note');
    if(pe)pe.textContent=pct+' %'; if(bi)bi.style.width=pct+'%'; if(nt)nt.textContent=T('suivi.goal_note',{cur:cur,left:left});
    var big=document.getElementById('where-big'); if(big)big.textContent='Jour '+cur;
    var gl=document.getElementById('where-goal'); if(gl)gl.textContent=T('suivi.goalline',{n:goal});
  }
  function renderCalendar(map){
    var host=document.getElementById('cal-grid'); if(!host)return;
    var today=new Date(); today.setHours(0,0,0,0);
    var start=new Date(today); start.setDate(start.getDate()-29);
    var lead=(start.getDay()+6)%7, html='';
    for(var i=0;i<lead;i++) html+='<div class="cal-cell empty"></div>';
    for(var j=0;j<30;j++){
      var d=new Date(start); d.setDate(start.getDate()+j); var key=iso(d), e=map[key], cls='none', lab=T('cal.none');
      if(e){ var lv=Math.max(0,Math.min(3,Number(e.level)||0)); cls=LV[lv]; lab=lv===0?T('suivi.noconso'):((e.substance||'')+' '+(e.qty||'')).trim(); }
      var tody=key===iso(today)?' today':'';
      html+='<button type="button" class="cal-cell '+cls+tody+'" data-date="'+key+'" title="'+d.getDate()+' '+MONTHS[d.getMonth()]+' · '+lab+'" aria-label="'+d.getDate()+' '+MONTHS[d.getMonth()]+', '+lab+'">'+d.getDate()+'</button>';
    }
    host.innerHTML=html;
    host.querySelectorAll('.cal-cell[data-date]').forEach(function(c){ c.addEventListener('click',function(){ openSheet(c.getAttribute('data-date')); }); });
    var ml=document.getElementById('cal-month'); if(ml) ml.textContent=MONTHS[start.getMonth()]+(start.getMonth()!==today.getMonth()?' – '+MONTHS[today.getMonth()]:'');
    var dow=document.getElementById('cal-dow'); if(dow) dow.innerHTML=DOW.map(function(x){return '<span>'+x+'</span>';}).join('');
  }
  function renderJournal(){
    var host=document.getElementById('journal'); if(!host)return; var es=entries();
    var sorted=es.slice().sort(function(a,b){return (b.date||'').localeCompare(a.date||'');}).slice(0,8);
    host.innerHTML=sorted.map(function(e){
      var d=new Date(e.date+'T00:00:00'), dd=isNaN(d)?'':d.getDate(), mm=isNaN(d)?'':MONTHS[d.getMonth()];
      var clean=(Number(e.level)||0)===0, title=clean?T('suivi.noconso'):(e.substance||'—');
      var sub=clean?'':[e.qty,e.note].filter(Boolean).join(' · '), cost=clean?'—':((Number(e.cost)||0)?Math.round(e.cost)+' €':'—');
      return '<button type="button" class="entry" data-date="'+e.date+'" style="width:100%;text-align:left"><div class="day"><div class="d">'+dd+'</div><div class="m">'+mm+'</div></div><div class="sep"></div><div class="main"><div class="t">'+title+'</div>'+(sub?'<div class="s">'+sub+'</div>':'')+'</div><span class="cost">'+cost+'</span></button>';
    }).join('');
    host.querySelectorAll('.entry[data-date]').forEach(function(b){ b.addEventListener('click',function(){ openSheet(b.getAttribute('data-date')); }); });
    var em=document.getElementById('empty'); if(em) em.hidden=es.length>0;
  }
  function renderAll(){ var m=byDate(); renderStats(m); renderGoal(m); renderCalendar(m); renderJournal(); }

  /* ---- modale ---- */
  var sheet, curDate, curLevel;
  function setLevel(lv){
    curLevel=lv;
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.classList.toggle('on', Number(b.getAttribute('data-lv'))===lv); });
    document.getElementById('conso-fields').hidden = (lv===0);
  }
  function openSheet(dateStr){
    curDate=dateStr;
    var map=byDate(), e=map[dateStr]||null;
    var d=new Date(dateStr+'T00:00:00');
    document.getElementById('sheet-date').textContent = d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    document.getElementById('f-date').value=dateStr;
    setLevel(e?Math.max(0,Math.min(3,Number(e.level)||0)):0);
    document.getElementById('f-sub').value = e&&e.substance?e.substance:'';
    document.getElementById('f-qty').value = e&&e.qty?e.qty:'';
    document.getElementById('f-cost').value = e&&e.cost?e.cost:'';
    document.getElementById('sheet-del').hidden = !e;
    sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');
  }
  function closeSheet(){ sheet.classList.remove('open'); sheet.setAttribute('aria-hidden','true'); }
  function saveEntry(){
    var arr=entries().filter(function(x){ return x.date!==curDate; });
    var entry={ date:curDate, level:curLevel };
    if(curLevel>0){
      entry.substance=document.getElementById('f-sub').value.trim();
      entry.qty=document.getElementById('f-qty').value.trim();
      entry.cost=Number(document.getElementById('f-cost').value)||0;
    }
    arr.push(entry); setEntries(arr); closeSheet(); renderAll();
  }
  function deleteEntry(){ setEntries(entries().filter(function(x){ return x.date!==curDate; })); closeSheet(); renderAll(); }

  ready(function(){
    if(window.MDCore) MDCore.init({ page:'suivi', section:'progression' });
    sheet=document.getElementById('sheet');
    document.getElementById('add-entry').addEventListener('click', function(){ openSheet(iso(new Date())); });
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.addEventListener('click', function(){ setLevel(Number(b.getAttribute('data-lv'))); }); });
    document.getElementById('sheet-save').addEventListener('click', saveEntry);
    document.getElementById('sheet-del').addEventListener('click', deleteEntry);
    document.getElementById('sheet-cancel').addEventListener('click', closeSheet);
    sheet.addEventListener('click', function(e){ if(e.target===sheet) closeSheet(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeSheet(); });
    renderAll();
    document.addEventListener('langchange', renderAll);
  });
})();
