/* MyDope Off — page-suivi.js · « Ta progression »
   Entrées (localStorage ctc_v6.entries[]) :
     { date:'YYYY-MM-DD', level:0|1|2|3, substance, qty, cost:Number, note }
   level : 0 sans conso · 1 léger · 2 modéré · 3 notable
*/
(function () {
  'use strict';
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function save(s){ try { localStorage.setItem('ctc_v6', JSON.stringify(s)); } catch(e){} }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }
  function setEntries(arr){ var s=store(); s.entries=arr; save(s); }
  function goalDays(){ var s=store(); return (s.goal&&s.goal.days)||14; }
  function T(k,v){ return window.MDCore? MDCore.t(k,v):k; }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  var MONTHS=['janv.','févr.','mars','avr.','mai','juin','juil.','août','sept.','oct.','nov.','déc.'];
  var DOW=['L','M','M','J','V','S','D'], LV=['clean','low','mid','high'];

  function byDate(){ var m={}; entries().forEach(function(e){ if(e&&e.date){ if(!m[e.date]||(Number(e.level)||0)>(Number(m[e.date].level)||0)) m[e.date]=e; } }); return m; }
  function streak(map){ var d=new Date(); d.setHours(0,0,0,0); var n=0; for(var i=0;i<400;i++){ if(map[iso(d)]){n++;d.setDate(d.getDate()-1);}else break; } return n; }

  /* ---------- Micro-célébrations (engagement bienveillant, jamais punitif) ---------- */
  var CLEAN_MSGS=['Journée sans conso notée. Un pas, puis un autre.','C\u2019est noté. Prendre soin de toi, ça compte.','Beau geste pour ton futur toi.','Noté. Tu avances à ton rythme.'];
  var LOG_MSGS=['C\u2019est noté, sans jugement.','Entrée ajoutée. Tu gardes la main.','Noté. Voir clair, c\u2019est déjà avancer.'];
  var STREAK_MSGS={7:'7 jours de suivi d\u2019affilée — tu tiens le fil.',14:'14 jours notés. Belle régularité.',30:'30 jours de suivi. Respect.',90:'90 jours. Tu connais ton parcours par cœur.'};
  function pick(a){ return a[Math.floor(Math.random()*a.length)]; }
  function popCell(dateStr){ var c=document.querySelector('.cal-cell[data-date="'+dateStr+'"]'); if(c){ c.classList.remove('atlas-pop'); void c.offsetWidth; c.classList.add('atlas-pop'); } }
  function celebrate(level){
    var msg, today=iso(new Date()), st=streak(byDate());
    if(curDate===today && STREAK_MSGS[st]) msg='\u2726 '+STREAK_MSGS[st];
    else if(Number(level)===0) msg=pick(CLEAN_MSGS);
    else msg=pick(LOG_MSGS);
    if(window.atlasToast) atlasToast(msg,'ok');
    popCell(curDate);
  }

  /* ---- rendus ---- */
  function renderStats(map){
    var host=document.getElementById('stats'); if(!host)return;
    var es=entries(), spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    host.innerHTML='<div class="stat"><div class="n">'+(streak(map)||Object.keys(map).length)+'</div><div class="l">'+T('suivi.st_days')+'</div></div>'+
      '<div class="stat"><div class="n">≈ '+Math.round(spend)+' €</div><div class="l">'+T('suivi.st_est')+'</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">'+T('suivi.st_entries')+'</div></div>';
  }
  function renderGoal(map){
    var g=getGoal();
    var pe=document.getElementById('goal-pct'), bi=document.getElementById('goal-bar'), nt=document.getElementById('goal-note');
    var big=document.getElementById('where-big'), gl=document.getElementById('where-goal');
    var pct=0, bigTxt='', goalLine='', note='';
    if(g.type==='sober'){
      var sub=g.substance||'', tgt=g.days||7, cur=soberStreak(sub);
      pct=Math.min(100,Math.round(cur/tgt*100))||0; bigTxt='Jour '+cur;
      goalLine='Objectif : '+tgt+' j sans '+(sub||'conso');
      note=cur+' jour'+(cur>1?'s':'')+' sans '+(sub||'conso')+' \u00b7 encore '+Math.max(0,tgt-cur)+' j';
    } else if(g.type==='freq'){
      var n=g.freq||3, used=usesLast7(); pct=Math.min(100,Math.round((1-Math.min(1,used/n))*100));
      bigTxt=used+'\u00d7'; goalLine='Objectif : max '+n+' usages / semaine';
      note=used+' usage'+(used>1?'s':'')+' sur 7 j \u00b7 plafond '+n;
    } else if(g.type==='budget'){
      var t2=g.target||100, sp=spendLast30(); pct=Math.min(100,Math.round((1-Math.min(1,sp/t2))*100));
      bigTxt=Math.round(sp)+' \u20ac'; goalLine='Objectif : \u2264 '+t2+' \u20ac / 30 j';
      note=Math.round(sp)+' \u20ac sur 30 j \u00b7 plafond '+t2+' \u20ac';
    } else if(g.type==='custom'){
      pct=0; bigTxt='Mon objectif'; goalLine=g.text||'Objectif personnalis\u00e9'; note=g.text||'\u2014';
    } else {
      var goal=g.days||14, cur2=streak(map); pct=Math.min(100,Math.round(cur2/goal*100))||0;
      bigTxt='Jour '+cur2; goalLine=T('suivi.goalline',{n:goal}); note=T('suivi.goal_note',{cur:cur2,left:Math.max(0,goal-cur2)});
    }
    if(pe)pe.textContent=pct+' %'; if(bi)bi.style.width=pct+'%'; if(nt)nt.textContent=note;
    if(big)big.textContent=bigTxt; if(gl)gl.textContent=goalLine;
  }
  function renderCalendar(map){
    var host=document.getElementById('cal-grid'); if(!host)return;
    var today=new Date(); today.setHours(0,0,0,0);
    var start=new Date(today); start.setDate(start.getDate()-29);
    var lead=(start.getDay()+6)%7, html='';
    for(var i=0;i<lead;i++) html+='<div class="cal-cell empty"></div>';
    for(var j=0;j<30;j++){
      var d=new Date(start); d.setDate(start.getDate()+j); var key=iso(d), e=map[key], cls='none', lab=T('cal.none');
      if(e){ var lv=Math.max(0,Math.min(3,Number(e.level)||0)); cls=LV[lv]; lab=lv===0?T('suivi.noconso'):((e.substance||'')+' '+(e.qty||'')).trim(); }
      var tody=key===iso(today)?' today':'';
      html+='<button type="button" class="cal-cell '+cls+tody+'" data-date="'+key+'" title="'+d.getDate()+' '+MONTHS[d.getMonth()]+' · '+lab+'" aria-label="'+d.getDate()+' '+MONTHS[d.getMonth()]+', '+lab+'">'+d.getDate()+'</button>';
    }
    host.innerHTML=html;
    host.querySelectorAll('.cal-cell[data-date]').forEach(function(c){ c.addEventListener('click',function(){ openSheet(c.getAttribute('data-date')); }); });
    var ml=document.getElementById('cal-month'); if(ml) ml.textContent=MONTHS[start.getMonth()]+(start.getMonth()!==today.getMonth()?' – '+MONTHS[today.getMonth()]:'');
    var dow=document.getElementById('cal-dow'); if(dow) dow.innerHTML=DOW.map(function(x){return '<span>'+x+'</span>';}).join('');
  }
  function renderJournal(){
    var host=document.getElementById('journal'); if(!host)return; var es=entries();
    var sorted=es.slice().sort(function(a,b){return (b.date||'').localeCompare(a.date||'');}).slice(0,8);
    host.innerHTML=sorted.map(function(e){
      var d=new Date(e.date+'T00:00:00'), dd=isNaN(d)?'':d.getDate(), mm=isNaN(d)?'':MONTHS[d.getMonth()];
      var clean=(Number(e.level)||0)===0, title=clean?T('suivi.noconso'):(e.substance||'—');
      var sub=clean?'':[e.qty,e.note].filter(Boolean).join(' · '), cost=clean?'—':((Number(e.cost)||0)?Math.round(e.cost)+' €':'—');
      return '<button type="button" class="entry" data-date="'+e.date+'" style="width:100%;text-align:left"><div class="day"><div class="d">'+dd+'</div><div class="m">'+mm+'</div></div><div class="sep"></div><div class="main"><div class="t">'+title+'</div>'+(sub?'<div class="s">'+sub+'</div>':'')+'</div><span class="cost">'+cost+'</span></button>';
    }).join('');
    host.querySelectorAll('.entry[data-date]').forEach(function(b){ b.addEventListener('click',function(){ openSheet(b.getAttribute('data-date')); }); });
    var em=document.getElementById('empty'); if(em) em.hidden=es.length>0;
  }
  function renderAll(){ var m=byDate(); renderStats(m); renderGoal(m); renderProjection(); renderCalendar(m); renderJournal(); }

  /* ---- modale ---- */
  var sheet, curDate, curLevel;
  function setLevel(lv){
    curLevel=lv;
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.classList.toggle('on', Number(b.getAttribute('data-lv'))===lv); });
    document.getElementById('conso-fields').hidden = (lv===0);
  }
  function escHtml(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  var LVL_LABEL=['Sans conso','Léger','Modéré','Notable'];
  function renderDayEntries(dateStr){
    var host=document.getElementById('day-entries'); if(!host) return;
    var all=entries(), rows=[];
    all.forEach(function(e,idx){ if(e&&e.date===dateStr) rows.push({e:e,idx:idx}); });
    if(!rows.length){ host.innerHTML=''; return; }
    var html='<div class="de-head">Déjà noté ce jour-là ('+rows.length+')</div>';
    rows.forEach(function(r){
      var e=r.e, lv=Number(e.level)||0;
      var title = lv===0 ? 'Sans conso' : (e.substance ? escHtml(e.substance) : LVL_LABEL[lv]);
      var bits=[]; if(lv>0){ if(e.qty) bits.push(escHtml(e.qty)); bits.push(LVL_LABEL[lv]); }
      var sub = bits.join(' · ');
      var cost = (Number(e.cost)||0) ? (Math.round(Number(e.cost))+' €') : '';
      html+='<div class="de-row"><span class="lvl l'+lv+'"></span>'+
            '<div class="body"><div class="t">'+title+'</div>'+(sub?'<div class="s">'+sub+'</div>':'')+'</div>'+
            (cost?'<span class="cost">'+cost+'</span>':'')+
            '<button type="button" class="x" data-del-idx="'+r.idx+'" aria-label="Supprimer cette entrée">×</button></div>';
    });
    host.innerHTML=html;
    host.querySelectorAll('[data-del-idx]').forEach(function(b){
      b.addEventListener('click', function(){ deleteEntryAt(parseInt(b.getAttribute('data-del-idx'),10)); });
    });
  }
  function deleteEntryAt(idx){
    var arr=entries(); if(idx<0||idx>=arr.length) return;
    arr.splice(idx,1); setEntries(arr);
    renderDayEntries(curDate); renderAll();
    if(window.atlasToast) atlasToast('Entrée supprimée','ok');
  }
  function openSheet(dateStr){
    curDate=dateStr;
    var d=new Date(dateStr+'T00:00:00');
    document.getElementById('sheet-date').textContent = d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    document.getElementById('f-date').value=dateStr;
    setLevel(0);
    document.getElementById('f-sub').value = '';
    document.getElementById('f-qty').value = '';
    document.getElementById('f-cost').value = '';
    document.getElementById('sheet-del').hidden = true; /* suppression par entrée désormais */
    renderDayEntries(dateStr);
    renderDetect('');
    sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');
  }
  function closeSheet(){ sheet.classList.remove('open'); sheet.setAttribute('aria-hidden','true'); }
  function saveEntry(){
    var arr=entries();
    var entry={ date:curDate, level:curLevel };
    if(curLevel>0){
      entry.substance=document.getElementById('f-sub').value.trim();
      entry.qty=document.getElementById('f-qty').value.trim();
      entry.cost=Number(document.getElementById('f-cost').value)||0;
    }
    arr.push(entry); setEntries(arr);
    /* on garde la feuille ouverte pour pouvoir ajouter plusieurs entrées le même jour */
    document.getElementById('f-sub').value=''; document.getElementById('f-qty').value=''; document.getElementById('f-cost').value='';
    setLevel(0);
    renderDayEntries(curDate); renderAll();
    celebrate(entry.level);
  }
  function deleteEntry(){ var arr=entries(); for(var i=arr.length-1;i>=0;i--){ if(arr[i].date===curDate){ arr.splice(i,1); break; } } setEntries(arr); closeSheet(); renderAll(); }

  /* ---- substances : index complet (270 fiches) + détection ---- */
  function detList(){ return (window.MD_DETECTION||[]); }
  function subIndex(){
    var base=(window.MD_SUBS_INDEX||[]).slice();
    var cust=(window.MD_CUSTOM_FICHES||[]).slice();
    try{ var ls=JSON.parse(localStorage.getItem('mdo_admin_fiches')||'[]'); if(Array.isArray(ls)) cust=cust.concat(ls); }catch(e){}
    cust.forEach(function(o){ if(o&&o.nom) base.push({n:o.nom,f:(o.categories&&o.categories[0])||'',a:o.aliases||[]}); });
    return base;
  }
  function suggestMatches(q){
    q=(q||'').trim().toLowerCase(); if(!q) return [];
    var ix=subIndex(), pre=[], inc=[], seen={};
    function push(arr,nom,alias){ var k=nom.toLowerCase(); if(seen[k])return; seen[k]=1; arr.push({nom:nom,alias:alias}); }
    ix.forEach(function(d){
      var n=d.n.toLowerCase();
      if(n.indexOf(q)===0){ push(pre,d.n,null); return; }
      var ap=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap){ push(pre,d.n,ap); return; }
      if(n.indexOf(q)>0){ push(inc,d.n,null); return; }
      var ai=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,d.n,ai);
    });
    return pre.concat(inc).slice(0,8);
  }
  function renderSuggest(q){
    var box=document.getElementById('f-sug'); if(!box) return;
    var m=suggestMatches(q);
    if(!q || !m.length){ box.classList.remove('open'); box.innerHTML=''; return; }
    box.innerHTML=m.map(function(x){ return '<div data-val="'+x.nom.replace(/"/g,'&quot;')+'">'+x.nom+(x.alias?' <small>'+x.alias+'</small>':'')+'</div>'; }).join('');
    box.classList.add('open');
    box.querySelectorAll('[data-val]').forEach(function(d){ d.addEventListener('mousedown', function(ev){ ev.preventDefault(); pickSub(d.getAttribute('data-val')); }); });
  }
  function pickSub(nom){ var el=document.getElementById('f-sub'); if(el) el.value=nom; var b=document.getElementById('f-sug'); if(b) b.classList.remove('open'); renderDetect(nom); var q=document.getElementById('f-qty'); if(q) q.focus(); }
  function canonicalOf(q){
    if(!q) return null; q=q.trim().toLowerCase(); if(!q) return null;
    var ix=subIndex();
    for(var i=0;i<ix.length;i++){ if(ix[i].n.toLowerCase()===q) return ix[i].n;
      if((ix[i].a||[]).some(function(a){return a.toLowerCase()===q;})) return ix[i].n; }
    var dl=detList();
    for(var j=0;j<dl.length;j++){ if(dl[j].nom.toLowerCase()===q) return dl[j].nom;
      if((dl[j].aliases||[]).some(function(a){return a.toLowerCase()===q;})) return dl[j].nom; }
    for(var k=0;k<ix.length;k++){ if(ix[k].n.toLowerCase().indexOf(q)===0) return ix[k].n; }
    return null;
  }
  function famOf(c){ var ix=subIndex(); for(var i=0;i<ix.length;i++){ if(ix[i].n===c) return ix[i].f||''; } return ''; }
  function findDetection(canon){
    if(!canon) return null; var c=canon.toLowerCase(), dl=detList();
    for(var i=0;i<dl.length;i++){ if(dl[i].nom.toLowerCase()===c) return dl[i];
      if((dl[i].aliases||[]).some(function(a){return a.toLowerCase()===c;})) return dl[i]; }
    return null;
  }
  function fmtH(h){ return h<24 ? (String(h).replace('.',',')+' h') : (Math.round(h/24)+' j'); }
  function fmtR(a){ return (a&&a.length===2) ? fmtH(a[0])+'\u2013'+fmtH(a[1]) : '\u2014'; }
  function renderDetect(q){
    var box=document.getElementById('detect-note'); if(!box) return;
    var canon=canonicalOf(q), d=findDetection(canon||q);
    if(d && d.detectable!==false){
      box.className='notice';
      box.innerHTML='<span><b>D\u00e9tection \u2014 '+(canon||d.nom)+'</b> (estimations) : salive ~'+fmtR(d.sal)+' \u00b7 urine ~'+fmtR(d.uri)+'.'+
        (d.source?' <span class="muted xs">Source : '+String(d.source).split('\u00b7')[0].trim()+'</span>':'')+'</span>';
      box.hidden=false; return;
    }
    if(d && d.detectable===false){ box.className='notice'; box.innerHTML='<span><b>'+(canon||d.nom)+'</b> \u2014 non d\u00e9tect\u00e9 en test de routine.</span>'; box.hidden=false; return; }
    if(canon){ var fa=famOf(canon); box.className='notice'; box.innerHTML='<span><b>'+canon+'</b>'+(fa?' \u00b7 '+fa:'')+' \u2014 fen\u00eatre de d\u00e9tection non document\u00e9e.</span>'; box.hidden=false; return; }
    box.hidden=true;
  }
  function normalizeSub(){
    var el=document.getElementById('f-sub'); if(!el) return;
    var c=canonicalOf(el.value);
    if(c && c.toLowerCase()!==el.value.trim().toLowerCase()) el.value=c;
    renderDetect(el.value);
  }

  /* ---- projection 12 mois (cagnotte potentielle) ---- */
  function equivalents(a){
    var L=[
      {min:80,em:'\uD83C\uDF7D\uFE0F',tx:function(n){return '<b>'+Math.floor(n/40)+'</b> bons restos';}},
      {min:150,em:'\uD83C\uDFA7',tx:function(n){return '<b>'+Math.floor(n/120)+'</b> places de concert';}},
      {min:300,em:'\uD83D\uDEB2',tx:function(){return 'un <b>v\u00e9lo</b> correct';}},
      {min:600,em:'\u2708\uFE0F',tx:function(n){return '<b>'+Math.floor(n/600)+'</b> vol(s) A/R en Europe';}},
      {min:1200,em:'\uD83C\uDF34',tx:function(n){return 'un <b>A/R long-courrier</b> (ex. Br\u00e9sil)'+(n>=2400?' \u00e0 deux':'');}},
      {min:2500,em:'\uD83C\uDFDD\uFE0F',tx:function(){return '<b>3 semaines</b> de voyage';}},
      {min:5000,em:'\uD83D\uDE97',tx:function(){return 'un <b>acompte voiture</b> / gros achat';}},
      {min:10000,em:'\uD83C\uDFE0',tx:function(){return 'plusieurs <b>mois de loyer</b>';}}
    ];
    var pick=L.filter(function(x){return a>=x.min;}).slice(-3);
    if(!pick.length) pick=[L[0]];
    return pick.map(function(x){ return {em:x.em, tx:x.tx(a)}; });
  }
  function renderProjection(){
    var card=document.getElementById('proj-card'); if(!card) return;
    var es=entries().filter(function(e){ return (Number(e.cost)||0)>0 && e.date; });
    if(!es.length){ card.hidden=true; return; }
    var now=Date.now(), MS=86400000;
    var es30=es.filter(function(e){ return (now-new Date(e.date+'T00:00:00').getTime())<=31*MS; });
    var monthTotal=es30.reduce(function(a,e){return a+(Number(e.cost)||0);},0), basis;
    if(monthTotal>0){ basis='D\u2019apr\u00e8s '+Math.round(monthTotal)+' \u20ac sur les 30 derniers jours \u00d7 12.'; }
    else {
      var dates=es.map(function(e){return e.date;}).sort();
      var first=new Date(dates[0]+'T00:00:00'), last=new Date(dates[dates.length-1]+'T00:00:00');
      var months=Math.max(1,(last-first)/(30*MS));
      monthTotal=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0)/months;
      basis='Moyenne mensuelle estim\u00e9e \u00d7 12.';
    }
    var annual=Math.round(monthTotal*12);
    if(annual<1){ card.hidden=true; return; }
    document.getElementById('proj-amount').textContent='\u2248 '+annual.toLocaleString('fr-FR')+' \u20ac / an';
    document.getElementById('proj-basis').textContent=basis;
    document.getElementById('proj-equiv').innerHTML=equivalents(annual).map(function(x){ return '<div class="eq"><span class="em">'+x.em+'</span><span class="tx">'+x.tx+'</span></div>'; }).join('');
    card.hidden=false;
  }
  /* ---- objectif \u00e9ditable (types + personnalis\u00e9) ---- */
  function gid(id){ return document.getElementById(id); }
  function clampN(v,mn,mx,df){ var n=parseInt(v,10); if(isNaN(n))n=df; return Math.max(mn,Math.min(mx,n)); }
  function getGoal(){ var s=store(); return (s.goal&&s.goal.type)? s.goal : {type:'days',days:(s.goal&&s.goal.days)||14}; }
  function soberStreak(sub){ var d=new Date(); d.setHours(0,0,0,0); var es=entries(), cnt=0, q=(sub||'').toLowerCase();
    for(var i=0;i<366;i++){ var key=iso(d);
      var consumed=es.some(function(e){ return e.date===key && (Number(e.level)||0)>0 && (!q || (e.substance||'').toLowerCase().indexOf(q)>=0); });
      if(consumed) break; cnt++; d.setDate(d.getDate()-1); }
    return cnt;
  }
  function usesLast7(){ var now=Date.now(); return entries().filter(function(e){ return (Number(e.level)||0)>0 && e.date && (now-new Date(e.date+'T00:00:00').getTime())<=7*86400000; }).length; }
  function spendLast30(){ var now=Date.now(); return entries().reduce(function(a,e){ return a + (((now-new Date(e.date+'T00:00:00').getTime())<=30*86400000)?(Number(e.cost)||0):0); },0); }

  function setupGoalEditor(){
    var btn=gid('goal-edit-btn'), box=gid('goal-edit'), sel=gid('goal-type'), fields=gid('goal-fields'), sv=gid('goal-save');
    if(!btn||!box||!sel) return;
    function esc(v){ return String(v==null?'':v).replace(/"/g,'&quot;'); }
    function renderFields(){
      var t=sel.value, c=getGoal(), h='';
      if(t==='days') h='<div class="field"><label>Objectif (jours)</label><input class="input" id="gf-days" type="number" min="1" max="365" inputmode="numeric" value="'+(c.days||14)+'"></div><div class="goal-presets" id="gf-pre"></div>';
      else if(t==='sober') h='<div class="field"><label>Substance \u00e0 \u00e9viter</label><input class="input" id="gf-sub" type="text" placeholder="ex. alcool, cannabis\u2026" value="'+esc(c.substance)+'"></div><div class="field"><label>Objectif (jours sans)</label><input class="input" id="gf-days" type="number" min="1" max="365" inputmode="numeric" value="'+(c.days||7)+'"></div>';
      else if(t==='freq') h='<div class="field"><label>Maximum d\'usages par semaine</label><input class="input" id="gf-n" type="number" min="1" max="50" inputmode="numeric" value="'+(c.freq||3)+'"></div>';
      else if(t==='budget') h='<div class="field"><label>Plafond de d\u00e9pense sur 30 jours (\u20ac)</label><input class="input" id="gf-eur" type="number" min="1" inputmode="numeric" value="'+(c.target||100)+'"></div>';
      else h='<div class="field"><label>Ton objectif (texte libre)</label><input class="input" id="gf-text" type="text" placeholder="ex. une semaine plus douce" value="'+esc(c.text)+'"></div>';
      fields.innerHTML=h;
      if(t==='days'){ var P=[7,14,30,60,90], dd=gid('gf-days'), pr=gid('gf-pre');
        pr.innerHTML=P.map(function(d){return '<button type="button" data-d="'+d+'">'+d+' j</button>';}).join('');
        pr.querySelectorAll('[data-d]').forEach(function(b){ b.addEventListener('click', function(){ dd.value=b.getAttribute('data-d'); }); });
      }
    }
    btn.addEventListener('click', function(){ box.classList.toggle('open'); if(box.classList.contains('open')){ sel.value=getGoal().type||'days'; renderFields(); } });
    sel.addEventListener('change', renderFields);
    sv.addEventListener('click', function(){
      var t=sel.value, s2=store(), go={type:t};
      if(t==='days') go.days=clampN(gid('gf-days').value,1,365,14);
      else if(t==='sober'){ go.substance=(gid('gf-sub').value||'').trim(); go.days=clampN(gid('gf-days').value,1,365,7); }
      else if(t==='freq') go.freq=clampN(gid('gf-n').value,1,50,3);
      else if(t==='budget') go.target=clampN(gid('gf-eur').value,1,100000,100);
      else go.text=(gid('gf-text').value||'').trim();
      s2.goal=go; save(s2); box.classList.remove('open'); renderAll();
    });
  }

  ready(function(){
    if(window.MDCore) MDCore.init({ page:'suivi', section:'progression' });
    sheet=document.getElementById('sheet');
    var fsub=document.getElementById('f-sub');
    if(fsub){
      fsub.addEventListener('input', function(){ renderSuggest(fsub.value); renderDetect(fsub.value); });
      fsub.addEventListener('focus', function(){ renderSuggest(fsub.value); });
      fsub.addEventListener('blur', function(){ setTimeout(function(){ var b=document.getElementById('f-sug'); if(b) b.classList.remove('open'); normalizeSub(); },150); });
    }
    setupGoalEditor();
    document.getElementById('add-entry').addEventListener('click', function(){ openSheet(iso(new Date())); });
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.addEventListener('click', function(){ setLevel(Number(b.getAttribute('data-lv'))); }); });
    document.getElementById('sheet-save').addEventListener('click', saveEntry);
    document.getElementById('sheet-del').addEventListener('click', deleteEntry);
    document.getElementById('sheet-cancel').addEventListener('click', closeSheet);
    sheet.addEventListener('click', function(e){ if(e.target===sheet) closeSheet(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeSheet(); });
    renderAll();
    document.addEventListener('langchange', renderAll);
  });
})();
