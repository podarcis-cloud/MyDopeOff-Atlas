/* MyDope Off — page-suivi.js · « Ta progression »
   Entrées (localStorage ctc_v6.entries[]) :
     { id, date:'YYYY-MM-DD', level:0|1|2|3, substance, qty:Number, unit, cost:Number, note }
   Objectifs multiples : ctc_v6.goals[] = [{ id, type, substance, unit, days, freq, target, text }]
*/
(function () {
  'use strict';
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function save(s){ try { localStorage.setItem('ctc_v6', JSON.stringify(s)); } catch(e){} }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  function uid(){ return 'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,6); }
  var MONTHS=['janv.','f\u00e9vr.','mars','avr.','mai','juin','juil.','ao\u00fbt','sept.','oct.','nov.','d\u00e9c.'];
  var DOW=['L','M','M','J','V','S','D'], LV=['clean','low','mid','high'], LVN=['Sans conso','L\u00e9ger','Mod\u00e9r\u00e9','Notable'];

  /* ---- migration + acc\u00e8s ---- */
  function entries(){ var s=store(); var a=Array.isArray(s.entries)?s.entries:[]; var dirty=false;
    a.forEach(function(e){ if(e&&!e.id){ e.id=uid(); dirty=true; } if(e&&typeof e.qty==='string'){ var m=parseFloat((e.qty||'').replace(',','.')); var u=(e.qty.replace(/[0-9.,\s]/g,'')||''); e.qty=isNaN(m)?null:m; if(!e.unit&&u)e.unit=u; dirty=true; } });
    if(dirty) setEntries(a); return a; }
  function setEntries(arr){ var s=store(); s.entries=arr; save(s); }
  function goals(){ var s=store(); if(Array.isArray(s.goals)&&s.goals.length) return s.goals;
    if(s.goal&&s.goal.type){ s.goals=[Object.assign({id:uid()}, s.goal)]; } else { s.goals=[{id:uid(),type:'days',days:14}]; }
    save(s); return s.goals; }
  function setGoals(arr){ var s=store(); s.goals=arr; save(s); }

  /* ---- unit\u00e9s par produit ---- */
  function unitsFor(name){
    var n=(name||'').toLowerCase();
    if(/cannabis|weed|beuh|herbe|ganja|shit|r[\u00e9e]sine|hash|thc|joint|space/.test(n)) return ['joint(s)','g','bang(s)'];
    if(/alcool|bi[\u00e8e]re|vin|vodka|whisky|rhum|[\u00e9e]thanol|pastis|spiritueux|champagne/.test(n)) return ['verre(s)','cl','unit\u00e9(s)'];
    if(/mdma|ecsta|ecstasy|comprim|cachet|pilule/.test(n)) return ['comprim\u00e9(s)','mg','g'];
    if(/lsd|buvard|acide|trip/.test(n)) return ['buvard(s)','\u00b5g','goutte(s)'];
    if(/champi|psilo|truffe/.test(n)) return ['g','pi\u00e8ce(s)','g\u00e9lule(s)'];
    if(/protoxyde|proto d|whippet|cartouche|ballon/.test(n)) return ['cartouche(s)','ballon(s)','bonbonne(s)'];
    if(/popper/.test(n)) return ['bouff\u00e9e(s)','ml','flacon(s)'];
    if(/ghb|gbl/.test(n)) return ['ml','dose(s)','capsule(s)'];
    if(/k[\u00e9e]tamine|k[\u00e9e]ta\b/.test(n)) return ['g','ligne(s)','ml'];
    if(/coca|coke|speed|amph[\u00e9e]t/.test(n)) return ['g','ligne(s)','mg'];
    if(/h[\u00e9e]ro[i\u00ef]ne|opium|fentanyl|m[\u00e9e]thadone/.test(n)) return ['mg','g','dose(s)'];
    if(/mdpv|3-?mmc|4-?mmc|2cb|2c-b|nbome|cathinone|sels? de bain|m[\u00e9e]thylph/.test(n)) return ['mg','g','comprim\u00e9(s)'];
    if(/cigarette|tabac|nicotine|vape|puff|clope/.test(n)) return ['cigarette(s)','g','bouff\u00e9e(s)'];
    return ['g','mg','ml','comprim\u00e9(s)','unit\u00e9(s)'];
  }
  function fillUnitSelect(sel, name, current){
    if(!sel) return; var us=unitsFor(name); sel.innerHTML=us.map(function(u){ return '<option'+(u===current?' selected':'')+'>'+u+'</option>'; }).join('');
    if(current && us.indexOf(current)<0){ var o=document.createElement('option'); o.textContent=current; o.selected=true; sel.appendChild(o); }
  }

  /* ---- regroupements ---- */
  function byDate(){ var m={}; entries().forEach(function(e){ if(e&&e.date){ if(!m[e.date]||(Number(e.level)||0)>(Number(m[e.date].level)||0)) m[e.date]=e; } }); return m; }
  function entriesForDate(d){ return entries().filter(function(e){ return e.date===d; }); }
  function streak(map){ var d=new Date(); d.setHours(0,0,0,0); var n=0; for(var i=0;i<400;i++){ if(map[iso(d)]){n++;d.setDate(d.getDate()-1);}else break; } return n; }
  function qtyLabel(e){ var q=(e.qty!=null&&e.qty!=='')?(String(e.qty).replace('.',',')):''; return (q+' '+(e.unit||'')).trim(); }

  /* ============ STATS ============ */
  function renderStats(map){
    var host=document.getElementById('stats'); if(!host)return;
    var es=entries(), spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    host.innerHTML='<div class="stat"><div class="n">'+(streak(map)||Object.keys(map).length)+'</div><div class="l">Jours suivis</div></div>'+
      '<div class="stat"><div class="n n-money">\u2248\u00a0'+Math.round(spend)+'\u00a0\u20ac</div><div class="l">Estim\u00e9</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">Entr\u00e9es</div></div>';
  }

  /* ============ OBJECTIFS (multiples) ============ */
  function soberStreak(sub){ var d=new Date(); d.setHours(0,0,0,0); var es=entries(), cnt=0, q=(sub||'').toLowerCase();
    for(var i=0;i<366;i++){ var key=iso(d);
      var consumed=es.some(function(e){ return e.date===key && (Number(e.level)||0)>0 && (!q || (e.substance||'').toLowerCase().indexOf(q)>=0); });
      if(consumed) break; cnt++; d.setDate(d.getDate()-1); }
    return cnt;
  }
  function usesLast7(sub){ var now=Date.now(), q=(sub||'').toLowerCase(); return entries().filter(function(e){ return (Number(e.level)||0)>0 && e.date && (now-new Date(e.date+'T00:00:00').getTime())<=7*86400000 && (!q||(e.substance||'').toLowerCase().indexOf(q)>=0); }); }
  function qtyLast7(sub){ return usesLast7(sub).reduce(function(a,e){ return a+(Number(e.qty)||0); },0); }
  function spendLast30(){ var now=Date.now(); return entries().reduce(function(a,e){ return a + (((now-new Date(e.date+'T00:00:00').getTime())<=30*86400000)?(Number(e.cost)||0):0); },0); }

  function goalProgress(g, map){
    if(g.type==='sober'){ var sub=g.substance||'', tgt=g.days||7, cur=soberStreak(sub);
      return { pct:Math.min(100,Math.round(cur/tgt*100))||0, big:'Jour '+cur, line:'Objectif : '+tgt+' j sans '+(sub||'conso'), note:cur+' j sans '+(sub||'conso')+' \u00b7 encore '+Math.max(0,tgt-cur)+' j' }; }
    if(g.type==='freq'){ var n=g.freq||3, sub2=g.substance||'', unit=g.unit||'usages';
      var used = g.byQty ? qtyLast7(sub2) : usesLast7(sub2).length;
      var pct=Math.min(100,Math.round((1-Math.min(1,used/(n||1)))*100));
      var lineWhat = g.byQty? (n+' '+unit+' de '+(sub2||'conso')) : (n+' '+(sub2?sub2:'usages'));
      var noteWhat = g.byQty? (used+' '+unit) : (used+'\u00d7');
      return { pct:pct, big:noteWhat, line:'Objectif : max '+lineWhat+' / sem.', note:noteWhat+' sur 7 j \u00b7 plafond '+n }; }
    if(g.type==='budget'){ var t2=g.target||100, sp=spendLast30();
      return { pct:Math.min(100,Math.round((1-Math.min(1,sp/t2))*100)), big:Math.round(sp)+' \u20ac', line:'Objectif : \u2264 '+t2+' \u20ac / 30 j', note:Math.round(sp)+' \u20ac sur 30 j \u00b7 plafond '+t2+' \u20ac' }; }
    if(g.type==='custom'){ return { pct:0, big:'Mon objectif', line:g.text||'Objectif personnalis\u00e9', note:g.text||'\u2014' }; }
    var goal=g.days||14, cur2=streak(map);
    return { pct:Math.min(100,Math.round(cur2/goal*100))||0, big:'Jour '+cur2, line:'Objectif : '+goal+' jours de suivi', note:cur2+' j suivis \u00b7 encore '+Math.max(0,goal-cur2)+' j' };
  }
  function renderGoals(map){
    var host=document.getElementById('goals-list'); if(!host) return;
    var gs=goals();
    host.innerHTML = gs.map(function(g){
      var p=goalProgress(g, map);
      return '<section class="goal" style="margin-bottom:12px" data-gid="'+g.id+'">'+
        '<div class="row"><h3 style="margin:0;font-size:var(--fs-ui,15px)">'+p.line+'</h3><span class="pct">'+p.pct+' %</span></div>'+
        '<div class="bar"><i style="width:'+p.pct+'%"></i></div>'+
        '<p class="note" style="margin:6px 0 8px">'+p.note+'</p>'+
        '<div style="display:flex;gap:8px"><button type="button" class="btn btn-sm btn-outline g-edit" data-gid="'+g.id+'">Modifier</button>'+
        (gs.length>1?'<button type="button" class="btn btn-sm btn-outline g-del" data-gid="'+g.id+'" style="color:var(--terra,#C7765C)">Supprimer</button>':'')+'</div>'+
        '</section>';
    }).join('');
    host.querySelectorAll('.g-edit').forEach(function(b){ b.addEventListener('click',function(){ openGoalEditor(b.getAttribute('data-gid')); }); });
    host.querySelectorAll('.g-del').forEach(function(b){ b.addEventListener('click',function(){ var id=b.getAttribute('data-gid'); setGoals(goals().filter(function(x){return x.id!==id;})); renderAll(); }); });
    var prim=gs[0]?goalProgress(gs[0],map):null, big=document.getElementById('where-big'), gl=document.getElementById('where-goal');
    if(prim){ if(big)big.textContent=prim.big; if(gl)gl.textContent=prim.line; }
  }
  function esc(v){ return String(v==null?'':v).replace(/"/g,'&quot;'); }
  function escHtml(v){ return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function openGoalEditor(id){
    var box=document.getElementById('goal-edit'), sel=document.getElementById('goal-type'); if(!box||!sel) return;
    var g = id ? goals().filter(function(x){return x.id===id;})[0] : {type:'days',days:14};
    document.getElementById('goal-edit-id').value = id||'';
    sel.value=g.type||'days'; renderGoalFields(g); box.classList.add('open');
    box.scrollIntoView({behavior:'smooth',block:'center'});
  }
  function renderGoalFields(g){
    var t=document.getElementById('goal-type').value, fields=document.getElementById('goal-fields'), h='';
    if(t==='days') h='<div class="field"><label>Objectif (jours de suivi)</label><input class="input" id="gf-days" type="number" min="1" max="365" inputmode="numeric" value="'+(g.days||14)+'"></div>';
    else if(t==='sober') h='<div class="field ac-wrap"><label>Substance \u00e0 \u00e9viter</label><input class="input" id="gf-sub" type="text" placeholder="ex. alcool, cannabis\u2026" autocomplete="off" value="'+esc(g.substance)+'"><div class="suggestions" id="gf-sug"></div></div><div class="field"><label>Objectif (jours sans)</label><input class="input" id="gf-days" type="number" min="1" max="365" inputmode="numeric" value="'+(g.days||7)+'"></div>';
    else if(t==='freq') h='<div class="field ac-wrap"><label>Substance (optionnel)</label><input class="input" id="gf-sub" type="text" placeholder="toutes si vide" autocomplete="off" value="'+esc(g.substance)+'"><div class="suggestions" id="gf-sug"></div></div><div class="row2"><div class="field"><label>Maximum / semaine</label><input class="input" id="gf-n" type="number" min="1" max="200" inputmode="numeric" value="'+(g.freq||3)+'"></div><div class="field"><label>Unit\u00e9</label><select class="input" id="gf-unit"></select></div></div>';
    else if(t==='budget') h='<div class="field"><label>Plafond de d\u00e9pense / 30 j (\u20ac)</label><input class="input" id="gf-eur" type="number" min="1" inputmode="numeric" value="'+(g.target||100)+'"></div>';
    else h='<div class="field"><label>Ton objectif (texte libre)</label><input class="input" id="gf-text" type="text" placeholder="ex. une semaine plus douce" value="'+esc(g.text)+'"></div>';
    fields.innerHTML=h;
    var sub=document.getElementById('gf-sub'), unit=document.getElementById('gf-unit');
    if(unit){ fillUnitSelect(unit, g.substance, g.unit); }
    if(sub){ attachSuggest(sub, document.getElementById('gf-sug'), function(nom){ if(unit) fillUnitSelect(unit, nom, unit.value); });
      sub.addEventListener('input', function(){ if(unit) fillUnitSelect(unit, sub.value, unit.value); }); }
  }
  function saveGoal(){
    var t=document.getElementById('goal-type').value, id=document.getElementById('goal-edit-id').value, go={type:t};
    function gv(i){ var e=document.getElementById(i); return e?e.value:''; }
    function cn(v,mn,mx,df){ var n=parseInt(v,10); if(isNaN(n))n=df; return Math.max(mn,Math.min(mx,n)); }
    if(t==='days') go.days=cn(gv('gf-days'),1,365,14);
    else if(t==='sober'){ go.substance=(gv('gf-sub')||'').trim(); go.days=cn(gv('gf-days'),1,365,7); }
    else if(t==='freq'){ go.substance=(gv('gf-sub')||'').trim(); go.freq=cn(gv('gf-n'),1,200,3); go.unit=(gv('gf-unit')||'').trim(); go.byQty=!!go.unit; }
    else if(t==='budget') go.target=cn(gv('gf-eur'),1,100000,100);
    else go.text=(gv('gf-text')||'').trim();
    var gs=goals();
    if(id){ for(var i=0;i<gs.length;i++) if(gs[i].id===id){ go.id=id; gs[i]=go; break; } }
    else { go.id=uid(); gs.push(go); }
    setGoals(gs); document.getElementById('goal-edit').classList.remove('open'); renderAll();
  }

  /* ============ CALENDRIER ============ */
  function renderCalendar(){
    var host=document.getElementById('cal-grid'); if(!host)return;
    var today=new Date(); today.setHours(0,0,0,0);
    var start=new Date(today); start.setDate(start.getDate()-29);
    var lead=(start.getDay()+6)%7, html='';
    for(var i=0;i<lead;i++) html+='<div class="cal-cell empty"></div>';
    for(var j=0;j<30;j++){
      var d=new Date(start); d.setDate(start.getDate()+j); var key=iso(d), dayEs=entriesForDate(key), cls='none', lab='Non renseign\u00e9';
      if(dayEs.length){ var mx=dayEs.reduce(function(a,e){return Math.max(a,Number(e.level)||0);},0); cls=LV[Math.max(0,Math.min(3,mx))];
        lab = mx===0 ? 'Sans conso' : dayEs.filter(function(e){return (Number(e.level)||0)>0;}).map(function(e){return (e.substance||'').trim();}).filter(Boolean).join(', ');
        if(dayEs.length>1) lab += ' ('+dayEs.length+')';
      }
      var tody=key===iso(today)?' today':'';
      html+='<button type="button" class="cal-cell '+cls+tody+'" data-date="'+key+'" title="'+d.getDate()+' '+MONTHS[d.getMonth()]+' \u00b7 '+lab+'"><span>'+d.getDate()+'</span>'+(dayEs.length>1?'<span class="cal-count">('+dayEs.length+')</span>':'')+'</button>';
    }
    host.innerHTML=html;
    host.querySelectorAll('.cal-cell[data-date]').forEach(function(c){ c.addEventListener('click',function(){ openDay(c.getAttribute('data-date')); }); });
    var ml=document.getElementById('cal-month'); if(ml) ml.textContent=MONTHS[start.getMonth()]+(start.getMonth()!==today.getMonth()?' \u2013 '+MONTHS[today.getMonth()]:'');
    var dow=document.getElementById('cal-dow'); if(dow) dow.innerHTML=DOW.map(function(x){return '<span>'+x+'</span>';}).join('');
  }

  /* ============ JOURNAL ============ */
  var journalExpanded=false;
  function renderJournal(){
    var host=document.getElementById('journal'); if(!host)return; var es=entries();
    var sorted=es.slice().sort(function(a,b){return (b.date||'').localeCompare(a.date||'')|| (b.id||'').localeCompare(a.id||'');}).slice(0,12);
    var visible=journalExpanded?sorted:sorted.slice(0,3);
    host.innerHTML=visible.map(function(e){
      var d=new Date(e.date+'T00:00:00'), dd=isNaN(d)?'':d.getDate(), mm=isNaN(d)?'':MONTHS[d.getMonth()];
      var clean=(Number(e.level)||0)===0, title=clean?'Sans conso':(e.substance||'\u2014');
      var sub=clean?'':[qtyLabel(e),escHtml(e.note)].filter(Boolean).join(' \u00b7 '), cost=clean?'\u2014':((Number(e.cost)||0)?Math.round(e.cost)+' \u20ac':'\u2014');
      return '<button type="button" class="entry" data-id="'+e.id+'" data-date="'+e.date+'" style="width:100%;text-align:left"><div class="day"><div class="d">'+dd+'</div><div class="m">'+mm+'</div></div><div class="sep"></div><div class="main"><div class="t">'+title+'</div>'+(sub?'<div class="s">'+sub+'</div>':'')+'</div><span class="cost">'+cost+'</span></button>';
    }).join('');
    if(sorted.length>3){
      if(!journalExpanded){
        host.innerHTML+='<button type="button" id="journal-more" class="btn btn-outline btn-block" style="margin-top:8px">Afficher la suite\u2026</button>';
        var more=document.getElementById('journal-more');
        if(more) more.addEventListener('click', function(){ journalExpanded=true; renderJournal(); });
      } else {
        host.innerHTML+='<button type="button" id="journal-less" class="btn btn-outline btn-block" style="margin-top:8px">Afficher moins</button>';
        var less=document.getElementById('journal-less');
        if(less) less.addEventListener('click', function(){ journalExpanded=false; renderJournal(); });
      }
    }
    host.querySelectorAll('.entry[data-id]').forEach(function(b){ b.addEventListener('click',function(){ openDay(b.getAttribute('data-date')); var id=b.getAttribute('data-id'); setTimeout(function(){ editEntry(id); },20); }); });
    var em=document.getElementById('empty'); if(em) em.hidden=es.length>0;
  }

  /* ============ MODALE JOUR (entr\u00e9es multiples) ============ */
  var sheet, curDate, curLevel, curId;
  function openDay(dateStr){
    curDate=dateStr;
    var d=new Date(dateStr+'T00:00:00');
    document.getElementById('sheet-date').textContent = d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    renderDayEntries(dateStr); newEntryForm(dateStr);
    sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');
  }
  function renderDayEntries(dateStr){
    var wrap=document.getElementById('day-list'), host=document.getElementById('day-entries');
    var es=entriesForDate(dateStr);
    if(!es.length){ wrap.hidden=true; host.innerHTML=''; return; }
    wrap.hidden=false;
    host.innerHTML=es.map(function(e){
      var clean=(Number(e.level)||0)===0, title=clean?'Sans conso':(e.substance||'\u2014');
      var sub=clean?LVN[0]:[LVN[Number(e.level)||0], qtyLabel(e), ((Number(e.cost)||0)?Math.round(e.cost)+' \u20ac':'')].filter(Boolean).join(' \u00b7 ');
      var noteHtml = e.note ? '<div class="s" style="margin-top:2px;font-style:italic">'+escHtml(e.note)+'</div>' : '';
      return '<div class="entry" style="width:100%" data-id="'+e.id+'"><div class="main" style="cursor:pointer"><div class="t">'+title+'</div><div class="s">'+sub+'</div>'+noteHtml+'</div>'+
        '<button type="button" class="del-x" data-del="'+e.id+'" aria-label="Supprimer" style="background:none;border:0;color:var(--terra,#C7765C);font-size:var(--fs-lead,18px);padding:4px 10px;cursor:pointer">\u2715</button></div>';
    }).join('');
    host.querySelectorAll('.entry[data-id] .main').forEach(function(m){ m.addEventListener('click',function(){ editEntry(m.parentNode.getAttribute('data-id')); }); });
    host.querySelectorAll('[data-del]').forEach(function(b){ b.addEventListener('click',function(ev){ ev.stopPropagation(); deleteEntryById(b.getAttribute('data-del')); }); });
  }
  function setLevel(lv){
    curLevel=lv;
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.classList.toggle('on', Number(b.getAttribute('data-lv'))===lv); });
    document.getElementById('conso-fields').hidden = (lv===0);
  }
  function newEntryForm(dateStr){
    curId=null;
    document.getElementById('form-label').textContent='Nouvelle entr\u00e9e';
    document.getElementById('f-date').value=dateStr; document.getElementById('f-id').value='';
    setLevel(0);
    document.getElementById('f-sub').value=''; document.getElementById('f-qty').value=''; document.getElementById('f-cost').value=''; document.getElementById('f-note').value='';
    fillUnitSelect(document.getElementById('f-unit'),'',null);
    document.getElementById('sheet-del').hidden=true;
    renderDetect('');
  }
  function editEntry(id){
    var e=entries().filter(function(x){return x.id===id;})[0]; if(!e) return;
    curId=id;
    document.getElementById('form-label').textContent='Modifier l\u2019entr\u00e9e';
    document.getElementById('f-id').value=id; document.getElementById('f-date').value=e.date;
    setLevel(Number(e.level)||0);
    document.getElementById('f-sub').value=e.substance||'';
    document.getElementById('f-qty').value=(e.qty!=null?e.qty:'');
    fillUnitSelect(document.getElementById('f-unit'), e.substance, e.unit);
    document.getElementById('f-cost').value=(e.cost||'');
    document.getElementById('f-note').value=e.note||'';
    document.getElementById('sheet-del').hidden=false;
    renderDetect(e.substance||'');
    document.getElementById('entry-form').scrollIntoView({behavior:'smooth',block:'center'});
  }
  function closeSheet(){ sheet.classList.remove('open'); sheet.setAttribute('aria-hidden','true'); }
  function saveEntry(){
    var arr=entries(), rec={ id:curId||uid(), date:curDate, level:curLevel };
    var noteVal=(document.getElementById('f-note').value||'').trim();
    if(noteVal) rec.note=noteVal;
    if(curLevel>0){
      rec.substance=document.getElementById('f-sub').value.trim();
      var qv=parseFloat((document.getElementById('f-qty').value||'').replace(',','.')); rec.qty=isNaN(qv)?null:qv;
      rec.unit=document.getElementById('f-unit').value||'';
      rec.cost=Number(document.getElementById('f-cost').value)||0;
    }
    if(curId){ for(var i=0;i<arr.length;i++) if(arr[i].id===curId){ arr[i]=rec; break; } }
    else arr.push(rec);
    setEntries(arr); renderDayEntries(curDate); newEntryForm(curDate); renderAll();
  }
  function deleteEntryById(id){ setEntries(entries().filter(function(e){return e.id!==id;})); renderDayEntries(curDate); if(curId===id) newEntryForm(curDate); renderAll(); }

  /* ============ RECHERCHE SUBSTANCES (partag\u00e9e) ============ */
  function detList(){ return (window.MD_DETECTION||[]); }
  function subIndex(){
    var base=(window.MD_SUBS_INDEX||[]).slice();
    var cust=(window.MD_CUSTOM_FICHES||[]).slice();
    try{ var ls=JSON.parse(localStorage.getItem('mdo_admin_fiches')||'[]'); if(Array.isArray(ls)) cust=cust.concat(ls); }catch(e){}
    cust.forEach(function(o){ if(o&&o.nom) base.push({n:o.nom,f:(o.categories&&o.categories[0])||'',a:o.aliases||[]}); });
    return base;
  }
  function suggestMatches(q){
    q=(q||'').trim().toLowerCase(); if(!q) return [];
    var ix=subIndex(), pre=[], inc=[], seen={};
    function push(arr,nom,alias){ var k=nom.toLowerCase(); if(seen[k])return; seen[k]=1; arr.push({nom:nom,alias:alias}); }
    ix.forEach(function(d){
      var n=d.n.toLowerCase();
      if(n.indexOf(q)===0){ push(pre,d.n,null); return; }
      var ap=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap){ push(pre,d.n,ap); return; }
      if(n.indexOf(q)>0){ push(inc,d.n,null); return; }
      var ai=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,d.n,ai);
    });
    return pre.concat(inc).slice(0,8);
  }
  function attachSuggest(input, box, onPick){
    if(!input||!box) return;
    function render(){ var m=suggestMatches(input.value);
      if(!input.value.trim()||!m.length){ box.classList.remove('open'); box.innerHTML=''; return; }
      box.innerHTML=m.map(function(x){ return '<div data-val="'+x.nom.replace(/"/g,'&quot;')+'">'+x.nom+(x.alias?' <small>'+x.alias+'</small>':'')+'</div>'; }).join('');
      box.classList.add('open');
      box.querySelectorAll('[data-val]').forEach(function(d){ d.addEventListener('mousedown', function(ev){ ev.preventDefault(); var v=d.getAttribute('data-val'); input.value=v; box.classList.remove('open'); if(onPick)onPick(v); }); });
    }
    input.addEventListener('input', render);
    input.addEventListener('focus', render);
    input.addEventListener('blur', function(){ setTimeout(function(){ box.classList.remove('open'); },150); });
  }
  function canonicalOf(q){
    if(!q) return null; q=q.trim().toLowerCase(); if(!q) return null;
    var ix=subIndex();
    for(var i=0;i<ix.length;i++){ if(ix[i].n.toLowerCase()===q) return ix[i].n; if((ix[i].a||[]).some(function(a){return a.toLowerCase()===q;})) return ix[i].n; }
    var dl=detList();
    for(var j=0;j<dl.length;j++){ if(dl[j].nom.toLowerCase()===q) return dl[j].nom; if((dl[j].aliases||[]).some(function(a){return a.toLowerCase()===q;})) return dl[j].nom; }
    for(var k=0;k<ix.length;k++){ if(ix[k].n.toLowerCase().indexOf(q)===0) return ix[k].n; }
    return null;
  }
  function findDetection(canon){
    if(!canon) return null; var c=canon.toLowerCase(), dl=detList();
    for(var i=0;i<dl.length;i++){ if(dl[i].nom.toLowerCase()===c) return dl[i]; if((dl[i].aliases||[]).some(function(a){return a.toLowerCase()===c;})) return dl[i]; }
    return null;
  }
  function fmtH(h){ return h<24 ? (String(h).replace('.',',')+' h') : (Math.round(h/24)+' j'); }
  function fmtR(a){ return (a&&a.length===2) ? fmtH(a[0])+'\u2013'+fmtH(a[1]) : '\u2014'; }
  function renderDetect(q){
    var box=document.getElementById('detect-note'); if(!box) return;
    var canon=canonicalOf(q), d=findDetection(canon||q);
    if(d && d.detectable!==false){ box.className='notice';
      box.innerHTML='<span><b>D\u00e9tection \u2014 '+(canon||d.nom)+'</b> (estimations) : salive ~'+fmtR(d.sal)+' \u00b7 urine ~'+fmtR(d.uri)+'.</span>'; box.hidden=false; return; }
    if(d && d.detectable===false){ box.className='notice'; box.innerHTML='<span><b>'+(canon||d.nom)+'</b> \u2014 non d\u00e9tect\u00e9 en test de routine.</span>'; box.hidden=false; return; }
    if(canon){ box.className='notice'; box.innerHTML='<span><b>'+canon+'</b> \u2014 fen\u00eatre de d\u00e9tection non document\u00e9e.</span>'; box.hidden=false; return; }
    box.hidden=true;
  }

  /* ============ MOTEUR DE D\u00c9TECTION (temps r\u00e9el) ============ */
  function detectionWindows(){
    var now=Date.now(), res={sal:null, uri:null};
    entries().forEach(function(e){
      if((Number(e.level)||0)<=0 || !e.substance || !e.date) return;
      var d=findDetection(canonicalOf(e.substance)); if(!d) return;
      var base=new Date(e.date+'T12:00:00').getTime();
      ['sal','uri'].forEach(function(k){
        if(d[k] && d[k].length===2){ var neg=base + d[k][1]*3600000;
          if(neg>now && (!res[k] || neg>res[k].ts)) res[k]={ts:neg, sub:(canonicalOf(e.substance)||e.substance), date:e.date}; }
      });
    });
    return res;
  }
  function renderDetectLive(){
    var host=document.getElementById('detect-live'); if(!host) return;
    var w=detectionWindows(), now=Date.now();
    // y a-t-il des consommations reconnues (avec fenêtre documentée) ?
    var recognized=0;
    entries().forEach(function(e){ if((Number(e.level)||0)>0 && e.substance){ var d=findDetection(canonicalOf(e.substance)); if(d && (d.sal||d.uri)) recognized++; } });
    function line(k,label){
      var r=w[k]; if(!r) return '<div style="display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px solid var(--line,#E2DCD0)"><span style="font-weight:var(--w-bold,700);font-family:var(--font-technical,Inter)">'+label+'</span><span style="color:var(--sauge,#7A8F72);font-weight:var(--w-medium,600)">probablement n\u00e9gatif</span></div>';
      var dd=new Date(r.ts), day=dd.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
      var hrs=Math.max(0,Math.round((r.ts-now)/3600000)), rem=hrs<48?('~'+hrs+' h'):('~'+Math.round(hrs/24)+' j');
      return '<div style="display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px solid var(--line,#E2DCD0)"><span style="font-weight:var(--w-bold,700);font-family:var(--font-technical,Inter)">'+label+'</span><span style="text-align:right;font-size:var(--fs-xs,13px)">n\u00e9gatif estim\u00e9 <b>'+day+'</b><br><span class="muted xs">'+rem+' \u00b7 dernier d\u00e9tectable : '+r.sub+'</span></span></div>';
    }
    var any=w.sal||w.uri, note;
    if(any) note='Estimations \u2014 varient selon dose, fr\u00e9quence, m\u00e9tabolisme et hydratation. Ne sert pas \u00e0 tromper un test.';
    else if(recognized) note='D\u2019apr\u00e8s tes derni\u00e8res entr\u00e9es, tu ne devrais plus \u00eatre d\u00e9tectable (estimation). Ne sert pas \u00e0 tromper un test.';
    else note='Renseigne tes consommations avec un produit reconnu pour estimer ta fen\u00eatre. Ne sert pas \u00e0 tromper un test.';
    host.innerHTML='<p style="font-size:var(--fs-xs,13px);color:var(--ink-2,#58635E);margin:0 0 6px">D\u2019apr\u00e8s tes entr\u00e9es, date estim\u00e9e \u00e0 partir de laquelle un test reviendrait n\u00e9gatif :</p>'+
      '<div>'+line('sal','Test salivaire')+line('uri','Test urinaire')+'</div>'+
      '<p class="muted xs" style="margin:10px 0 0">'+note+'</p>';
  }

  /* ============ PROJECTION ============ */
  function equivalents(a){
    var L=[{min:80,em:'\uD83C\uDF7D\uFE0F',tx:function(n){return '<b>'+Math.floor(n/40)+'</b> bons restos';}},
      {min:150,em:'\uD83C\uDFA7',tx:function(n){return '<b>'+Math.floor(n/120)+'</b> places de concert';}},
      {min:300,em:'\uD83D\uDEB2',tx:function(){return 'un <b>v\u00e9lo</b> correct';}},
      {min:600,em:'\u2708\uFE0F',tx:function(n){return '<b>'+Math.floor(n/600)+'</b> vol(s) A/R en Europe';}},
      {min:1200,em:'\uD83C\uDF34',tx:function(n){return 'un <b>A/R long-courrier</b>'+(n>=2400?' \u00e0 deux':'');}},
      {min:2500,em:'\uD83C\uDFDD\uFE0F',tx:function(){return '<b>3 semaines</b> de voyage';}},
      {min:5000,em:'\uD83D\uDE97',tx:function(){return 'un <b>acompte voiture</b>';}}];
    var pick=L.filter(function(x){return a>=x.min;}).slice(-3); if(!pick.length) pick=[L[0]];
    return pick.map(function(x){ return {em:x.em, tx:x.tx(a)}; });
  }
  function renderProjection(){
    var card=document.getElementById('proj-card'); if(!card) return;
    var es=entries().filter(function(e){ return (Number(e.cost)||0)>0 && e.date; });
    if(!es.length){ card.hidden=true; return; }
    var now=Date.now(), MS=86400000;
    var es30=es.filter(function(e){ return (now-new Date(e.date+'T00:00:00').getTime())<=31*MS; });
    var monthTotal=es30.reduce(function(a,e){return a+(Number(e.cost)||0);},0), basis;
    if(monthTotal>0){ basis='D\u2019apr\u00e8s '+Math.round(monthTotal)+' \u20ac sur les 30 derniers jours \u00d7 12.'; }
    else { var dates=es.map(function(e){return e.date;}).sort(); var first=new Date(dates[0]+'T00:00:00'), last=new Date(dates[dates.length-1]+'T00:00:00');
      var months=Math.max(1,(last-first)/(30*MS)); monthTotal=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0)/months; basis='Moyenne mensuelle estim\u00e9e \u00d7 12.'; }
    var annual=Math.round(monthTotal*12); if(annual<1){ card.hidden=true; return; }
    document.getElementById('proj-amount').textContent='\u2248 '+annual.toLocaleString('fr-FR')+' \u20ac / an';
    document.getElementById('proj-basis').textContent=basis;
    document.getElementById('proj-equiv').innerHTML=equivalents(annual).map(function(x){ return '<div class="eq"><span class="em">'+x.em+'</span><span class="tx">'+x.tx+'</span></div>'; }).join('');
    card.hidden=false;
  }

  function renderAll(){ var m=byDate(); renderStats(m); renderGoals(m); renderCalendar(); renderJournal(); renderProjection(); renderDetectLive(); }

  ready(function(){
    if(window.MDCore){ try{ MDCore.init({ page:'suivi', section:'progression' }); }catch(e){} }
    sheet=document.getElementById('sheet');
    var fsub=document.getElementById('f-sub'), funit=document.getElementById('f-unit');
    if(fsub){ attachSuggest(fsub, document.getElementById('f-sug'), function(nom){ renderDetect(nom); fillUnitSelect(funit, nom, funit.value); var q=document.getElementById('f-qty'); if(q) q.focus(); });
      fsub.addEventListener('input', function(){ renderDetect(fsub.value); fillUnitSelect(funit, fsub.value, funit.value); }); }
    document.getElementById('goal-add-btn').addEventListener('click', function(){ openGoalEditor(null); });
    document.getElementById('goal-type').addEventListener('change', function(){ renderGoalFields({type:this.value}); });
    document.getElementById('goal-save').addEventListener('click', saveGoal);
    document.getElementById('goal-cancel').addEventListener('click', function(){ document.getElementById('goal-edit').classList.remove('open'); });
    document.getElementById('add-entry').addEventListener('click', function(){ openDay(iso(new Date())); });
    var histBtn=document.getElementById('open-history'); if(histBtn){ histBtn.addEventListener('click', function(){ if(window.MDHistorique) MDHistorique.open(); }); }
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.addEventListener('click', function(){ setLevel(Number(b.getAttribute('data-lv'))); }); });
    document.getElementById('sheet-save').addEventListener('click', saveEntry);
    document.getElementById('sheet-del').addEventListener('click', function(){ if(curId) deleteEntryById(curId); });
    document.getElementById('sheet-cancel').addEventListener('click', closeSheet);
    sheet.addEventListener('click', function(e){ if(e.target===sheet) closeSheet(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeSheet(); });
    
    renderAll();
    document.addEventListener('langchange', renderAll);
  });
})();
