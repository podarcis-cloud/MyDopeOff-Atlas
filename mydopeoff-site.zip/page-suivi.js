/* MyDope Off — page-suivi.js · « Ta progression »
   Entrées (localStorage ctc_v6.entries[]) :
     { date:'YYYY-MM-DD', level:0|1|2|3, substance, qty, cost:Number, note }
   level : 0 sans conso · 1 léger · 2 modéré · 3 notable
*/
(function () {
  'use strict';
  function ready(fn){ document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn); }
  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function save(s){ try { localStorage.setItem('ctc_v6', JSON.stringify(s)); } catch(e){} }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }
  function setEntries(arr){ var s=store(); s.entries=arr; save(s); }
  function goalDays(){ var s=store(); return (s.goal&&s.goal.days)||14; }
  function T(k,v){ return window.MDCore? MDCore.t(k,v):k; }
  function iso(d){ var z=new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,10); }
  var MONTHS=['janv.','févr.','mars','avr.','mai','juin','juil.','août','sept.','oct.','nov.','déc.'];
  var DOW=['L','M','M','J','V','S','D'], LV=['clean','low','mid','high'];

  function byDate(){ var m={}; entries().forEach(function(e){ if(e&&e.date)m[e.date]=e; }); return m; }
  function streak(map){ var d=new Date(); d.setHours(0,0,0,0); var n=0; for(var i=0;i<400;i++){ if(map[iso(d)]){n++;d.setDate(d.getDate()-1);}else break; } return n; }

  /* ---- rendus ---- */
  function renderStats(map){
    var host=document.getElementById('stats'); if(!host)return;
    var es=entries(), spend=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    host.innerHTML='<div class="stat"><div class="n">'+(streak(map)||Object.keys(map).length)+'</div><div class="l">'+T('suivi.st_days')+'</div></div>'+
      '<div class="stat"><div class="n">≈ '+Math.round(spend)+' €</div><div class="l">'+T('suivi.st_est')+'</div></div>'+
      '<div class="stat"><div class="n">'+es.length+'</div><div class="l">'+T('suivi.st_entries')+'</div></div>';
  }
  function renderGoal(map){
    var cur=streak(map), goal=goalDays(), pct=Math.min(100,Math.round(cur/goal*100))||0, left=Math.max(0,goal-cur);
    var pe=document.getElementById('goal-pct'), bi=document.getElementById('goal-bar'), nt=document.getElementById('goal-note');
    if(pe)pe.textContent=pct+' %'; if(bi)bi.style.width=pct+'%'; if(nt)nt.textContent=T('suivi.goal_note',{cur:cur,left:left});
    var big=document.getElementById('where-big'); if(big)big.textContent='Jour '+cur;
    var gl=document.getElementById('where-goal'); if(gl)gl.textContent=T('suivi.goalline',{n:goal});
  }
  function renderCalendar(map){
    var host=document.getElementById('cal-grid'); if(!host)return;
    var today=new Date(); today.setHours(0,0,0,0);
    var start=new Date(today); start.setDate(start.getDate()-29);
    var lead=(start.getDay()+6)%7, html='';
    for(var i=0;i<lead;i++) html+='<div class="cal-cell empty"></div>';
    for(var j=0;j<30;j++){
      var d=new Date(start); d.setDate(start.getDate()+j); var key=iso(d), e=map[key], cls='none', lab=T('cal.none');
      if(e){ var lv=Math.max(0,Math.min(3,Number(e.level)||0)); cls=LV[lv]; lab=lv===0?T('suivi.noconso'):((e.substance||'')+' '+(e.qty||'')).trim(); }
      var tody=key===iso(today)?' today':'';
      html+='<button type="button" class="cal-cell '+cls+tody+'" data-date="'+key+'" title="'+d.getDate()+' '+MONTHS[d.getMonth()]+' · '+lab+'" aria-label="'+d.getDate()+' '+MONTHS[d.getMonth()]+', '+lab+'">'+d.getDate()+'</button>';
    }
    host.innerHTML=html;
    host.querySelectorAll('.cal-cell[data-date]').forEach(function(c){ c.addEventListener('click',function(){ openSheet(c.getAttribute('data-date')); }); });
    var ml=document.getElementById('cal-month'); if(ml) ml.textContent=MONTHS[start.getMonth()]+(start.getMonth()!==today.getMonth()?' – '+MONTHS[today.getMonth()]:'');
    var dow=document.getElementById('cal-dow'); if(dow) dow.innerHTML=DOW.map(function(x){return '<span>'+x+'</span>';}).join('');
  }
  function renderJournal(){
    var host=document.getElementById('journal'); if(!host)return; var es=entries();
    var sorted=es.slice().sort(function(a,b){return (b.date||'').localeCompare(a.date||'');}).slice(0,8);
    host.innerHTML=sorted.map(function(e){
      var d=new Date(e.date+'T00:00:00'), dd=isNaN(d)?'':d.getDate(), mm=isNaN(d)?'':MONTHS[d.getMonth()];
      var clean=(Number(e.level)||0)===0, title=clean?T('suivi.noconso'):(e.substance||'—');
      var sub=clean?'':[e.qty,e.note].filter(Boolean).join(' · '), cost=clean?'—':((Number(e.cost)||0)?Math.round(e.cost)+' €':'—');
      return '<button type="button" class="entry" data-date="'+e.date+'" style="width:100%;text-align:left"><div class="day"><div class="d">'+dd+'</div><div class="m">'+mm+'</div></div><div class="sep"></div><div class="main"><div class="t">'+title+'</div>'+(sub?'<div class="s">'+sub+'</div>':'')+'</div><span class="cost">'+cost+'</span></button>';
    }).join('');
    host.querySelectorAll('.entry[data-date]').forEach(function(b){ b.addEventListener('click',function(){ openSheet(b.getAttribute('data-date')); }); });
    var em=document.getElementById('empty'); if(em) em.hidden=es.length>0;
  }
  function renderAll(){ var m=byDate(); renderStats(m); renderGoal(m); renderProjection(); renderCalendar(m); renderJournal(); }

  /* ---- modale ---- */
  var sheet, curDate, curLevel;
  function setLevel(lv){
    curLevel=lv;
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.classList.toggle('on', Number(b.getAttribute('data-lv'))===lv); });
    document.getElementById('conso-fields').hidden = (lv===0);
  }
  function openSheet(dateStr){
    curDate=dateStr;
    var map=byDate(), e=map[dateStr]||null;
    var d=new Date(dateStr+'T00:00:00');
    document.getElementById('sheet-date').textContent = d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    document.getElementById('f-date').value=dateStr;
    setLevel(e?Math.max(0,Math.min(3,Number(e.level)||0)):0);
    document.getElementById('f-sub').value = e&&e.substance?e.substance:'';
    document.getElementById('f-qty').value = e&&e.qty?e.qty:'';
    document.getElementById('f-cost').value = e&&e.cost?e.cost:'';
    document.getElementById('sheet-del').hidden = !e;
    renderDetect(document.getElementById('f-sub').value);
    sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');
  }
  function closeSheet(){ sheet.classList.remove('open'); sheet.setAttribute('aria-hidden','true'); }
  function saveEntry(){
    var arr=entries().filter(function(x){ return x.date!==curDate; });
    var entry={ date:curDate, level:curLevel };
    if(curLevel>0){
      entry.substance=document.getElementById('f-sub').value.trim();
      entry.qty=document.getElementById('f-qty').value.trim();
      entry.cost=Number(document.getElementById('f-cost').value)||0;
    }
    arr.push(entry); setEntries(arr); closeSheet(); renderAll();
  }
  function deleteEntry(){ setEntries(entries().filter(function(x){ return x.date!==curDate; })); closeSheet(); renderAll(); }

  /* ---- substances : index complet (270 fiches) + détection ---- */
  function detList(){ return (window.MD_DETECTION||[]); }
  function subIndex(){
    var base=(window.MD_SUBS_INDEX||[]).slice();
    var cust=(window.MD_CUSTOM_FICHES||[]).slice();
    try{ var ls=JSON.parse(localStorage.getItem('mdo_admin_fiches')||'[]'); if(Array.isArray(ls)) cust=cust.concat(ls); }catch(e){}
    cust.forEach(function(o){ if(o&&o.nom) base.push({n:o.nom,f:(o.categories&&o.categories[0])||'',a:o.aliases||[]}); });
    return base;
  }
  function suggestMatches(q){
    q=(q||'').trim().toLowerCase(); if(!q) return [];
    var ix=subIndex(), pre=[], inc=[], seen={};
    function push(arr,nom,alias){ var k=nom.toLowerCase(); if(seen[k])return; seen[k]=1; arr.push({nom:nom,alias:alias}); }
    ix.forEach(function(d){
      var n=d.n.toLowerCase();
      if(n.indexOf(q)===0){ push(pre,d.n,null); return; }
      var ap=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)===0;})[0];
      if(ap){ push(pre,d.n,ap); return; }
      if(n.indexOf(q)>0){ push(inc,d.n,null); return; }
      var ai=(d.a||[]).filter(function(a){return a.toLowerCase().indexOf(q)>=0;})[0];
      if(ai) push(inc,d.n,ai);
    });
    return pre.concat(inc).slice(0,8);
  }
  function renderSuggest(q){
    var box=document.getElementById('f-sug'); if(!box) return;
    var m=suggestMatches(q);
    if(!q || !m.length){ box.classList.remove('open'); box.innerHTML=''; return; }
    box.innerHTML=m.map(function(x){ return '<div data-val="'+x.nom.replace(/"/g,'&quot;')+'">'+x.nom+(x.alias?' <small>'+x.alias+'</small>':'')+'</div>'; }).join('');
    box.classList.add('open');
    box.querySelectorAll('[data-val]').forEach(function(d){ d.addEventListener('mousedown', function(ev){ ev.preventDefault(); pickSub(d.getAttribute('data-val')); }); });
  }
  function pickSub(nom){ var el=document.getElementById('f-sub'); if(el) el.value=nom; var b=document.getElementById('f-sug'); if(b) b.classList.remove('open'); renderDetect(nom); var q=document.getElementById('f-qty'); if(q) q.focus(); }
  function canonicalOf(q){
    if(!q) return null; q=q.trim().toLowerCase(); if(!q) return null;
    var ix=subIndex();
    for(var i=0;i<ix.length;i++){ if(ix[i].n.toLowerCase()===q) return ix[i].n;
      if((ix[i].a||[]).some(function(a){return a.toLowerCase()===q;})) return ix[i].n; }
    var dl=detList();
    for(var j=0;j<dl.length;j++){ if(dl[j].nom.toLowerCase()===q) return dl[j].nom;
      if((dl[j].aliases||[]).some(function(a){return a.toLowerCase()===q;})) return dl[j].nom; }
    for(var k=0;k<ix.length;k++){ if(ix[k].n.toLowerCase().indexOf(q)===0) return ix[k].n; }
    return null;
  }
  function famOf(c){ var ix=subIndex(); for(var i=0;i<ix.length;i++){ if(ix[i].n===c) return ix[i].f||''; } return ''; }
  function findDetection(canon){
    if(!canon) return null; var c=canon.toLowerCase(), dl=detList();
    for(var i=0;i<dl.length;i++){ if(dl[i].nom.toLowerCase()===c) return dl[i];
      if((dl[i].aliases||[]).some(function(a){return a.toLowerCase()===c;})) return dl[i]; }
    return null;
  }
  function fmtH(h){ return h<24 ? (String(h).replace('.',',')+' h') : (Math.round(h/24)+' j'); }
  function fmtR(a){ return (a&&a.length===2) ? fmtH(a[0])+'\u2013'+fmtH(a[1]) : '\u2014'; }
  function renderDetect(q){
    var box=document.getElementById('detect-note'); if(!box) return;
    var canon=canonicalOf(q), d=findDetection(canon||q);
    if(d && d.detectable!==false){
      box.className='notice';
      box.innerHTML='<span><b>D\u00e9tection \u2014 '+(canon||d.nom)+'</b> (estimations) : salive ~'+fmtR(d.sal)+' \u00b7 urine ~'+fmtR(d.uri)+'.'+
        (d.source?' <span class="muted xs">Source : '+String(d.source).split('\u00b7')[0].trim()+'</span>':'')+'</span>';
      box.hidden=false; return;
    }
    if(d && d.detectable===false){ box.className='notice'; box.innerHTML='<span><b>'+(canon||d.nom)+'</b> \u2014 non d\u00e9tect\u00e9 en test de routine.</span>'; box.hidden=false; return; }
    if(canon){ var fa=famOf(canon); box.className='notice'; box.innerHTML='<span><b>'+canon+'</b>'+(fa?' \u00b7 '+fa:'')+' \u2014 fen\u00eatre de d\u00e9tection non document\u00e9e.</span>'; box.hidden=false; return; }
    box.hidden=true;
  }
  function normalizeSub(){
    var el=document.getElementById('f-sub'); if(!el) return;
    var c=canonicalOf(el.value);
    if(c && c.toLowerCase()!==el.value.trim().toLowerCase()) el.value=c;
    renderDetect(el.value);
  }

  /* ---- projection 12 mois (loterie inversée) ---- */
  function equivalents(a){
    var L=[
      {min:80,em:'\uD83C\uDF7D\uFE0F',tx:function(n){return '<b>'+Math.floor(n/40)+'</b> bons restos';}},
      {min:150,em:'\uD83C\uDFA7',tx:function(n){return '<b>'+Math.floor(n/120)+'</b> places de concert';}},
      {min:300,em:'\uD83D\uDEB2',tx:function(){return 'un <b>v\u00e9lo</b> correct';}},
      {min:600,em:'\u2708\uFE0F',tx:function(n){return '<b>'+Math.floor(n/600)+'</b> vol(s) A/R en Europe';}},
      {min:1200,em:'\uD83C\uDF34',tx:function(n){return 'un <b>A/R long-courrier</b> (ex. Br\u00e9sil)'+(n>=2400?' \u00e0 deux':'');}},
      {min:2500,em:'\uD83C\uDFDD\uFE0F',tx:function(){return '<b>3 semaines</b> de voyage';}},
      {min:5000,em:'\uD83D\uDE97',tx:function(){return 'un <b>acompte voiture</b> / gros achat';}},
      {min:10000,em:'\uD83C\uDFE0',tx:function(){return 'plusieurs <b>mois de loyer</b>';}}
    ];
    var pick=L.filter(function(x){return a>=x.min;}).slice(-3);
    if(!pick.length) pick=[L[0]];
    return pick.map(function(x){ return {em:x.em, tx:x.tx(a)}; });
  }
  function renderProjection(){
    var card=document.getElementById('proj-card'); if(!card) return;
    var es=entries().filter(function(e){ return (Number(e.cost)||0)>0 && e.date; });
    if(!es.length){ card.hidden=true; return; }
    var dates=es.map(function(e){return e.date;}).sort();
    var first=new Date(dates[0]+'T00:00:00'), last=new Date(dates[dates.length-1]+'T00:00:00');
    var spanDays=Math.max(1,Math.round((last-first)/86400000)+1);
    var total=es.reduce(function(a,e){return a+(Number(e.cost)||0);},0);
    var perDay=total/spanDays, annual=Math.round(perDay*365);
    if(annual<1){ card.hidden=true; return; }
    document.getElementById('proj-amount').textContent='\u2248 '+annual.toLocaleString('fr-FR')+' \u20ac / an';
    document.getElementById('proj-basis').textContent='D\u2019apr\u00e8s '+Math.round(total)+' \u20ac sur '+spanDays+' jour'+(spanDays>1?'s':'')+' suivis ('+(perDay>=1?Math.round(perDay):perDay.toFixed(1))+' \u20ac/jour en moyenne).';
    document.getElementById('proj-equiv').innerHTML=equivalents(annual).map(function(x){ return '<div class="eq"><span class="em">'+x.em+'</span><span class="tx">'+x.tx+'</span></div>'; }).join('');
    card.hidden=false;
  }
  /* ---- objectif \u00e9ditable ---- */
  function setupGoalEditor(){
    var btn=document.getElementById('goal-edit-btn'), box=document.getElementById('goal-edit'),
        inp=document.getElementById('goal-days'), pres=document.getElementById('goal-presets'), sv=document.getElementById('goal-save');
    if(!btn||!box) return;
    var PRES=[7,14,30,60,90];
    function paint(){ var g=goalDays(); inp.value=g;
      pres.innerHTML=PRES.map(function(d){return '<button type="button" data-d="'+d+'" class="'+(d===g?'on':'')+'">'+d+' j</button>';}).join('');
      pres.querySelectorAll('[data-d]').forEach(function(b){ b.addEventListener('click', function(){ inp.value=b.getAttribute('data-d'); pres.querySelectorAll('button').forEach(function(x){x.classList.remove('on');}); b.classList.add('on'); }); });
    }
    btn.addEventListener('click', function(){ box.classList.toggle('open'); if(box.classList.contains('open')) paint(); });
    sv.addEventListener('click', function(){ var d=Math.max(1,Math.min(365,parseInt(inp.value,10)||14)); var s2=store(); s2.goal=s2.goal||{}; s2.goal.days=d; save(s2); box.classList.remove('open'); renderAll(); });
  }

  ready(function(){
    if(window.MDCore) MDCore.init({ page:'suivi', section:'progression' });
    sheet=document.getElementById('sheet');
    var fsub=document.getElementById('f-sub');
    if(fsub){
      fsub.addEventListener('input', function(){ renderSuggest(fsub.value); renderDetect(fsub.value); });
      fsub.addEventListener('focus', function(){ renderSuggest(fsub.value); });
      fsub.addEventListener('blur', function(){ setTimeout(function(){ var b=document.getElementById('f-sug'); if(b) b.classList.remove('open'); normalizeSub(); },150); });
    }
    setupGoalEditor();
    document.getElementById('add-entry').addEventListener('click', function(){ openSheet(iso(new Date())); });
    document.querySelectorAll('#seg-level button').forEach(function(b){ b.addEventListener('click', function(){ setLevel(Number(b.getAttribute('data-lv'))); }); });
    document.getElementById('sheet-save').addEventListener('click', saveEntry);
    document.getElementById('sheet-del').addEventListener('click', deleteEntry);
    document.getElementById('sheet-cancel').addEventListener('click', closeSheet);
    sheet.addEventListener('click', function(e){ if(e.target===sheet) closeSheet(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeSheet(); });
    renderAll();
    document.addEventListener('langchange', renderAll);
  });
})();
