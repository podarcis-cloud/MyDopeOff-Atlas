/* scanner.js — Scanner de craving (M1) + routeur de reco (M8), 100 % local.
   M1 : micro-éval < 10 s (envie + émotion + énergie + temps) -> état + type de craving.
   M8 : score chaque module (baseFit + efficacité apprise + besoin d'axe - récence), ε-greedy,
        explicable, et APPREND du delta d'envie mesuré (ctc_v6.reco). Aucune sortie réseau.
   Expose window.MDScanner et window.MDReco. Dépend de MDData. */
(function () {
  function clamp01(x) { return Math.max(0, Math.min(1, x)); }

  // émotion -> (valence, arousal)
  var EMO = {
    calme: { v: 0.6, a: 0.2 }, joie: { v: 0.8, a: 0.5 }, ennui: { v: -0.2, a: 0.2 },
    anxiete: { v: -0.7, a: 0.85 }, colere: { v: -0.7, a: 0.9 }, tristesse: { v: -0.7, a: 0.3 }, vide: { v: -0.5, a: 0.15 }
  };
  var EMO_LBL = { calme: 'calme', ennui: 'ennui', anxiete: 'anxiété', colere: 'colère', tristesse: 'tristesse', vide: 'vide', joie: 'joie' };

  // modules (clés = type de séance journalisée)
  var MODULES = {
    breathe: { nom: 'Souffle', dureeMin: 3, page: 'breathe.html', axes: ['emo', 'envies'] },
    tetris: { nom: 'Tetris', dureeMin: 3, page: 'tetris.html', axes: ['attn', 'envies'] },
    maze: { nom: 'Labyrinthe', dureeMin: 4, page: 'maze.html', axes: ['attn', 'stab'] },
    lettre: { nom: 'Lettre au futur toi', dureeMin: 5, page: 'lettre.html', axes: ['stab'] },
    echo: { nom: 'Écho', dureeMin: 2, page: 'echo.html', axes: ['attn', 'stab'] },
    filtre: { nom: 'Filtre', dureeMin: 2, page: 'filtre.html', axes: ['inhib', 'attn'] },
    virage: { nom: 'Virage', dureeMin: 2, page: 'virage.html', axes: ['inhib', 'attn'] },
    surf: { nom: 'Surf', dureeMin: 2, page: 'surf.html', axes: ['envies', 'emo'] },
    patience: { nom: 'Patience', dureeMin: 3, page: 'patience.html', axes: ['envies', 'stab'] },
    braise: { nom: 'Braise', dureeMin: 3, page: 'braise.html', axes: ['emo', 'stab'] },
    dualtask: { nom: 'Double tâche', dureeMin: 2, page: 'dualtask.html', axes: ['attn', 'inhib'] },
    elan: { nom: 'Élan', dureeMin: 2, page: 'elan.html', axes: ['envies', 'inhib'] },
    inhib: { nom: 'Contrôle du frein', dureeMin: 2, trigger: 'inhib', axes: ['inhib'] },
    stop: { nom: 'Stop-Signal', dureeMin: 2, trigger: 'stop', axes: ['inhib'] }
  };
  // adéquation type de craving -> module (0..1)
  var BASEFIT = {
    emotionnel: { breathe: 0.95, tetris: 0.4, maze: 0.4, lettre: 0.5,
      echo: 0.4, filtre: 0.3, virage: 0.3, surf: 0.95, patience: 0.5, braise: 0.85, dualtask: 0.35, elan: 0.5, inhib: 0.4, stop: 0.4 },
    intrusif: { tetris: 0.9, maze: 0.85, breathe: 0.5, lettre: 0.4,
      echo: 0.85, filtre: 0.7, virage: 0.75, surf: 0.5, patience: 0.45, braise: 0.4, dualtask: 0.8, elan: 0.55, inhib: 0.5, stop: 0.5 },
    impulsif: { breathe: 0.9, tetris: 0.5, maze: 0.5, lettre: 0.4,
      echo: 0.4, filtre: 0.75, virage: 0.5, surf: 0.6, patience: 0.85, braise: 0.35, dualtask: 0.45, elan: 0.9, inhib: 0.9, stop: 0.9 },
    cyclique: { breathe: 0.8, tetris: 0.5, maze: 0.5, lettre: 0.5,
      echo: 0.55, filtre: 0.5, virage: 0.55, surf: 0.65, patience: 0.6, braise: 0.6, dualtask: 0.5, elan: 0.6, inhib: 0.55, stop: 0.55 }
  };
  var WHY_TYPE = {
    emotionnel: 'une envie portée par l\u2019émotion', intrusif: 'une envie qui tourne en boucle',
    impulsif: 'une envie forte et soudaine', cyclique: 'une envie qui revient'
  };

  function ctc() { try { return window.MDData ? window.MDData.getCtc() : JSON.parse(localStorage.getItem('ctc_v6') || '{}'); } catch (e) { return {}; } }

  /* ---- M1 : calcul de l'état ---- */
  function computeState(inp) {
    var e = EMO[inp.emotion] || { v: 0, a: 0.3 };
    var arousalNeg = e.a * (e.v < 0 ? 1 : 0.3);
    var stress = clamp01(0.5 * arousalNeg + 0.5 * (inp.envie / 10));
    var type;
    if (stress >= 0.6 && e.v < 0) type = 'emotionnel';
    else if ((inp.emotion === 'ennui' || inp.emotion === 'vide') && inp.energie !== 'basse' && inp.envie <= 7) type = 'intrusif';
    else if (inp.envie >= 7 && inp.tempsDispo <= 2) type = 'impulsif';
    else type = 'emotionnel';
    return { envie: inp.envie, emotion: inp.emotion, energie: inp.energie, tempsDispo: inp.tempsDispo, stress: Math.round(stress * 100) / 100, type: type };
  }

  /* ---- M8 : routage ---- */
  function rank(state) {
    var o = ctc(); var reco = o.reco || {}; var eff = (reco.effAppris && reco.effAppris[state.type]) || {};
    var last = reco.lastModules || [];
    var axes = (o.parcours && o.parcours.axes) || { inhib: 0, emo: 0, attn: 0, envies: 0, stab: 0 };
    var fit = BASEFIT[state.type] || BASEFIT.emotionnel;
    var alpha = 0.9, beta = 0.5, gamma = 0.4;
    var out = [];
    Object.keys(MODULES).forEach(function (m) {
      var meta = MODULES[m];
      if (meta.dureeMin > (state.tempsDispo || 10)) return;          // éligibilité : temps
      if (state.envie >= 8 && meta.dureeMin > 3) return;             // envie forte : régulation rapide d'abord
      var besoin = 0; meta.axes.forEach(function (k) { besoin += (1 - (axes[k] || 0) / 100); }); besoin /= meta.axes.length;
      var recence = (last.indexOf(m) >= 0 && last.indexOf(m) < 2) ? 1 : 0;
      var score = (fit[m] || 0) + alpha * (eff[m] || 0) + beta * besoin - gamma * recence;
      out.push({ m: m, score: score, besoin: besoin, fit: fit[m] || 0, eff: eff[m] || 0 });
    });
    out.sort(function (a, b) { return b.score - a.score; });
    return out;
  }
  function route(state) {
    var ranked = rank(state);
    if (!ranked.length) ranked = [{ m: 'breathe', score: 0 }];
    // ε-greedy : 15 % exploration parmi les éligibles
    var pick = ranked[0];
    if (ranked.length > 1 && Math.random() < 0.15) pick = ranked[1 + Math.floor(Math.random() * (ranked.length - 1))];
    var why = WHY_TYPE[state.type] || 'ton état du moment';
    var extra = (pick.eff > 0.05) ? ' \u00B7 ça t\u2019a aidé récemment' : (pick.besoin > 0.6 ? ' \u00B7 axe à renforcer' : '');
    return { module: pick.m, why: why + extra, alternatives: ranked.slice(0, 3).map(function (r) { return r.m; }) };
  }
  function learn(cravingType, moduleKey, deltaNorm) {
    try {
      var o = ctc(); o.reco = o.reco || { effAppris: {}, statsHoraires: {}, lastModules: [] };
      o.reco.effAppris = o.reco.effAppris || {};
      var t = o.reco.effAppris[cravingType] = o.reco.effAppris[cravingType] || {};
      var prev = (t[moduleKey] != null) ? t[moduleKey] : 0;
      t[moduleKey] = Math.round(((1 - 0.25) * prev + 0.25 * deltaNorm) * 1000) / 1000;
      o.reco.lastModules = [moduleKey].concat((o.reco.lastModules || []).filter(function (x) { return x !== moduleKey; })).slice(0, 4);
      if (window.MDData) window.MDData.write(o); else localStorage.setItem('ctc_v6', JSON.stringify(o));
    } catch (e) { }
  }
  function go(moduleKey, envie, cravingType) {
    try { sessionStorage.setItem('mdScan', JSON.stringify({ envie: envie, type: cravingType, ts: Date.now() })); } catch (e) { }
    var meta = MODULES[moduleKey];
    if (!meta) return;
    if (meta.trigger) {
      try { sessionStorage.setItem('mdAutoOpen', meta.trigger); } catch (e) { }
      location.href = 'fiches.html';
    } else if (meta.page) {
      location.href = meta.page;
    }
  }
  function recordHoraire(envie) {
    try {
      var o = ctc(); o.reco = o.reco || { effAppris: {}, statsHoraires: {}, lastModules: [] };
      o.reco.statsHoraires = o.reco.statsHoraires || {};
      var h = String(new Date().getHours());
      var b = o.reco.statsHoraires[h] = o.reco.statsHoraires[h] || { scans: 0, forts: 0 };
      b.scans++; if (envie >= 7) b.forts++;
      if (window.MDData) window.MDData.write(o); else localStorage.setItem('ctc_v6', JSON.stringify(o));
    } catch (e) { }
  }
  function horaireRisque() {
    try {
      var o = ctc(); var sh = (o.reco && o.reco.statsHoraires) || {};
      var b = sh[String(new Date().getHours())];
      if (b && b.scans >= 3) return b.forts / b.scans;
    } catch (e) { }
    return 0;
  }
  window.MDReco = { route: route, rank: rank, learn: learn, go: go, recordHoraire: recordHoraire, horaireRisque: horaireRisque, MODULES: MODULES };

  /* ---- M1 : interface ---- */
  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mds-ov{z-index:var(--z-modal-3,4200);align-items:flex-start;justify-content:center;padding:20px;' +
      'background:var(--bg,#F5F2EA);font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mds-card{position:relative;z-index:var(--z-base,1);border:1px solid var(--line,#E2DCD0);border-radius:20px;' +
      'max-width:380px;width:100%;padding:22px;box-shadow:0 22px 60px rgba(51,70,62,.18)}' +
      '.mds-q{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,19px);margin:0 0 3px;text-align:center}' +
      '.mds-sub{font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);text-align:center;margin:0 0 14px}' +
      '.mds-insight{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-xs,13px);color:var(--ink,#1F2B25);background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:10px;padding:8px 11px;text-align:center;margin:0 0 12px}' +
      '.mds-lbl{font-size:var(--fs-caps,11.5px);color:var(--ink-2,#58635E);font-weight:var(--w-bold,700);margin:12px 0 6px;text-transform:uppercase;letter-spacing:var(--ls-caps,.04em)}' +
      '.mds-scale{display:flex;flex-wrap:wrap;gap:6px;justify-content:center}' +
      '.mds-n{min-width:30px;height:38px;flex:1 0 auto;border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);color:var(--ink,#1F2B25);' +
      'border-radius:9px;font-family:var(--font-human,sans-serif);font-size:var(--fs-sm,14px);font-weight:var(--w-bold,700);cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '.mds-n.sel{background:var(--terra,#C7765C);border-color:var(--terra,#C7765C);color:#fff}' +
      '.mds-chips{display:flex;flex-wrap:wrap;gap:6px}' +
      '.mds-chip{padding:8px 12px;border:1px solid var(--line,#E2DCD0);background:var(--surface,#fff);color:var(--ink,#1F2B25);' +
      'border-radius:20px;font-size:var(--fs-xs,13px);cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '.mds-chip.sel{background:var(--sauge,#7A8F72);border-color:var(--sauge,#7A8F72);color:#fff}' +
      '.mds-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);font-size:var(--fs-ui,15px);' +
      'padding:14px;cursor:pointer;margin-top:18px;opacity:.5}.mds-go.on{opacity:1}' +
      '.mds-skip{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer;margin-top:10px}' +
      '.mds-reco{text-align:center}.mds-recoc{background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:16px;margin:6px 0 14px}' +
      '.mds-recon{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,20px)}.mds-recow{font-size:var(--fs-xs,13px);color:var(--ink-2,#58635E);margin-top:4px}' +
      '.mds-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);font-weight:var(--w-medium,600);font-size:var(--fs-sm,14px);padding:11px;cursor:pointer;margin-top:8px}';
    var st = document.createElement('style'); st.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(st);
  }
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  var ov = null; function close() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }

  function open() {
    inject(); close();
    var sel = { envie: null, emotion: null, energie: null, tempsDispo: null };
    ov = E('div', 'mds-ov md-ov'); var c = E('div', 'mds-card md-card'); ov.appendChild(c);
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Point sur l\u2019envie' });
    if (window.MDCompagnon && window.MDCompagnon.avatarHTML) {
      var avWrap = document.createElement('div'); avWrap.style.cssText = 'display:flex;justify-content:center;margin-bottom:8px';
      avWrap.innerHTML = (window.MDMascotte ? MDMascotte.avatar('recommandation', { humeur:'ecoute' }) : window.MDCompagnon.avatarHTML('ecoute', { size: 'md' }));
      c.appendChild(avWrap);
    }
    c.appendChild(E('p', 'mds-q', 'Là, maintenant, l\u2019envie est à\u2026'));
    c.appendChild(E('p', 'mds-sub', '0 = aucune  ·  10 = irrésistible'));
    if (window.MDReco && window.MDReco.horaireRisque() >= 0.4) c.appendChild(E('p', 'mds-insight', 'Cette heure t\u2019est souvent délicate \u2014 tu as bien fait de venir.'));
    var scale = E('div', 'mds-scale');
    for (var i = 0; i <= 10; i++) (function (n) {
      var b = E('button', 'mds-n', String(n)); b.type = 'button'; b.setAttribute('aria-label', 'Envie ' + n);
      b.onclick = function () { sel.envie = n; scale.querySelectorAll('.mds-n').forEach(function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); refresh(); };
      scale.appendChild(b);
    })(i);
    c.appendChild(scale);
    c.appendChild(chipGroup('Ce qui domine', ['calme', 'ennui', 'anxiete', 'colere', 'tristesse', 'vide', 'joie'], function (k) { sel.emotion = k; }, function (k) { return EMO_LBL[k]; }));
    c.appendChild(chipGroup('Énergie', ['basse', 'moyenne', 'haute'], function (k) { sel.energie = k; }));
    c.appendChild(chipGroup('J\u2019ai', ['t1', 't3', 't10'], function (k) { sel.tempsDispo = (k === 't1' ? 1 : (k === 't3' ? 3 : 10)); }, function (k) { return k === 't1' ? '\u2264 1 min' : (k === 't3' ? '~3 min' : '\u2265 10 min'); }));
    var go = E('button', 'mds-go', 'Trouver quoi faire'); go.type = 'button';
    go.onclick = function () { if (sel.envie == null) return; submit(sel); };
    c.appendChild(go);
    var skip = E('button', 'mds-skip', 'passer cette étape'); skip.type = 'button'; skip.onclick = close; c.appendChild(skip);
    function refresh() { go.classList.toggle('on', sel.envie != null); }
    void 0;
    function chipGroup(label, keys, onpick, fmt) {
      var wrap = document.createElement('div'); wrap.appendChild(E('div', 'mds-lbl', label));
      var row = E('div', 'mds-chips');
      keys.forEach(function (k) {
        var b = E('button', 'mds-chip', fmt ? fmt(k) : k); b.type = 'button';
        b.onclick = function () { onpick(k); row.querySelectorAll('.mds-chip').forEach(function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); };
        row.appendChild(b);
      });
      wrap.appendChild(row); return wrap;
    }
  }

  function submit(sel) {
    if (sel.energie == null) sel.energie = 'moyenne';
    if (sel.tempsDispo == null) sel.tempsDispo = 10;
    if (sel.emotion == null) sel.emotion = 'calme';
    recordHoraire(sel.envie);
    var state = computeState(sel);
    var r = route(state);
    showReco(state, r);
  }
  function showReco(state, r) {
    inject(); close();
    ov = E('div', 'mds-ov md-ov'); var c = E('div', 'mds-card md-card mds-reco'); ov.appendChild(c); document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Point sur l\u2019envie' });
    if (window.MDCompagnon && window.MDCompagnon.avatarHTML) {
      var avWrap2 = document.createElement('div'); avWrap2.style.cssText = 'display:flex;justify-content:center;margin-bottom:8px';
      avWrap2.innerHTML = (window.MDMascotte ? MDMascotte.avatar('recommandation', { humeur:'encouragement' }) : window.MDCompagnon.avatarHTML('encouragement', { size: 'md' }));
      c.appendChild(avWrap2);
    }
    c.appendChild(E('p', 'mds-q', 'On te propose'));
    var meta = MODULES[r.module];
    var card = E('div', 'mds-recoc');
    card.appendChild(E('div', 'mds-recon', meta.nom + ' \u00B7 ' + meta.dureeMin + ' min'));
    card.appendChild(E('div', 'mds-recow', 'Pourquoi : ' + r.why));
    c.appendChild(card);
    var go = E('button', 'mds-go on', 'Commencer'); go.type = 'button';
    go.onclick = function () { close(); window.MDReco.go(r.module, state.envie, state.type); };
    c.appendChild(go);
    var alts = r.alternatives.filter(function (m) { return m !== r.module; }).slice(0, 2);
    alts.forEach(function (m) {
      var b = E('button', 'mds-2nd', 'Plutôt ' + MODULES[m].nom); b.type = 'button';
      b.onclick = function () { close(); window.MDReco.go(m, state.envie, state.type); };
      c.appendChild(b);
    });
    var skip = E('button', 'mds-skip', 'fermer'); skip.type = 'button'; skip.onclick = close; c.appendChild(skip);
  }
  window.MDScanner = { open: open, computeState: computeState };
})();
