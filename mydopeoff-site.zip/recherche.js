/* MyDope Off — recherche.js
   =========================================================================
   Moteur de recherche interne. Aucune requête réseau, aucun historique conservé :
   ce que quelqu'un tape à 3 h du matin ne doit rester nulle part.

   REFONTE (retour de Simon) — le moteur précédent ne trouvait ni « jeux » ni
   « stress », et n'affichait rien pendant la frappe. Quatre changements :

   1. RECHERCHE PAR PRÉFIXE dès 3 caractères. Quelqu'un qui tape « stre » doit
      voir « stress » avant d'avoir fini.
   2. ALIAS EXPLICITES dans l'index : « jeux », « exercices », « activités »
      désignent la même chose pour la personne, jamais pour un index bâti sur
      les seuls titres.
   3. SCORE PONDÉRÉ par zone : un mot du titre pèse le double d'un mot-clé, qui
      pèse le double d'une description.
   4. TOLÉRANCE : accents, tirets, apostrophes et pluriels simples ignorés.
      On cherche mal quand on va mal.

   Les entrées d'urgence portent leur GESTE dans le résultat : quelqu'un qui tape
   « il respire plus » n'a pas besoin d'un lien de plus à cliquer.
   ========================================================================= */
window.MDRecherche = (function () {
  'use strict';

  function lang() {
    try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; }
  }
  function L(o, champ) { return o[champ + '_' + lang()] || o[champ + '_fr'] || ''; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function norm(t) {
    return String(t || '').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/['\u2019`\-_.,;:!?()\[\]/]/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }
  function sansPluriel(m) {
    return (m.length > 4 && /(s|x)$/.test(m)) ? m.slice(0, -1) : m;
  }

  /* Mots vides : sans eux, « ça siffle » remontait l'urgence panique parce que « ça »
     correspond au « ça » de « ça monte trop fort ». Ignorés SAUF si la requête n'est
     faite que d'eux. */
  var VIDES = norm(
    'je tu il elle on nous vous ils elles me te se ma mon mes ta ton tes sa son ses ' +
    'le la les un une des du de d au aux a as ai est es et ou ni mais donc car que qui ' +
    'quoi dont pour par sur sous dans avec sans plus moins tres trop peu pas ne nen ' +
    'ce cet cette ces ca cela ceci y en avoir etre fait faire suis sommes ete the of ' +
    'to and or is it he she my your for with without more less not').split(' ');
  function utile(t) { return VIDES.indexOf(t) === -1; }

  /* exact 12 · préfixe 8 · inclusion 4 */
  function scoreZone(terme, zone) {
    var mots = zone.split(' ');
    var best = 0;
    var t = sansPluriel(terme);
    for (var i = 0; i < mots.length; i++) {
      var m = sansPluriel(mots[i]);
      if (!m) continue;
      if (m === t) { best = Math.max(best, 12); }
      else if (t.length >= 3 && m.indexOf(t) === 0) { best = Math.max(best, 8); }
      else if (t.length >= 4 && m.indexOf(t) !== -1) { best = Math.max(best, 4); }
      else if (t.length >= 5 && t.indexOf(m) === 0 && m.length >= 4) { best = Math.max(best, 3); }
    }
    return best;
  }

  function score(entree, termes) {
    var titre = norm(L(entree, 'titre'));
    var mots = norm(entree.mots || '');
    var desc = norm(L(entree, 'desc') || '');
    var total = 0, fort = false, touches = 0;

    for (var i = 0; i < termes.length; i++) {
      var t = termes[i];
      var sT = scoreZone(t, titre), sM = scoreZone(t, mots), sD = scoreZone(t, desc);
      var meilleur = Math.max(sT * 2.0, sM * 1.0, sD * 0.5);
      if (meilleur > 0) touches++;
      if (sT >= 12 || sM >= 12) fort = true;
      total += meilleur;
    }
    /* Bonus si TOUS les termes trouvent quelque chose : « dose femme » doit préférer
       une page qui répond aux deux mots plutôt qu'une qui n'en couvre qu'un très bien. */
    if (termes.length > 1 && touches === termes.length) total *= 1.4;
    return { total: total, fort: fort };
  }

  function chercher(q) {
    var bruts = norm(q).split(' ').filter(function (t) { return t.length >= 2; });
    var termes = bruts.filter(utile);
    if (!termes.length) termes = bruts;
    if (!termes.length) return [];
    var out = [];
    (window.MD_RECHERCHE || []).forEach(function (e) {
      var r = score(e, termes);
      if (r.total > 0) out.push({ e: e, s: r.total + (e.urgence && r.fort ? 200 : 0) });
    });
    out.sort(function (a, b) { return b.s - a.s; });
    return out.map(function (x) { return x.e; });
  }

  var T = {
    rien:    { fr: 'Rien ne correspond a ces mots.', en: 'Nothing matches those words.' },
    rien_d:  { fr: 'Essaie avec un autre mot, ou passe par les dossiers.',
               en: 'Try another word, or browse the files.' },
    voir:    { fr: 'Voir tous les dossiers', en: 'Browse all files' },
    urgence: { fr: 'Tout de suite', en: 'Right now' }
  };
  function t(k) { return T[k][lang()] || T[k].fr; }

  function rendre(q, cible) {
    if (!cible) return 0;
    if (!norm(q)) { cible.innerHTML = ''; return 0; }
    var res = chercher(q);
    if (!res.length) {
      cible.innerHTML = '<div class="rc-vide"><p class="rc-vt">' + esc(t('rien')) + '</p><p>' +
        esc(t('rien_d')) + '</p><p><a href="rdr.html" class="link-terra">' + esc(t('voir')) + ' &rarr;</a></p></div>';
      return 0;
    }
    cible.innerHTML = res.slice(0, 15).map(function (e) {
      if (e.urgence) {
        return '<a class="rc-item rc-urg" href="' + esc(e.url) + '">' +
          '<span class="rc-tag">' + esc(t('urgence')) + '</span>' +
          '<span class="rc-nom">' + esc(L(e, 'titre')) + '</span>' +
          '<span class="rc-geste">' + esc(L(e, 'geste')) + '</span></a>';
      }
      var d = L(e, 'desc');
      return '<a class="rc-item" href="' + esc(e.url) + '">' +
        '<span class="rc-nom">' + esc(L(e, 'titre')) + '</span>' +
        (d ? '<span class="rc-desc">' + esc(d) + '</span>' : '') +
        '<span class="rc-chev">&rsaquo;</span></a>';
    }).join('');
    return res.length;
  }

  function auto() {
    var champ = document.getElementById('recherche-champ');
    var res = document.getElementById('recherche-res');
    if (!champ || !res) return;
    champ.addEventListener('input', function () { rendre(champ.value, res); });
    champ.addEventListener('search', function () { rendre(champ.value, res); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', auto);
  else auto();

  return { chercher: chercher, rendre: rendre, norm: norm };
})();
