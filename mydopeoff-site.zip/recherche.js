/* MyDope Off — recherche.js
   ============================================================================
   Moteur de recherche interne. Rien ne sort de l'appareil : ni les mots tapés, ni
   les résultats, ni le fait qu'une recherche ait eu lieu. Aucun historique n'est
   conservé — ce que quelqu'un cherche à 3 h du matin ne doit rester nulle part.

   Trois choix de conception, tous dictés par le contexte d'usage :

   1. LES URGENCES PASSENT DEVANT, AVEC LEUR GESTE. Quelqu'un qui tape « il respire
      plus » n'a pas besoin d'une liste de liens : il a besoin d'une conduite, tout de
      suite. Ces résultats affichent le geste directement dans la liste.

   2. TOLÉRANCE AUX FAUTES. On cherche mal quand on va mal. La normalisation retire les
      accents, la ponctuation et les pluriels simples ; une correspondance partielle sur
      les mots d'au moins quatre lettres suffit.

   3. JAMAIS DE CUL-DE-SAC. Une recherche sans résultat propose une porte de sortie
      (ch. 40, G4 : aucun écran sans suite possible).
   ============================================================================ */
window.MDRecherche = (function () {
  'use strict';

  function lang() {
    try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; }
  }
  function L(o, champ) { return o[champ + '_' + lang()] || o[champ + '_fr'] || ''; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function norm(t) {
    return String(t || '').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/['’`\-_.]/g, ' ')
      .replace(/[^a-z0-9 ]/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }

  /* Mots vides. Sans cette liste, « ça siffle » remonte l'urgence panique : « ça »
     correspond exactement au « ça » de « ça monte trop fort ». Bug vu au test, invisible
     à la lecture du code. Ces mots sont ignorés SAUF si la requête n'est faite que d'eux. */
  var VIDES = norm(
    'je tu il elle on nous vous ils elles me te se ma mon mes ta ton tes sa son ses ' +
    'le la les un une des du de d au aux a as ai est es et ou ni mais donc car que qui ' +
    'quoi dont ou pour par sur sous dans avec sans plus moins tres trop peu pas ne nen ' +
    'ce cet cette ces ca cela ceci y en avoir etre fait faire suis sommes ete the of ' +
    'to and or is it he she my your for with without more less not' ).split(' ');

  function utile(t) { return VIDES.indexOf(t) === -1; }

  /* Score : correspondance exacte d'un mot > début de mot > inclusion.
     Le titre pèse plus que les mots-clés, un mot rare plus qu'un mot courant. */
  function score(entree, termes) {
    var champ = norm(entree.mots + ' ' + L(entree, 'titre'));
    var titre = norm(L(entree, 'titre'));
    var mots = champ.split(' ');
    var total = 0, fort = false;
    for (var i = 0; i < termes.length; i++) {
      var t = termes[i], best = 0;
      for (var j = 0; j < mots.length; j++) {
        var m = mots[j];
        if (m === t) { best = Math.max(best, 10); }
        else if (t.length >= 3 && m.indexOf(t) === 0) { best = Math.max(best, 7); }
        else if (t.length >= 4 && m.indexOf(t) !== -1) { best = Math.max(best, 4); }
        else if (t.length >= 5 && t.indexOf(m) === 0 && m.length >= 4) { best = Math.max(best, 3); }
      }
      /* Un mot EXACT, pas un préfixe. « arrêté » ressemble à « respiration arrêtée » :
         sans ce durcissement, « je vais mal depuis que j'ai arrêté » remontait l'urgence
         overdose au lieu du dossier PAWS. Vu au test, invisible en lisant le code. */
      if (best >= 10) fort = true;
      if (best && titre.indexOf(t) !== -1) best += 5;
      total += best;
    }
    /* `fort` distingue une vraie correspondance d'un simple fragment. Il conditionne le
       coup de pouce d'urgence : sans lui, une entrée d'urgence effleurée par un mot
       passait devant une correspondance parfaite ailleurs. */
    return { total: total, fort: fort };
  }

  function chercher(q) {
    var bruts = norm(q).split(' ').filter(function (t) { return t.length >= 2; });
    var termes = bruts.filter(utile);
    if (!termes.length) termes = bruts;      // requête faite uniquement de mots vides
    if (!termes.length) return [];
    var out = [];
    (window.MD_RECHERCHE || []).forEach(function (e) {
      var r = score(e, termes);
      if (r.total > 0) out.push({ e: e, s: r.total + (e.urgence && r.fort ? 100 : 0) });
    });
    out.sort(function (a, b) { return b.s - a.s; });
    return out.map(function (x) { return x.e; });
  }

  var T = {
    rien:   { fr: 'Rien ne correspond à ces mots.', en: 'Nothing matches those words.' },
    rien_d: { fr: 'Essaie avec un autre mot, ou passe par les dossiers — parfois ce qu’on cherche n’a pas encore de nom.',
              en: 'Try another word, or browse the files — sometimes what you’re looking for doesn’t have a name yet.' },
    voir:   { fr: 'Voir tous les dossiers', en: 'Browse all files' },
    urgence:{ fr: 'Tout de suite', en: 'Right now' }
  };
  function t(k) { return T[k][lang()] || T[k].fr; }

  function rendre(q, cible) {
    if (!cible) return 0;
    if (!norm(q)) { cible.innerHTML = ''; return 0; }
    var res = chercher(q);
    if (!res.length) {
      cible.innerHTML = '<div class="rc-vide"><p class="rc-vt">' + esc(t('rien')) + '</p><p>' +
        esc(t('rien_d')) + '</p><p><a href="rdr.html" class="link-terra">' + esc(t('voir')) + ' →</a></p></div>';
      return 0;
    }
    cible.innerHTML = res.slice(0, 12).map(function (e) {
      if (e.urgence) {
        return '<a class="rc-item rc-urg" href="' + esc(e.url) + '">' +
          '<span class="rc-tag">' + esc(t('urgence')) + '</span>' +
          '<span class="rc-nom">' + esc(L(e, 'titre')) + '</span>' +
          '<span class="rc-geste">' + esc(L(e, 'geste')) + '</span></a>';
      }
      return '<a class="rc-item" href="' + esc(e.url) + '">' +
        '<span class="rc-nom">' + esc(L(e, 'titre')) + '</span><span class="rc-chev">›</span></a>';
    }).join('');
    return res.length;
  }

  /* Auto-montage : toute page portant #recherche-champ et #recherche-res est équipée,
     sans code spécifique. La recherche est instantanée, sans bouton à presser. */
  function auto() {
    var champ = document.getElementById('recherche-champ');
    var res = document.getElementById('recherche-res');
    if (!champ || !res) return;
    champ.addEventListener('input', function () { rendre(champ.value, res); });
    champ.addEventListener('search', function () { rendre(champ.value, res); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', auto);
  else auto();

  return { chercher: chercher, rendre: rendre };
})();
