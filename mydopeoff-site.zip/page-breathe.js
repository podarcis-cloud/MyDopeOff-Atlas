/* MyDope Off — page-breathe.js
   Init + logique de breathe, extraits des scripts inline de breathe.html pour permettre
   une CSP stricte (script-src 'self'). Contenu inchangé, ordre préservé. */

try{MDCore.init({page:'breathe',section:'equilibre'});}catch(e){}

/* ---- logique de la page ---- */

(function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };
  function show(id){ ['scr-cal','scr-run','scr-end'].forEach(function(s){ $(s).classList.toggle('on', s===id); }); }

  /* ---------- état ---------- */
  var rateBpm = 6.0;        // cycles / minute
  var exhaleLong = false;   // 4 in / 6 out
  var motionOn = false, micOn = false;
  var running = false, startT = 0, rafId = null;
  var orb = $('orb'), phaseEl = $('phase');

  /* ---------- signal capteur (mouvement OU micro) ---------- */
  var sig = 0;              // signal respiratoire projeté (centré ~0)
  var gx=null,gy=null,gz=null;     // gravité lente (posture)
  var fx=0,fy=0,fz=0;              // composante respiration par axe (passe-bande)
  var calAxis=null, calAmp=0;      // axe principal + amplitude (calibration)
  var calibrating=false, calSamples=[], calRAF=null, calEnv=0.02;
  var buf = []; var BUF_MS = 24000;

  // Mouvement (accéléromètre + gravité)
  function onMotion(e){
    var a = e.accelerationIncludingGravity || e.acceleration; if(!a) return;
    var ax=a.x||0, ay=a.y||0, az=a.z||0;
    if(gx===null){ gx=ax; gy=ay; gz=az; }
    // gravité = passe-bas très lent (orientation/posture)
    gx=gx*0.9975+ax*0.0025; gy=gy*0.9975+ay*0.0025; gz=gz*0.9975+az*0.0025;
    // composante respiration par axe = passe-bande (oscillation lente de l'inclinaison)
    fx=fx*0.90+(ax-gx)*0.10; fy=fy*0.90+(ay-gy)*0.10; fz=fz*0.90+(az-gz)*0.10;
    if(calibrating) calSamples.push([fx,fy,fz]);
    // projection sur l'axe respiratoire calibré (sinon axe le plus probable)
    sig = calAxis ? (fx*calAxis[0]+fy*calAxis[1]+fz*calAxis[2]) : (Math.abs(fx)>Math.abs(fy)?(Math.abs(fx)>Math.abs(fz)?fx:fz):(Math.abs(fy)>Math.abs(fz)?fy:fz));
  }
  // axe principal d'oscillation (PCA, itération de puissance)
  function principalAxis(S){
    var n=S.length; if(n<10) return null;
    var mx=0,my=0,mz=0,i; for(i=0;i<n;i++){mx+=S[i][0];my+=S[i][1];mz+=S[i][2];} mx/=n;my/=n;mz/=n;
    var cxx=0,cxy=0,cxz=0,cyy=0,cyz=0,czz=0;
    for(i=0;i<n;i++){var x=S[i][0]-mx,y=S[i][1]-my,z=S[i][2]-mz;cxx+=x*x;cxy+=x*y;cxz+=x*z;cyy+=y*y;cyz+=y*z;czz+=z*z;}
    var v=[1,1,1];
    for(var it=0;it<30;it++){
      var nx=cxx*v[0]+cxy*v[1]+cxz*v[2], ny=cxy*v[0]+cyy*v[1]+cyz*v[2], nz=cxz*v[0]+cyz*v[1]+czz*v[2];
      var L=Math.sqrt(nx*nx+ny*ny+nz*nz)||1; v=[nx/L,ny/L,nz/L];
    }
    return v;
  }
  function startCalibration(){
    show('scr-cal'); calAxis=null; calAmp=0; calSamples=[]; gx=gy=gz=null; fx=fy=fz=0; sig=0; calEnv=0.02;
    enableMotion();
    var t0=performance.now(), started=false;
    cancelAnimationFrame(calRAF);
    (function loop(){
      if(motionOn){
        if(!started){ started=true; calibrating=true; t0=performance.now(); $('cal-status').textContent='Respire calmement, la forme suit ton souffle\u2026'; }
        var el=performance.now()-t0;
        calEnv=Math.max(calEnv*0.997, Math.abs(sig));
        var sN=Math.max(-1,Math.min(1, sig/((calEnv*1.4)||1)));
        $('cal-orb').style.transform='scale('+(0.55+0.4*(sN*0.5+0.5)).toFixed(3)+')';
        $('cal-bar').style.width=Math.min(100, el/6000*100)+'%';
        if(el>=6000){ finishCalibration(); return; }
      } else if(performance.now()-t0>4500){
        $('cal-status').innerHTML='Capteur indisponible. <b>Continue sans capteur</b> pour suivre l\u2019orbe.';
      }
      calRAF=requestAnimationFrame(loop);
    })();
  }
  function finishCalibration(){
    calibrating=false; cancelAnimationFrame(calRAF);
    var axis=principalAxis(calSamples);
    if(axis){
      var proj=calSamples.map(function(s){return s[0]*axis[0]+s[1]*axis[1]+s[2]*axis[2];});
      var m=proj.reduce(function(a,b){return a+b;},0)/proj.length;
      var sd=Math.sqrt(proj.reduce(function(a,b){return a+(b-m)*(b-m);},0)/proj.length);
      calAxis=axis; calAmp=sd;
    }
    startRun();
  }
  function enableMotion(){
    function attach(){ window.addEventListener('devicemotion', onMotion); motionOn=true; micOn=false; markSensors(); }
    try{
      if(typeof DeviceMotionEvent!=='undefined' && typeof DeviceMotionEvent.requestPermission==='function'){
        DeviceMotionEvent.requestPermission().then(function(p){ if(p==='granted') attach(); else sensorErr('st-motion','Refusé'); }).catch(function(){ sensorErr('st-motion','Indispo'); });
      } else if('ondevicemotion' in window){ attach(); }
      else sensorErr('st-motion','Indispo');
    }catch(err){ sensorErr('st-motion','Indispo'); }
  }

  // Micro (enveloppe RMS)
  var audioCtx=null, analyser=null, micData=null, micStream=null, micRAF=null;
  function enableMic(){
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){ sensorErr('st-mic','Indispo'); return; }
    navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false}}).then(function(stream){
      micStream=stream; audioCtx=new (window.AudioContext||window.webkitAudioContext)();
      var src=audioCtx.createMediaStreamSource(stream); analyser=audioCtx.createAnalyser(); analyser.fftSize=1024;
      micData=new Uint8Array(analyser.fftSize); src.connect(analyser);
      micOn=true; motionOn=false; window.removeEventListener('devicemotion', onMotion);
      markSensors();
      (function loop(){ analyser.getByteTimeDomainData(micData); var s=0;
        for(var i=0;i<micData.length;i++){ var d=(micData[i]-128)/128; s+=d*d; }
        var rms=Math.sqrt(s/micData.length);
        sig = sig*0.8 + (rms-0.04)*0.2*6;            // enveloppe centrée, amplifiée
        micRAF=requestAnimationFrame(loop);
      })();
    }).catch(function(){ sensorErr('st-mic','Refusé'); });
  }
  function sensorErr(id,txt){ var el=$(id); if(el) el.textContent=txt; }
  function markSensors(){
    $('sb-motion').classList.toggle('ok', motionOn); $('st-motion').textContent = motionOn?'Actif':'Activer';
    $('sb-mic').classList.toggle('ok', micOn); $('st-mic').textContent = micOn?'Actif':'Activer';
    if(typeof updateRunSensor==='function') updateRunSensor();
  }

  /* ---------- pacer (rythme guidé) ---------- */
  function cycleSec(){ return 60/rateBpm; }
  function inFrac(){ return exhaleLong ? 0.4 : 0.5; }   // part d'inspiration
  function ease(x){ return 0.5-0.5*Math.cos(Math.PI*Math.min(1,Math.max(0,x))); }
  // renvoie {scale 0..1, label, target -1..1}
  function pacer(elapsedSec){
    var P=cycleSec(), t=elapsedSec % P, inDur=P*inFrac(), label, k;
    if(t<inDur){ k=ease(t/inDur); label='Inspire'; }
    else { k=1-ease((t-inDur)/(P-inDur)); label='Expire'; }
    return { scale:0.55+0.45*k, label:label, target:(k*2-1) };
  }

  /* ---------- estimation du rythme (pics du signal) ---------- */
  function estimateRate(){
    if(buf.length<20) return null;
    var now=buf[buf.length-1].t, vs=buf.filter(function(p){return now-p.t<=BUF_MS;});
    if(vs.length<20) return null;
    var vals=vs.map(function(p){return p.v;});
    var mn=Math.min.apply(null,vals), mx=Math.max.apply(null,vals); if(mx-mn<1e-3) return null;
    var thr=(mn+mx)/2, peaks=[], above=false;
    for(var i=0;i<vs.length;i++){ var v=vs[i].v;
      if(!above && v>thr){ above=true; peaks.push(vs[i].t); }
      else if(above && v<thr){ above=false; }
    }
    if(peaks.length<2) return null;
    var span=(peaks[peaks.length-1]-peaks[0])/1000, n=peaks.length-1;
    if(span<=0) return null;
    var rate=n/span*60; if(rate<2||rate>30) return null;
    return rate;
  }

  /* ---------- boucle d'animation ---------- */
  var trace=$('trace'), tctx=trace.getContext('2d'), DPR=Math.min(2,window.devicePixelRatio||1);
  function sizeCanvas(){ var w=trace.clientWidth||528; trace.width=w*DPR; trace.height=96*DPR; tctx.setTransform(DPR,0,0,DPR,0,0); }
  function drawTrace(){
    var W=trace.clientWidth||528, H=96, now=performance.now();
    tctx.clearRect(0,0,W,H);
    var pts=buf.filter(function(p){return now-p.t<=BUF_MS;});
    // rythme guidé (référence) — sinusoïde au rythme courant
    tctx.strokeStyle=getComputedStyle(document.body).getPropertyValue('--ink-2')||'#58635E';
    tctx.globalAlpha=.45; tctx.lineWidth=2; tctx.beginPath();
    for(var x=0;x<=W;x+=4){ var tsec=(now-(W-x)/W*BUF_MS)/1000; var p=pacer(tsec-startSec()); var y=H/2 - p.target*(H*0.36);
      if(x===0) tctx.moveTo(x,y); else tctx.lineTo(x,y); }
    tctx.stroke(); tctx.globalAlpha=1;
    // signal capteur (normalisé)
    if(pts.length>3){
      var vals=pts.map(function(p){return p.v;}), mn=Math.min.apply(null,vals), mx=Math.max.apply(null,vals), rg=(mx-mn)||1;
      tctx.strokeStyle=getComputedStyle(document.body).getPropertyValue('--c')||'#D5A84A';
      tctx.lineWidth=2.5; tctx.beginPath();
      for(var i=0;i<pts.length;i++){ var px=(now-pts[i].t)/BUF_MS; var X=W-px*W; var norm=(pts[i].v-mn)/rg; var Y=H-8-norm*(H-16);
        if(i===0) tctx.moveTo(X,Y); else tctx.lineTo(X,Y); }
      tctx.stroke();
    } else {
      tctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--ink-2'); tctx.globalAlpha=.6;
      tctx.font='12px Inter, sans-serif'; tctx.textAlign='center';
      tctx.fillText(motionOn||micOn?'Capte ta respiration…':'Active un capteur pour voir ta courbe', W/2, H/2+4);
      tctx.globalAlpha=1;
    }
  }
  var _startMs=0; function startSec(){ return _startMs/1000; }

  var lastRateUpd=0;
  function frame(){
    if(!running) return;
    var now=performance.now(), elapsed=(now-startT)/1000;
    if(durGoal>0 && elapsed>=durGoal){ stop(); return; }
    var p=pacer(elapsed);
    phaseEl.textContent=p.label;
    // Orbe = rythme à suivre : gonfle à l'inspiration, dégonfle à l'expiration.
    // Anneau-guide = cible « inspiration pleine », statique : l'orbe vient la remplir.
    var orbScale = 0.58 + 0.52*((p.scale-0.55)/0.45);   // ~0.58 (expire) -> ~1.10 (inspire)
    orb.style.transform='scale('+orbScale.toFixed(3)+')';
    // Couleur : bleu (fjord) à l'inspiration -> rouge (terra) à l'expiration
    var warm = Math.max(0, Math.min(1, (1.0 - p.scale)/0.45));
    var cr=Math.round(105+(199-105)*warm), cg=Math.round(136+(118-136)*warm), cb=Math.round(154+(92-154)*warm);
    orb.style.background='radial-gradient(circle at 38% 32%, rgba(255,255,255,.55), rgb('+cr+','+cg+','+cb+') 80%)';
    var g=$('guide'); if(g) g.style.transform='scale(1.10)';
    // n° de cycle
    $('cyc').textContent='Cycle '+(Math.floor(elapsed/cycleSec())+1);
    // historique signal (si capteur) — alimente la courbe + l'estimation du rythme
    if(motionOn||micOn){ buf.push({t:now, v:sig}); var cut=now-BUF_MS; while(buf.length&&buf[0].t<cut) buf.shift(); }
    drawTrace();
    // métriques (1×/s)
    if(now-lastRateUpd>1000){
      lastRateUpd=now;
      var mm=Math.floor(elapsed/60), ss=Math.floor(elapsed%60);
      $('m-time').textContent=mm+':'+(ss<10?'0':'')+ss;
      var r=estimateRate();
      if(r){ $('m-rate').textContent=r.toFixed(1).replace('.',',')+'/min';
        var diff=r-rateBpm;
        $('hint').textContent = Math.abs(diff)<0.8 ? 'Joliment synchronisé — reste là.' : (diff>0 ? 'Ralentis un peu, allonge l\u2019expiration.' : 'Tu peux respirer un peu plus librement.');
        rateSamples.push(r);
      } else if(!(motionOn||micOn)){ $('m-rate').textContent='—'; }
    }
    rafId=requestAnimationFrame(frame);
  }

  /* ---------- contrôles ---------- */
  function fmtPace(){ var P=cycleSec(), inS=(P*inFrac()), outS=P-inS;
    $('p-val').textContent=rateBpm.toFixed(1).replace('.',',')+' / min · '+Math.round(inS)+'\u2013'+Math.round(outS)+' s'; }
  function setRate(r){ rateBpm=Math.min(7,Math.max(4.5,Math.round(r*2)/2)); fmtPace(); }

  var rateSamples=[]; var durGoal=180;
  function updateRunSensor(){
    var el=$('run-sensor'); if(!el) return;
    if(motionOn) el.innerHTML='<b style="color:var(--ok)">\u25CF Mouvement actif</b> \u2014 pose le téléphone à plat, entre le sternum et le nombril';
    else if(micOn) el.innerHTML='<b style="color:var(--ok)">\u25CF Micro actif</b> \u2014 respire près du micro';
    else el.innerHTML='Aucun capteur \u2014 suis l\u2019orbe. <b>Active le mouvement</b> pour voir ta courbe.';
  }
  function startRun(){
    show('scr-run'); updateRunSensor(); sizeCanvas(); fmtPace();
    phaseEl.textContent='Prêt'; if(orb) orb.style.transform='scale(0.58)';
    var b=$('btn-go'); if(b) b.style.display='';
  }
  function beginRun(){
    var b=$('btn-go'); if(b) b.style.display='none';
    running=true; startT=performance.now(); _startMs=startT; buf=[]; rateSamples=[]; lastRateUpd=0;
    rafId=requestAnimationFrame(frame);
  }
  function start(){
    // "Commencer" : calibration capteur si possible (geste utilisateur OK), sinon run direct
    if(!micOn && (typeof DeviceMotionEvent!=='undefined' || ('ondevicemotion' in window))){ startCalibration(); }
    else startRun();
  }
  function logSession(rec){
    try{ var k='ctc_v6', d=JSON.parse(localStorage.getItem(k)||'{}');
      d.sessions=Array.isArray(d.sessions)?d.sessions:[]; d.sessions.push(rec);
      localStorage.setItem(k,JSON.stringify(d));
      return d.sessions.filter(function(x){return x.type===rec.type;}).length;
    }catch(e){ return 1; }
  }
  function drawEndGraph(){
    var cv=$('e-graph'); if(!cv) return; var ctx=cv.getContext('2d');
    var W=cv.clientWidth||528, H=120, DPR=Math.min(2,window.devicePixelRatio||1);
    cv.width=W*DPR; cv.height=H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H);
    var cs=getComputedStyle(document.body);
    if(!rateSamples.length){ ctx.fillStyle=cs.getPropertyValue('--ink-2'); ctx.globalAlpha=.6; ctx.font='12px Inter,sans-serif'; ctx.textAlign='center'; ctx.fillText('Pas de capteur actif — aucune courbe enregistrée', W/2, H/2); ctx.globalAlpha=1; return; }
    var lo=Math.min(rateBpm-2, Math.min.apply(null,rateSamples))-0.5, hi=Math.max(rateBpm+2, Math.max.apply(null,rateSamples))+0.5, rg=(hi-lo)||1;
    function Y(v){ return H-10-((v-lo)/rg)*(H-20); }
    ctx.strokeStyle=cs.getPropertyValue('--ink-2'); ctx.globalAlpha=.45; ctx.setLineDash([5,4]); ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.moveTo(0,Y(rateBpm)); ctx.lineTo(W,Y(rateBpm)); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha=1;
    ctx.strokeStyle=cs.getPropertyValue('--c')||'#C7765C'; ctx.lineWidth=2.5; ctx.beginPath();
    rateSamples.forEach(function(r,i){ var X=rateSamples.length>1? i/(rateSamples.length-1)*W : W/2; var y=Y(r); if(i===0)ctx.moveTo(X,y); else ctx.lineTo(X,y); });
    ctx.stroke();
  }
  function stop(){
    running=false; if(rafId) cancelAnimationFrame(rafId);
    var elapsed=(performance.now()-startT)/1000, mm=Math.floor(elapsed/60), ss=Math.floor(elapsed%60);
    $('e-time').textContent=mm+':'+(ss<10?'0':'')+ss;
    var avg = rateSamples.length ? (rateSamples.reduce(function(a,b){return a+b;},0)/rateSamples.length) : null;
    $('e-rate').textContent = avg ? avg.toFixed(1).replace('.',',')+'/min' : '—';
    var coh=null; if(rateSamples.length){ var inb=rateSamples.filter(function(r){return Math.abs(r-rateBpm)<=1;}).length; coh=Math.round(inb/rateSamples.length*100); }
    $('e-coh').textContent = coh!=null ? coh+' %' : '—';
    $('end-explain').textContent = (avg==null)
      ? 'Pas de capteur actif cette fois : tu as suivi le guide visuel. Active le mouvement ou le micro pour visualiser ta courbe et mesurer ta cohérence.'
      : (coh>=60 ? 'Ta respiration est restée proche de la cohérence cardiaque : l\u2019état où cœur et respiration se synchronisent et où la tension retombe.'
                : 'Tu t\u2019es entraîné à ralentir. Viser ~6/min devient plus naturel avec la pratique — et l\u2019effet apaisant arrive plus vite.');
    $('end-msg').textContent = elapsed>=180 ? 'Trois minutes tenues — beau travail.' : (elapsed>=60 ? 'Bon moment passé à ralentir.' : 'Même court, c\u2019est un pas.');
    var total=(window.MDData?MDData.countSessions('breathe')+1:1);
    $('e-total').textContent = total>1 ? ('\u2728 '+total+' séances de souffle au total') : 'Première séance de souffle enregistrée';
    show('scr-end'); drawEndGraph();
    if(window.MDExercise){ MDExercise.after('breathe',{avant:window.__mdAvant, dureeSec:Math.round(elapsed), meta:{avg:(avg?Math.round(avg*10)/10:null),coherence:coh},
      title:'Souffle', stats:[{label:'durée',value:$('e-time').textContent},{label:'rythme moyen',value:$('e-rate').textContent},{label:'en cohérence',value:$('e-coh').textContent}],
      nav:{ primary:{label:'Recommencer'}, secondary:{label:'Retour au labo', onClick:function(){ location.href=(window.LUCIDE?LUCIDE.link('fiches.html'):'fiches.html'); }} },
      onClose:function(){ window.__mdAvant=null; begin(); }}); }
    else if(window.MDData){ MDData.logSession('breathe',{dureeSec:Math.round(elapsed),meta:{avg:(avg?Math.round(avg*10)/10:null),coherence:coh}}); }
  }

  /* ---------- liaisons ---------- */
  var SENSOR_DURATION_HTML =
    '<p class="seclabel">Capteur (optionnel)</p>' +
    '<div class="sensors">' +
      '<button type="button" class="sensor-btn" id="sb-motion">' +
        '<span class="em">\ud83d\udcc8</span><span><b>Mouvement du ventre</b><br><span class="muted" style="font-size:var(--fs-xs)">\u00c0 plat entre le sternum et le nombril</span></span><span class="st" id="st-motion">Activer</span>' +
      '</button>' +
      '<button type="button" class="sensor-btn" id="sb-mic">' +
        '<span class="em">\ud83c\udf99\ufe0f</span><span><b>Micro (souffle)</b><br><span class="muted" style="font-size:var(--fs-xs)">Capte le son de ta respiration</span></span><span class="st" id="st-mic">Activer</span>' +
      '</button>' +
    '</div>' +
    '<p class="muted" style="font-size:var(--fs-xs);margin:0 0 16px">Sans capteur, l\u2019orbe te guide quand m\u00eame. Rien n\u2019est enregistr\u00e9 ni envoy\u00e9 : tout reste sur ton t\u00e9l\u00e9phone, en direct.</p>' +
    '<p class="seclabel">Dur\u00e9e de la s\u00e9ance</p>' +
    '<div class="seg2" id="dur-seg" style="margin-bottom:16px">' +
      '<button type="button" data-dur="60">1 min</button>' +
      '<button type="button" class="on" data-dur="180">3 min</button>' +
      '<button type="button" data-dur="300">5 min</button>' +
      '<button type="button" data-dur="0">Libre</button>' +
    '</div>';
  function begin(){
    if(window.MDJeuHero){
      MDJeuHero.rules({mood:'respiration',title:'Souffle',
        lines:['Respire avec l\u2019orbe : inspire quand il grandit, expire quand il se resserre.',
               'Pose le téléphone à plat sur ton ventre si tu veux un retour précis (mouvement ou micro).',
               'Vise environ 6 respirations par minute — tu peux ajuster le rythme à tout moment.'],
        why:'Ralentir la respiration à ce rythme active le nerf vague et le système parasympathique : le corps envoie un signal de calme au cerveau, ce qui aide à faire retomber le stress et le craving (cohérence cardiaque).',
        extraHTML: SENSOR_DURATION_HTML,
        onRender: function(card){
          card.querySelector('#sb-motion').addEventListener('click', enableMotion);
          card.querySelector('#sb-mic').addEventListener('click', enableMic);
          var seg = card.querySelector('#dur-seg');
          if (seg) seg.addEventListener('click', function(e){ var b=e.target.closest('button'); if(!b) return; durGoal=parseInt(b.getAttribute('data-dur'))||0; Array.prototype.forEach.call(seg.querySelectorAll('button'),function(c){ c.classList.toggle('on', c===b); }); });
          markSensors(); // resynchronise l'état visuel des capteurs si déjà activés lors d'un tour précédent
        },
        onStart:function(avant){ window.__mdAvant=avant; start(); }});
    } else { start(); }
  }
  $('btn-go').addEventListener('click', beginRun);
  (function(){ var b=$('cal-skip'); if(b) b.addEventListener('click', function(){ calibrating=false; cancelAnimationFrame(calRAF); calAxis=null; calAmp=0; startRun(); }); })();
  $('btn-stop').addEventListener('click', stop);
  begin();

  $('p-up').addEventListener('click', function(){ setRate(rateBpm+0.5); });
  $('p-down').addEventListener('click', function(){ setRate(rateBpm-0.5); });
  $('btn-exhale').addEventListener('click', function(){ exhaleLong=!exhaleLong; this.classList.toggle('btn-primary',exhaleLong); this.classList.toggle('btn-outline',!exhaleLong); fmtPace(); });
  document.querySelectorAll('[data-back]').forEach(function(b){ b.addEventListener('click', function(e){ e.preventDefault(); if(history.length>1) history.back(); else location.href='index.html'; }); });
  window.addEventListener('resize', function(){ if(running) sizeCanvas(); });
  window.addEventListener('pagehide', function(){ if(micStream){ micStream.getTracks().forEach(function(t){t.stop();}); } });

  fmtPace();
})();
