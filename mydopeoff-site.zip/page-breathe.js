/* MyDope Off — page-breathe.js
   Init + logique de breathe, extraits des scripts inline de breathe.html pour permettre
   une CSP stricte (script-src 'self'). Contenu inchangé, ordre préservé. */

/* Dictionnaire des clés statiques injecté AVANT MDCore.init() : applyI18n() (appelé à
   l'intérieur de init()) doit trouver ces clés dès son premier passage, sinon le texte
   reste en français au premier rendu malgré les attributs data-i18n déjà en place. */
(function(){
  window.MD_DICT = window.MD_DICT || {};
  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'breathe.title':    { fr: 'Souffle', en: 'Breath' },
    'breathe.subtitle': { fr: 'Ralentis ta respiration, calme ton corps et ton esprit.', en: 'Slow your breathing, calm your body and mind.' },
    'breathe.calibration': { fr: 'Calibration', en: 'Calibration' },
    'breathe.cal_desc': { fr: 'Pose le téléphone à plat sur ton ventre, entre le sternum et le nombril. Respire normalement : la forme suit ton souffle.',
                          en: 'Lay the phone flat on your stomach, between your sternum and navel. Breathe normally: the shape follows your breath.' },
    'breathe.cal_activating': { fr: 'Activation du capteur…', en: 'Activating sensor…' },
    'breathe.continue_no_sensor': { fr: 'Continuer sans capteur', en: 'Continue without a sensor' },
    'breathe.ready': { fr: 'Prêt', en: 'Ready' },
    'breathe.start': { fr: 'Démarrer', en: 'Start' },
    'breathe.your_breath': { fr: 'Ta respiration', en: 'Your breathing' },
    'breathe.guided_pace': { fr: 'Rythme guidé', en: 'Guided pace' },
    'breathe.your_pace': { fr: 'Ton rythme', en: 'Your pace' },
    'breathe.duration': { fr: 'Durée', en: 'Duration' },
    'breathe.follow_orb': { fr: 'Suis l\u2019orbe : inspire quand il grandit, expire quand il rétrécit.', en: 'Follow the orb: breathe in as it grows, breathe out as it shrinks.' },
    'breathe.sensor_activating': { fr: 'Capteur en cours d\u2019activation…', en: 'Sensor activating…' },
    'breathe.slow_down_btn': { fr: 'Ralentir', en: 'Slow down' },
    'breathe.speed_up_btn': { fr: 'Accélérer', en: 'Speed up' },
    'breathe.long_exhale': { fr: 'Expiration longue', en: 'Long exhale' },
    'breathe.finish': { fr: 'Terminer', en: 'Finish' },
    'breathe.session_done': { fr: 'Séance terminée', en: 'Session complete' },
    'breathe.took_moment': { fr: 'Tu as pris un moment pour toi.', en: 'You took a moment for yourself.' },
    'breathe.your_rate': { fr: 'Ta vitesse de respiration', en: 'Your breathing rate' },
    'breathe.target_6': { fr: 'Cible 6/min', en: 'Target 6/min' },
    'breathe.graph_desc': { fr: 'Chaque point = ta vitesse de respiration (cycles par minute) au fil de la séance. Plus la courbe reste près de la ligne pointillée <b>6/min</b>, plus tu étais en cohérence cardiaque.',
                            en: 'Each point = your breathing rate (cycles per minute) over the course of the session. The closer the curve stays to the <b>6/min</b> dashed line, the more you were in cardiac coherence.' },
    'breathe.avg_rate': { fr: 'Rythme moyen', en: 'Average rate' },
    'breathe.stat_coherence': { fr: 'En cohérence', en: 'In coherence' }
  };
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });
})();

try{MDCore.init({page:'breathe',section:'equilibre'});}catch(e){}

/* ---- logique de la page ---- */

(function(){
  'use strict';
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var T = {
    breathe_calm:{fr:'Respire calmement, la forme suit ton souffle\u2026',en:'Breathe calmly, the shape follows your breath\u2026'},
    sensor_unavailable:{fr:'Capteur indisponible. <b>Continue sans capteur</b> pour suivre l\u2019orbe.',en:'Sensor unavailable. <b>Continue without a sensor</b> to follow the orb.'},
    refused:{fr:'Refusé',en:'Denied'},
    unavailable:{fr:'Indispo',en:'Unavail.'},
    active:{fr:'Actif',en:'Active'},
    activate:{fr:'Activer',en:'Activate'},
    ready:{fr:'Prêt',en:'Ready'},
    motion_active:{fr:'\u25CF Mouvement actif',en:'\u25CF Motion active'},
    motion_active_sub:{fr:' \u2014 pose le téléphone à plat, entre le sternum et le nombril',en:' \u2014 lay the phone flat, between your sternum and navel'},
    mic_active:{fr:'\u25CF Micro actif',en:'\u25CF Mic active'},
    mic_active_sub:{fr:' \u2014 respire près du micro',en:' \u2014 breathe near the microphone'},
    no_sensor:{fr:'Aucun capteur \u2014 suis l\u2019orbe. <b>Active le mouvement</b> pour voir ta courbe.',en:'No sensor \u2014 follow the orb. <b>Turn on motion</b> to see your curve.'},
    breathe_in:{fr:'Inspire',en:'Breathe in'},
    breathe_out:{fr:'Expire',en:'Breathe out'},
    no_curve:{fr:'Pas de capteur actif — aucune courbe enregistrée',en:'No active sensor — no curve recorded'},
    sensing_breath:{fr:'Capte ta respiration…',en:'Sensing your breath…'},
    activate_sensor_curve:{fr:'Active un capteur pour voir ta courbe',en:'Activate a sensor to see your curve'},
    cycle:{fr:'Cycle ',en:'Cycle '},
    nicely_synced:{fr:'Joliment synchronisé — reste là.',en:'Nicely synced — stay right there.'},
    slow_down:{fr:'Ralentis un peu, allonge l\u2019expiration.',en:'Slow down a little, lengthen the exhale.'},
    breathe_freer:{fr:'Tu peux respirer un peu plus librement.',en:'You can breathe a bit more freely.'},
    no_curve_end:{fr:'Pas de capteur actif cette fois : tu as suivi le guide visuel. Active le mouvement ou le micro pour visualiser ta courbe et mesurer ta cohérence.',
      en:'No active sensor this time: you followed the visual guide. Turn on motion or the mic to see your curve and measure your coherence.'},
    coherent:{fr:'Ta respiration est restée proche de la cohérence cardiaque : l\u2019état où cœur et respiration se synchronisent et où la tension retombe.',
      en:'Your breathing stayed close to cardiac coherence: the state where heart and breath synchronise and tension eases.'},
    training_slow:{fr:'Tu t\u2019es entraîné à ralentir. Viser ~6/min devient plus naturel avec la pratique — et l\u2019effet apaisant arrive plus vite.',
      en:'You trained yourself to slow down. Aiming for ~6/min becomes more natural with practice — and the calming effect kicks in faster.'},
    three_min:{fr:'Trois minutes tenues — beau travail.',en:'Three minutes held — well done.'},
    good_moment:{fr:'Bon moment passé à ralentir.',en:'A good stretch of time spent slowing down.'},
    even_short:{fr:'Même court, c\u2019est un pas.',en:'Even short, it\u2019s a step.'},
    sessions_total:{fr:(n)=>'\u2728 '+n+' séances de souffle au total',en:(n)=>'\u2728 '+n+' breathing sessions in total'},
    first_session:{fr:'Première séance de souffle enregistrée',en:'First breathing session recorded'},
    title:{fr:'Souffle',en:'Breath'},
    stat_duration:{fr:'durée',en:'duration'},
    stat_avg_rate:{fr:'rythme moyen',en:'average rate'},
    stat_coherence:{fr:'en cohérence',en:'in coherence'},
    restart:{fr:'Recommencer',en:'Restart'},
    back_labo:{fr:'Retour au labo',en:'Back to Lab'},
    sensor_optional:{fr:'Capteur (optionnel)',en:'Sensor (optional)'},
    belly_motion:{fr:'Mouvement du ventre',en:'Belly movement'},
    belly_motion_sub:{fr:'À plat entre le sternum et le nombril',en:'Flat on your stomach, between sternum and navel'},
    mic_breath:{fr:'Micro (souffle)',en:'Microphone (breath)'},
    mic_breath_sub:{fr:'Capte le son de ta respiration',en:'Picks up the sound of your breathing'},
    no_sensor_note:{fr:'Sans capteur, l\u2019orbe te guide quand même. Rien n\u2019est enregistré ni envoyé : tout reste sur ton téléphone, en direct.',
      en:'Without a sensor, the orb still guides you. Nothing is recorded or sent: everything stays on your phone, live.'},
    session_length:{fr:'Durée de la séance',en:'Session length'},
    free:{fr:'Libre',en:'Free'},
    rules_l1:{fr:'Respire avec l\u2019orbe : inspire quand il grandit, expire quand il se resserre.',en:'Breathe with the orb: breathe in as it grows, breathe out as it shrinks.'},
    rules_l2:{fr:'Pose le téléphone à plat sur ton ventre si tu veux un retour précis (mouvement ou micro).',en:'Lay the phone flat on your stomach if you want precise feedback (motion or microphone).'},
    rules_l3:{fr:'Vise environ 6 respirations par minute — tu peux ajuster le rythme à tout moment.',en:'Aim for about 6 breaths per minute — you can adjust the pace at any time.'},
    rules_why:{fr:'Ralentir la respiration à ce rythme active le nerf vague et le système parasympathique : le corps envoie un signal de calme au cerveau, ce qui aide à faire retomber le stress et le craving (cohérence cardiaque).',
      en:'Slowing your breathing to this rhythm activates the vagus nerve and the parasympathetic system: the body sends a calm signal to the brain, which helps stress and craving settle down (cardiac coherence).'}
  };
  function t(k, arg){ var e=T[k]; if(!e) return k; var v=L==='en'?e.en:e.fr; return (typeof v==='function') ? v(arg) : v; }

  var $ = function(id){ return document.getElementById(id); };
  function show(id){ ['scr-cal','scr-run','scr-end'].forEach(function(s){ $(s).classList.toggle('on', s===id); }); }

  /* ---------- état ---------- */
  var rateBpm = 6.0;        // cycles / minute
  var exhaleLong = false;   // 4 in / 6 out
  var motionOn = false, micOn = false;
  var running = false, startT = 0, rafId = null;
  var orb = $('orb'), phaseEl = $('phase');

  /* ---------- signal capteur (mouvement OU micro) ---------- */
  var sig = 0;              // signal respiratoire projeté (centré ~0)
  var gx=null,gy=null,gz=null;     // gravité lente (posture)
  var fx=0,fy=0,fz=0;              // composante respiration par axe (passe-bande)
  var calAxis=null, calAmp=0;      // axe principal + amplitude (calibration)
  var calibrating=false, calSamples=[], calRAF=null, calEnv=0.02;
  var buf = []; var BUF_MS = 24000;

  // Mouvement (accéléromètre + gravité)
  function onMotion(e){
    var a = e.accelerationIncludingGravity || e.acceleration; if(!a) return;
    var ax=a.x||0, ay=a.y||0, az=a.z||0;
    if(gx===null){ gx=ax; gy=ay; gz=az; }
    // gravité = passe-bas très lent (orientation/posture)
    gx=gx*0.9975+ax*0.0025; gy=gy*0.9975+ay*0.0025; gz=gz*0.9975+az*0.0025;
    // composante respiration par axe = passe-bande (oscillation lente de l'inclinaison)
    fx=fx*0.90+(ax-gx)*0.10; fy=fy*0.90+(ay-gy)*0.10; fz=fz*0.90+(az-gz)*0.10;
    if(calibrating) calSamples.push([fx,fy,fz]);
    // projection sur l'axe respiratoire calibré (sinon axe le plus probable)
    sig = calAxis ? (fx*calAxis[0]+fy*calAxis[1]+fz*calAxis[2]) : (Math.abs(fx)>Math.abs(fy)?(Math.abs(fx)>Math.abs(fz)?fx:fz):(Math.abs(fy)>Math.abs(fz)?fy:fz));
  }
  // axe principal d'oscillation (PCA, itération de puissance)
  function principalAxis(S){
    var n=S.length; if(n<10) return null;
    var mx=0,my=0,mz=0,i; for(i=0;i<n;i++){mx+=S[i][0];my+=S[i][1];mz+=S[i][2];} mx/=n;my/=n;mz/=n;
    var cxx=0,cxy=0,cxz=0,cyy=0,cyz=0,czz=0;
    for(i=0;i<n;i++){var x=S[i][0]-mx,y=S[i][1]-my,z=S[i][2]-mz;cxx+=x*x;cxy+=x*y;cxz+=x*z;cyy+=y*y;cyz+=y*z;czz+=z*z;}
    var v=[1,1,1];
    for(var it=0;it<30;it++){
      var nx=cxx*v[0]+cxy*v[1]+cxz*v[2], ny=cxy*v[0]+cyy*v[1]+cyz*v[2], nz=cxz*v[0]+cyz*v[1]+czz*v[2];
      var L=Math.sqrt(nx*nx+ny*ny+nz*nz)||1; v=[nx/L,ny/L,nz/L];
    }
    return v;
  }
  function startCalibration(){
    show('scr-cal'); calAxis=null; calAmp=0; calSamples=[]; gx=gy=gz=null; fx=fy=fz=0; sig=0; calEnv=0.02;
    enableMotion();
    var t0=performance.now(), started=false;
    cancelAnimationFrame(calRAF);
    (function loop(){
      if(motionOn){
        if(!started){ started=true; calibrating=true; t0=performance.now(); $('cal-status').textContent=t('breathe_calm'); }
        var el=performance.now()-t0;
        calEnv=Math.max(calEnv*0.997, Math.abs(sig));
        var sN=Math.max(-1,Math.min(1, sig/((calEnv*1.4)||1)));
        $('cal-orb').style.transform='scale('+(0.55+0.4*(sN*0.5+0.5)).toFixed(3)+')';
        $('cal-bar').style.width=Math.min(100, el/6000*100)+'%';
        if(el>=6000){ finishCalibration(); return; }
      } else if(performance.now()-t0>4500){
        $('cal-status').innerHTML=t('sensor_unavailable');
      }
      calRAF=requestAnimationFrame(loop);
    })();
  }
  function finishCalibration(){
    calibrating=false; cancelAnimationFrame(calRAF);
    var axis=principalAxis(calSamples);
    if(axis){
      var proj=calSamples.map(function(s){return s[0]*axis[0]+s[1]*axis[1]+s[2]*axis[2];});
      var m=proj.reduce(function(a,b){return a+b;},0)/proj.length;
      var sd=Math.sqrt(proj.reduce(function(a,b){return a+(b-m)*(b-m);},0)/proj.length);
      calAxis=axis; calAmp=sd;
    }
    startRun();
  }
  function enableMotion(){
    function attach(){ window.addEventListener('devicemotion', onMotion); motionOn=true; micOn=false; markSensors(); }
    try{
      if(typeof DeviceMotionEvent!=='undefined' && typeof DeviceMotionEvent.requestPermission==='function'){
        DeviceMotionEvent.requestPermission().then(function(p){ if(p==='granted') attach(); else sensorErr('st-motion',t('refused')); }).catch(function(){ sensorErr('st-motion',t('unavailable')); });
      } else if('ondevicemotion' in window){ attach(); }
      else sensorErr('st-motion',t('unavailable'));
    }catch(err){ sensorErr('st-motion','Indispo'); }
  }

  // Micro (enveloppe RMS)
  var audioCtx=null, analyser=null, micData=null, micStream=null, micRAF=null;
  function enableMic(){
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){ sensorErr('st-mic',t('unavailable')); return; }
    navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false}}).then(function(stream){
      micStream=stream; audioCtx=new (window.AudioContext||window.webkitAudioContext)();
      var src=audioCtx.createMediaStreamSource(stream); analyser=audioCtx.createAnalyser(); analyser.fftSize=1024;
      micData=new Uint8Array(analyser.fftSize); src.connect(analyser);
      micOn=true; motionOn=false; window.removeEventListener('devicemotion', onMotion);
      markSensors();
      (function loop(){ analyser.getByteTimeDomainData(micData); var s=0;
        for(var i=0;i<micData.length;i++){ var d=(micData[i]-128)/128; s+=d*d; }
        var rms=Math.sqrt(s/micData.length);
        sig = sig*0.8 + (rms-0.04)*0.2*6;            // enveloppe centrée, amplifiée
        micRAF=requestAnimationFrame(loop);
      })();
    }).catch(function(){ sensorErr('st-mic',t('refused')); });
  }
  function sensorErr(id,txt){ var el=$(id); if(el) el.textContent=txt; }
  function markSensors(){
    $('sb-motion').classList.toggle('ok', motionOn); $('st-motion').textContent = motionOn?t('active'):t('activate');
    $('sb-mic').classList.toggle('ok', micOn); $('st-mic').textContent = micOn?t('active'):t('activate');
    if(typeof updateRunSensor==='function') updateRunSensor();
  }

  /* ---------- pacer (rythme guidé) ---------- */
  function cycleSec(){ return 60/rateBpm; }
  function inFrac(){ return exhaleLong ? 0.4 : 0.5; }   // part d'inspiration
  function ease(x){ return 0.5-0.5*Math.cos(Math.PI*Math.min(1,Math.max(0,x))); }
  // renvoie {scale 0..1, label, target -1..1}
  function pacer(elapsedSec){
    var P=cycleSec(), tt=elapsedSec % P, inDur=P*inFrac(), label, k;
    if(tt<inDur){ k=ease(tt/inDur); label=t('breathe_in'); }
    else { k=1-ease((tt-inDur)/(P-inDur)); label=t('breathe_out'); }
    return { scale:0.55+0.45*k, label:label, target:(k*2-1) };
  }

  /* ---------- estimation du rythme (pics du signal) ---------- */
  function estimateRate(){
    if(buf.length<20) return null;
    var now=buf[buf.length-1].t, vs=buf.filter(function(p){return now-p.t<=BUF_MS;});
    if(vs.length<20) return null;
    var vals=vs.map(function(p){return p.v;});
    var mn=Math.min.apply(null,vals), mx=Math.max.apply(null,vals); if(mx-mn<1e-3) return null;
    var thr=(mn+mx)/2, peaks=[], above=false;
    for(var i=0;i<vs.length;i++){ var v=vs[i].v;
      if(!above && v>thr){ above=true; peaks.push(vs[i].t); }
      else if(above && v<thr){ above=false; }
    }
    if(peaks.length<2) return null;
    var span=(peaks[peaks.length-1]-peaks[0])/1000, n=peaks.length-1;
    if(span<=0) return null;
    var rate=n/span*60; if(rate<2||rate>30) return null;
    return rate;
  }

  /* ---------- boucle d'animation ---------- */
  var trace=$('trace'), tctx=trace.getContext('2d'), DPR=Math.min(2,window.devicePixelRatio||1);
  function sizeCanvas(){ var w=trace.clientWidth||528; trace.width=w*DPR; trace.height=96*DPR; tctx.setTransform(DPR,0,0,DPR,0,0); }
  function drawTrace(){
    var W=trace.clientWidth||528, H=96, now=performance.now();
    tctx.clearRect(0,0,W,H);
    var pts=buf.filter(function(p){return now-p.t<=BUF_MS;});
    // rythme guidé (référence) — sinusoïde au rythme courant
    tctx.strokeStyle=getComputedStyle(document.body).getPropertyValue('--ink-2')||'#58635E';
    tctx.globalAlpha=.45; tctx.lineWidth=2; tctx.beginPath();
    for(var x=0;x<=W;x+=4){ var tsec=(now-(W-x)/W*BUF_MS)/1000; var p=pacer(tsec-startSec()); var y=H/2 - p.target*(H*0.36);
      if(x===0) tctx.moveTo(x,y); else tctx.lineTo(x,y); }
    tctx.stroke(); tctx.globalAlpha=1;
    // signal capteur (normalisé)
    if(pts.length>3){
      var vals=pts.map(function(p){return p.v;}), mn=Math.min.apply(null,vals), mx=Math.max.apply(null,vals), rg=(mx-mn)||1;
      tctx.strokeStyle=getComputedStyle(document.body).getPropertyValue('--c')||'#D5A84A';
      tctx.lineWidth=2.5; tctx.beginPath();
      for(var i=0;i<pts.length;i++){ var px=(now-pts[i].t)/BUF_MS; var X=W-px*W; var norm=(pts[i].v-mn)/rg; var Y=H-8-norm*(H-16);
        if(i===0) tctx.moveTo(X,Y); else tctx.lineTo(X,Y); }
      tctx.stroke();
    } else {
      tctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--ink-2'); tctx.globalAlpha=.6;
      tctx.font='12px Inter, sans-serif'; tctx.textAlign='center';
      tctx.fillText(motionOn||micOn?t('sensing_breath'):t('activate_sensor_curve'), W/2, H/2+4);
      tctx.globalAlpha=1;
    }
  }
  var _startMs=0; function startSec(){ return _startMs/1000; }

  var lastRateUpd=0;
  function frame(){
    if(!running) return;
    var now=performance.now(), elapsed=(now-startT)/1000;
    if(durGoal>0 && elapsed>=durGoal){ stop(); return; }
    var p=pacer(elapsed);
    phaseEl.textContent=p.label;
    // Orbe = rythme à suivre : gonfle à l'inspiration, dégonfle à l'expiration.
    // Anneau-guide = cible « inspiration pleine », statique : l'orbe vient la remplir.
    var orbScale = 0.58 + 0.52*((p.scale-0.55)/0.45);   // ~0.58 (expire) -> ~1.10 (inspire)
    orb.style.transform='scale('+orbScale.toFixed(3)+')';
    // Couleur : bleu (fjord) à l'inspiration -> rouge (terra) à l'expiration
    var warm = Math.max(0, Math.min(1, (1.0 - p.scale)/0.45));
    var cr=Math.round(105+(199-105)*warm), cg=Math.round(136+(118-136)*warm), cb=Math.round(154+(92-154)*warm);
    orb.style.background='radial-gradient(circle at 38% 32%, rgba(255,255,255,.55), rgb('+cr+','+cg+','+cb+') 80%)';
    var g=$('guide'); if(g) g.style.transform='scale(1.10)';
    // n° de cycle
    $('cyc').textContent=t('cycle')+(Math.floor(elapsed/cycleSec())+1);
    // historique signal (si capteur) — alimente la courbe + l'estimation du rythme
    if(motionOn||micOn){ buf.push({t:now, v:sig}); var cut=now-BUF_MS; while(buf.length&&buf[0].t<cut) buf.shift(); }
    drawTrace();
    // métriques (1×/s)
    if(now-lastRateUpd>1000){
      lastRateUpd=now;
      var mm=Math.floor(elapsed/60), ss=Math.floor(elapsed%60);
      $('m-time').textContent=mm+':'+(ss<10?'0':'')+ss;
      var r=estimateRate();
      if(r){ $('m-rate').textContent=r.toFixed(1).replace('.',',')+'/min';
        var diff=r-rateBpm;
        $('hint').textContent = Math.abs(diff)<0.8 ? t('nicely_synced') : (diff>0 ? t('slow_down') : t('breathe_freer'));
        rateSamples.push(r);
      } else if(!(motionOn||micOn)){ $('m-rate').textContent='—'; }
    }
    rafId=requestAnimationFrame(frame);
  }

  /* ---------- contrôles ---------- */
  function fmtPace(){ var P=cycleSec(), inS=(P*inFrac()), outS=P-inS;
    $('p-val').textContent=rateBpm.toFixed(1).replace('.',',')+' / min · '+Math.round(inS)+'\u2013'+Math.round(outS)+' s'; }
  function setRate(r){ rateBpm=Math.min(7,Math.max(4.5,Math.round(r*2)/2)); fmtPace(); }

  var rateSamples=[]; var durGoal=180;
  function updateRunSensor(){
    var el=$('run-sensor'); if(!el) return;
    if(motionOn) el.innerHTML='<b style="color:var(--ok)">'+t('motion_active')+'</b>'+t('motion_active_sub');
    else if(micOn) el.innerHTML='<b style="color:var(--ok)">'+t('mic_active')+'</b>'+t('mic_active_sub');
    else el.innerHTML=t('no_sensor');
  }
  function startRun(){
    show('scr-run'); updateRunSensor(); sizeCanvas(); fmtPace();
    phaseEl.textContent=t('ready'); if(orb) orb.style.transform='scale(0.58)';
    var b=$('btn-go'); if(b) b.style.display='';
  }
  function beginRun(){
    var b=$('btn-go'); if(b) b.style.display='none';
    running=true; startT=performance.now(); _startMs=startT; buf=[]; rateSamples=[]; lastRateUpd=0;
    rafId=requestAnimationFrame(frame);
  }
  function start(){
    // "Commencer" : calibration capteur si possible (geste utilisateur OK), sinon run direct
    if(!micOn && (typeof DeviceMotionEvent!=='undefined' || ('ondevicemotion' in window))){ startCalibration(); }
    else startRun();
  }
  function logSession(rec){
    try{ var k='ctc_v6', d=JSON.parse(localStorage.getItem(k)||'{}');
      d.sessions=Array.isArray(d.sessions)?d.sessions:[]; d.sessions.push(rec);
      localStorage.setItem(k,JSON.stringify(d));
      return d.sessions.filter(function(x){return x.type===rec.type;}).length;
    }catch(e){ return 1; }
  }
  function drawEndGraph(){
    var cv=$('e-graph'); if(!cv) return; var ctx=cv.getContext('2d');
    var W=cv.clientWidth||528, H=120, DPR=Math.min(2,window.devicePixelRatio||1);
    cv.width=W*DPR; cv.height=H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H);
    var cs=getComputedStyle(document.body);
    if(!rateSamples.length){ ctx.fillStyle=cs.getPropertyValue('--ink-2'); ctx.globalAlpha=.6; ctx.font='12px Inter,sans-serif'; ctx.textAlign='center'; ctx.fillText(t('no_curve'), W/2, H/2); ctx.globalAlpha=1; return; }
    var lo=Math.min(rateBpm-2, Math.min.apply(null,rateSamples))-0.5, hi=Math.max(rateBpm+2, Math.max.apply(null,rateSamples))+0.5, rg=(hi-lo)||1;
    function Y(v){ return H-10-((v-lo)/rg)*(H-20); }
    ctx.strokeStyle=cs.getPropertyValue('--ink-2'); ctx.globalAlpha=.45; ctx.setLineDash([5,4]); ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.moveTo(0,Y(rateBpm)); ctx.lineTo(W,Y(rateBpm)); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha=1;
    ctx.strokeStyle=cs.getPropertyValue('--c')||'#C7765C'; ctx.lineWidth=2.5; ctx.beginPath();
    rateSamples.forEach(function(r,i){ var X=rateSamples.length>1? i/(rateSamples.length-1)*W : W/2; var y=Y(r); if(i===0)ctx.moveTo(X,y); else ctx.lineTo(X,y); });
    ctx.stroke();
  }
  function stop(){
    running=false; if(rafId) cancelAnimationFrame(rafId);
    var elapsed=(performance.now()-startT)/1000, mm=Math.floor(elapsed/60), ss=Math.floor(elapsed%60);
    $('e-time').textContent=mm+':'+(ss<10?'0':'')+ss;
    var avg = rateSamples.length ? (rateSamples.reduce(function(a,b){return a+b;},0)/rateSamples.length) : null;
    $('e-rate').textContent = avg ? avg.toFixed(1).replace('.',',')+'/min' : '—';
    var coh=null; if(rateSamples.length){ var inb=rateSamples.filter(function(r){return Math.abs(r-rateBpm)<=1;}).length; coh=Math.round(inb/rateSamples.length*100); }
    $('e-coh').textContent = coh!=null ? coh+' %' : '—';
    $('end-explain').textContent = (avg==null)
      ? t('no_curve_end')
      : (coh>=60 ? t('coherent') : t('training_slow'));
    $('end-msg').textContent = elapsed>=180 ? t('three_min') : (elapsed>=60 ? t('good_moment') : t('even_short'));
    var total=(window.MDData?MDData.countSessions('breathe')+1:1);
    $('e-total').textContent = total>1 ? t('sessions_total',total) : t('first_session');
    show('scr-end'); drawEndGraph();
    if(window.MDExercise){ MDExercise.after('breathe',{avant:window.__mdAvant, dureeSec:Math.round(elapsed), meta:{avg:(avg?Math.round(avg*10)/10:null),coherence:coh},
      title:t('title'), stats:[{label:t('stat_duration'),value:$('e-time').textContent},{label:t('stat_avg_rate'),value:$('e-rate').textContent},{label:t('stat_coherence'),value:$('e-coh').textContent}],
      nav:{ primary:{label:t('restart')}, secondary:{label:t('back_labo'), onClick:function(){ location.href=(window.LUCIDE?LUCIDE.link('fiches.html'):'fiches.html'); }} },
      onClose:function(){ window.__mdAvant=null; begin(); }}); }
    else if(window.MDData){ MDData.logSession('breathe',{dureeSec:Math.round(elapsed),meta:{avg:(avg?Math.round(avg*10)/10:null),coherence:coh}}); }
  }

  /* ---------- liaisons ---------- */
  var SENSOR_DURATION_HTML =
    '<p class="seclabel">'+t('sensor_optional')+'</p>' +
    '<div class="sensors">' +
      '<button type="button" class="sensor-btn" id="sb-motion">' +
        '<span class="em">\ud83d\udcc8</span><span><b>'+t('belly_motion')+'</b><br><span class="muted" style="font-size:var(--fs-xs)">'+t('belly_motion_sub')+'</span></span><span class="st" id="st-motion">'+t('activate')+'</span>' +
      '</button>' +
      '<button type="button" class="sensor-btn" id="sb-mic">' +
        '<span class="em">\ud83c\udf99\ufe0f</span><span><b>'+t('mic_breath')+'</b><br><span class="muted" style="font-size:var(--fs-xs)">'+t('mic_breath_sub')+'</span></span><span class="st" id="st-mic">'+t('activate')+'</span>' +
      '</button>' +
    '</div>' +
    '<p class="muted" style="font-size:var(--fs-xs);margin:0 0 16px">'+t('no_sensor_note')+'</p>' +
    '<p class="seclabel">'+t('session_length')+'</p>' +
    '<div class="seg2" id="dur-seg" style="margin-bottom:16px">' +
      '<button type="button" data-dur="60">1 min</button>' +
      '<button type="button" class="on" data-dur="180">3 min</button>' +
      '<button type="button" data-dur="300">5 min</button>' +
      '<button type="button" data-dur="0">'+t('free')+'</button>' +
    '</div>';
  function begin(){
    if(window.MDJeuHero){
      MDJeuHero.rules({mood:'respiration',title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        extraHTML: SENSOR_DURATION_HTML,
        onRender: function(card){
          card.querySelector('#sb-motion').addEventListener('click', enableMotion);
          card.querySelector('#sb-mic').addEventListener('click', enableMic);
          var seg = card.querySelector('#dur-seg');
          if (seg) seg.addEventListener('click', function(e){ var b=e.target.closest('button'); if(!b) return; durGoal=parseInt(b.getAttribute('data-dur'))||0; Array.prototype.forEach.call(seg.querySelectorAll('button'),function(c){ c.classList.toggle('on', c===b); }); });
          markSensors(); // resynchronise l'état visuel des capteurs si déjà activés lors d'un tour précédent
        },
        onStart:function(avant){ window.__mdAvant=avant; start(); }});
    } else { start(); }
  }
  $('btn-go').addEventListener('click', beginRun);
  (function(){ var b=$('cal-skip'); if(b) b.addEventListener('click', function(){ calibrating=false; cancelAnimationFrame(calRAF); calAxis=null; calAmp=0; startRun(); }); })();
  $('btn-stop').addEventListener('click', stop);
  begin();

  $('p-up').addEventListener('click', function(){ setRate(rateBpm+0.5); });
  $('p-down').addEventListener('click', function(){ setRate(rateBpm-0.5); });
  $('btn-exhale').addEventListener('click', function(){ exhaleLong=!exhaleLong; this.classList.toggle('btn-primary',exhaleLong); this.classList.toggle('btn-outline',!exhaleLong); fmtPace(); });
  document.querySelectorAll('[data-back]').forEach(function(b){ b.addEventListener('click', function(e){ e.preventDefault(); if(history.length>1) history.back(); else location.href='index.html'; }); });
  window.addEventListener('resize', function(){ if(running) sizeCanvas(); });
  window.addEventListener('pagehide', function(){ if(micStream){ micStream.getTracks().forEach(function(t){t.stop();}); } });

  fmtPace();
})();
