/* MyDope Off — page-publics.js
   Dossier « Quand les conseils habituels ne collent pas ». MDCore.init() suffit
   (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'situations', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
