/* MyDope Off — tools/sitemap.js
   ============================================================================
   Régénère sitemap.xml et robots.txt. À relancer après tout ajout de page.

       node tools/sitemap.js https://mon-domaine.example

   Sans argument, reprend l'URL déjà inscrite dans robots.txt. L'adresse n'est écrite
   qu'à un seul endroit du dépôt : ici, à l'exécution. Le site lui-même n'utilise que
   des chemins relatifs — c'est ce qui lui permet de fonctionner hors ligne et depuis
   n'importe quel domaine.

   Ce dossier `tools/` ne fait pas partie du site livré : ni chargé, ni précaché.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const RACINE = path.join(__dirname, '..');

/* Pages exclues de l'indexation. `admin` et `profil` donnent accès aux données locales
   de la personne, `inscription` n'a aucun sens comme résultat de recherche. */
const EXCLU = new Set(['inscription.html', 'admin.html', 'profil.html']);
const PRIO = { 'index.html': '1.0', 'rdr.html': '0.9', 'alertes.html': '0.9',
               'fiches.html': '0.8', 'guide.html': '0.8' };

function baseActuelle() {
  try {
    const r = fs.readFileSync(path.join(RACINE, 'robots.txt'), 'utf8');
    const m = r.match(/Sitemap:\s*(\S+)\/sitemap\.xml/);
    if (m) return m[1];
  } catch (e) {}
  return 'https://EXEMPLE-A-REMPLACER.github.io';
}

const base = (process.argv[2] || baseActuelle()).replace(/\/+$/, '');
const today = new Date().toISOString().slice(0, 10);

const pages = fs.readdirSync(RACINE)
  .filter(f => f.endsWith('.html') && !EXCLU.has(f))
  .sort();

const urls = pages.map(p => {
  const loc = base + '/' + (p === 'index.html' ? '' : p);
  return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${today}</lastmod>\n` +
         `    <priority>${PRIO[p] || '0.6'}</priority>\n  </url>`;
}).join('\n');

fs.writeFileSync(path.join(RACINE, 'sitemap.xml'),
  `<?xml version="1.0" encoding="UTF-8"?>\n` +
  `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`);

fs.writeFileSync(path.join(RACINE, 'robots.txt'),
`# MyDope Off — robots.txt
# Site d'information et de réduction des risques. Contenu sanitaire, éditeur identifié
# (voir /mentions-legales.html), sources et date de vérification sur chaque dossier.
#
# Trois pages sont exclues : elles n'ont aucun sens comme résultat de recherche, et deux
# d'entre elles donnent accès aux données locales de la personne.

User-agent: *
Allow: /
Disallow: /inscription.html
Disallow: /admin.html
Disallow: /profil.html
Disallow: /tools/

Sitemap: ${base}/sitemap.xml
`);

console.log(`sitemap.xml : ${pages.length} pages · base ${base}`);
if (base.includes('EXEMPLE-A-REMPLACER')) {
  console.log('⚠  Domaine non renseigné. Relance avec : node tools/sitemap.js https://ton-domaine');
}
