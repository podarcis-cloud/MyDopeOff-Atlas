/* MyDope Off — tools/audit-lacunes.js
   ============================================================================
   Mesure la couverture des termes de l'audit dans le code réel.

       node tools/audit-lacunes.js

   POURQUOI CET OUTIL EXISTE
   Deux fois dans la même session, un `grep` naïf a déclaré manquant un contenu qui était
   présent : le produit écrit « bouchons d'oreilles » avec une apostrophe typographique (’),
   l'audit cherche l'apostrophe droite ('). Un contenu que la mesure ne voit pas sera
   redéclaré manquant à la prochaine session, et réécrit pour rien.

   Ce script normalise les apostrophes et les accents avant de comparer. Il est la
   référence : aucun constat de manque ne devrait être écrit sans l'avoir lancé.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const RACINE = path.join(__dirname, '..');

const TERMES = [
  'chemsex', 'grossesse', 'enceinte', 'contraception', 'préservatif', 'pilule du lendemain',
  'consentement', 'PAWS', 'syndrome prolongé', 'risques auditifs', "bouchons d'oreilles",
  'sortie de prison', 'tolérance', 'naloxone', 'LGBT', 'travail du sexe', 'précarité',
  'sans-abri', 'senior', 'femme', 'falsifié', 'vendu comme', 'trip sitter', 'checklist',
  'électrolytes', 'capital nasal', 'plan de sécurité', 'violence symbolique',
  'savoir expérientiel', 'quantité moindre', 'eau par le nez', 'changer le point d\'injection'
];

function norm(t) {
  return t.replace(/[\u2018\u2019\u02BC]/g, "'")
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
          .toLowerCase();
}

const fichiers = fs.readdirSync(RACINE)
  .filter(f => /\.(js|html)$/.test(f))
  .map(f => ({ nom: f, texte: norm(fs.readFileSync(path.join(RACINE, f), 'utf8')) }));

let absents = 0;
console.log('Couverture des termes de l\'audit — ' + fichiers.length + ' fichiers\n');
for (const t of TERMES) {
  const n = fichiers.filter(f => f.texte.includes(norm(t))).length;
  if (n === 0) absents++;
  console.log(String(n).padStart(4) + '  ' + (n === 0 ? '✗' : '·') + '  ' + t);
}
console.log('\n' + absents + ' terme(s) à 0.');
