/* MyDope Off — tools/lisibilite.js
   ============================================================================
   Classe les phrases par difficulté de lecture. À lancer après toute rédaction.

       node tools/lisibilite.js [nombre]

   POURQUOI
   Simon, développeur du produit, a signalé avoir « du mal à comprendre où je veux en
   venir sur beaucoup de phrases ». L'exemple qui a déclenché la remarque : « Toi plus
   tard connaîtra tout ce que tu connais aujourd'hui » — un groupe nominal bancal en
   position sujet, fabriqué pour éviter une répétition, au prix du lecteur.

   Si le développeur bute, quelqu'un qui ouvre le produit à 3 h du matin ne lira pas.

   CE QUE MESURE L'INDICE
   Ce qui oblige concrètement à relire : longueur au-delà de vingt mots · virgules ·
   incises entre tirets · parenthèses · relatives empilées · subordonnées lourdes
   (« alors que », « précisément parce que »). Ce n'est pas une mesure savante, c'est un
   compteur d'obstacles.

   COMMENT S'EN SERVIR
   Regarder les vingt premières et réécrire celles qui demandent deux lectures. Les
   listes de sources et les énumérations légitimes montent haut sans être fautives :
   l'outil signale, il ne juge pas.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const RACINE = path.join(__dirname, '..');

/* Dictionnaires et tables de données : ce ne sont pas des phrases lues d'affilée. */
const EXCLU = /i18n-phrases|anecdotes|rdr-i18n|interactions|detection-|substance-names|protocols|-data\.js/;

function visible(s) {
  return s.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<!--[\s\S]*?-->|\/\*[\s\S]*?\*\//g, '')
          .replace(/<[^>]+>/g, ' ');
}

function difficulte(p) {
  const mots = p.split(/\s+/);
  let d = Math.max(0, mots.length - 20) * 0.7;
  d += (p.match(/,/g) || []).length * 1.2;
  d += (p.match(/—/g) || []).length * 1.4;
  d += (p.match(/:/g) || []).length * 0.8;
  d += (p.match(/\(/g) || []).length * 1.5;
  d += (p.match(/\b(qui|que|dont|ce que|ce qui|lequel|laquelle)\b/gi) || []).length * 1.4;
  d += (p.match(/\b(alors que|tandis que|bien que|sans que|de sorte que|au point que|précisément parce que)\b/gi) || []).length * 2.5;
  return d;
}

const out = [];
for (const f of fs.readdirSync(RACINE)) {
  if (!/\.(html|js)$/.test(f) || EXCLU.test(f)) continue;
  let t = visible(fs.readFileSync(path.join(RACINE, f), 'utf8'))
    .replace(/[\u2018\u2019]/g, "'").replace(/\\u2019/g, "'").replace(/\\u2014/g, '—')
    .replace(/\\u[0-9a-f]{4}/g, '').replace(/\s+/g, ' ');
  for (const p of t.split(/(?<=[.!?])\s+/)) {
    const q = p.trim();
    if (q.length < 45 || q.length > 400) continue;
    if (q.split(/\s+/).length < 10) continue;
    if (/[{}<>=\[\]|]|http|_|Sources ?:|·.*·/.test(q)) continue;
    out.push({ f, q, d: difficulte(q) });
  }
}
out.sort((a, b) => b.d - a.d);

const n = parseInt(process.argv[2], 10) || 15;
console.log(`${out.length} phrases · pire indice ${out[0].d.toFixed(1)} · moyenne des 20 pires ${(out.slice(0,20).reduce((a,x)=>a+x.d,0)/20).toFixed(1)}\n`);
for (const x of out.slice(0, n)) {
  console.log(`[${x.d.toFixed(1).padStart(5)}] ${x.f}`);
  console.log(`        ${x.q.slice(0, 190)}\n`);
}
