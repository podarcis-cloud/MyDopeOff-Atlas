/* MyDope Off — tools/veille-molecules.js
   ============================================================================
   Vérifie quelles molécules connues sont absentes du produit.
   À lancer EN DÉBUT DE SESSION, avec la captation d'alertes.

       node tools/veille-molecules.js

   POURQUOI
   L'agence européenne enregistre **environ une nouvelle substance par semaine** et en
   surveille plus de mille. Un produit d'information sur les drogues vieillit donc en
   continu, sans que rien ne le signale : une fiche reste lisible et juste sur ce qu'elle
   dit, tout en ayant cessé de couvrir ce qui circule.

   Ce script ne remplace pas la recherche — il dit seulement ce qui manque parmi ce qu'on
   sait déjà exister. **La liste ci-dessous doit être enrichie à chaque veille**, à partir
   des sources du chapitre 44 : EUDA (rapport annuel + système d'alerte précoce), OFDT /
   SINTES, ANSM (classements stupéfiants), checkit!, Saferparty, DIMS.

   CE QUE LE SCRIPT NE PEUT PAS FAIRE
   Repérer une molécule que personne n'a encore nommée. C'est pourquoi le vrai travail
   reste la lecture des sources, et pourquoi le dossier cannabis explique désormais le
   **mécanisme** de remplacement plutôt que de courir après une liste qui périme.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const RACINE = path.join(__dirname, '..');

/* Dernière mise à jour de cette liste : 17/08/2026. */
const FAMILLES = {
  'Opioïdes de synthèse': [
    'fentanyl', 'carfentanil', 'nitazène', 'métonitazène', 'isotonitazène', 'protonitazène',
    'étonitazène', 'fluonitazène', 'brorphine', 'orphine', 'cychlorphine', 'spirochlorphine',
    'xylazine', 'médétomidine', 'oxycodone', 'tramadol'
  ],
  'Cathinones': [
    '3-MMC', '4-MMC', '3-CMC', '4-CMC', '2-MMC', 'α-PHP', 'α-PHiP', 'N-éthylpentédrone',
    'eutylone', 'méphédrone', 'MDPV', 'pentédrone'
  ],
  'Cannabinoïdes semi-synthétiques': [
    'HHC', 'HHC-O', 'HHC-P', 'HHCPO', '10-OH-HHC', 'THCP', 'THCB', 'THCH', 'THCJD',
    'H4CBD', 'H2CBD', 'delta-8', 'delta-10', 'THCA', 'THCV'
  ],
  'Cannabinoïdes de synthèse': [
    'MDMB-INACA', 'ADB-4en-PINACA', 'MDMB-4en-PINACA', '5F-MDMB-PINACA', 'ADB-BUTINACA',
    'MDMB-BUTINACA', 'EDMB-4en-PINACA', '4-F-MDMB-BUTINACA', '5F-Cumyl-Pegaclone', '7APAICA'
  ],
  'Psychédéliques et dissociatifs': [
    '2C-B', '2C-I', 'DOC', '25I-NBOMe', '1T-LSD', '1cP-LSD', '1V-LSD', 'ALD-52',
    '4-AcO-DMT', '4-HO-MET', '4-AcO-MET', 'DMT', '5-MeO-DMT', 'deschloroketamine',
    '2-FDCK', 'méthoxétamine', 'O-PCE'
  ],
  'Benzodiazépines de synthèse': [
    'étizolam', 'flualprazolam', 'bromazolam', 'clonazolam', 'flubromazolam',
    'désalkylflurazépam', 'phénazépam'
  ],
  'Autres': [
    'tusi', 'GHB', 'GBL', '1,4-BD', 'kratom', 'mitragynine', 'tianeptine', 'protoxyde',
    'PMMA', 'PMA', 'lévamisole', 'phénacétine', 'procaïne', 'fénéthylline'
  ]
};

function norm(t) {
  return t.replace(/[\u2018\u2019]/g, "'")
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
          .toLowerCase();
}

let corpus = '';
for (const f of fs.readdirSync(RACINE)) {
  if (/\.(js|html)$/.test(f)) corpus += fs.readFileSync(path.join(RACINE, f), 'utf8');
}
corpus = norm(corpus);

let total = 0, absents = 0;
for (const [famille, liste] of Object.entries(FAMILLES)) {
  const manque = liste.filter(m => !corpus.includes(norm(m)));
  total += liste.length; absents += manque.length;
  const etat = manque.length ? '  ✗ absent : ' + manque.join(' · ') : '  ✓ complet';
  console.log(`${famille} (${liste.length - manque.length}/${liste.length})\n${etat}\n`);
}
console.log(`${total - absents}/${total} molécules couvertes · ${absents} absente(s).`);
/* Exclusions décidées, avec leur motif. Les rappeler évite qu'une session future les
   rajoute par réflexe — et évite de retrancher ce qui l'a été à raison. */
const EXCLUES = {
  'MDMB-BUTINACA, EDMB-4en-PINACA, 4-F-MDMB-BUTINACA, 5F-Cumyl-Pegaclone, 7APAICA':
    'Cannabinoïdes de synthèse nommés individuellement. La fiche cannabis explique désormais\n'
  + '    le MÉCANISME de remplacement plutôt que de courir après une liste : 209 molécules\n'
  + '    détectées depuis 2008, une nouvelle par semaine. Les citer une à une contredirait\n'
  + '    ce choix éditorial et périmerait en trois mois.',
  'fénéthylline (captagon)':
    'Quasi absente du marché européen ; concentrée au Moyen-Orient. Le produit couvre\n'
  + '    l\'Europe et l\'Afrique francophone.',
  'fluonitazène':
    'La famille des nitazènes est traitée comme telle dans la fiche opioïdes et dans trois\n'
  + '    alertes. Nommer chaque variante n\'ajoute rien au geste, qui est identique.'
};
console.log('\nExclusions décidées (ne pas rajouter sans raison nouvelle) :');
for (const [m, motif] of Object.entries(EXCLUES)) console.log('  · ' + m + '\n    ' + motif);
console.log('\nRappel : une absence n\'est pas toujours une lacune. Trancher au cas par cas.');
