/* MyDope Off — tools/verif-alertes.js
   ============================================================================
   Contrôle d'intégrité du système d'alerte. À lancer AVANT toute livraison.

       node tools/verif-alertes.js

   L'INCIDENT QUI A MOTIVÉ CET OUTIL (12/08/2026)
   Un renommage de champ (`annonce` → `annonce_fr`) a laissé dans `alertes.js` une
   condition testant l'ancien nom. Résultat : **les dix alertes ont cessé de s'afficher**,
   sur la page dédiée comme dans les encarts de fiche. Aucune erreur console, aucun
   symptôme visible dans le code — la page se chargeait normalement, simplement vide.

   C'est le pire mode de panne possible pour ce dispositif : le système de sécurité du
   produit peut tomber sans que rien ne le dise. Quelqu'un qui cherche « est-ce que ce
   que j'ai acheté est signalé » verrait « aucune alerte » et en conclurait qu'il n'y a
   rien à signaler.

   CE QUE CE SCRIPT VÉRIFIE
   1. Chaque alerte porte tous les champs obligatoires du chapitre 44.
   2. Les noms de champs lus par `alertes.js` existent réellement dans `alertes-data.js`.
      C'est ce contrôle-là qui aurait attrapé l'incident.
   3. Au moins une alerte est encore valide à la date du jour.
   4. Les identifiants sont uniques et les dates cohérentes.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const RACINE = path.join(__dirname, '..');

const REQUIS = ['id', 'date', 'perime_le', 'gravite', 'regions', 'titre_fr', 'titre_en',
                'corps_fr', 'corps_en', 'geste_fr', 'geste_en', 'source_nom', 'source_url'];
const GRAVITES = ['critique', 'eleve', 'information'];

function charger(fichier, cle) {
  const sb = { window: {} };
  sb.window = sb;
  vm.createContext(sb);
  vm.runInContext(fs.readFileSync(path.join(RACINE, fichier), 'utf8'), sb);
  return sb[cle];
}

const alertes = charger('alertes-data.js', 'MD_ALERTES') || [];
/* `alertes.js` sert AUSSI les actualités et le répertoire : un champ lu peut appartenir
   à l'un de ces jeux sans figurer dans les alertes. On vérifie donc contre les trois. */
const actus = charger('actus-data.js', 'MD_ACTUS') || [];
const annuaire = charger('annuaire-data.js', 'MD_ANNUAIRE') || [];
const moteur = fs.readFileSync(path.join(RACINE, 'alertes.js'), 'utf8');
const today = new Date().toISOString().slice(0, 10);

let erreurs = 0;
const dire = m => { console.log('  ✗ ' + m); erreurs++; };

/* --- 1. champs obligatoires --- */
const vus = new Set();
for (const a of alertes) {
  const id = a.id || '(sans id)';
  for (const k of REQUIS) {
    if (k === 'regions') { if (!(k in a)) dire(id + ' : champ `regions` absent (mettre null pour « partout »)'); continue; }
    if (!a[k]) dire(id + ' : champ `' + k + '` manquant ou vide');
  }
  if (a.gravite && GRAVITES.indexOf(a.gravite) === -1) dire(id + ' : gravité inconnue « ' + a.gravite + ' »');
  if (a.format === 'vendu_comme' && (!a.annonce_fr || !a.reel_fr || !a.annonce_en || !a.reel_en))
    dire(id + ' : format `vendu_comme` sans annonce_fr/en ou reel_fr/en');
  if (a.date && a.perime_le && a.perime_le <= a.date) dire(id + ' : péremption antérieure à la date du signalement');
  if (vus.has(a.id)) dire('identifiant en double : ' + a.id);
  vus.add(a.id);
}

/* --- 2. LE CONTRÔLE QUI AURAIT ATTRAPÉ L'INCIDENT ---
   Tout champ lu par le moteur doit exister sur au moins une alerte. Un renommage
   incomplet laisse une lecture orpheline, et le rendu tombe en silence. */
const lus = new Set();
const re = /\ba\.([a-z_]+[a-z0-9_]*)\b/g;
let m;
while ((m = re.exec(moteur)) !== null) lus.add(m[1]);
/* Les champs composés (titre_fr / titre_en) ne sont lus QUE via L(a, 'titre').
   Un accès direct `a.titre` serait justement le bug : il renvoie undefined en silence.
   On vérifie donc que ces bases n'apparaissent jamais en accès direct dans le moteur —
   c'est le contrôle qui aurait attrapé l'incident du 12/08/2026. */
const COMPOSES = ['titre', 'corps', 'geste', 'change', 'position', 'note', 'annonce', 'reel'];
for (const base of COMPOSES) {
  const direct = new RegExp('\\ba\\.' + base + '\\b(?!_)', 'g');
  const n = (moteur.match(direct) || []).length;
  if (n) dire('`alertes.js` accède directement à `a.' + base + '` (' + n + ' fois) : ce champ '
            + 'n\'existe qu\'en ' + base + '_fr / ' + base + '_en. L\'accès direct renvoie '
            + 'undefined et vide le rendu sans erreur. Utiliser L(a, \'' + base + '\').');
}
for (const champ of lus) {
  if (COMPOSES.indexOf(champ) !== -1) continue;
  const existe = alertes.some(a => champ in a)
             || actus.some(a => champ in a)
             || annuaire.some(a => champ in a);
  if (!existe) dire('`alertes.js` lit `a.' + champ + '`, absent des trois jeux de données — rendu silencieusement vide');
}

/* --- 3. actualités : `change` obligatoire, trois sources minimum (ch. 44) --- */
for (const a of actus) {
  const id = a.id || '(sans id)';
  for (const k of ['date', 'perime_le', 'titre_fr', 'titre_en', 'corps_fr', 'corps_en', 'change_fr', 'change_en']) {
    if (!a[k]) dire('actu ' + id + ' : champ `' + k + '` manquant');
  }
  if (!Array.isArray(a.sources) || a.sources.length < 3)
    dire('actu ' + id + ' : moins de trois sources (protocole renforcé pour les actualités politiques)');
}

/* --- 4. au moins une alerte vivante --- */
const vivantes = alertes.filter(a => a.perime_le > today);
if (!alertes.length) dire('aucune alerte dans le fichier');
else if (!vivantes.length) console.log('  ⚠ toutes les alertes sont périmées — la page affichera son message d\'absence');

console.log(`\n${alertes.length} alerte(s) · ${vivantes.length} valide(s) au ${today} · ${erreurs} erreur(s)`);
process.exit(erreurs ? 1 : 0);
