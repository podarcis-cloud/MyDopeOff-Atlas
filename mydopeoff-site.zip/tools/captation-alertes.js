/* MyDope Off — tools/captation-alertes.js
   ============================================================================
   Moulinette de captation, exécutée HORS LIGNE, sur la machine de l'éditeur, jamais
   depuis l'appareil de la personne (44_CAPTATION_DONNEES_OUVERTES.md).

   Ce dossier `tools/` ne fait pas partie du site : il n'est ni chargé par une page,
   ni précaché par le service worker.

       node tools/captation-alertes.js > /tmp/brouillon-alertes.js

   Le fichier produit est un BROUILLON. Il n'est jamais copié tel quel dans
   `alertes-data.js` : chaque alerte est relue à la main avant publication, parce que
   trois choses ne s'automatisent pas.

     1. **Le geste.** Aucune source ne le fournit. Les services d'analyse publient un
        résultat ; la traduction en « ce que tu peux faire » est un travail éditorial,
        et une alerte sans geste est un échec (ch. 44).
     2. **Le ton.** Les sources écrivent en registre laboratoire. Le produit ne parle
        pas comme un laboratoire.
     3. **La péremption.** Elle dépend de la nature du signalement, pas d'une règle
        fixe : un lot précis se périme vite, une tendance de marché tient des mois.

   Sources suivies — toutes publient leurs résultats librement :
     · checkit! Vienne      https://checkit.wien/en/warnungen/
     · Saferparty / DIZ     https://www.saferparty.ch/de/infos/drugchecking/warnungen
     · Modus Vivendi (BE)   système d'alerte précoce, via Eurotox
     · EUDA                 signalements européens (CC BY 4.0)
     · DIMS (NL)            https://www.drugs-test.nl/

   Deux modes :
     · sans argument  → lit les pages déjà déposées dans `tools/captures/`
     · `--fetch`      → télécharge les sources lui-même

   Le mode `--fetch` n'est PAS une entorse au principe « aucune requête réseau ». Le principe
   porte sur l'appareil de la personne, pas sur la machine qui construit le site. Ce script
   tourne chez l'éditeur ou sur GitHub Actions (.github/workflows/alertes.yml) — jamais dans
   un navigateur, jamais chez quelqu'un qui consulte le produit. Le fichier produit est
   statique et livré avec le site, exactement comme le reste du contenu.

   La revue humaine reste obligatoire dans les deux modes : le workflow ouvre une pull
   request, il ne publie jamais directement.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');

const DOSSIER = path.join(__dirname, 'captures');
const AUJOURDHUI = new Date().toISOString().slice(0, 10);

function dansNMois(n) {
  const d = new Date();
  d.setMonth(d.getMonth() + n);
  return d.toISOString().slice(0, 10);
}

/* Repère les formulations « X vendu comme Y » dans un texte, quelle que soit la langue
   des sources suivies. C'est le seul motif réellement commun au champ. */
const MOTIFS = [
  /([A-Za-z0-9\-]+)\s+verkauft als\s+([A-Za-z0-9\-]+)/gi,      // de
  /([A-Za-z0-9\-]+)\s+sold as\s+([A-Za-z0-9\-]+)/gi,           // en
  /([A-Za-z0-9\-]+)\s+vendu comme\s+([A-Za-z0-9\-]+)/gi        // fr
];

function extraire(txt, fichier) {
  const trouves = [];
  for (const re of MOTIFS) {
    let m;
    while ((m = re.exec(txt)) !== null) {
      trouves.push({ reel: m[1], annonce: m[2], fichier });
    }
  }
  return trouves;
}

function gabarit(t, i) {
  return `  {
    id: 'alerte-${AUJOURDHUI}-${i}',
    date: '${AUJOURDHUI}', capte_le: '${AUJOURDHUI}', perime_le: '${dansNMois(3)}',
    regions: null,                       // ← à restreindre si le signalement est local
    gravite: 'eleve',                    // critique | eleve | information — ordonne, ne colore pas
    format: 'vendu_comme',
    annonce: ${JSON.stringify(t.annonce)}, reel: ${JSON.stringify(t.reel)},
    substances: [${JSON.stringify(t.annonce)}],
    titre_fr: '', titre_en: '',
    corps_fr: '', corps_en: '',
    geste_fr: '',                        // ← OBLIGATOIRE, à écrire à la main
    geste_en: '',
    source_nom: '', source_url: ''       // ← source de ${t.fichier}
  },`;
}

/* Sources suivies en mode --fetch. Toutes publient librement leurs résultats.
   Ajouter une source ici suffit : le reste du pipeline est générique. */
const SOURCES = [
  { nom: 'checkit! Vienne',     url: 'https://checkit.wien/en/warnungen/' },
  { nom: 'Saferparty / DIZ',    url: 'https://www.saferparty.ch/de/infos/drugchecking/warnungen' },
  { nom: 'Mindzone',            url: 'https://mindzone.info/aktuelles/substanz-drogen-warnungen/' },
  { nom: 'DIMS (NL)',           url: 'https://www.drugs-test.nl/' },
  { nom: 'Eurotox (BE)',        url: 'https://eurotox.org/category/alertes/' }
];

async function telecharger() {
  fs.mkdirSync(DOSSIER, { recursive: true });
  for (const s of SOURCES) {
    try {
      const r = await fetch(s.url, { headers: { 'User-Agent': 'MyDopeOff-captation/1.0' } });
      if (!r.ok) { console.error('  ' + s.nom + ' : HTTP ' + r.status); continue; }
      const nom = s.url.replace(/[^a-z0-9]+/gi, '-').slice(0, 80) + '.html';
      fs.writeFileSync(path.join(DOSSIER, nom), await r.text(), 'utf8');
      console.error('  ' + s.nom + ' : ok');
    } catch (e) {
      console.error('  ' + s.nom + ' : échec (' + e.message + ')');
    }
  }
}

async function main() {
  if (process.argv.includes('--fetch')) {
    console.error('Téléchargement des sources…');
    await telecharger();
  }
  if (!fs.existsSync(DOSSIER)) {
    console.error('Rien à lire. Enregistre les pages sources dans ' + DOSSIER + ' puis relance.');
    process.exit(1);
  }
  const fichiers = fs.readdirSync(DOSSIER).filter(f => /\.(html?|txt)$/i.test(f));
  let tout = [];
  for (const f of fichiers) {
    const brut = fs.readFileSync(path.join(DOSSIER, f), 'utf8').replace(/<[^>]+>/g, ' ');
    tout = tout.concat(extraire(brut, f));
  }
  const vus = new Set();
  const uniques = tout.filter(t => {
    const c = (t.reel + '>' + t.annonce).toLowerCase();
    if (vus.has(c)) return false;
    vus.add(c); return true;
  });

  console.log('/* BROUILLON du ' + AUJOURDHUI + ' — ' + uniques.length + ' signalement(s), ' +
              fichiers.length + ' source(s).');
  console.log('   À RELIRE INTÉGRALEMENT. Aucune alerte ne se publie sans geste, sans source');
  console.log('   et sans date. Ne jamais copier ce fichier tel quel. */');
  console.log('window.MD_ALERTES = [');
  uniques.forEach((t, i) => console.log(gabarit(t, i + 1)));
  console.log('];');
}

main();
