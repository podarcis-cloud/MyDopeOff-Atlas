/* MyDope Off — tools/tics.js
   ============================================================================
   Détecteur de tics de langage. À lancer après toute passe éditoriale.

       node tools/tics.js

   POURQUOI CET OUTIL EXISTE
   Un tic ne se voit pas en écrivant : il apparaît à l'échelle du corpus. Trois ont été
   trouvés en une session — « ce n'est pas X, c'est Y » (37 fois), les majuscules
   d'emphase (23), « Et » en tête de phrase (20) — et aucun n'était visible phrase à
   phrase. C'est Simon qui a signalé le premier, ce qui veut dire qu'il était devenu
   perceptible à la lecture normale : bien trop tard.

   MÉTHODE : LA DENSITÉ, PAS LE COMPTE
   Un compte brut ne dit rien. Ce qui distingue un tic d'un trait de style, c'est
   l'écart de densité entre ce qui vient d'être écrit et le reste du produit. Le tiret
   cadratin sort à 1 997 occurrences mais à 0,97/phrase dans le contenu ancien contre
   0,32 dans le neuf : c'est le style de maison, pas une dérive. « Et » en tête sortait
   à 20 seulement, mais à 0,053 contre 0,005 : dix fois la densité de référence.

   Seuil retenu : un patron dont la densité dépasse **le double** de la référence
   mérite un examen. En dessous, ne rien toucher.
   ============================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const RACINE = path.join(__dirname, '..');

/* Contenu écrit récemment vs référence. À ajuster à chaque session. */
const RECENT = ['chemsex.html', 'femmes.html', 'grossesse.html', 'situations.html',
                'apres-une-pause.html', 'paws.html', 'audition.html',
                'crise-psychedelique.html', 'alertes.html', 'mentions-legales.html'];
const REFERENCE = ['rechute.html', 'autosabotage.html', 'environnement.html', 'soutenir.html',
                   'controles.html', 'rdr-vs-abstinence.html', 'antisabotage.html', 'detection.html'];

const PATRONS = {
  "négation-correction (ce n'est pas X, c'est Y)": /n[’']est (pas|ni)[^.!?]{0,70}?[,—:-]\s*c[’']est/gi,
  "majuscules d'emphase":                          /\b(PAS|NOT|NEVER|JAMAIS|TOUJOURS)\b/g,
  "« Et » en tête de phrase":                      /(?:^|[.!?]\s)Et\b/gm,
  "« Mais » en tête de phrase":                    /(?:^|[.!?]\s)Mais\b/gm,
  "« sans avoir à »":                              /sans (rien à|avoir à|que tu aies à)/gi,
  "tiret cadratin":                                /—/g,
  "deux-points explicatif":                        /\w : [a-zàéèêç]/g,
  "« ça compte »":                                 /ça compte/gi,
  "« à ton rythme »":                              /à ton rythme/gi,
  "« ce qui compte »":                             /ce qui compte/gi,
  "« se prépare / se travaille »":                 /\bse (prépare|travaille|construit|répare)\b/gi,
  "parenthèse d'aparté":                           /\([^)]{15,90}\)/g
};

function texteVisible(fichiers) {
  let out = '';
  for (const f of fichiers) {
    const p = path.join(RACINE, f);
    if (!fs.existsSync(p)) continue;
    let s = fs.readFileSync(p, 'utf8');
    s = s.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<!--[\s\S]*?-->|\/\*[\s\S]*?\*\//g, '');
    out += s.replace(/<[^>]+>/g, ' ');
  }
  return out.replace(/[\u2018\u2019]/g, "'");
}

function densites(fichiers) {
  const t = texteVisible(fichiers);
  const phrases = t.split(/[.!?]\s/).filter(p => p.length > 25).length || 1;
  const d = {};
  for (const [nom, re] of Object.entries(PATRONS)) {
    d[nom] = (t.match(re) || []).length / phrases;
  }
  return d;
}

const rec = densites(RECENT);
const ref = densites(REFERENCE);

console.log('Densité par phrase — récent vs référence\n');
const lignes = Object.keys(PATRONS).map(n => {
  const r = rec[n], f = ref[n];
  const ratio = f > 0 ? r / f : (r > 0 ? Infinity : 0);
  return { n, r, f, ratio };
}).sort((a, b) => b.ratio - a.ratio);

let alertes = 0;
for (const l of lignes) {
  const drapeau = (l.ratio >= 2 && l.r >= 0.01) ? '  ← À EXAMINER' : '';
  if (drapeau) alertes++;
  console.log(`  ${l.r.toFixed(3)}  vs ${l.f.toFixed(3)}   ${l.n}${drapeau}`);
}
console.log(`\n${alertes} patron(s) au-dessus du double de la référence.`);
