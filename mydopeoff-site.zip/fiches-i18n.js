/* ============================================================
   MyDope Off — TRADUCTION DES FICHES SUBSTANCES
   Fichier INDÉPENDANT. Ne dépend d'aucun autre code du site.
   Reste valable même si le reste du site est transformé.
   ------------------------------------------------------------
   FORMAT
   window.MD_FICHES_I18N = {
     en: { "NomFrançaisDeLaFiche": { effets:[...], dosage:{faible,modere,fort},
                                     duree:"...", tripReport:"...", description:"..." }, ... },
     es: { ... },
     de: { ... }
   };
   - La clé est EXACTEMENT le nom français de la fiche (1er argument de addSub).
   - Tous les champs sont optionnels : un champ absent retombe sur le français.
   - Une fiche absente d'une langue s'affiche entièrement en français.
   - addiction (niveau) et catégories sont traduits ailleurs (étiquettes UI).

   BRANCHEMENT (déjà prévu dans psychochecker.html, à activer une seule fois) :
     <script src="fiches-i18n.js"></script>
   puis un helper tr(nom, champ, valeurFR) qui lit ce dictionnaire
   selon MDCore.lang() et retombe sur la valeur française si absente.
   ============================================================ */
window.MD_FICHES_I18N = {
  en: {
    "Alcool": {
      effets:["Sedation","Disinhibition","Mild euphoria","Anxiety relief"],
      dosage:{faible:"1–2 drinks",modere:"3–5 drinks",fort:"≥6 drinks — severe intoxication"},
      duree:"Onset 10–30 min | Peak 1–2 h | Total 3–8 h",
      tripReport:"Alcohol, 4 drinks: pleasant disinhibition. Beyond that: loss of control, blackouts.",
      description:"Ethanol: potentiates every CNS depressant. Lethal synergy with opioids/benzos/GHB."
    },
    "Diazépam": {
      effets:["Anxiety relief","Muscle relaxation","Sedation","Anticonvulsant"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"20–40 mg"},
      duree:"Onset 15–45 min | Peak 1–2 h | Total 6–12 h",
      tripReport:"Diazepam 10 mg: deep anxiety relief. Physical dependence within 4 weeks.",
      description:"Valium: the reference benzodiazepine. Lethal interactions with alcohol/opioids."
    },
    "Alprazolam": {
      effets:["Anxiety relief","Sedation","Disinhibition","Amnesia"],
      dosage:{faible:"0.25–0.5 mg",modere:"0.5–1 mg",fort:"1.5–2 mg — blackout"},
      duree:"Onset 15–40 min | Peak 1–2 h | Total 3–6 h",
      tripReport:"Alprazolam 1 mg: anxiety gone in 20 min. 2 h of actions with no memory.",
      description:"Xanax: 1 mg potency = 10 mg Valium. Fast dependence. Alcohol = possible cardiac arrest."
    },
    "MDMA": {
      effets:["Euphoria","Empathy","Stimulation","Emotional connection"],
      dosage:{faible:"75–100 mg",modere:"100–125 mg",fort:"150–200 mg"},
      duree:"Onset 30–60 min | Peak 1.5–3 h | Total 4–6 h",
      tripReport:"MDMA 110 mg: universal love, transcendent music. 2-day comedown. Max once / 3 months.",
      description:"3,4-MDMA. Lethal hyperthermia, hyponatremia. Neurotoxic. MAOI/tramadol = death."
    },
    "Cocaïne": {
      effets:["Euphoria","Intense stimulation","Increased confidence","Vasoconstriction"],
      dosage:{faible:"20–40 mg (nasal)",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 5–15 min | Peak 20–40 min | Total 1–2 h",
      tripReport:"Cocaine 50 mg: short euphoric rush. Cocaine + alcohol = cardiotoxic cocaethylene.",
      description:"DAT/NET/SERT inhibitor. Cardiotoxic. Alcohol → toxic cocaethylene. Fast dependence."
    },
    "GHB": {
      effets:["Euphoria","Sedation","Disinhibition","Amnesia"],
      dosage:{faible:"0.5–1 g",modere:"1–2 g",fort:"≥2.5 g — easy overdose"},
      duree:"Onset 15–30 min | Peak 45–90 min | Total 2–4 h",
      tripReport:"GHB 1.5 g: party euphoria. 0.5 g too much = coma.",
      description:"GABA-B agonist. Narrow therapeutic index. Never with alcohol."
    },
    "Kétamine": {
      effets:["Dissociation","Analgesia","Euphoria","Hallucinations"],
      dosage:{faible:"25–50 mg (nasal)",modere:"75–150 mg",fort:"200–400 mg — k-hole"},
      duree:"Onset 5–15 min | Peak 20–40 min | Total 1–2 h",
      tripReport:"Ketamine 100 mg: full dissociation. K-hole at 300 mg: out-of-body experience.",
      description:"NMDA antagonist. Ketamine bladder syndrome with repeated use. Alcohol mix = apnea risk."
    },
    "Cannabis": {
      effets:["Euphoria","Relaxation","Altered perception","Increased appetite"],
      dosage:{faible:"1–3 mg THC",modere:"5–15 mg THC",fort:"20–50 mg THC"},
      duree:"Onset 15–45 min (oral) / 5–15 min (smoked) | Total 2–6 h",
      tripReport:"Cannabis ~15 mg THC: euphoria and laughter, heightened music. Paranoia possible from 20 mg.",
      description:"CB1/CB2 agonist. Documented cannabis psychosis. Hyperemesis syndrome with chronic use."
    },
    "LSD": {
      effets:["Hallucinations","Euphoria","Introspection","Universal connection"],
      dosage:{faible:"50–75 µg",modere:"100–150 µg",fort:"200–400 µg"},
      duree:"Onset 30–90 min | Peak 3–5 h | Total 8–12 h",
      tripReport:"LSD 120 µg: gorgeous visuals, total musical connection. Lithium = lethal seizures.",
      description:"5-HT2A agonist. Lithium → seizures. Set & setting essential."
    },
    "Héroïne": {
      effets:["Intense euphoria","Analgesia","Sedation","Warmth"],
      dosage:{faible:"varies — tolerance-dependent",modere:"dose impossible to standardise",fort:"respiratory depression"},
      duree:"Onset 1–5 min (IV) | Total 3–5 h",
      tripReport:"Heroin: opioid 'rush' then drowsiness. Street purity unknown → overdose. Often cut with fentanyl.",
      description:"Mu agonist. Respiratory depression = main cause of death. Test, naloxone, never alone."
    },
    "Morphine": {
      effets:["Analgesia","Euphoria","Sedation","Anxiety relief"],
      dosage:{faible:"10–20 mg (oral)",modere:"30–60 mg",fort:"100 mg+ (without tolerance: dangerous)"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Morphine: the reference opioid. Euphoria and analgesia, dose-dependent respiratory depression.",
      description:"Mu agonist. Respiratory depression worsened by alcohol/benzos. Tolerance and dependence."
    },
    "Fentanyl": {
      effets:["Powerful analgesia","Intense euphoria","Sedation","Respiratory depression"],
      dosage:{faible:"micrograms (not home-measurable)",modere:"unpredictable dose",fort:"respiratory arrest"},
      duree:"Onset 1–5 min | Total 1–2 h",
      tripReport:"Fentanyl: ~50× stronger than heroin. Invisible amounts kill. Massively present in the street supply.",
      description:"Very potent mu agonist. Tiny dose-to-overdose margin. Test strips, naloxone, never alone."
    },
    "Méthadone": {
      effets:["Analgesia","Stabilisation","Mild sedation"],
      dosage:{faible:"medical use only",modere:"prescribed substitution dose",fort:"respiratory depression"},
      duree:"Onset 30 min–1 h | Total 24–36 h",
      tripReport:"Methadone: opioid substitution treatment. Very long-acting → accumulation and overdose risk if misused.",
      description:"Long-acting mu agonist. Accumulates (long half-life). QT prolongation. Dangerous with benzos/alcohol."
    },
    "Tramadol": {
      effets:["Analgesia","Mild euphoria","Nausea"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–400 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Tramadol 100 mg: painkiller with mild euphoria. Seizures at high dose.",
      description:"SNRI + opioid agonist. Serotonin syndrome with MDMA/MAOI. Documented seizures."
    },
    "Codéine": {
      effets:["Analgesia","Cough suppression","Mild euphoria"],
      dosage:{faible:"15–30 mg",modere:"60–120 mg",fort:"200+ mg"},
      duree:"Onset 30–45 min | Total 4–6 h",
      tripReport:"Codeine 60 mg: gentle analgesia and mild euphoria. Alcohol strongly potentiates.",
      description:"Morphine prodrug. CYP2D6 variability. Alcohol → respiratory depression."
    },
    "Psilocybine": {
      effets:["Hallucinations","Euphoria","Ego dissolution","Introspection"],
      dosage:{faible:"1–2 g mushrooms",modere:"2–3.5 g",fort:"5+ g"},
      duree:"Onset 20–60 min | Peak 2–4 h | Total 4–6 h",
      tripReport:"Psilocybin 2 g: visuals and emotional connection. 5 g: full mystical experience.",
      description:"5-HT2A agonist. Lithium → seizures. Set & setting critical."
    },
    "Amphétamine": {
      effets:["Stimulation","Euphoria","Focus","Appetite suppression"],
      dosage:{faible:"5–10 mg",modere:"15–30 mg",fort:"40 mg+"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Amphetamine ('speed') 20 mg: energy and focus. Comedown, insomnia, compulsive redosing.",
      description:"Dopamine/noradrenaline releaser. Cardiac strain, dependence. Crash on the way down."
    },
    "Méthamphetamine": {
      effets:["Intense stimulation","Strong euphoria","Hypervigilance","Appetite suppression"],
      dosage:{faible:"5–10 mg",modere:"10–25 mg",fort:"30 mg+"},
      duree:"Onset varies by route | Total 8–12 h",
      tripReport:"Methamphetamine: stronger and far longer than amphetamine. Severe dependence, days-long binges, psychosis.",
      description:"Powerful dopamine releaser, neurotoxic. Hyperthermia, psychosis, dental damage. High abuse liability."
    },
    "Caféine": {
      effets:["Wakefulness","Mild stimulation","Focus"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"300–400 mg+"},
      duree:"Onset 15–45 min | Total 3–6 h",
      tripReport:"Caffeine 100 mg (a coffee): mild boost. Beyond 400 mg: jitters, palpitations, anxiety.",
      description:"Adenosine antagonist. Tolerance and withdrawal (headaches). Caution with the heart at high dose."
    },
    "Nicotine": {
      effets:["Mild stimulation","Relaxation","Focus"],
      dosage:{faible:"1–2 mg",modere:"a few cigarettes",fort:"chronic use"},
      duree:"Onset seconds (smoked) | Total 30 min–2 h",
      tripReport:"Nicotine: brief stimulation then relaxation. One of the most addictive substances there is.",
      description:"Nicotinic agonist. Extremely addictive. Cardiovascular and cancer risk via smoking."
    },
    "Naloxone": {
      effets:["Opioid antagonism","Overdose reversal"],
      dosage:{faible:"0.4–0.8 mg (nasal/IM)",modere:"0.8–1.6 mg",fort:"2 mg+"},
      duree:"Onset 2–5 min | Total 30–90 min",
      tripReport:"Naloxone: if someone is overdosing, THIS is what saves lives. Always carry it.",
      description:"Full mu antagonist. Reverses any opioid overdose. Short duration = redosing sometimes needed."
    },
    "Klonopin": {
      effets:["Anxiety relief", "Anticonvulsant", "Sedation", "Amnesia"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3–4 mg"},
      duree:"Onset 20–60 min | Total 6–12 h",
      tripReport:"Klonopin 2 mg: deep anxiety relief, mild sedation. Very hard withdrawal.",
      description:"Clonazepam: long-acting benzo. Severe physical dependence. Withdrawal = seizures."
    },
    "Lorazépam": {
      effets:["Anxiety relief", "Sedation", "Amnesia", "Muscle relaxation"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"2.5–4 mg"},
      duree:"Onset 15–30 min | Total 6–8 h",
      tripReport:"Lorazepam 2 mg: deep sedation, partial amnesia. Alcohol = respiratory arrest.",
      description:"Ativan: potent benzo, intermediate half-life. Physical dependence. Never with alcohol."
    },
    "Zolpidem": {
      effets:["Sedation", "Hypnosis", "Amnesia", "Sleepwalking"],
      dosage:{faible:"5 mg",modere:"10 mg",fort:"15–20 mg"},
      duree:"Onset 15–30 min | Total 6–8 h",
      tripReport:"Zolpidem 10 mg: fast onset of sleep. Sleepwalking sometimes. Alcohol = total amnesia.",
      description:"GABA-A agonist. Documented sleepwalking. Alcohol severely potentiates."
    },
    "Pregabaline": {
      effets:["Anxiety relief", "Euphoria", "Sedation", "Well-being"],
      dosage:{faible:"75–150 mg",modere:"150–300 mg",fort:"450–600 mg"},
      duree:"Onset 30–90 min | Total 6–8 h",
      tripReport:"Pregabalin 150 mg: sedation and mild euphoria. Linked to many opioid deaths.",
      description:"GABA analogue. Opioid combination = documented death. Underestimated physical dependence."
    },
    "Gabapentine": {
      effets:["Sedation", "Anxiety relief", "Mild euphoria"],
      dosage:{faible:"100–300 mg",modere:"600–900 mg",fort:"1200–1800 mg"},
      duree:"Onset 60–90 min | Total 5–7 h",
      tripReport:"Gabapentin 900 mg: sedation and calm. Linked to deaths in opioid combinations.",
      description:"Gabapentinoid. Documented deaths in opioid combination. Growing misuse."
    },
    "Quétiapine": {
      effets:["Sedation", "Anxiety relief", "Antipsychotic"],
      dosage:{faible:"25–50 mg",modere:"100–200 mg",fort:"400–800 mg"},
      duree:"Onset 30–60 min | Total 6–12 h",
      tripReport:"Quetiapine 50 mg: powerful sleep aid. Diverted from prescription.",
      description:"D2/5-HT2A antagonist. Neuroleptic malignant syndrome. Alcohol = severe hypotension."
    },
    "Phénibut": {
      effets:["Anxiety relief", "Euphoria", "Sociability", "Sedation"],
      dosage:{faible:"250–500 mg",modere:"500–1000 mg",fort:"1500–2000 mg"},
      duree:"Onset 2–4 h | Total 5–8 h",
      tripReport:"Phenibut 750 mg: anxiety erased, sociability boosted. Brutal withdrawal after 3 uses.",
      description:"GABA-B agonist + weak D2. Fast physical dependence. Intense withdrawal. GHB/alcohol = coma."
    },
    "Clonazolam": {
      effets:["Extreme sedation", "Deep amnesia", "Anxiety relief"],
      dosage:{faible:"0.25–0.5 mg",modere:"0.5–1 mg",fort:"1–2 mg (death possible)"},
      duree:"Onset 20–60 min | Total 8–18 h",
      tripReport:"Clonazolam 0.5 mg: hours of amnesia. 1 mg + alcohol: can be lethal.",
      description:"Ultra-potent designer benzo. Accumulation = death. Never with alcohol. Withdrawal = seizures."
    },
    "Flubromazolam": {
      effets:["Extreme sedation", "Total amnesia", "Hypnosis"],
      dosage:{faible:"0.1–0.25 mg",modere:"0.25–0.5 mg",fort:"0.5 mg+ (dangerous)"},
      duree:"Onset 20–60 min | Total 12–20 h",
      tripReport:"Flubromazolam 0.25 mg: the most potent designer benzo. Total amnesia. Death possible.",
      description:"Most potent benzo known. Alcohol = death. Insidious accumulation. Withdrawal = seizures."
    },
    "1,4-Butanediol": {
      effets:["Euphoria", "Sedation", "Disinhibition"],
      dosage:{faible:"0.5–0.8 ml/kg",modere:"0.8–1.2 ml/kg",fort:"1.5 ml/kg+ (easy coma)"},
      duree:"Onset 20–40 min | Total 2–4 h",
      tripReport:"Resembles GHB but liquid dosing makes overdose very easy.",
      description:"GHB prodrug. Very narrow therapeutic index. Alcohol mix = respiratory coma."
    },
    "GBL": {
      effets:["Euphoria", "Sedation", "Disinhibition"],
      dosage:{faible:"0.5–0.8 ml",modere:"0.8–1.3 ml",fort:"1.5 ml+"},
      duree:"Onset 5–20 min | Peak 30–60 min | Total 1.5–3 h",
      tripReport:"GBL 1 ml: ultra-fast onset, disorientation in 5 min. Lethal margin of error.",
      description:"GHB prodrug. Faster metabolism. Never with alcohol."
    },
    "Carisoprodol": {
      effets:["Muscle relaxation", "Sedation", "Anxiety relief"],
      dosage:{faible:"250 mg",modere:"350–500 mg",fort:"700–1000 mg"},
      duree:"Onset 20–40 min | Total 4–6 h",
      tripReport:"Carisoprodol 350 mg: fast dependence reminiscent of benzos.",
      description:"Metabolised to meprobamate. Potentially fatal with alcohol."
    },
    "Etizolam": {
      effets:["Anxiety relief", "Sedation", "Possible amnesia"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3–5 mg"},
      duree:"Onset 20–40 min | Total 6–10 h",
      tripReport:"Etizolam 1 mg: dependence after 2 weeks.",
      description:"Same mechanism as benzos. Seizure-inducing withdrawal."
    },
    "Flubromazépam": {
      effets:["Sedation", "Anxiety relief", "Amnesia"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"15–20 mg"},
      duree:"Onset 30–60 min | Total 24–48 h",
      tripReport:"Flubromazepam 8 mg: effect persists 2 days. Fast dependence.",
      description:"Half-life >100 h. Accumulation. Seizure-inducing withdrawal."
    },
    "Deschloroetizolam": {
      effets:["Anxiety relief", "Sedation", "Amnesia"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3–5 mg"},
      duree:"Onset 20–40 min | Total 6–12 h",
      tripReport:"Deschloroetizolam 1 mg: fast tolerance, hard withdrawal.",
      description:"Lethal alcohol/opioid interactions."
    },
    "Metizolam": {
      effets:["Anxiety relief", "Sedation", "Amnesia"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"2–4 mg"},
      duree:"Onset 20–40 min | Total 8–12 h",
      tripReport:"Metizolam 1 mg: subtle but real dependence.",
      description:"Potentially seizure-inducing withdrawal."
    },
    "Pyrazolam": {
      effets:["Anxiety relief", "Mild sedation"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3–5 mg"},
      duree:"Onset 20–40 min | Total 8–14 h",
      tripReport:"Pyrazolam 1 mg: pure anxiolytic. Subtle dependence.",
      description:"Long half-life benzo."
    },
    "O-DSMT": {
      effets:["Analgesia", "Euphoria", "Sedation", "Respiratory depression"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–80 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"O-DSMT 25 mg: potent opioid. Marked respiratory depression. Lethal alcohol potentiation.",
      description:"O-desmethyltramadol: active metabolite of tramadol, strong mu agonist. Never with alcohol."
    },
    "Buprenorphine": {
      effets:["Analgesia", "Craving reduction", "Mild sedation"],
      dosage:{faible:"0.4–2 mg",modere:"2–8 mg",fort:"16–32 mg"},
      duree:"Onset 30–60 min | Total 24–72 h",
      tripReport:"Buprenorphine 8 mg: opioid substitution treatment. Physical dependence present but stable.",
      description:"Partial mu agonist + kappa antagonist. Analgesic ceiling. Used in OST. Benzos = death."
    },
    "Naltrexone": {
      effets:["Blocks opioid effects", "Reduces alcohol craving"],
      dosage:{faible:"25 mg",modere:"50 mg",fort:"100–150 mg"},
      duree:"Onset 60–90 min | Total 24–72 h",
      tripReport:"Naltrexone 50 mg/day: fully blocks opioids. Used for OST and alcoholism.",
      description:"Full mu antagonist. Hepatotoxic at high dose. Never with active opioids."
    },
    "Acétylfentanyl": {
      effets:["Analgesia", "Respiratory depression"],
      dosage:{faible:"0.1–0.2 mg",modere:"0.2–0.4 mg",fort:"0.5 mg+"},
      duree:"Onset 5–15 min | Total 1–3 h",
      tripReport:"Acetylfentanyl: overdose at the slightest imprecision.",
      description:"~5× morphine. Naloxone may be insufficient."
    },
    "Hydrocodone": {
      effets:["Analgesia", "Euphoria", "Constipation"],
      dosage:{faible:"5–10 mg",modere:"15–20 mg",fort:"30–40 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Hydrocodone 15 mg: warm euphoria. Fast dependence.",
      description:"Vicodin: ~1.5× codeine. Overdose with alcohol."
    },
    "Hydromorphone": {
      effets:["Powerful analgesia", "Intense euphoria", "Respiratory depression"],
      dosage:{faible:"1–2 mg",modere:"2–4 mg",fort:"6–8 mg"},
      duree:"Onset 15–30 min | Total 3–5 h",
      tripReport:"Hydromorphone 3 mg: a hospital opioid. Never outside prescription.",
      description:"Dilaudid: ~8× morphine. Extremely fast dependence."
    },
    "Oxymorphone": {
      effets:["Analgesia", "Intense euphoria", "Respiratory depression"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"15–20 mg"},
      duree:"Onset 15–30 min | Total 4–6 h",
      tripReport:"Oxymorphone 5 mg: ~10× morphine. Extremely addictive.",
      description:"Never mix with alcohol/benzos."
    },
    "Dextropropoxyphène": {
      effets:["Mild analgesia", "Weak euphoria", "Sedation"],
      dosage:{faible:"65 mg",modere:"130–200 mg",fort:"300 mg+"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Withdrawn from the market over fatal arrhythmias. Do not use.",
      description:"Major cardiotoxicity. Metabolite blocks cardiac sodium channels."
    },
    "Sufentanil": {
      effets:["Analgesia", "Respiratory depression", "Deep sedation"],
      dosage:{faible:"2–5 µg",modere:"10–25 µg",fort:"50 µg+"},
      duree:"Onset 1–3 min | Total 20–45 min",
      tripReport:"Sufentanil: 5–10× more potent than fentanyl. Hospital use only.",
      description:"500–1000× morphine. Naloxone insufficient."
    },
    "Péthidine": {
      effets:["Analgesia", "Euphoria", "Sedation"],
      dosage:{faible:"25–50 mg",modere:"50–100 mg",fort:"150–200 mg"},
      duree:"Onset 10–15 min (IM) | Total 2–4 h",
      tripReport:"Pethidine 75 mg: euphoric and fast. Fast dependence.",
      description:"Meperidine. Normeperidine metabolite → seizures. MAOI fatal."
    },
    "Tapentadol": {
      effets:["Analgesia", "Moderate euphoria", "Sedation"],
      dosage:{faible:"50 mg",modere:"100–150 mg",fort:"200–250 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Tapentadol 100 mg: opioid-SNRI, powerful painkiller.",
      description:"Mu agonist + NA reuptake inhibitor. MAOIs contraindicated."
    },
    "Isotonitazène": {
      effets:["Powerful analgesia", "Deep sedation", "Respiratory depression", "Euphoria"],
      dosage:{faible:"micrograms (not home-measurable)",modere:"unpredictable dose",fort:"respiratory arrest"},
      duree:"Onset 1–10 min | Total 1–4 h",
      tripReport:"Isotonitazene ('iso'): synthetic opioid stronger than fentanyl. Often found in powders or fake pills. Naloxone works but several doses may be needed.",
      description:"Very potent mu agonist (nitazene family). Tiny dose-to-overdose margin. Always test (strips), never use alone, carry naloxone."
    },
    "Métonitazène": {
      effets:["Analgesia", "Extreme sedation", "Respiratory depression"],
      dosage:{faible:"micrograms (not measurable)",modere:"unpredictable dose",fort:"respiratory arrest"},
      duree:"Onset 1–10 min | Total 1–4 h",
      tripReport:"Metonitazene: a nitazene close in potency to fentanyl, involved in many deaths. Found in mixes (heroin, fake meds).",
      description:"Mu agonist (nitazene). Major respiratory depression. Naloxone sometimes in repeated doses. Test, never be alone."
    },
    "Protonitazène": {
      effets:["Powerful analgesia", "Deep sedation", "Respiratory depression"],
      dosage:{faible:"micrograms (not measurable)",modere:"unpredictable dose",fort:"respiratory arrest"},
      duree:"Onset 1–10 min | Total 1–4 h",
      tripReport:"Protonitazene: estimated about 4× more potent than fentanyl. Found in deaths across Europe, North America and Australia.",
      description:"Very potent mu agonist (nitazene). Extreme overdose risk. Naloxone, nitazene strips, presence of a third party essential."
    },
    "Carfentanil": {
      effets:["Massive analgesia", "Immediate respiratory depression", "Loss of consciousness"],
      dosage:{faible:"micrograms (not measurable, lethal)",modere:"unpredictable dose",fort:"near-immediate respiratory arrest"},
      duree:"Onset <1–5 min | Total 0.5–2 h",
      tripReport:"Carfentanil: ~100× more potent than fentanyl (veterinary use for large animals). An amount invisible to the eye can kill. Found in street powders.",
      description:"Extremely potent mu agonist. Ultra-fast overdose. Multiple naloxone doses often needed. Never use alone, test, rescue doses ready."
    },
    "Oxycodone": {
      effets:["Analgesia", "Euphoria", "Sedation", "Anxiety relief"],
      dosage:{faible:"5–10 mg",modere:"15–30 mg",fort:"40 mg+ (without tolerance: dangerous)"},
      duree:"Onset 20–40 min | Total 4–6 h",
      tripReport:"Oxycodone (OxyContin) ~15 mg: classic opioid euphoria. Fake pills very often cut with fentanyl: never assume the contents.",
      description:"Mu agonist. Dose-dependent respiratory depression, worsened by alcohol/benzos. Fast tolerance and dependence. Naloxone for overdose."
    },
    "Krokodil (désomorphine)": {
      effets:["Analgesia", "Brief opioid euphoria", "Sedation"],
      dosage:{faible:"not quantifiable (homemade)",modere:"unpredictable dose",fort:"overdose / necrosis"},
      duree:"Onset 2–5 min | Total 1.5–2 h",
      tripReport:"Krokodil ('crocodile', 'zombie drug'): desomorphine made at home from codeine and caustic products (petrol, red phosphorus, acid). Short but very strong opioid effect. Toxic residues cause tissue necrosis (greenish scaly skin, gangrene, amputations). Greatly shortened life expectancy with regular use.",
      description:"Desomorphine: mu agonist ~8–10× stronger than morphine, short duration → frequent reinjection. The main danger comes mostly from the caustic impurities of homemade synthesis (necrosis, infections, abscesses, bone damage). Classic opioid respiratory depression on top."
    },
    "Opium": {
      effets:["Analgesia", "Euphoria", "Sedation", "Dreaminess"],
      dosage:{faible:"depends on morphine content (highly variable)",modere:"unpredictable dose",fort:"respiratory depression"},
      duree:"Onset 15–45 min | Total 4–6 h",
      tripReport:"Opium (poppy latex): classic opioid euphoria, smoked or eaten. Highly variable morphine content → unpredictable dosing. Dependence and respiratory depression like all opioids.",
      description:"Morphine + codeine + thebaine (opioid agonists). Respiratory depression, dependence. Major danger with alcohol/benzos. Naloxone for overdose."
    },
    "Tianeptine": {
      effets:["Euphoria", "Anxiety relief", "Sedation", "Analgesia"],
      dosage:{faible:"12.5–25 mg",modere:"25–50 mg",fort:"100–250 mg"},
      duree:"Onset 30–60 min | Total 3–4 h",
      tripReport:"Tianeptine 50 mg: an antidepressant turned street opioid. Ultra-fast dependence.",
      description:"Atypical mu agonist. Explosive dependence. Alcohol = respiratory risk."
    },
    "Kratom": {
      effets:["Analgesia", "Mild euphoria", "Low-dose stimulation", "High-dose sedation"],
      dosage:{faible:"2–5 g",modere:"5–10 g",fort:"15–25 g"},
      duree:"Onset 15–30 min | Total 3–6 h",
      tripReport:"Kratom 5 g: gentle opioid effect. 15 g: strong sedation. Physical dependence within a few weeks.",
      description:"Partial opioid agonist + alpha-2 agonist. Withdrawal comparable to heroin. Hepatotoxic."
    },
    "Psilocine": {
      effets:["Hallucinations", "Euphoria", "Ego dissolution"],
      dosage:{faible:"10–15 mg",modere:"15–25 mg",fort:"30–40 mg"},
      duree:"Onset 15–45 min | Total 4–6 h",
      tripReport:"Psilocin 20 mg: faster trip than psilocybin. Comparable visuals.",
      description:"4-HO-DMT: active metabolite of psilocybin. Identical profile."
    },
    "DMT": {
      effets:["Intense hallucinations", "Entities", "Break-through", "Euphoria"],
      dosage:{faible:"10–15 mg (smoked)",modere:"20–40 mg",fort:"50–70 mg"},
      duree:"Onset 30 s (smoked) | Total 10–20 min",
      tripReport:"DMT 40 mg smoked: encounter with entities. Total dissociation for 15 min. The most intense experience possible.",
      description:"N,N-DMT. Potent 5-HT2A agonist. Endogenous. Never with MAOI except an ayahuasca protocol."
    },
    "2C-B": {
      effets:["Euphoria", "Hallucinations", "Stimulation", "Empathy"],
      dosage:{faible:"10–15 mg",modere:"15–25 mg",fort:"30–40 mg"},
      duree:"Onset 45–75 min | Total 4–6 h",
      tripReport:"2C-B 18 mg: the most balanced psychedelic. Entactogen + visual. Popular at festivals.",
      description:"5-HT2A + 5-HT2C agonist. Possible tachycardia. Never with lithium."
    },
    "Mescaline": {
      effets:["Colourful hallucinations", "Euphoria", "Connection to nature", "Introspection"],
      dosage:{faible:"100–200 mg",modere:"200–400 mg",fort:"400–600 mg"},
      duree:"Onset 60–120 min | Total 10–14 h",
      tripReport:"Mescaline 300 mg: dazzling colours, connection to nature. Long, deep trip.",
      description:"5-HT2A agonist. Very long duration. Tachycardia. Nausea at onset is common."
    },
    "Ayahuasca": {
      effets:["Intense visions", "Purge", "Introspection", "Hallucinations"],
      dosage:{faible:"100–150 ml",modere:"150–200 ml",fort:"200+ ml"},
      duree:"Onset 20–60 min | Peak 2–4 h | Total 4–6 h",
      tripReport:"Ayahuasca: deep inner journey, possible purge. MAOI = lethal interactions with many substances.",
      description:"Contains MAOI (harmala). LETHAL interactions: tramadol, MDMA, cocaine, amphetamines, antidepressants."
    },
    "Ibogaïne": {
      effets:["Dreamlike visions", "Deep revelations", "Stimulation", "Nausea"],
      dosage:{faible:"5–10 mg/kg",modere:"10–20 mg/kg",fort:"20+ mg/kg"},
      duree:"Onset 1–2 h | Total 12–36 h",
      tripReport:"Ibogaine: a 36 h journey, reliving one's whole life. Cardiac arrest possible without medical supervision.",
      description:"Multimodal reuptake inhibitor. Long QT = death. Never use without a prior cardiac workup."
    },
    "1P-LSD": {
      effets:["Hallucinations", "Introspection", "Time distortion", "Empathy"],
      dosage:{faible:"50–75 µg",modere:"100–150 µg",fort:"200–400 µg"},
      duree:"Onset 45–90 min | Total 8–12 h",
      tripReport:"1P-LSD 125 µg: splendid visuals, deep musical connection.",
      description:"Legal LSD prodrug in some countries. Identical profile to LSD."
    },
    "1cP-LSD": {
      effets:["Hallucinations", "Euphoria", "Time distortion"],
      dosage:{faible:"50–75 µg",modere:"100–150 µg",fort:"200–300 µg"},
      duree:"Onset 60–90 min | Total 8–14 h",
      tripReport:"1cP-LSD 100 µg: slightly milder than LSD, gradual come-up.",
      description:"Cyclopropanoyl LSD analogue. Avoid lithium, antipsychotics."
    },
    "DOM": {
      effets:["Intense hallucinations", "Extreme duration", "Stimulation"],
      dosage:{faible:"1–3 mg",modere:"3–6 mg",fort:"8–14 mg"},
      duree:"Onset 60–180 min | Total 16–24 h",
      tripReport:"DOM 4 mg: a 20-hour trip. Very slow come-up = redosing trap.",
      description:"2,5-dimethoxy-4-methylamphetamine. Hypertensive risk."
    },
    "2C-C": {
      effets:["Mild hallucinations", "Sedation", "Euphoria"],
      dosage:{faible:"15–25 mg",modere:"25–40 mg",fort:"50–80 mg"},
      duree:"Onset 45–90 min | Total 4–6 h",
      tripReport:"2C-C 30 mg: one of the gentlest 2Cs, sedating and visual.",
      description:"2C-C: 5-HT2A agonist. Short duration. Sedating effects."
    },
    "2C-D": {
      effets:["Mental stimulation", "Light hallucinations", "Creativity"],
      dosage:{faible:"10–20 mg",modere:"20–30 mg",fort:"40–60 mg"},
      duree:"Onset 45–75 min | Total 4–6 h",
      tripReport:"2C-D 25 mg: a nootropic-psychedelic effect, mental clarity.",
      description:"The most nootropic of the 2Cs according to Shulgin."
    },
    "2C-E": {
      effets:["Intense hallucinations", "Stimulation", "Empathy"],
      dosage:{faible:"5–10 mg",modere:"10–15 mg",fort:"20–30 mg"},
      duree:"Onset 60–120 min | Total 8–12 h",
      tripReport:"2C-E 15 mg: long, anxious come-up but a very deep peak.",
      description:"Nicknamed 'The Aquarust'. Treacherous slow onset. Bad-trip risk."
    },
    "2C-I": {
      effets:["Euphoria", "Hallucinations", "Stimulation"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25–35 mg"},
      duree:"Onset 45–75 min | Total 6–8 h",
      tripReport:"2C-I 15 mg: euphoric and visual, a feeling of invincibility.",
      description:"Strong 5-HT2A agonist. Possible tachycardia."
    },
    "2C-P": {
      effets:["Very intense hallucinations", "Very long duration", "Stimulation"],
      dosage:{faible:"3–6 mg",modere:"6–12 mg",fort:"15–25 mg"},
      duree:"Onset 90–180 min | Total 10–16 h",
      tripReport:"2C-P 8 mg: a 14-hour trip. Never without prior experience.",
      description:"One of the most potent psychedelics of the 2C family. Overdose possible."
    },
    "2C-T-2": {
      effets:["Hallucinations", "Empathy", "Introspection"],
      dosage:{faible:"5–10 mg",modere:"10–15 mg",fort:"20–30 mg"},
      duree:"Onset 60–120 min | Total 6–10 h",
      tripReport:"2C-T-2 12 mg: deep experience. Lethal interaction with lithium.",
      description:"Documented MAOI interactions (deaths). Never mix with MAOI."
    },
    "2C-T-7": {
      effets:["Intense hallucinations", "Empathy", "Nausea"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25–35 mg"},
      duree:"Onset 60–120 min | Total 8–15 h",
      tripReport:"2C-T-7 15 mg: 3 hours of vomiting then magnificent effects. Never with MAOI.",
      description:"Involved in several MAOI-combination deaths. Possible hepatotoxicity."
    },
    "4-AcO-DMT": {
      effets:["Hallucinations", "Euphoria", "Emotional connection"],
      dosage:{faible:"10–15 mg",modere:"20–30 mg",fort:"40–60 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"4-AcO-DMT 25 mg: like mushrooms but cleaner.",
      description:"Psilocin prodrug. Profile close to psilocybin."
    },
    "4-AcO-MET": {
      effets:["Hallucinations", "Creativity", "Euphoria"],
      dosage:{faible:"10–20 mg",modere:"20–30 mg",fort:"35–55 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"4-AcO-MET 25 mg: very crisp colourful visuals, musical euphoria.",
      description:"5-HT2A agonist. Mild physical stimulation."
    },
    "4-AcO-DET": {
      effets:["Hallucinations", "Euphoria", "Creativity"],
      dosage:{faible:"10–15 mg",modere:"15–25 mg",fort:"30–50 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"4-AcO-DET 20 mg: a shorter, more visual psilocybin.",
      description:"5-HT2A agonist. Less nausea than raw psilocybin."
    },
    "5-MeO-DiPT": {
      effets:["Hallucinations", "Physical stimulation", "Sexual effects"],
      dosage:{faible:"3–6 mg",modere:"6–12 mg",fort:"15–25 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"5-MeO-DiPT 8 mg (Foxy): hallucinations and marked sexual stimulation.",
      description:"5-HT2A agonist. Neurotoxicity with repeated use."
    },
    "5-MeO-MiPT": {
      effets:["Mild hallucinations", "Empathy", "Stimulation"],
      dosage:{faible:"3–5 mg",modere:"5–10 mg",fort:"12–20 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"5-MeO-MiPT 7 mg (Moxy): mildly empathogenic, bodily lightness.",
      description:"5-HT agonist. Short duration."
    },
    "Dextrométhorphane": {
      effets:["Dissociation", "Euphoria", "Hallucinations", "Mild stimulation"],
      dosage:{faible:"200–400 mg",modere:"400–600 mg",fort:"600–1000 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"DXM 400 mg: mild dissociation. 600 mg: sigma plateau, hallucinations. MAOI = death.",
      description:"σ1 agonist + NMDA antagonist + weak SSRI. Serotonin syndrome with MDMA/MAOI."
    },
    "Deschlorokétamine": {
      effets:["Dissociation", "Euphoria", "Sedation"],
      dosage:{faible:"30–50 mg",modere:"75–125 mg",fort:"150–200 mg"},
      duree:"Onset 20–40 min | Total 3–6 h",
      tripReport:"Deschloroketamine 80 mg: clean dissociation. Longer-lasting than ketamine.",
      description:"NMDA antagonist. Cystitis risk with repeated use."
    },
    "Diphenidine": {
      effets:["Dissociation", "Anaesthesia", "Hallucinations"],
      dosage:{faible:"20–40 mg",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 30–60 min | Total 6–10 h",
      tripReport:"Diphenidine 60 mg: dissociation similar to ketamine but longer.",
      description:"Non-PCP NMDA antagonist. Long duration. Fast tolerance."
    },
    "3-HO-PCE": {
      effets:["Dissociation", "Analgesia", "Euphoria"],
      dosage:{faible:"5–10 mg",modere:"15–25 mg",fort:"30–50 mg"},
      duree:"Onset 20–40 min | Total 4–8 h",
      tripReport:"3-HO-PCE 15 mg: deep dissociation with opioid euphoria. Highly addictive.",
      description:"Double risk: dissociative + opioid dependence."
    },
    "3-HO-PCP": {
      effets:["Dissociation", "Strong analgesia", "Intense euphoria"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"15–25 mg"},
      duree:"Onset 15–30 min | Total 4–8 h",
      tripReport:"3-HO-PCP 7 mg: dependence after 2 weeks.",
      description:"Strong opioid activity. Potentially cardiotoxic."
    },
    "3-MeO-PCE": {
      effets:["Dissociation", "Euphoria", "Possible mania"],
      dosage:{faible:"3–7 mg",modere:"8–15 mg",fort:"20–30 mg"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"3-MeO-PCE 10 mg: grandiosity and confusion. Psychosis at high dose.",
      description:"Risk of pharmacological mania."
    },
    "3-MeO-PCP": {
      effets:["Dissociation", "Manic euphoria", "Potential psychosis"],
      dosage:{faible:"3–8 mg",modere:"10–15 mg",fort:"20–35 mg"},
      duree:"Onset 30–90 min | Total 6–12 h",
      tripReport:"3-MeO-PCP 10 mg: grandiosity, then confusion. Documented manic psychosis.",
      description:"NMDA antagonist + partial dopaminergic. Very dangerous alone."
    },
    "O-PCE": {
      effets:["Dissociation", "Euphoria", "Analgesia"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–75 mg"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"O-PCE 30 mg: clean dissociation, less k-hole than ketamine.",
      description:"NMDA antagonist. Cystitis risk. Don't mix with alcohol."
    },
    "PCE": {
      effets:["Dissociation", "Euphoria", "Anaesthesia"],
      dosage:{faible:"5–10 mg",modere:"15–25 mg",fort:"30–50 mg"},
      duree:"Onset 15–30 min | Total 4–8 h",
      tripReport:"PCE 20 mg: similar to PCP but slightly different.",
      description:"NMDA antagonist. Psychosis risk."
    },
    "PCP": {
      effets:["Strong dissociation", "Anaesthesia", "Agitation", "Potential psychosis"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"15–25 mg"},
      duree:"Onset 5–20 min | Total 4–8 h",
      tripReport:"PCP 7 mg: total disconnection, multiplied physical strength. Aggression possible.",
      description:"NMDA antagonist + dopaminergic. Rhabdomyolysis possible."
    },
    "Méthoxétamine": {
      effets:["Dissociation", "Euphoria", "Anaesthesia", "Hallucinations"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–90 mg"},
      duree:"Onset 30–90 min (oral) | Total 5–7 h",
      tripReport:"MXE (methoxetamine) ~30 mg: dissociation close to ketamine but far longer and stronger. Easy overdose, prolonged 'M-hole', cardiovascular risk (hypertension).",
      description:"NMDA antagonist + serotonergic activity. Deceptive long duration → dangerous redose. Urinary toxicity with repeated use. Documented fatal cases."
    },
    "2-FDCK": {
      effets:["Dissociation", "Analgesia", "Mild euphoria"],
      dosage:{faible:"25–40 mg",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 10–25 min | Total 2–4 h",
      tripReport:"2-FDCK 60 mg: deep dissociation, clearer than ketamine.",
      description:"Fluorinated ketamine analogue. Possible cystitis. Don't mix with alcohol/benzos."
    },
    "3-MeO-PCMo": {
      effets:["Mild dissociation", "Sedation"],
      dosage:{faible:"30–60 mg",modere:"60–120 mg",fort:"120 mg+"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"3-MeO-PCMo: an RC dissociative of the PCP family, weaker and more sedating. Limited data.",
      description:"NMDA antagonist (morpholine). Less potent than 3-MeO-PCP. Scarce toxicology data."
    },
    "Méthoxphénidine": {
      effets:["Dissociation", "Hallucinations", "Stimulation"],
      dosage:{faible:"40–60 mg",modere:"60–100 mg",fort:"100 mg+"},
      duree:"Onset 30–90 min | Total 4–8 h",
      tripReport:"MXP (methoxphenidine): a diphenidine-type dissociative, long, with a risk of hypertension and agitation/psychosis at high doses. Deceptive slow come-up.",
      description:"NMDA antagonist (diarylethylamine). Slow come-up → dangerous redose. Hypertension, long duration."
    },
    "Nitreux": {
      effets:["Brief euphoria", "Mild dissociation", "Giggles"],
      dosage:{faible:"1 charger",modere:"2–3 chargers",fort:"many repeated (B12 deficiency)"},
      duree:"Onset a few seconds | Total 2–5 min",
      tripReport:"Nitrous (balloons): 2 minutes of euphoria. Repeated use = serious B12 deficiency.",
      description:"Nitrous oxide. B12 deficiency → severe neuropathy."
    },
    "THC (delta-9)": {
      effets:["Euphoria", "Relaxation", "Altered perception", "Appetite stimulation"],
      dosage:{faible:"2–5 mg",modere:"5–15 mg",fort:"20–50 mg"},
      duree:"Onset 15–45 min (oral) | Peak 1–3 h | Total 4–6 h",
      tripReport:"THC 15 mg: euphoria and laughter, heightened music. Anxiety and paranoia possible from 20 mg.",
      description:"Δ9-tetrahydrocannabinol: CB1/CB2 agonist. Documented cannabinoid psychosis."
    },
    "CBD": {
      effets:["Anxiety relief", "Anti-inflammatory", "Relaxation"],
      dosage:{faible:"10–25 mg",modere:"25–75 mg",fort:"100–300 mg"},
      duree:"Onset 20–45 min | Total 4–8 h",
      tripReport:"CBD 50 mg: mild relaxation, no high. Can moderate THC's anxiety-inducing effects.",
      description:"Negative CB1 modulator. Antagonises some THC effects. Very low toxicity."
    },
    "THCP": {
      effets:["Intense euphoria", "Sedation", "Cognitive alteration"],
      dosage:{faible:"1–2 mg",modere:"2–5 mg",fort:"7–10 mg"},
      duree:"Onset 10–30 min | Total 4–8 h",
      tripReport:"THCP 3 mg: 30× more potent than THC. For non-habituated users: extreme disorienting effects.",
      description:"Tetrahydrocannabiphorol. CB1 affinity 33× > THC. Limited safety data."
    },
    "THCV": {
      effets:["Mild stimulation", "Anxiety relief", "Appetite reduction"],
      dosage:{faible:"2–5 mg",modere:"5–15 mg",fort:"20–30 mg"},
      duree:"Onset 5–15 min (smoked) | Total 2–4 h",
      tripReport:"THCV 10 mg: clear and stimulating, less sedating than THC. Reduces appetite.",
      description:"CB1 antagonist at low dose, CB1/CB2 agonist at high dose."
    },
    "HHC": {
      effets:["Euphoria", "Relaxation", "Mild cognitive alteration"],
      dosage:{faible:"3–6 mg",modere:"8–15 mg",fort:"20–35 mg"},
      duree:"Onset 15–30 min | Total 3–5 h",
      tripReport:"HHC 10 mg: similar to THC but 'clearer'. Good euphoria.",
      description:"Hexahydrocannabinol: hydrogenated THC, moderate CB1 agonist."
    },
    "HHC-P": {
      effets:["Strong euphoria", "Sedation", "Relaxation"],
      dosage:{faible:"2–3 mg",modere:"3–7 mg",fort:"8–15 mg"},
      duree:"Onset 10–25 min | Total 3–6 h",
      tripReport:"HHC-P 5 mg: clearly more potent than HHC. Comparable to THCP in intensity.",
      description:"Hexahydrocannabiphorol: strong CB1 agonist."
    },
    "THC (delta-8)": {
      effets:["Mild euphoria", "Relaxation", "Anxiety relief"],
      dosage:{faible:"5–10 mg",modere:"10–25 mg",fort:"40–60 mg"},
      duree:"Onset 15–45 min | Total 3–6 h",
      tripReport:"THC (delta-8) 15 mg: a milder THC effect, less anxiety-inducing. Possible chemical contaminants.",
      description:"Isomer of delta-9. The manufacturing process can leave dangerous residues."
    },
    "Delta-10 THC": {
      effets:["Mild euphoria", "Gentle stimulation", "Clarity"],
      dosage:{faible:"5–10 mg",modere:"10–25 mg",fort:"30–50 mg"},
      duree:"Onset 15–45 min | Total 3–5 h",
      tripReport:"Delta-10 (often sold as 'D10'): more stimulating and 'clear' than delta-9, less anxiety-inducing, weaker in intensity.",
      description:"THC isomer obtained by chemical conversion of CBD. The process can leave residues (acids, metal catalysts). Lower CB1 affinity than delta-9."
    },
    "CBC": {
      effets:["Anti-inflammatory", "Mild relaxation", "Entourage effect"],
      dosage:{faible:"10–25 mg",modere:"25–50 mg",fort:"50–100 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"CBC alone: no high. Mostly sold in flower as a legal alternative; the felt effect often comes from terpenes and the entourage effect rather than CBC itself.",
      description:"Cannabichromene: a natural, non-psychoactive cannabinoid. Acts mainly on TRPV1/TRPA1 receptors. Low CB1 affinity. Studied for inflammation. Legal."
    },
    "CBN": {
      effets:["Mild sedation", "Relaxation", "Drowsiness"],
      dosage:{faible:"2.5–5 mg",modere:"5–15 mg",fort:"15–30 mg"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"CBN 10 mg: mostly sedating, often used for sleep. Very weakly psychoactive.",
      description:"Cannabinol: a THC degradation product. Weak CB1 agonist. Low toxicity. Legal depending on formulation."
    },
    "CBG": {
      effets:["Focus", "Anti-inflammatory", "Mild relaxation"],
      dosage:{faible:"10–25 mg",modere:"25–50 mg",fort:"50–100 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"CBG 30 mg: non-intoxicating, a subtle effect sometimes described as clarifying. Well tolerated.",
      description:"Cannabigerol: the biosynthetic precursor of the other cannabinoids. Non-psychoactive. Studied (inflammation, antibacterial). Low toxicity."
    },
    "HHCH": {
      effets:["Powerful euphoria", "Sedation", "Marked cognitive alteration"],
      dosage:{faible:"1–3 mg",modere:"3–7 mg",fort:"8–15 mg"},
      duree:"Onset 15–35 min | Total 4–8 h",
      tripReport:"HHCH ~5 mg: 10–15× more potent than THC, longer effects. Disorientation common in non-habituated users.",
      description:"Hexahydrocannabihexol: hydrogenated version of THCH. Strong CB1 agonist. Almost no scientific record. Banned in France since 2024."
    },
    "HHC-O": {
      effets:["Intense euphoria", "Sedation", "Deep relaxation"],
      dosage:{faible:"2–4 mg",modere:"4–8 mg",fort:"10–18 mg"},
      duree:"Onset 20–45 min | Total 4–7 h",
      tripReport:"HHC-O 5 mg: HHC acetate, slower come-up but stronger than HHC. Uncertain pyrolysis when vaped.",
      description:"HHC-O-acetate: acetylated ester of HHC. Inhaled acetates raise a pulmonary toxicity concern (cf. vitamin E acetate). Banned in France."
    },
    "HHCP": {
      effets:["Very strong euphoria", "Heavy sedation", "Intense cognitive alteration"],
      dosage:{faible:"1–2 mg",modere:"2–5 mg",fort:"6–10 mg"},
      duree:"Onset 15–30 min | Total 5–9 h",
      tripReport:"HHCP 3 mg: among the most potent neo-cannabinoids sold, close to THCP. Very long effects.",
      description:"Hexahydrocannabiphorol: heptyl chain, very high CB1 affinity. Almost no safety data. Banned in France."
    },
    "THCB": {
      effets:["Euphoria", "Relaxation", "Altered perception"],
      dosage:{faible:"2–5 mg",modere:"5–12 mg",fort:"15–25 mg"},
      duree:"Onset 15–40 min | Total 3–6 h",
      tripReport:"THCB ~8 mg: close to THC, slightly faster. Butyl chain.",
      description:"Tetrahydrocannabutol: a butyl-chain THC analogue, present in trace amounts in cannabis. CB1 agonist. Banned in France since 2024."
    },
    "THCH": {
      effets:["Strong euphoria", "Sedation", "Cognitive alteration"],
      dosage:{faible:"1–3 mg",modere:"3–8 mg",fort:"10–18 mg"},
      duree:"Onset 15–35 min | Total 4–7 h",
      tripReport:"THCH ~5 mg: clearly more potent than THC (estimated ~10×). Long, sedating effects.",
      description:"Tetrahydrocannabihexol: hexyl chain, strong CB1 affinity. Very little human data. Banned in France."
    },
    "THCJD": {
      effets:["Powerful euphoria", "Relaxation", "Altered perception"],
      dosage:{faible:"2–4 mg",modere:"4–9 mg",fort:"10–18 mg"},
      duree:"Onset 15–40 min | Total 4–7 h",
      tripReport:"THCJD ~5 mg: presented as very potent (octyl chain), real data scarce.",
      description:"Tetrahydrocannabioctol: a long-alkyl-chain THC analogue. Poorly characterised pharmacological profile. Banned in France."
    },
    "H4CBD": {
      effets:["Anxiety relief", "Anti-inflammatory", "Relaxation"],
      dosage:{faible:"10–25 mg",modere:"25–60 mg",fort:"75–150 mg"},
      duree:"Onset 20–45 min | Total 4–8 h",
      tripReport:"H4CBD 40 mg: close to CBD, sometimes described as a bit more relaxing. No high.",
      description:"Hydrogenated CBD (tetrahydrocannabidiol). Non-psychoactive, increased affinity for some receptors. Limited data. Banned in France since 2024."
    },
    "H2CBD": {
      effets:["Mild anxiety relief", "Relaxation"],
      dosage:{faible:"15–30 mg",modere:"30–70 mg",fort:"80–150 mg"},
      duree:"Onset 20–45 min | Total 4–7 h",
      tripReport:"H2CBD 40 mg: a partially hydrogenated CBD analogue, non-psychoactive. Very little track record.",
      description:"Dihydrocannabidiol: does not convert to THC. Presumed non-psychoactive. Banned in France since 2024."
    },
    "CBDP": {
      effets:["Relaxation", "Mild anxiety relief"],
      dosage:{faible:"10–30 mg",modere:"30–60 mg",fort:"60–100 mg"},
      duree:"Onset 20–40 min | Total 4–6 h",
      tripReport:"CBDP 30 mg: a phorol analogue of CBD. Very limited data.",
      description:"Cannabidiphorol: a CBD analogue. Presumed non-psychoactive profile."
    },
    "10-OH-HHC": {
      effets:["Euphoria", "Relaxation", "Mild sedation"],
      dosage:{faible:"3–5 mg",modere:"5–12 mg",fort:"15–25 mg"},
      duree:"Onset 15–30 min | Total 3–5 h",
      tripReport:"10-OH-HHC: a slightly different profile from HHC, similar effects.",
      description:"Hydroxylated metabolite of HHC. Limited data."
    },
    "Cannabis CBD": {
      effets:["Anxiety relief", "Anti-inflammatory", "Relaxation"],
      dosage:{faible:"10–25 mg",modere:"25–75 mg",fort:"100–300 mg"},
      duree:"Onset 20–45 min | Total 4–8 h",
      tripReport:"CBD 50 mg: mild relaxation, no high. Can moderate THC's anxiety-inducing effects.",
      description:"Negative CB1 modulator. Antagonises some THC effects. Very low toxicity."
    },
    "MDPV": {
      effets:["Powerful euphoria", "Intense stimulation", "Psychosis"],
      dosage:{faible:"3–5 mg",modere:"5–10 mg",fort:"15–25 mg"},
      duree:"Onset 10–20 min | Total 3–5 h",
      tripReport:"MDPV 8 mg: 48 h redosing, psychosis.",
      description:"One of the most addictive known. Documented deaths."
    },
    "Méphédrone": {
      effets:["Euphoria", "Empathy", "Stimulation", "Increased libido"],
      dosage:{faible:"75–150 mg",modere:"150–200 mg",fort:"250–400 mg"},
      duree:"Onset 15–45 min | Total 2–4 h",
      tripReport:"Mephedrone 150 mg: MDMA-like but shorter. Compulsive redosing. Intense craving.",
      description:"4-MMC. DA/5-HT releaser. Cardiotoxic. Ultra-fast dependence. MDMA = hyperthermia."
    },
    "3-MMC": {
      effets:["Euphoria", "Empathy", "Stimulation", "Increased libido"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–400 mg"},
      duree:"Onset 20–45 min | Total 3–5 h",
      tripReport:"3-MMC 150 mg: redosing inevitable, hard comedown.",
      description:"Mephedrone substitute. Cardiotoxicity, hyperthermia."
    },
    "2-MMC": {
      effets:["Euphoria", "Stimulation", "Moderate empathy"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–400 mg"},
      duree:"Onset 20–40 min | Total 3–5 h",
      tripReport:"2-MMC 150 mg: compulsive redosing, hard comedown.",
      description:"Monoaminergic releaser. Fast dependence, cardiotoxicity."
    },
    "4-CMC": {
      effets:["Stimulation", "Euphoria", "Sociability"],
      dosage:{faible:"20–50 mg",modere:"50–120 mg",fort:"150 mg+"},
      duree:"Onset 20–45 min | Total 2–4 h",
      tripReport:"4-CMC (clephedrone): a cathinone between stimulation and empathy, weaker than mephedrone. Frequent redosing.",
      description:"Monoamine releaser/reuptake inhibitor. Possible nephrotoxicity. Cardiovascular risks."
    },
    "3-CMC": {
      effets:["Stimulation", "Euphoria", "Sociability"],
      dosage:{faible:"30–70 mg",modere:"70–150 mg",fort:"150 mg+"},
      duree:"Onset 20–45 min | Total 2–4 h",
      tripReport:"3-CMC (clophedrone): a stimulant cathinone close to 3-MMC, common after bans. Frequent redosing, hard comedown.",
      description:"Dopamine-noradrenaline inhibitor/releaser. Cardiac strain, dependence. Fast tolerance."
    },
    "Méthylone": {
      effets:["Empathy", "Euphoria", "Stimulation"],
      dosage:{faible:"100–150 mg",modere:"150–250 mg",fort:"250–350 mg"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"Methylone (bk-MDMA): an empathogen close to MDMA but shorter, more stimulating and less 'deep'. Frequent redosing, hyperthermia. Often sold as MDMA.",
      description:"Dopamine/noradrenaline > serotonin releaser (cathinone). Hyperthermia, cardiac strain. Moderate hydration, breaks."
    },
    "Eutylone": {
      effets:["Stimulation", "Euphoria", "Moderate empathy", "Insomnia"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"200 mg+"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"Eutylone (bk-EBDB): a very common cathinone, often sold as MDMA or 'molly'. More stimulating than empathogenic, marked insomnia, compulsive redosing. A cause of disappointing/anxious experiences mistaken for MDMA.",
      description:"Monoamine reuptake inhibitor. Prolonged insomnia, anxiety, cardiac strain. Test beforehand (often confused with MDMA)."
    },
    "Pentedrone": {
      effets:["Stimulation", "Euphoria", "Insomnia"],
      dosage:{faible:"30–60 mg",modere:"60–100 mg",fort:"130–200 mg"},
      duree:"Onset 15–30 min | Total 2–4 h",
      tripReport:"Pentedrone 80 mg: a 6 h redosing session with vasoconstriction.",
      description:"DAT/NET inhibitor. Very high abuse potential."
    },
    "Pentylone": {
      effets:["Stimulation", "Euphoria", "Redosing"],
      dosage:{faible:"30–60 mg",modere:"60–120 mg",fort:"120 mg+"},
      duree:"Onset 30–60 min | Total 3–6 h",
      tripReport:"Pentylone: a stimulant cathinone, often an adulterant of 'MDMA'/'molly'. Insomnia, anxiety, compulsive redosing.",
      description:"Monoamine reuptake inhibitor. Cardiac strain, insomnia. Frequently present in mixes."
    },
    "Alpha-PVP": {
      effets:["Powerful stimulation", "Euphoria", "Hypervigilance", "Compulsive redosing"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25 mg+"},
      duree:"Onset 10–30 min | Total 2–4 h",
      tripReport:"Alpha-PVP ('flakka') ~15 mg insufflated: a brutal cocaine/meth-type come-up. Compulsive redosing, agitation, paranoia, hyperthermia at high doses.",
      description:"DAT/NET inhibitor, weak serotonergic effect. Strong abuse liability. Publicised cases of agitated delirium. Fast tolerance."
    },
    "Alpha-PHP": {
      effets:["Intense stimulation", "Euphoria", "Compulsive redosing", "Insomnia"],
      dosage:{faible:"3–5 mg",modere:"5–15 mg",fort:"20 mg+"},
      duree:"Onset 10–30 min | Total 2–4 h (insufflated)",
      tripReport:"Alpha-PHP: successor to alpha-PVP (flakka), effects close to smoked meth but short, which drives compulsive redosing. Psychosis and delusions at high dose or in a binge.",
      description:"Dopamine/noradrenaline reuptake inhibitor (pyrrolidinophenone). Strong behavioural addiction, hyperthermia, cardiovascular risk. Limited toxicology data."
    },
    "NEP": {
      effets:["Stimulation", "Mild euphoria", "Focus"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50 mg+"},
      duree:"Onset 20–45 min | Total 3–5 h",
      tripReport:"NEP (N-ethyl-pentedrone): a stimulant cathinone close to pentedrone, often sold as a legal alternative. Frequent redosing, insomnia.",
      description:"Dopamine/noradrenaline reuptake inhibitor. Medium-duration stimulant. Cardiovascular and dependence risks."
    },
    "Hexen": {
      effets:["Stimulation", "Euphoria", "Sociability", "Redosing"],
      dosage:{faible:"5–15 mg",modere:"15–35 mg",fort:"40 mg+"},
      duree:"Onset 15–40 min | Total 2–4 h",
      tripReport:"Hexen (N-ethyl-hexedrone): a short-acting stimulant cathinone, close to MDPV in intensity. Compulsive redosing, hard comedown.",
      description:"DAT/NET inhibitor. Potent, brief stimulant. Hyperthermia and tachycardia at high doses. Behavioural dependence."
    },
    "4-FA": {
      effets:["Euphoria", "Stimulation", "Mild empathy"],
      dosage:{faible:"50–100 mg",modere:"100–150 mg",fort:"150–250 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"4-FA (4-fluoroamphetamine): between amphetamine and MDMA, social euphoria. Cardiovascular risks (blood-pressure spikes, reported stroke/cerebral haemorrhage cases). Avoid redosing.",
      description:"Dopamine-noradrenaline releaser/inhibitor + serotonin. Reported cerebral haemorrhage risk. Do not combine with stimulants/MAOI."
    },
    "2-FA": {
      effets:["Stimulation", "Focus", "Mild euphoria"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–80 mg"},
      duree:"Onset 30–60 min | Total 6–10 h",
      tripReport:"2-FA 30 mg: like a very strong coffee but more focused.",
      description:"2-Fluoroamphetamine. Cardiac risk. Insomnia."
    },
    "3-FA": {
      effets:["Stimulation", "Mild empathy", "Focus"],
      dosage:{faible:"15–25 mg",modere:"30–50 mg",fort:"70–100 mg"},
      duree:"Onset 30–60 min | Total 6–10 h",
      tripReport:"3-FA 40 mg: between amphetamine and MDMA, gentle empathy.",
      description:"Balanced monoaminergic releaser."
    },
    "4-FMA": {
      effets:["Stimulation", "Mild euphoria"],
      dosage:{faible:"40–80 mg",modere:"80–150 mg",fort:"150 mg+"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"4-FMA: a fluorinated amphetamine stimulant, more 'speed' than 4-FA. Limited data, cardiovascular risks.",
      description:"Dopamine/noradrenaline releaser. Cardiac caution, no stimulant combinations."
    },
    "Salvia divinorum": {
      effets:["Intense dissociation", "Reality distortions", "Merging with objects", "Loss of the body"],
      dosage:{faible:"dried leaves 0.25–0.5 g",modere:"5× extract: 0.1–0.2 g",fort:"pure salvinorin A: 200–500 µg (very potent)"},
      duree:"Onset <1 min (smoked) / 10 min (sublingual) | Total 5–20 min (smoked) / up to 2 h (sublingual)",
      tripReport:"Smoked salvia: an extremely fast, intense and unpredictable trip (uncontrollable laughter, merging with surroundings, total loss of bearings), thankfully brief. Always with a sober sitter, as motor control is lost.",
      description:"Salvinorin A: selective kappa-opioid agonist (≠ serotonergic psychedelics). The most potent known natural psychoactive. No notable toxicity or addiction, but frequent physical accidents (falls). Rare prolonged psychoses."
    },
    "Kava": {
      effets:["Relaxation", "Anxiety relief", "Sociability", "Oral numbness"],
      dosage:{faible:"1 spoon (~70 g root as a drink)",modere:"traditional social dose",fort:"several bowls (sedation, nausea)"},
      duree:"Onset 20–30 min | Total 2–4 h",
      tripReport:"Kava (Pacific drink): relaxation close to mild alcohol or a benzo, without losing clarity, with a numbing tongue. Enjoyed socially. Possible hepatotoxicity with heavy use or with alcohol.",
      description:"Kavalactones: GABA modulation. Anxiolytic sedative. Liver risk (especially extracts, alcohol, fragile liver). Potentiates alcohol and benzodiazepines."
    },
    "Khat": {
      effets:["Stimulation", "Mild euphoria", "Talkativeness", "Appetite suppression"],
      dosage:{faible:"a few fresh leaves",modere:"1 chewed bunch (~100–200 g)",fort:"prolonged use over several hours"},
      duree:"Onset 15–45 min | Total 3–6 h (prolonged chewing)",
      tripReport:"Khat: fresh leaves chewed for hours (Horn of Africa, Arabian Peninsula). Mild amphetamine-type stimulation, social euphoria. Insomnia, dental problems and dependence with daily use.",
      description:"Cathinone + cathine (natural amphetamines). Dopamine/noradrenaline release. Must be consumed fresh (cathinone degrades). Cardiovascular risks, psychological dependence."
    },
    "Kanna": {
      effets:["Mood elevation", "Anxiety relief", "Mild euphoria", "Sociability"],
      dosage:{faible:"50–100 mg",modere:"100–250 mg",fort:"250–500 mg+"},
      duree:"Onset 15–45 min | Total 1–3 h",
      tripReport:"Kanna (South Africa): chewed, snorted or as powder. A mild anxiolytic and slightly euphoric effect, sometimes empathogenic at higher dose. Combined with SSRIs: caution (theoretical serotonin syndrome).",
      description:"Mesembrine: serotonin reuptake inhibitor + PDE4 inhibitor. Mild effect. Avoid with SSRI/MAOI antidepressants."
    },
    "Lotus bleu": {
      effets:["Relaxation", "Mild euphoria", "Dreaminess", "Gentle sedation"],
      dosage:{faible:"tea 2–5 g",modere:"5–10 g (infusion/wine)",fort:"concentrated extracts"},
      duree:"Onset 20–45 min | Total 1–3 h",
      tripReport:"Blue lotus (Nymphaea caerulea): infused, smoked or steeped in wine. A gentle, slightly dreamlike relaxation, used in ancient Egypt. Subtle, sometimes disappointing effects.",
      description:"Aporphine + nuciferine (dopaminergic modulation). Mild relaxing effect. Low toxicity at usual doses."
    },
    "Bétel": {
      effets:["Stimulation", "Well-being", "Warmth", "Red salivation"],
      dosage:{faible:"1 quid",modere:"regular use through the day",fort:"chronic use"},
      duree:"Onset 5–15 min | Total 1–3 h",
      tripReport:"Areca/betel nut: chewed in Southeast Asia, a mild stimulant and euphoriant. Stains the mouth red. Chronic use: strong addiction and oral-pharyngeal cancers.",
      description:"Arecoline: cholinergic agonist. Stimulant. Proven carcinogen (oral cavity) with chronic use. Marked dependence."
    },
    "Muscade": {
      effets:["Sedation", "At high dose: delirium, hallucinations", "Dry mouth", "Nausea"],
      dosage:{faible:"non-psychoactive (spice)",modere:"5–10 g (10–20 g powder)",fort:"20 g+ (unpleasant delirium, dangerous)"},
      duree:"Onset 3–6 h (very slow) | Total 12–48 h",
      tripReport:"Nutmeg at high dose: a long anticholinergic delirium, often very unpleasant (nausea, dry mouth, tachycardia, confusion, a 2-day hangover). Rarely repeated.",
      description:"Myristicin + elemicin (anticholinergic and weakly psychedelic effects). Deceptive very slow onset. Marked discomfort, risk at high dose."
    },
    "Absinthe / Armoise": {
      effets:["Intoxication", "Effect described as 'clear'", "Relaxation"],
      dosage:{faible:"a measured glass of absinthe",modere:"social use",fort:"heavy drinking"},
      duree:"Onset like alcohol | Total like alcohol",
      tripReport:"Absinthe: the effect comes above all from the alcohol (often 50–70%). The thujone from wormwood is present at too low a dose for the mythical 'hallucinogenic' effects. The risks are those of strong alcohol.",
      description:"Thujone (wormwood/Artemisia): GABA antagonist at high dose (convulsant), but modern amounts are low. The real danger remains the alcohol."
    },
    "Éphédra": {
      effets:["Stimulation", "Energy", "Appetite suppression", "Bronchodilation"],
      dosage:{faible:"ephedrine 8–15 mg",modere:"15–30 mg",fort:"50 mg+ (cardiac risk)"},
      duree:"Onset 30–60 min | Total 3–6 h",
      tripReport:"Ephedra (ma huang): a stimulant and appetite suppressant, formerly in 'fat-burner' products. Serious cardiovascular risks (hypertension, arrhythmias, stroke), especially with caffeine.",
      description:"Ephedrine/pseudoephedrine: adrenergic agonists. Hypertension, tachycardia. Dangerous for the heart, interactions with stimulants and MAOI."
    },
    "Wachuma (San Pedro)": {
      effets:["Visual hallucinations", "Introspection", "Empathy", "Nausea (come-up)"],
      dosage:{faible:"~15–25 cm of fresh cactus",modere:"25–50 cm (≈ mescaline 200–400 mg)",fort:"long cactus / extract"},
      duree:"Onset 1–2 h | Total 8–14 h",
      tripReport:"San Pedro/Wachuma: a mescaline cactus, a long, gentle psychedelic trip, often described as warm and 'earthy'. Strong nausea on the come-up. Setting and a sitter recommended.",
      description:"Mescaline (phenethylamine, 5-HT2A agonist). Like peyote but more accessible. MAOI/SSRI interactions. Cardiovascular precautions."
    },
    "Peyotl": {
      effets:["Hallucinations", "Deep introspection", "Empathy", "Nausea"],
      dosage:{faible:"3–4 fresh buttons",modere:"5–8 buttons (≈ mescaline 200–400 mg)",fort:"10+ buttons"},
      duree:"Onset 1–2 h | Total 8–12 h",
      tripReport:"Peyote: a small sacred cactus (North America), a long mescaline trip. Very bitter, frequent nausea. A threatened plant, sacred to several peoples: use respectfully.",
      description:"Mescaline. 5-HT2A agonist. MAOI/SSRI interactions, cardiac precautions. Protected species, very slow growth."
    },
    "Champignons Amanita muscaria": {
      effets:["Dreamlike sedation", "Distortions", "Micro-sleeps", "Delirium"],
      dosage:{faible:"1 g dried (caution)",modere:"5–10 g dried",fort:"10 g+ (delirium, nausea)"},
      duree:"Onset 30–120 min | Total 4–10 h",
      tripReport:"Fly agaric: a dreamy/sedating effect, very different from psilocybe mushrooms (it is not a psychedelic). Nausea, confusion, micro-sleeps. Must be decarboxylated; ibotenic acid is neurotoxic.",
      description:"Muscimol (GABA-A agonist) + ibotenic acid (neurotoxic, converted to muscimol). Not to be confused with the deadly amanitas. Highly variable dosing."
    },
    "Belladone": {
      effets:["Delirium", "Hallucinations", "Mydriasis", "Tachycardia"],
      dosage:{faible:"any dose is risky",modere:"narrow therapeutic/toxic margin",fort:"coma, death possible"},
      duree:"Onset 1–2 h | Total 12–48 h",
      tripReport:"Belladonna: a very dangerous anticholinergic deliriant (like Datura). Unpleasant delirium, fever, blurred vision, risk of coma and death. Tiny margin between effective and lethal dose.",
      description:"Atropine, scopolamine, hyoscyamine: anticholinergics. Severe cardiac and neurological toxicity. To be treated as a poison."
    },
    "Jusquiame": {
      effets:["Delirium", "Hallucinations", "Sedation", "Mydriasis"],
      dosage:{faible:"any dose is risky",modere:"narrow toxic margin",fort:"coma, death possible"},
      duree:"Onset 1–2 h | Total 8–24 h",
      tripReport:"Henbane: another deliriant nightshade (Datura/belladonna family). Dangerous and unpleasant anticholinergic effects. Life-threatening. To be avoided.",
      description:"Scopolamine, hyoscyamine, atropine. Toxic deliriant. No reliable safety margin."
    },
    "Datura": {
      effets:["Total delirium", "Real hallucinations", "Hyperthermia", "Amnesia"],
      dosage:{faible:"unknown",modere:"unknown",fort:"1 flower = death possible"},
      duree:"Onset 30–120 min | Total 12–48 h",
      tripReport:"Datura: impossible to dose. Not a pretty trip — real delirium, dangerous acts. Systematic hospitalisations.",
      description:"Scopolamine/atropine. No pleasant trip. Near-systematic hospitalisation. Death common."
    },
    "Yopo / Anadenanthera": {
      effets:["Intense hallucinations", "Visions", "Nausea", "Brief effect"],
      dosage:{faible:"a pinch of insufflated powder",modere:"ritual dose (snuffed)",fort:"high insufflated dose"},
      duree:"Onset 1–5 min | Total 30–90 min",
      tripReport:"Yopo: an insufflated seed powder (Amazon/Orinoco), rich in bufotenin/DMT. A brutal, physical come-up (strong pressure, nausea), intense and short visions. Ritual use with preparation.",
      description:"Bufotenin + DMT + 5-MeO-DMT (5-HT2A agonists). Marked cardiovascular effects. Often combined with MAO inhibitors: risky interactions."
    },
    "Crapaud du Colorado (5-MeO-DMT)": {
      effets:["Ego dissolution", "Mystical experience", "Very intense and brief effect"],
      dosage:{faible:"2–5 mg vaporised",modere:"5–15 mg",fort:"20 mg+"},
      duree:"Onset <1 min | Total 15–40 min",
      tripReport:"Bufo alvarius venom / 5-MeO-DMT: one of the most intense psychedelics, total ego dissolution within seconds. Very short but overwhelming. Risks: accidents, distress, lethal MAOI interactions.",
      description:"5-MeO-DMT (5-HT1A/2A agonist). Different from classic DMT. A sitter is essential. Lethal combined with MAOIs. Soft surfaces, never alone."
    },
    "5-MeO-DMT (synthétique)": {
      effets:["Ego dissolution", "Mystical experience", "Brief and intense effect"],
      dosage:{faible:"2–5 mg vaporised",modere:"5–12 mg",fort:"15 mg+"},
      duree:"Onset <1 min | Total 15–40 min",
      tripReport:"5-MeO-DMT: one of the most powerful psychedelics, total ego dissolution within seconds. Very short but overwhelming. Lethal with an MAOI. A sitter and a soft surface are essential.",
      description:"5-HT1A/2A agonist. Different from the visual DMT. Potentially fatal MAOI interaction. Distress/blackout common."
    },
    "LSA": {
      effets:["Hallucinations", "Sedation", "Introspection", "Nausea"],
      dosage:{faible:"25–75 µg",modere:"75–150 µg",fort:"200–400 µg"},
      duree:"Onset 30–90 min | Total 8–12 h",
      tripReport:"LSA 100 µg: a sedating trip. Significant nausea.",
      description:"Found in Morning Glory seeds. Less potent than LSD."
    },
    "Muscimol": {
      effets:["Dreamlike sedation", "Distortions", "Deep relaxation", "Mild delirium"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"10–15 mg+"},
      duree:"Onset 30–120 min | Total 4–10 h",
      tripReport:"Muscimol (fly agaric) ~5 mg: a dreamy state, heaviness, sometimes nausea. At high dose: confusion, micro-sleeps, delirium. Very variable between people.",
      description:"Potent GABA-A agonist (≠ cannabinoid). The active principle of Amanita muscaria, sold as gummies. The associated ibotenic acid is neurotoxic and converted to muscimol by decarboxylation. Frequent nausea; caution about the real dosing of products."
    },
    "Modafinil": {
      effets:["Wakefulness", "Focus", "Reduced drowsiness"],
      dosage:{faible:"50–100 mg",modere:"200 mg",fort:"400 mg"},
      duree:"Onset 45–90 min | Total 12–15 h",
      tripReport:"Modafinil 200 mg: 12 h of pure focus.",
      description:"Eugeroic. Rare hepatotoxicity. Reduced birth-control efficacy."
    },
    "Adrafinil": {
      effets:["Wakefulness", "Focus", "Reduced fatigue"],
      dosage:{faible:"150–300 mg",modere:"300–600 mg",fort:"600–900 mg"},
      duree:"Onset 60–90 min | Total 8–12 h",
      tripReport:"Adrafinil 300 mg: increased alertness. No euphoria.",
      description:"Modafinil prodrug. Hepatotoxic with regular use."
    },
    "Armodafinil": {
      effets:["Prolonged wakefulness", "Focus", "Reduced drowsiness"],
      dosage:{faible:"50–100 mg",modere:"150 mg",fort:"200–300 mg"},
      duree:"Onset 45–90 min | Total 10–15 h",
      tripReport:"Armodafinil 150 mg: 14 h of work without fatigue. No euphoria.",
      description:"R-enantiomer of modafinil. Long-term liver risk."
    },
    "Méthylphénidate": {
      effets:["Stimulation", "Focus", "Appetite reduction", "Mild euphoria"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"60–100 mg"},
      duree:"Onset 20–40 min | Total 3–5 h",
      tripReport:"Methylphenidate 30 mg: laser focus. Dependence if used recreationally.",
      description:"Ritalin: DAT/NET inhibitor. Cardiotoxic. MAOIs contraindicated."
    },
    "Ethylphénidate": {
      effets:["Stimulation", "Euphoria", "Focus", "Insomnia"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–80 mg"},
      duree:"Onset 20–40 min | Total 4–8 h",
      tripReport:"Ethylphenidate 30 mg: intense cocaine-like euphoria but longer.",
      description:"DAT inhibitor. Cocaine-like profile. Insufflation = serious vascular risk."
    },
    "Piracétam": {
      effets:["Memory enhancement", "Verbal fluency", "Neuroprotection"],
      dosage:{faible:"1600–2400 mg",modere:"2400–4800 mg",fort:"6400–9600 mg"},
      duree:"Onset 1–2 h | Total 5–8 h",
      tripReport:"Piracetam 4800 mg: mental improvement after 1 week. Take with choline.",
      description:"Pioneer racetam. Take with choline."
    },
    "Aniracétam": {
      effets:["Memory enhancement", "Reduced anxiety", "Mild stimulation"],
      dosage:{faible:"400–750 mg",modere:"750–1500 mg",fort:"2000–3000 mg"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"Aniracetam 750 mg: reduced social anxiety, mental clarity.",
      description:"AMPA and cholinergic modulator. Fat-soluble."
    },
    "Oxiracétam": {
      effets:["Mild stimulation", "Memory enhancement", "Mental clarity"],
      dosage:{faible:"400–800 mg",modere:"800–1600 mg",fort:"2000–3000 mg"},
      duree:"Onset 30–60 min | Total 6–8 h",
      tripReport:"Oxiracetam 1200 mg: mild stimulation, improved verbal fluency.",
      description:"Mildly stimulating racetam."
    },
    "Phénylpiracétam": {
      effets:["Mild stimulation", "Focus", "Athletic enhancement"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–400 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"Phenylpiracetam 150 mg: better focus and physical endurance.",
      description:"Banned in competition (WADA). Fast tolerance."
    },
    "Noopept": {
      effets:["Memory enhancement", "Neuroprotection", "Mild anxiety relief"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"30–40 mg"},
      duree:"Onset 20–30 min | Total 3–5 h",
      tripReport:"Noopept 10 mg: mild improvement in memorisation.",
      description:"Piracetam analogue 1000× more potent. Stimulates NGF and BDNF."
    },
    "5-HTP": {
      effets:["Mood improvement", "Reduced anxiety", "Sleep aid"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"300–500 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"5-HTP 200 mg: mood improvement. Useful post-MDMA (D+3).",
      description:"Never combine with MAOIs or SSRIs. Serotonin syndrome."
    },
    "Mélatonine": {
      effets:["Sleep induction", "Circadian rhythm regulation"],
      dosage:{faible:"0.5–1 mg",modere:"2–5 mg",fort:"10–20 mg"},
      duree:"Onset 20–40 min | Total 4–8 h",
      tripReport:"Melatonin 1 mg: eased onset of sleep. More is not better.",
      description:"Physiological hormone. Low risk."
    },
    "Diphenhydramine": {
      effets:["Sedation", "At high dose: delirium, hallucinations"],
      dosage:{faible:"25–50 mg",modere:"100–200 mg (sedative)",fort:"300 mg+ (dangerous delirium)"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"Diphenhydramine (Benadryl): sedative at a normal dose; at high dose, a very unpleasant and dangerous anticholinergic delirium (tachycardia, hyperthermia, seizures). Not a sought-after 'trip'.",
      description:"H1 antagonist + central anticholinergic. Overdose: delirium, urinary retention, arrhythmias, seizures. Potentiates depressants."
    },
    "Prométhazine": {
      effets:["Sedation", "Drowsiness", "Opioid potentiation"],
      dosage:{faible:"12.5–25 mg",modere:"25–50 mg",fort:"75 mg+"},
      duree:"Onset 20–60 min | Total 4–8 h",
      tripReport:"Promethazine: a sedating antihistamine, a component of 'lean' (codeine-promethazine syrup). Reinforces the sedation and respiratory depression of opioids.",
      description:"H1 antagonist + anticholinergic. Dangerous combined with opioids (lean). Risk of long QT and respiratory depression."
    },
    "Hydroxyzine": {
      effets:["Sedation", "Anxiety relief", "Drowsiness"],
      dosage:{faible:"25 mg",modere:"50–100 mg",fort:"150 mg+"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"Hydroxyzine (Atarax): a sedating antihistamine used for anxiety and itching. Little euphoria. Risk of QT prolongation at high dose.",
      description:"H1 antagonist + anxiolytic effect. Potentiates other depressants. Overdose: sedation, tachycardia, arrhythmias."
    },
    "Paracétamol": {
      effets:["Analgesia", "Antipyretic"],
      dosage:{faible:"500 mg",modere:"1000 mg",fort:"4000 mg/day (hepatotoxic)"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"Paracetamol 1000 mg: effective but hepatotoxic in overdose or with alcohol.",
      description:"Hepatic metabolism. Alcohol → severe hepatotoxicity. Overdose = fatal liver failure."
    },
    "Ibuprofène": {
      effets:["Analgesia", "Anti-inflammatory", "Antipyretic"],
      dosage:{faible:"200–400 mg",modere:"400–600 mg",fort:"800–1200 mg"},
      duree:"Onset 30–60 min | Total 6–8 h",
      tripReport:"Ibuprofen 400 mg: an effective painkiller. Gastric ulcer with chronic use.",
      description:"NSAID: COX inhibitor. Ulcers, nephrotoxicity. Not advised with anticoagulants."
    },
    "25I-NBOMe": {
      effets:["Powerful hallucinations", "Agitation", "Hyperthermia"],
      dosage:{faible:"200–400 µg",modere:"500–800 µg",fort:"1 mg+"},
      duree:"Onset 20–60 min | Total 5–10 h",
      tripReport:"25I-NBOMe 600 µg: hospitalised for tachycardia. This substance kills.",
      description:"Extremely potent NBOMe. Many deaths: seizures, arrhythmias."
    },
    "25C-NBOMe": {
      effets:["Intense hallucinations", "Vasoconstriction", "Agitation"],
      dosage:{faible:"200–400 µg",modere:"400–700 µg",fort:"1 mg+"},
      duree:"Onset 20–60 min | Total 6–8 h",
      tripReport:"25C-NBOMe 500 µg: seizures reported at high dose.",
      description:"Synthetic NBOMe. Severe cardiovascular effects."
    },
    "25B-NBOMe": {
      effets:["Hallucinations", "Tachycardia", "Vasoconstriction"],
      dosage:{faible:"200–400 µg",modere:"400–700 µg",fort:"1–1.5 mg"},
      duree:"Onset 20–60 min | Total 5–8 h",
      tripReport:"25B-NBOMe 500 µg: muscle cramps and a racing heart.",
      description:"NBOMe: documented deaths. Never inject. Tachycardia → fatal arrhythmia."
    },
    "DOB": {
      effets:["Hallucinations", "Stimulation", "Very long effects", "Vasoconstriction"],
      dosage:{faible:"1–2 mg",modere:"2–3 mg",fort:"3–5 mg"},
      duree:"Onset 1.5–3 h | Total 12–24 h",
      tripReport:"DOB: an extremely potent psychedelic (active at the milligram) and very long. Marked vasoconstriction (risk to the extremities). Often sold on blotter in place of LSD → overdose if taken as LSD.",
      description:"Partial 5-HT2A agonist, long half-life. Severe vasoconstriction possible (ischaemia). Dose by mg, never as a presumed-LSD blotter."
    },
    "DOC": {
      effets:["Hallucinations", "Strong stimulation", "Very long effects"],
      dosage:{faible:"1–3 mg",modere:"3–5 mg",fort:"5–8 mg"},
      duree:"Onset 1.5–3 h | Total 12–20 h",
      tripReport:"DOC: a chlorinated DOB analogue, a very long stimulating psychedelic. Often on blotter. Marked vasoconstriction and cardiac stimulation.",
      description:"5-HT2A agonist, long half-life. Cardiovascular and vasoconstrictor risks. Precise mg dosing."
    },
    "DOI": {
      effets:["Hallucinations", "Stimulation", "Very long effects"],
      dosage:{faible:"1–3 mg",modere:"3–5 mg",fort:"5–7 mg"},
      duree:"Onset 1.5–3 h | Total 12–30 h",
      tripReport:"DOI: an iodinated DOx, very long and potent. Used mostly in research (5-HT2A ligand), sometimes sold on blotter.",
      description:"Potent 5-HT2A agonist. Extremely long effects, vasoconstriction. Dose by mg."
    },
    "AMT": {
      effets:["Hallucinations", "Stimulation", "Empathy", "Very long effects", "Nausea"],
      dosage:{faible:"15–25 mg",modere:"25–40 mg",fort:"40–60 mg"},
      duree:"Onset 2–4 h | Total 12–24 h",
      tripReport:"AMT (alpha-methyltryptamine): an extremely long psychedelic-stimulant. Very slow come-up (redosing risk), nausea. It is also a weak MAOI → dangerous food/drug interactions.",
      description:"Monoamine releaser + 5-HT2A agonist + MAOI activity. Risky interactions (tyramine, SSRIs, other serotonergics). Exhausting duration."
    },
    "4-HO-MET": {
      effets:["Colourful hallucinations", "Euphoria", "Laughter"],
      dosage:{faible:"10–15 mg",modere:"15–25 mg",fort:"25–40 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"4-HO-MET (metocin): a psychedelic close to psilocin, often described as joyful and colourful, shorter. Easy to handle, but still a potent psychedelic.",
      description:"5-HT2A agonist. Psilocin analogue. Classic psychedelic precautions (psychiatric history, lithium)."
    },
    "4-HO-MiPT": {
      effets:["Hallucinations", "Bodily euphoria", "Empathy"],
      dosage:{faible:"10–20 mg",modere:"20–30 mg",fort:"30–45 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"4-HO-MiPT (miprocin): a euphoric, very tactile/bodily tryptamine, marked visuals. Liked for its warmth. Still a serious psychedelic.",
      description:"5-HT2A agonist. Psilocin analogue. Classic precautions."
    },
    "DPT": {
      effets:["Intense hallucinations", "Spiritual depth", "Confusion"],
      dosage:{faible:"20–50 mg",modere:"75–125 mg",fort:"150–250 mg"},
      duree:"Onset 5–20 min (inhaled) | Total 3–5 h",
      tripReport:"DPT 80 mg smoked: similar to DMT but more terrifying.",
      description:"Potent 5-HT2A agonist. MAOI potentiates → unpredictable duration."
    },
    "DiPT": {
      effets:["Auditory distortion", "Mild hallucinations", "Introspection"],
      dosage:{faible:"10–20 mg",modere:"25–40 mg",fort:"50–80 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"DiPT 30 mg: a unique distortion of pitch.",
      description:"5-HT2A agonist. Auditory effects only."
    },
    "MET": {
      effets:["Hallucinations", "Euphoria", "Mild stimulation"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–80 mg"},
      duree:"Onset 45–75 min | Total 4–7 h",
      tripReport:"MET 30 mg: a short, colourful trip.",
      description:"5-HT2A agonist."
    },
    "MiPT": {
      effets:["Mild hallucinations", "Empathy", "Mild stimulation"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25–40 mg"},
      duree:"Onset 30–60 min | Total 5–7 h",
      tripReport:"MiPT 15 mg: close to psilocybin but more empathic.",
      description:"5-HT2A/1A agonist."
    },
    "ETH-LAD": {
      effets:["Hallucinations", "Euphoria", "Mild stimulation"],
      dosage:{faible:"50–75 µg",modere:"100–150 µg",fort:"200–300 µg"},
      duree:"Onset 45–90 min | Total 8–12 h",
      tripReport:"ETH-LAD 120 µg: more sensual than LSD, colourful visuals.",
      description:"Ethyl analogue of LSD. Lithium forbidden."
    },
    "PRO-LAD": {
      effets:["Hallucinations", "Euphoria", "Mild stimulation"],
      dosage:{faible:"50–100 µg",modere:"150–200 µg",fort:"250–400 µg"},
      duree:"Onset 45–90 min | Total 8–12 h",
      tripReport:"PRO-LAD 175 µg: similar to LSD, slightly stimulating.",
      description:"5-HT2A agonist. Same precautions as LSD."
    },
    "Mescaline (sulfate/HCl)": {
      effets:["Colourful hallucinations", "Empathy", "Introspection", "Nausea"],
      dosage:{faible:"100–200 mg",modere:"200–400 mg",fort:"400–700 mg"},
      duree:"Onset 1–2 h | Total 8–12 h",
      tripReport:"Pure mescaline (extracted or synthetic powder): a warm, visual classic psychedelic, with a nauseous come-up. 'Softer' and more bodily than LSD. MAOI/SSRI interactions.",
      description:"5-HT2A agonist. Physiologically well tolerated but cardiac precautions. High doses by weight (a low-potency substance per mg)."
    },
    "Escaline": {
      effets:["Hallucinations", "Empathy", "Euphoria"],
      dosage:{faible:"15–25 mg",modere:"30–50 mg",fort:"60–100 mg"},
      duree:"Onset 60–120 min | Total 8–14 h",
      tripReport:"Escaline 40 mg: close to mescaline but shorter.",
      description:"Ethoxy-mescaline. MAOI interactions."
    },
    "Proscaline": {
      effets:["Hallucinations", "Empathy", "Euphoria"],
      dosage:{faible:"20–30 mg",modere:"40–60 mg",fort:"70–100 mg"},
      duree:"Onset 60–90 min | Total 8–12 h",
      tripReport:"Proscaline 50 mg: similar to mescaline, slightly less intense.",
      description:"Propoxy-mescaline. 5-HT2A agonist."
    },
    "Méthallylescaline": {
      effets:["Hallucinations", "Empathy", "Very long duration"],
      dosage:{faible:"40–60 mg",modere:"60–100 mg",fort:"120–160 mg"},
      duree:"Onset 60–120 min | Total 12–18 h",
      tripReport:"Methallylescaline 80 mg: a surprising 16 h trip.",
      description:"Record duration among the phenethylamines."
    },
    "Allylescaline": {
      effets:["Hallucinations", "Empathy", "Mild euphoria"],
      dosage:{faible:"15–25 mg",modere:"30–45 mg",fort:"50–80 mg"},
      duree:"Onset 60–120 min | Total 8–14 h",
      tripReport:"Allylescaline 35 mg: similar to mescaline but shorter.",
      description:"5-HT2A agonist. Limited safety data."
    },
    "PMA": {
      effets:["Hyperthermia", "Tachycardia", "Weak euphoria"],
      dosage:{faible:"unknown",modere:"unknown",fort:"50–100 mg (lethal)"},
      duree:"Onset 2–3 h | Total 8–12 h",
      tripReport:"PMA sold as MDMA. Delayed onset → redosing → death. Many festival deaths.",
      description:"Para-methoxyamphetamine. 5-HT releaser without DA → lethal hyperthermia. Deceptive onset."
    },
    "Clonidine": {
      effets:["Sedation", "Anxiety relief", "Craving reduction", "Hypotension"],
      dosage:{faible:"0.1 mg",modere:"0.2–0.3 mg",fort:"0.4–0.6 mg"},
      duree:"Onset 30–60 min | Total 6–8 h",
      tripReport:"Clonidine 0.2 mg: helps with opioid withdrawal. Alcohol = severe hypotension.",
      description:"Alpha-2 agonist. Used in opioid/alcohol withdrawal. Alcohol = fainting."
    },
    "2-FEA": {
      effets:["Empathy", "Mild euphoria", "Stimulation"],
      dosage:{faible:"50–80 mg",modere:"80–120 mg",fort:"150–200 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"2-FEA 100 mg: a gentle entactogen, presumed less neurotoxic.",
      description:"Synthetic entactogen, moderate serotonin releaser. Serotonergic risk."
    },
    "2-FMA": {
      effets:["Focus", "Stimulation", "Wakefulness"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25–40 mg"},
      duree:"Onset 30–60 min | Total 8–12 h",
      tripReport:"2-FMA 15 mg: an effective study stimulant. Causes insomnia if taken late.",
      description:"Long stimulant, a productivity nootropic. Cardiovascular risk."
    },
    "25B-NBOH": {
      effets:["Visual hallucinations", "Euphoria", "Tachycardia"],
      dosage:{faible:"250–500 µg",modere:"500–750 µg",fort:"1–1.5 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"25B-NBOH 700 µg: intense visuals. Marked vasoconstriction.",
      description:"Very potent 5-HT2A agonist. Documented seizures."
    },
    "2M2B": {
      effets:["Sedation", "Disinhibition", "Alcohol-like euphoria", "Amnesia"],
      dosage:{faible:"0.5–1 ml",modere:"1–2 ml",fort:"2–3 ml"},
      duree:"Onset 15–30 min | Total 2–4 h",
      tripReport:"2M2B 1.5 ml: very fast blackout, a ridiculous safety margin.",
      description:"Tertiary alcohol. Coma at low dose. Fatal synergy with benzos/opioids."
    },
    "3-FEA": {
      effets:["Empathy", "Euphoria", "Stimulation"],
      dosage:{faible:"60–100 mg",modere:"100–150 mg",fort:"180–250 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"3-FEA 120 mg: more empathogenic than stimulating.",
      description:"Entactogen, strong serotonin releaser. Serotonergic risk."
    },
    "3-FMA": {
      effets:["Stimulation", "Focus", "Wakefulness"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"25–40 mg"},
      duree:"Onset 30–60 min | Total 8–14 h",
      tripReport:"3-FMA 15 mg: a clean stimulant, very effective for productivity.",
      description:"Dominant dopaminergic/noradrenergic profile."
    },
    "3-FPM": {
      effets:["Stimulation", "Focus", "Mild euphoria"],
      dosage:{faible:"20–40 mg",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 20–45 min | Total 6–10 h",
      tripReport:"3-FPM 60 mg: similar to Ritalin but more euphoric.",
      description:"Monoamine reuptake inhibitor. Unknown neurotoxicity."
    },
    "3-MEC": {
      effets:["Stimulation", "Euphoria", "Sociability"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–350 mg"},
      duree:"Onset 20–40 min | Total 3–5 h",
      tripReport:"3-MEC 150 mg: an intense rush, compulsive redosing.",
      description:"Cathinone. Cardiotoxicity, psychosis."
    },
    "6-APB": {
      effets:["Euphoria", "Empathy", "Stimulation"],
      dosage:{faible:"60–80 mg",modere:"80–120 mg",fort:"150–200 mg"},
      duree:"Onset 45–90 min | Total 6–10 h",
      tripReport:"6-APB 100 mg: close to MDMA but more psychedelic.",
      description:"Benzofuran analogue of MDMA. Serotonergic risk."
    },
    "Butylone": {
      effets:["Euphoria", "Empathy", "Stimulation"],
      dosage:{faible:"50–100 mg",modere:"100–175 mg",fort:"200–300 mg"},
      duree:"Onset 20–45 min | Total 4–6 h",
      tripReport:"Butylone 120 mg: a short entactogen, fast come-up.",
      description:"Monoamine releaser. Frequent redosing → toxicity."
    },
    "Desoxypipradrol": {
      effets:["Intense stimulation", "Euphoria", "Prolonged insomnia"],
      dosage:{faible:"2–5 mg",modere:"5–10 mg",fort:"10–15 mg"},
      duree:"Onset 30–60 min | Total 16–24 h",
      tripReport:"Desoxypipradrol 7 mg: 20 h with no sleep. Psychosis after 3 days.",
      description:"2-DPMP. Extremely long duration, stimulant psychosis."
    },
    "EPT": {
      effets:["Hallucinations", "Empathy", "Mild euphoria"],
      dosage:{faible:"10–20 mg",modere:"25–40 mg",fort:"50–75 mg"},
      duree:"Onset 30–60 min | Total 5–7 h",
      tripReport:"EPT 30 mg: a gentle, empathic trip.",
      description:"5-HT2A agonist. Little safety data."
    },
    "ETH-CAT": {
      effets:["Stimulation", "Mild euphoria", "Insomnia"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"250–350 mg"},
      duree:"Onset 20–40 min | Total 4–6 h",
      tripReport:"ETH-CAT 150 mg: frequent redosing, rising blood pressure.",
      description:"Monoamine releaser."
    },
    "Ethylone": {
      effets:["Euphoria", "Empathy", "Stimulation"],
      dosage:{faible:"100–150 mg",modere:"150–225 mg",fort:"250–350 mg"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"Ethylone 180 mg: MDMA light, notable crash.",
      description:"Moderate monoamine releaser."
    },
    "Hexédrone": {
      effets:["Stimulation", "Euphoria", "Vasoconstriction"],
      dosage:{faible:"30–60 mg",modere:"60–100 mg",fort:"120–200 mg"},
      duree:"Onset 15–30 min | Total 2–4 h",
      tripReport:"Hexedrone 80 mg: a short rush, intense craving.",
      description:"DAT/NET inhibitor. Compulsive use."
    },
    "Isopropylphénidate": {
      effets:["Stimulation", "Focus", "Mild euphoria"],
      dosage:{faible:"10–20 mg",modere:"20–40 mg",fort:"50–80 mg"},
      duree:"Onset 20–40 min | Total 4–8 h",
      tripReport:"Isopropylphenidate 25 mg: less euphoric than methylphenidate.",
      description:"DAT/NET inhibitor. A slightly shorter Ritalin profile."
    },
    "LSM-775": {
      effets:["Mild hallucinations", "Euphoria", "Introspection"],
      dosage:{faible:"75–150 µg",modere:"200–350 µg",fort:"400–600 µg"},
      duree:"Onset 60–90 min | Total 6–8 h",
      tripReport:"LSM-775 250 µg: softer and shorter than LSD.",
      description:"Lysergol methyl ester. 5-HT2A agonist."
    },
    "LSZ": {
      effets:["Hallucinations", "Mild stimulation", "Euphoria"],
      dosage:{faible:"50–100 µg",modere:"100–200 µg",fort:"250–400 µg"},
      duree:"Onset 60–90 min | Total 8–10 h",
      tripReport:"LSZ 150 µg: LSD-like with mild bodily sedation.",
      description:"Potent LSD analogue. Similar profile."
    },
    "Lisdexamfétamine": {
      effets:["Stimulation", "Focus", "Appetite reduction"],
      dosage:{faible:"20–30 mg",modere:"50–70 mg",fort:"90–120 mg"},
      duree:"Onset 60–90 min | Total 10–14 h",
      tripReport:"Lisdexamfetamine 50 mg: a long-acting stimulant, effective for ADHD.",
      description:"Vyvanse: d-amphetamine prodrug. MAOIs contraindicated."
    },
    "MCPP": {
      effets:["Anxiety", "Mild stimulation", "Nausea"],
      dosage:{faible:"20–40 mg",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 30–60 min | Total 5–7 h",
      tripReport:"MCPP 60 mg: anxiety and nausea. Not very recreational.",
      description:"A contaminant found in cut ecstasy."
    },
    "MDA": {
      effets:["Euphoria", "Empathy", "Mild hallucinations"],
      dosage:{faible:"60–80 mg",modere:"80–120 mg",fort:"150–200 mg"},
      duree:"Onset 45–90 min | Total 6–10 h",
      tripReport:"MDA 100 mg: more hallucinatory than MDMA.",
      description:"Precursor of MDMA. More neurotoxic. Avoid MAOIs."
    },
    "MDAI": {
      effets:["Empathy", "Mild euphoria", "Socialisation"],
      dosage:{faible:"100–150 mg",modere:"150–250 mg",fort:"300–400 mg"},
      duree:"Onset 30–60 min | Total 5–8 h",
      tripReport:"MDAI 200 mg: gentle empathy without stimulation.",
      description:"Selective serotonin releaser. Not very addictive on its own."
    },
    "MDEA": {
      effets:["Euphoria", "Empathy", "Moderate stimulation"],
      dosage:{faible:"80–100 mg",modere:"120–160 mg",fort:"200–250 mg"},
      duree:"Onset 45–90 min | Total 4–6 h",
      tripReport:"MDEA 130 mg: similar to MDMA but less intense.",
      description:"Monoamine releaser. Slightly reduced duration."
    },
    "MDPHP": {
      effets:["Intense euphoria", "Stimulation", "Compulsion"],
      dosage:{faible:"20–40 mg",modere:"50–80 mg",fort:"100–150 mg"},
      duree:"Onset 10–20 min | Total 2–4 h",
      tripReport:"MDPHP 50 mg: a strong, very short rush. Compulsive redosing.",
      description:"Potent DAT inhibitor. Extremely addictive."
    },
    "Mexedrone": {
      effets:["Mild euphoria", "Stimulation", "Weak empathy"],
      dosage:{faible:"100–150 mg",modere:"200–300 mg",fort:"400–500 mg"},
      duree:"Onset 30–60 min | Total 3–5 h",
      tripReport:"Mexedrone 200 mg: often combined. Interaction risk.",
      description:"Limited safety data."
    },
    "Pentobarbital": {
      effets:["Deep sedation", "Coma", "Respiratory depression"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"300 mg+"},
      duree:"Onset 15–30 min | Total 4–8 h",
      tripReport:"Pentobarbital: used in euthanasia. No reasonable recreational use.",
      description:"Ultra-narrow therapeutic index. Alcohol mix = death."
    },
    "Phénobarbital": {
      effets:["Sedation", "Anticonvulsant", "Anxiety relief"],
      dosage:{faible:"15–30 mg",modere:"30–60 mg",fort:"100–200 mg"},
      duree:"Onset 20–60 min | Total 8–12 h",
      tripReport:"Phenobarbital 60 mg: deep sedation.",
      description:"Respiratory depression. Many CYP450 interactions."
    },
    "Pramiracétam": {
      effets:["Memory enhancement", "Focus", "Mental clarity"],
      dosage:{faible:"200–400 mg",modere:"400–800 mg",fort:"1200 mg"},
      duree:"Onset 30–60 min | Total 6–8 h",
      tripReport:"Pramiracetam 600 mg: better information retention.",
      description:"High-potency fat-soluble racetam."
    },
    "Prolintane": {
      effets:["Stimulation", "Focus", "Reduced fatigue"],
      dosage:{faible:"5–10 mg",modere:"10–20 mg",fort:"30–50 mg"},
      duree:"Onset 30–60 min | Total 6–10 h",
      tripReport:"Prolintane 15 mg: a clean stimulant without major euphoria.",
      description:"DA/NA reuptake inhibitor."
    },
    "Secobarbital": {
      effets:["Sedation", "Euphoria", "Respiratory depression"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"300 mg+"},
      duree:"Onset 10–20 min | Total 3–6 h",
      tripReport:"Secobarbital 150 mg: a near-zero safety margin.",
      description:"Respiratory depression. Potentially fatal."
    },
    "TMA-2": {
      effets:["Hallucinations", "Euphoria", "Long duration"],
      dosage:{faible:"10–20 mg",modere:"25–40 mg",fort:"50–80 mg"},
      duree:"Onset 60–120 min | Total 12–16 h",
      tripReport:"TMA-2 30 mg: similar to mescaline, a surprising duration.",
      description:"Psychedelic amphetamine. MAOI interactions."
    },
    "TMA-6": {
      effets:["Hallucinations", "Empathy", "Long duration"],
      dosage:{faible:"5–15 mg",modere:"20–35 mg",fort:"40–60 mg"},
      duree:"Onset 60–120 min | Total 12–18 h",
      tripReport:"TMA-6 25 mg: more potent than TMA-2, pronounced nausea.",
      description:"Isomer of TMA-2. MAOI interactions."
    },
    "Theacrine": {
      effets:["Wakefulness", "Focus", "Mild euphoria"],
      dosage:{faible:"50–100 mg",modere:"100–200 mg",fort:"300–400 mg"},
      duree:"Onset 45–90 min | Total 5–8 h",
      tripReport:"Theacrine 150 mg: caffeine-like but with less crash.",
      description:"Slower tolerance build-up."
    },
    "3C-E": {
      effets:["Hallucinations", "Empathy", "Stimulation"],
      dosage:{faible:"10–15 mg",modere:"20–30 mg",fort:"35–60 mg"},
      duree:"Onset 60–120 min | Total 8–12 h",
      tripReport:"3C-E 25 mg: similar to mescaline but more stimulating.",
      description:"Documented MAOI interactions."
    },
    "5-APB": {
      effets:["Empathy", "Euphoria", "Stimulation"],
      dosage:{faible:"50–80 mg",modere:"80–120 mg",fort:"120–160 mg"},
      duree:"Onset 45–90 min | Total 5–8 h",
      tripReport:"5-APB: a benzofuran close to MDA/6-APB, mixing empathy + stimulation, longer-lasting than MDMA. Cardiac strain (5-HT2B agonist → theoretical valvular risk). No redosing.",
      description:"Serotonin/dopamine releaser, 5-HT2B agonist (cardiac risk). Hyperthermia possible. Avoid MAOIs."
    },
    "6-APDB": {
      effets:["Empathy", "Emotional warmth", "Gentle stimulation"],
      dosage:{faible:"40–70 mg",modere:"70–110 mg",fort:"110–150 mg"},
      duree:"Onset 45–90 min | Total 4–6 h",
      tripReport:"6-APDB: an entactogen close to MDA, gentler and more empathic, less stimulating. Same precautions as the benzofurans (5-HT2B).",
      description:"Serotonin releaser. 5-HT2B agonist (cardiac caution). Hyperthermia, no MAOIs."
    },
    "AB-CHMINACA": {
      effets:["Extreme sedation", "Paranoia", "Psychosis"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3 mg+"},
      duree:"Onset 5–15 min | Total 2–5 h",
      tripReport:"AB-CHMINACA 1 mg: paralysed for 2 h, heart at 180. A terrifying substance.",
      description:"3rd-generation noid, ultra-potent. Many deaths."
    },
    "JWH-018": {
      effets:["Intense euphoria", "Sedation", "Tachycardia", "Paranoia"],
      dosage:{faible:"0.5–1 mg",modere:"1–3 mg",fort:"4–6 mg"},
      duree:"Onset 5–15 min | Total 2–4 h",
      tripReport:"JWH-018 2 mg: a cannabis high but stronger and shorter. Tachycardia at 3 mg.",
      description:"Naphthylindole cannabinoid. Full CB1 agonist. Documented deaths."
    },
    "JWH-073": {
      effets:["Sedation", "Euphoria", "Tachycardia"],
      dosage:{faible:"0.5–1.5 mg",modere:"1.5–3 mg",fort:"4–6 mg"},
      duree:"Onset 5–15 min | Total 2–4 h",
      tripReport:"JWH-073 2 mg: slightly less potent than JWH-018.",
      description:"Butyl-naphthylindole, full CB1 agonist."
    },
    "AM-2201": {
      effets:["Sedation", "Euphoria", "Tachycardia", "Possible psychosis"],
      dosage:{faible:"0.5–1 mg",modere:"1–2 mg",fort:"3–5 mg"},
      duree:"Onset 5–15 min | Total 2–4 h",
      tripReport:"AM-2201 1.5 mg: potent and sedating. Seizures reported at 3 mg.",
      description:"Fluoropentyl cannabinoid. Full CB1 agonist."
    },
    "AB-FUBINACA": {
      effets:["Sedation", "Paranoia", "Hallucinations"],
      dosage:{faible:"0.3–0.7 mg",modere:"0.7–1.5 mg",fort:"2–3 mg"},
      duree:"Onset 5–15 min | Total 2–4 h",
      tripReport:"AB-FUBINACA 1 mg: involved in a series of mass comas (New York 2016).",
      description:"Fluorobenzyl indazole carboxamide. Full CB1 agonist."
    },
    "5F-ADB": {
      effets:["Extreme sedation", "Psychosis", "Severe tachycardia"],
      dosage:{faible:"0.1–0.5 mg",modere:"0.5–1 mg",fort:"1.5 mg+"},
      duree:"Onset 5–10 min | Total 1–3 h",
      tripReport:"5F-ADB: a 3rd-generation noid. Documented deaths at a tiny dose. Extremely dangerous.",
      description:"5-fluoro indazole carboxamide. Full-power full CB1 agonist. A wave of deaths in Europe 2016-2019."
    },
    "ADB-BUTINACA": {
      effets:["Total sedation", "Possible cardiac arrest", "Psychosis"],
      dosage:{faible:"0.1–0.3 mg",modere:"0.3–0.7 mg",fort:"1 mg+ (dangerous)"},
      duree:"Onset 2–10 min | Total 1–3 h",
      tripReport:"ADB-BUTINACA: a noid found in recent fatal overdoses. One of the most dangerous currently.",
      description:"Ultra-potent CB1 agonist. Responsible for many ER visits and hospitalisations 2020-2024."
    },
    "MDMB-4en-PINACA": {
      effets:["Total sedation", "Seizures", "Psychosis", "Possible cardiac arrest"],
      dosage:{faible:"0.1–0.25 mg",modere:"0.25–0.6 mg",fort:"1 mg+ (potentially lethal)"},
      duree:"Onset 2–10 min | Total 1–4 h",
      tripReport:"MDMB-4en-PINACA: one of the noids most often found in deaths and impaired driving (2019-2024). The margin between active and lethal dose is tiny.",
      description:"Ultra-potent full CB1 agonist (~2.5 nM). Often sprayed unevenly on plant matter: unpredictable overdose. Schedule I (US), banned in the EU."
    },
    "ADB-4en-PINACA": {
      effets:["Extreme sedation", "Tachycardia", "Paranoia", "Loss of consciousness"],
      dosage:{faible:"0.1–0.3 mg",modere:"0.3–0.7 mg",fort:"1 mg+ (dangerous)"},
      duree:"Onset 2–10 min | Total 1–3 h",
      tripReport:"ADB-4en-PINACA: a 3rd-generation noid that appeared in 2021, very potent, present in prison seizures (soaked papers).",
      description:"High-affinity full CB1 agonist. Blind dosing is impossible for the user. Temporary Schedule I (US)."
    },
    "4F-MDMB-BICA": {
      effets:["Deep sedation", "Vomiting", "Seizures", "Respiratory distress"],
      dosage:{faible:"0.1–0.3 mg",modere:"0.3–0.8 mg",fort:"1 mg+ (dangerous)"},
      duree:"Onset 2–10 min | Total 1–3 h",
      tripReport:"4F-MDMB-BICA: involved in mass poisonings. Like all noids, uneven distribution on the herb = roulette.",
      description:"Full CB1 agonist. Active metabolites. No reliable safety margin. Classified as a narcotic."
    },
    "CUMYL-PEGACLONE": {
      effets:["Sedation", "Bradycardia", "Confusion", "Loss of consciousness"],
      dosage:{faible:"0.2–0.5 mg",modere:"0.5–1.5 mg",fort:"2 mg+"},
      duree:"Onset 5–15 min | Total 2–5 h",
      tripReport:"CUMYL-PEGACLONE: a gamma-carboline-type noid, found in several deaths in Europe (notably Germany).",
      description:"CB1 agonist with an original structure (not a classic indazole/indole). Detected in fatal cases. Classified as a narcotic."
    },
    "Propofol": {
      effets:["Rapid sedation", "Loss of consciousness", "Amnesia", "Brief euphoria"],
      dosage:{faible:"not recreational",modere:"anaesthetic dose, hospital only",fort:"apnoea / respiratory arrest"},
      duree:"Onset 15–45 s (IV) | Total 5–10 min",
      tripReport:"Propofol: an ultra-fast IV anaesthetic. No safe recreational use: the margin between sedation and respiratory arrest is tiny, and there is no antidote. Several deaths of healthcare workers who diverted the drug.",
      description:"Potent GABA-A agonist. No analgesic effect. Dose-dependent respiratory depression with no safety plateau. Lethal outside anaesthetic monitoring with resuscitation equipment."
    },
    "Alpha-PHiP": {
      effets:["Stimulation", "Euphoria", "Compulsive redosing"],
      dosage:{faible:"5–10 mg",modere:"15–25 mg",fort:"30 mg+"},
      duree:"Onset 10–30 min | Total 2–4 h",
      tripReport:"Alpha-PHiP: a recent alpha-PVP analogue, profile close to cocaine when insufflated but longer-lasting. Very limited human data.",
      description:"Monoamine reuptake inhibitor (pyrrolidinophenone). Cardiovascular and psychiatric risks comparable to other pyrrolidine cathinones."
    },
    "Xylazine": {
      effets:["Prolonged sedation", "Bradycardia", "Hypotension", "Analgesia"],
      dosage:{faible:"undosed adulterant",modere:"present in heroin/fentanyl",fort:"deep sedation + wounds"},
      duree:"Onset 5–15 min | Total 2–8 h+",
      tripReport:"Xylazine ('tranq'): a veterinary sedative added to fentanyl/heroin to extend the effect. Naloxone does not reverse its sedation. Causes necrotic wounds in people who inject.",
      description:"Alpha-2 agonist (not an opioid). No antidote. Prolongs sedation and the respiratory risk combined with opioids. Wound care essential."
    },
    "Médétomidine": {
      effets:["Very deep sedation", "Severe bradycardia", "Hypotension"],
      dosage:{faible:"undosed adulterant",modere:"present in fentanyl",fort:"extreme sedation + severe withdrawal"},
      duree:"Onset 5–20 min | Total several hours",
      tripReport:"Medetomidine: a veterinary tranquilliser replacing xylazine as a fentanyl adulterant. More potent, longer sedation, severe autonomic withdrawal (hypertension, tachycardia) resistant to usual treatments.",
      description:"Potent alpha-2 agonist. Not reversed by naloxone. Detected in a majority of street-opioid samples in some US cities in late 2024."
    },
    "Graines de liseron (LSA)": {
      effets:["Mild hallucinations", "Dreaminess", "Nausea", "Vasoconstriction"],
      dosage:{faible:"3–5 seeds (Hawaiian baby woodrose)",modere:"5–8 HBWR seeds / 100–200 ipomoea seeds",fort:"8+ HBWR seeds"},
      duree:"Onset 1–2 h | Total 6–10 h",
      tripReport:"Morning glory/HBWR seeds: a natural source of LSA, close to a mild and bodily LSD, but with marked nausea and vasoconstriction. The effect is often sedating and physically uncomfortable.",
      description:"LSA (ergine), related to LSD but more bodily/sedating. Vasoconstriction (avoid with circulatory problems). Seed coatings are sometimes toxic."
    },
    "Sels de bain (cathinones)": {
      effets:["Intense stimulation", "Euphoria", "Agitation", "Paranoia", "Psychosis"],
      dosage:{faible:"varies by molecule",modere:"real content unknown",fort:"agitated delirium, hyperthermia"},
      duree:"Onset 10–30 min | Total 2–6 h (variable)",
      tripReport:"'Bath salts': a catch-all trade name for synthetic cathinones (MDPV, alpha-PVP/flakka, mephedrone, hexen…) sold labelled 'not for human consumption'. Powerful stimulant effects, compulsive redosing, media-covered episodes of agitated delirium and psychosis ('zombie drug'). You never know which molecule or dose you're taking.",
      description:"The substituted-cathinone family (dopamine-noradrenaline inhibitors/releasers). Unpredictable composition and potency. Risks: hyperthermia, rhabdomyolysis, cardiac failure, psychosis, strong addiction. See the MDPV, Alpha-PVP, Mephedrone, Hexen and NEP entries for detail."
    },
    "Tusi (cocaïne rose)": {
      effets:["Stimulation", "Euphoria", "Unpredictable effects depending on the mix"],
      dosage:{faible:"unknown dose (variable composition)",modere:"real content unknown",fort:"interaction risk"},
      duree:"Onset variable | Total variable",
      tripReport:"Tusi / tucibi / 2C / pink cocaine: BEWARE, this is almost never 2C-B. It is a pink marketing mix (often ketamine + MDMA + caffeine, sometimes cocaine, meth, opioids…), coloured and scented. The composition changes with every batch: you never know what you're taking or the interactions. The name comes from the Spanish pronunciation of '2C-B', but the molecule is usually absent.",
      description:"A composite product, not a single molecule. Risks = the unpredictable sum of the components (ketamine + MDMA = cardiac strain; possible presence of opioids or potent stimulants). Get it tested, start very low."
    },
    "2C-H": {
      effets:["Nearly inactive", "Precursor"],
      dosage:{faible:"little/not active",modere:"barely active",fort:"barely active"},
      duree:"Onset variable | Total short",
      tripReport:"2C-H: a phenethylamine almost inactive in itself, mostly known as a synthesis precursor for other 2Cs. Rarely taken for its effects.",
      description:"Weak 5-HT2A agonist, quickly metabolised by MAO. Mainly a chemical intermediate."
    },
    "2C-T-4": {
      effets:["Hallucinations", "Introspection", "Slow come-up"],
      dosage:{faible:"8–12 mg",modere:"12–20 mg",fort:"20–30 mg"},
      duree:"Onset 1.5–3 h | Total 8–12 h",
      tripReport:"2C-T-4: a sulphur analogue of 2C-B, very slow come-up (risk of premature redosing), long and introspective effects.",
      description:"5-HT2A agonist. Dangerous MAOI interaction. Deceptive slow onset."
    },
    "4-AcO-MiPT": {
      effets:["Hallucinations", "Euphoria", "Empathy"],
      dosage:{faible:"12–20 mg",modere:"20–35 mg",fort:"35–50 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"4-AcO-MiPT: the acetylated ester of 4-HO-MiPT (the equivalent of 4-AcO-DMT vs psilocin). Warm, visual effects.",
      description:"Prodrug converted to 4-HO-MiPT. 5-HT2A agonist. Psychedelic precautions."
    },
    "4-AcO-DiPT": {
      effets:["Hallucinations", "Euphoria", "Distortions"],
      dosage:{faible:"15–25 mg",modere:"25–40 mg",fort:"40–60 mg"},
      duree:"Onset 30–60 min | Total 4–6 h",
      tripReport:"4-AcO-DiPT: the ester of 4-HO-DiPT, a tryptamine psychedelic with marked visuals, medium duration.",
      description:"Prodrug. 5-HT2A agonist. Classic psychedelic precautions."
    },
    "Bufoténine": {
      effets:["Visions", "Intense physical effects", "Pressure/nausea"],
      dosage:{faible:"variable (route-dependent)",modere:"unpredictable dose",fort:"marked cardiovascular effects"},
      duree:"Onset fast | Total short",
      tripReport:"Bufotenin: a tryptamine present in certain toads and seeds (yopo). Heavy physical effects (blood pressure, a sense of oppression) sometimes more than visual. Narrow margin.",
      description:"Serotonergic agonist with marked cardiovascular effects. Present in yopo/Anadenanthera. Caution."
    },
    "Kétamine S (eskétamine)": {
      effets:["Dissociation", "Analgesia", "Euphoria"],
      dosage:{faible:"15–30 mg",modere:"30–60 mg",fort:"60–100 mg"},
      duree:"Onset 5–15 min | Total 45–90 min",
      tripReport:"Esketamine (the S-enantiomer of ketamine): ~2× more potent than racemic ketamine for the same weight → adjust the dose. A medical version (Spravato) for depression.",
      description:"NMDA antagonist. More potent than standard ketamine. Cystitis with repeated use, accidents while dissociated."
    },
    "Bromazolam": {
      effets:["Anxiety relief", "Sedation", "Amnesia"],
      dosage:{faible:"0.25–0.5 mg",modere:"0.5–1 mg",fort:"1 mg+"},
      duree:"Onset 20–40 min | Total 8–12 h",
      tripReport:"Bromazolam: a designer benzo that has become very common on the street (fake Xanax, mixed with opioids). Combined with fentanyl/nitazenes: major respiratory depression that naloxone does not reverse.",
      description:"GABA-A agonist. Strong amnesia, tolerance, dangerous withdrawal (seizures). Lethal with opioids/alcohol."
    },
    "Flualprazolam": {
      effets:["Anxiety relief", "Deep sedation", "Amnesia"],
      dosage:{faible:"0.25–0.5 mg",modere:"0.5–1 mg",fort:"1 mg+"},
      duree:"Onset 20–40 min | Total 10–16 h",
      tripReport:"Flualprazolam: a potent RC benzo, found in fake tablets and in deaths combined with opioids. A long, strong effect.",
      description:"Potent GABA-A agonist. Respiratory depression with opioids/alcohol. Seizure-risk withdrawal."
    },
    "Clonazépam": {
      effets:["Anxiety relief", "Sedation", "Anticonvulsant", "Amnesia"],
      dosage:{faible:"0.25–0.5 mg",modere:"0.5–1 mg",fort:"2 mg+"},
      duree:"Onset 30–60 min | Total 6–12 h",
      tripReport:"Clonazepam (Rivotril/Klonopin): a widely prescribed long benzo. Fast tolerance and dependence, dangerous withdrawal (seizures). Lethal combined with opioids/alcohol.",
      description:"Long-acting GABA-A agonist. See also Klonopin. Withdrawal must be medically supervised."
    },
    "Bromazépam": {
      effets:["Anxiety relief", "Sedation", "Muscle relaxation"],
      dosage:{faible:"3 mg",modere:"6 mg",fort:"12 mg+"},
      duree:"Onset 30–60 min | Total 8–12 h",
      tripReport:"Bromazepam (Lexomil): a common anxiolytic benzo. Dependence, amnesia, risky withdrawal. Dangerous with alcohol and opioids.",
      description:"GABA-A agonist. Tolerance/dependence. Never stop abruptly."
    },
    "Triazolam": {
      effets:["Hypnotic sedation", "Amnesia", "Falling asleep"],
      dosage:{faible:"0.125 mg",modere:"0.25 mg",fort:"0.5 mg+"},
      duree:"Onset 15–30 min | Total 4–6 h",
      tripReport:"Triazolam (Halcion): a short-acting hypnotic benzo, strong amnesia. Marked disinhibition and anterograde amnesia. Fast dependence.",
      description:"Short-acting GABA-A agonist. Amnesia, automatic behaviours. Dangerous with depressants."
    },
    "Témazépam": {
      effets:["Sedation", "Falling asleep", "Anxiety relief"],
      dosage:{faible:"10 mg",modere:"20 mg",fort:"30–40 mg+"},
      duree:"Onset 30–60 min | Total 6–8 h",
      tripReport:"Temazepam: a hypnotic benzo. Diverted, sometimes injected (very dangerous: embolisms). Dependence, risky withdrawal.",
      description:"GABA-A agonist. Injection = serious vascular risk. Dangerous with opioids/alcohol."
    },
    "Nitrazépam": {
      effets:["Sedation", "Falling asleep", "Relaxation"],
      dosage:{faible:"2.5–5 mg",modere:"5–10 mg",fort:"10 mg+"},
      duree:"Onset 30–60 min | Total 8–12 h",
      tripReport:"Nitrazepam (Mogadon): a long hypnotic benzo. Residual drowsiness, dependence, risky withdrawal.",
      description:"Long-acting GABA-A agonist. Accumulation in older people. Dangerous with depressants."
    },
    "Zopiclone": {
      effets:["Falling asleep", "Sedation", "Metallic taste"],
      dosage:{faible:"3.75 mg",modere:"7.5 mg",fort:"15 mg+"},
      duree:"Onset 20–40 min | Total 6–8 h",
      tripReport:"Zopiclone (Imovane): a benzo-like hypnotic. Typical bitter taste. Amnesia, automatic behaviours (driving/eating while asleep), dependence. Dangerous with alcohol/opioids.",
      description:"GABA-A modulator (Z-drug). Tolerance, dependence, withdrawal. Don't mix with depressants."
    },
    "Zaleplon": {
      effets:["Fast onset of sleep", "Brief sedation"],
      dosage:{faible:"5 mg",modere:"10 mg",fort:"20 mg+"},
      duree:"Onset 15–30 min | Total 2–4 h",
      tripReport:"Zaleplon (Sonata): a very short Z-drug hypnotic, used for falling asleep. Amnesia, possible dependence. Dangerous with alcohol.",
      description:"Short-acting GABA-A modulator. Risk of automatic behaviours. Avoid depressants."
    },
    "Méthaqualone": {
      effets:["Sedation", "Euphoria", "Muscle relaxation", "Disinhibition"],
      dosage:{faible:"75–150 mg",modere:"150–300 mg",fort:"300 mg+"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"Methaqualone (Quaalude, 'mandrax'): a 1970s sedative-hypnotic, euphoric and disinhibiting. Narrow margin, respiratory depression, dependence. Often smoked (mandrax) in South Africa/India.",
      description:"GABA-A modulator. Overdose: coma, respiratory depression, seizures. Dangerous with alcohol/opioids."
    },
    "Chloral hydrate": {
      effets:["Sedation", "Falling asleep"],
      dosage:{faible:"250 mg",modere:"500–1000 mg",fort:"1500 mg+"},
      duree:"Onset 30–60 min | Total 4–8 h",
      tripReport:"Chloral hydrate: an old sedative ('Mickey Finn'). Narrow margin, gastric irritant, arrhythmias, respiratory depression. Dangerous with alcohol (historic synergy).",
      description:"Prodrug of trichloroethanol (GABA). Cardiotoxic at high dose. Very dangerous with alcohol."
    },
    "Méprobamate": {
      effets:["Anxiety relief", "Sedation", "Muscle relaxation"],
      dosage:{faible:"200–400 mg",modere:"400–800 mg",fort:"1200 mg+"},
      duree:"Onset 30–60 min | Total 6–10 h",
      tripReport:"Meprobamate: an old anxiolytic (a metabolite of carisoprodol). Severe overdose (coma, hypotension, respiratory depression), dependence. Dangerous with alcohol.",
      description:"GABA modulator. Narrow therapeutic margin. Risky withdrawal. Avoid alcohol/depressants."
    },
    "Poppers": {
      effets:["Head rush", "Vasodilation", "Brief euphoria", "Sphincter relaxation"],
      dosage:{faible:"1 brief inhalation",modere:"a few inhalations",fort:"repeated inhalations (higher risk)"},
      duree:"Onset 10–30 s | Total 1–5 min",
      tripReport:"Poppers: head spinning and warmth for 1–2 min. NEVER swallow (near-fatal methemoglobinemia), NEVER with Viagra/Cialis.",
      description:"Alkyl nitrites (amyl/isobutyl/isopropyl). Vasodilator. Risks: methemoglobinemia (especially if swallowed — \"chocolate\" blood, emergency/methylene blue), maculopathy (vision loss, especially isopropyl), sudden death. Fatal with sildenafil/tadalafil."
    },
    "Solvants volatils": {
      effets:["Intoxication", "Euphoria", "Disinhibition", "Hallucinations", "Dizziness"],
      dosage:{faible:"not quantifiable",modere:"not quantifiable",fort:"prolonged inhalation — life-threatening"},
      duree:"Onset seconds | Total 5–30 min",
      tripReport:"Glue/toluene: fast, brief intoxication. Risk of SUDDEN DEATH from arrhythmia from the very first time. Brain damage with repeated use.",
      description:"Toluene, trichloroethylene, glues, paints. \"Sudden sniffing death syndrome\" (cardiac sensitisation to catecholamines \u2192 fatal arrhythmia), hypoxia. Chronic: leukoencephalopathy, kidney/cognitive damage."
    },
    "Butane / gaz": {
      effets:["Brief intoxication", "Euphoria", "Light-headedness"],
      dosage:{faible:"not quantifiable",modere:"not quantifiable",fort:"direct inhalation — life-threatening"},
      duree:"Onset seconds | Total 1–5 min",
      tripReport:"Lighter gas/aerosols: very brief effect. Sudden death from arrhythmia, asphyxia, airway frostbite (direct spray).",
      description:"Butane/propane/aerosols. \"Sudden sniffing death syndrome\", asphyxia from oxygen displacement, laryngospasm/frostbite. No margin of safety."
    },
    "Éther diéthylique": {
      effets:["Sedation", "Intoxication", "Analgesia", "Loss of consciousness"],
      dosage:{faible:"brief inhalation",modere:"moderate inhalation",fort:"rapid loss of consciousness"},
      duree:"Onset seconds\u2013minutes | Total short",
      tripReport:"Ether: anaesthesia-like sedation. Rapid loss of consciousness, vomiting, respiratory depression. Extremely flammable.",
      description:"Volatile anaesthetic. Respiratory depression, inhalation = loss of consciousness and aspiration risk. Highly flammable. Dangerous synergy with alcohol/benzos/opioids."
    }

  }
};
