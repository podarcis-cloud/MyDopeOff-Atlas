/* bilan-hero.js — « Faire le point » version discussion avec le compagnon Atlas.
   Reprend le FOND des bilans validés (Bilan Craving, AUDIT-C Alcool OMS, Bien-être WHO-5)
   mais noyé dans une conversation chaleureuse, didactique, un brin punk/pop culture —
   sans jamais moraliser ni juger. Le scoring et l'interprétation sont IDENTIQUES aux
   bilans cliniques d'origine, et l'enregistrement est compatible avec l'historique
   existant (sessions type 'q'), donc ça alimente le profil / la carte neurocognitive
   comme avant.

   API :
     MDBilanHero.data            -> tableau des bilans (structure compatible avec l'ancien QS)
     MDBilanHero.list()          -> idem (pour afficher les cartes)
     MDBilanHero.open(id)        -> lance la discussion d'un bilan
     MDBilanHero.openMenu(opts)  -> préambule : le héros propose de faire le point
   Dépend de MDCompagnon (avatars) si présent ; dégrade proprement sinon.
   100 % local. Respecte prefers-reduced-motion (via MDCompagnon). */
window.MDBilanHero = (function () {
  'use strict';

  function lang() { try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; } }
  var UI = {
    lets_go:{fr:'C\u2019est parti',en:'Let\u2019s go'}, later:{fr:'Plus tard',en:'Later'},
    go_on:{fr:'On continue',en:'Let\u2019s continue'}, stop_here:{fr:'Arrêter là',en:'Stop here'},
    continue_btn:{fr:'Continuer',en:'Continue'}, finish:{fr:'Terminer',en:'Finish'},
    for_info:{fr:'Pour info \u2014',en:'For context \u2014'},
    score_lbl:{fr:function(t,m){return 'Score : '+t+' / '+m+' \u00b7 ajouté à ton profil';}, en:function(t,m){return 'Score: '+t+' / '+m+' \u00b7 added to your profile';}},
    want_to_talk:{fr:'Envie d\u2019en parler ?',en:'Want to talk about it?'},
    support_line_centres:{fr:' Des lignes d\u2019écoute et des assos près de chez toi, dans Réduire les risques \u203A Centres.',
                           en:' Helplines and local support groups, in Reduce risks \u203A Centres.'},
    support_line_reflexes:{fr:' Des lignes d\u2019écoute et des assos près de chez toi, dans Réflexes \u203A Centres.',
                            en:' Helplines and local support groups, in Reflexes \u203A Centres.'},
    noted:{fr:'Noté !',en:'Noted!'},
    faire_le_point:{fr:'Faire le point',en:'Check in'},
    menu_intro:{fr:'On fait le point ensemble ? Le plus sympa, c\u2019est la discussion complète — je mêle les questions utiles à des anecdotes et des trucs légers. Ou tu prends juste un repère précis.',
                en:'Want to check in together? The nicest way is the full conversation — I mix the useful questions with anecdotes and light stuff. Or you can just grab one specific reading.'},
    full_conv:{fr:'La discussion complète',en:'The full conversation'},
    full_conv_desc:{fr:'Envie, alcool, moral, lien, stress \u2014 en une conversation détendue (~10 min)',en:'Craving, alcohol, mood, connection, stress \u2014 in one relaxed conversation (~10 min)'},
    or_precise:{fr:'Ou un repère précis',en:'Or one specific reading'},
    thanks_moment:{fr:'Merci pour ce moment. Voilà ce que j\u2019en retiens — sans jugement, juste des repères qui nourrissent ton profil.',
                   en:'Thanks for this moment. Here\u2019s what I\u2019m taking from it — no judgment, just readings that feed your profile.'},
    no_worries_stop:{fr:'Pas de souci, on s\u2019arrête là. Reviens quand tu veux.',en:'No worries, we\u2019ll stop here. Come back whenever you want.'},
    axis_craving:{fr:'Ton envie',en:'Your craving'}, axis_audit:{fr:'Alcool',en:'Alcohol'}, axis_wellbeing:{fr:'Ton moral',en:'Your mood'},
    axis_loneliness:{fr:'Ton lien',en:'Your connection'}, axis_stress:{fr:'Ta pression',en:'Your pressure'}, axis_mood2:{fr:'Moral & tension',en:'Mood & tension'}
  };
  function ui(k, a, b) { var e = UI[k]; if (!e) return k; var v = lang() === 'en' ? e.en : e.fr; return (typeof v === 'function') ? v(a, b) : v; }

  var KEY = 'ctc_v6';
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function save(d) { try { if (window.MDData && MDData.write) { MDData.write(d); } else { localStorage.setItem(KEY, JSON.stringify(d)); } } catch (e) { } }
  function read() { return (window.MDData && MDData.read) ? MDData.read() : load(); }

  /* — Les 3 bilans. `questions/opts/scores/interp` = fidèles aux versions validées.
     Champs d'habillage en plus : mood (avatar), intro (le héros pose le décor),
     fact (encart didactique « pour info »), transitions (petites relances entre Q),
     outro(interp,total) (mot de fin humain). BILANS_FR/BILANS_EN : même structure et
     mêmes scores/seuils cliniques dans les deux langues — seul le texte change. — */
  var BILANS_FR = [
    {
      id: 'craving', name: 'Le craving, on le cartographie', desc: 'Intensité, fréquence, résistance',
      color: 'var(--terra)', mood: 'ecoute',
      intro: 'Le craving, cette envie qui débarque sans frapper et prend toute la place. On va la cartographier ensemble — trois questions. Un ennemi qu\u2019on connaît fait toujours moins peur.',
      fact: 'Le craving n\u2019est pas un manque de volonté : c\u2019est un circuit cérébral qui s\u2019emballe. Le nommer, c\u2019est déjà reprendre un peu la main.',
      questions: [
        { q: 'Cette semaine, l\u2019envie tapait à quelle intensité, en moyenne ?', opts: ['Quasi absente', 'Plutôt légère', 'Bien là', 'Assez forte', 'Version maximale'], scores: [1, 2, 3, 4, 5],
          reacts: ['Ok, noté. Une semaine plutôt tranquille de ce côté-là.', 'Ok, noté. Ça se sent, sans être envahissant.', 'Ok, noté. Présente, mine de rien.', 'Ok, noté. Ça a dû prendre pas mal de place.', 'Ok, noté. Une semaine intense, clairement.'] },
        { q: 'Cette envie, elle revenait à quelle fréquence, cette semaine ?', opts: ['Rare', 'Quelques fois', 'Tous les jours', 'Plusieurs fois/jour', 'Quasi non-stop'], scores: [1, 2, 3, 4, 5],
          reacts: ['Je vois. Pas grand-chose à gérer, alors.', 'Je vois. De temps en temps, sans plus.', 'Je vois. Un rendez-vous quotidien, donc.', 'Je vois. Ça revient souvent dans la journée.', 'Je vois. Presque en continu — ça pèse, forcément.'] },
        { q: 'Tu as réussi à laisser passer des envies sans céder ?', opts: ['Toujours', 'Souvent', 'La moitié du temps', 'Rarement', 'Jamais'], scores: [5, 4, 3, 2, 1],
          reacts: ['Un contrôle solide, tout du long.', 'Plutôt bien tenu, dans l\u2019ensemble.', 'Un coup sur deux — déjà pas rien.', 'Difficile cette fois, et c\u2019est ok de le dire.', 'Aucune, cette semaine — retiens juste que tu es encore là à en parler.'] }
      ],
      interp: function (s) { return s <= 5 ? { label: 'Semaine stable', color: 'var(--terra)' } : s <= 9 ? { label: 'Semaine avec du mouvement', color: 'var(--terra)' } : { label: 'Semaine chargée', color: 'var(--terra)' }; },
      outro: function (it, s) {
        if (s <= 5) return { mood: 'encouragement', text: 'Une semaine plutôt calme de ce côté-là. Ce que tu fais déjà pour traverser ces moments continue de fonctionner — ça vaut la peine de savoir quoi, précisément.' };
        if (s <= 9) return { mood: 'bienveillance', text: 'Une semaine avec du mouvement. Tu as traversé ces vagues sans que rien ne s’arrête — c’est déjà quelque chose que tu sais faire. Un exercice peut rendre la prochaine moins longue.',
          goExercise: { href:'surf.html', label:'Surf de l\u2019envie', desc:' \u2014 laisser passer une vague, sans la combattre.' } };
        return { mood: 'bienveillance', text: 'Une semaine chargée. Et tu es encore là à en parler, ce qui veut dire que tu as tenu à travers chacune de ces vagues \u2014 y compris celles que personne n\u2019a vues. Si tu te reproches quelque chose en lisant ça, ce reproche vient de bien plus loin que toi.',
          goExercise: { href:'braise.html', label:'Braise', desc:' \u2014 pour les moments où l\u2019envie brûle sans prévenir.' } };
      }
    },
    {
      id: 'audit', name: 'AUDIT-C · le thermomètre alcool', desc: 'Le questionnaire de référence de l\u2019OMS',
      color: 'var(--fjord)', mood: 'curiosite',
      intro: 'L\u2019AUDIT-C, c\u2019est le petit questionnaire que l\u2019OMS a filé aux soignants du monde entier. Trois questions, pas une de plus. Pas de piège, pas de morale — juste un thermomètre pour situer où tu en es.',
      fact: 'Un « verre standard », c\u2019est ~10 g d\u2019alcool pur : un demi de bière, un ballon de vin, une dose de spiritueux. Servis maison, ils sont souvent plus costauds.',
      questions: [
        { q: 'Et l\u2019alcool, ça t\u2019arrive d\u2019en boire souvent ces temps-ci ?', opts: ['Jamais', 'Une fois par mois, grand max', '2 à 4 fois par mois', '2 à 3 fois par semaine', '4 fois par semaine ou plus'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok. Pas vraiment ton truc, alors.', 'Ok. Occasionnel, donc.', 'Ok. Quelques fois dans le mois.', 'Ok. Une bonne partie de la semaine.', 'Ok. Presque un rituel, alors.'] },
        { q: 'Et un jour où tu bois, tu t\u2019arrêtes généralement à combien de verres ?', opts: ['1 ou 2', '3 ou 4', '5 ou 6', '7 à 9', '10 ou plus'], scores: [0, 1, 2, 3, 4],
          reacts: ['Reçu. Plutôt sobre, dans l\u2019ensemble.', 'Reçu. Une consommation modérée.', 'Reçu. Ça commence à compter.', 'Reçu. C\u2019est une vraie quantité.', 'Reçu. Une quantité conséquente, notée.'] },
        { q: 'À quelle fréquence ça t\u2019arrive de boire six verres ou plus en une seule occasion ?', opts: ['Jamais', 'Moins d\u2019une fois par mois', 'Une fois par mois', 'Une fois par semaine', 'Presque tous les jours'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ça n\u2019arrive jamais \u2014 très bien.', 'Rarement, donc \u2014 noté.', 'Une fois de temps en temps.', 'Une habitude hebdomadaire, alors.', 'Quasi quotidien \u2014 un vrai repère à garder en tête.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Rien à signaler', color: 'var(--fjord)' } : s <= 5 ? { label: 'Zone à surveiller', color: 'var(--fjord)' } : { label: 'Un repère qui mérite un regard', color: 'var(--fjord)' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'encouragement', text: 'Le thermomètre ne signale rien de particulier ce mois-ci. Ça ne dit pas ce que tu dois faire de ta consommation — seulement où en est ce repère-là, aujourd’hui.' };
        if (s <= 5) return { mood: 'reflexion', text: 'Zone modérée. Avoir répondu à ces trois questions sans arrondir, c\u2019est déjà regarder les choses en face — beaucoup de gens n\u2019y arrivent pas. Ce que tu en fais ensuite t\u2019appartient entièrement.',
          goExercise: { href:'alcool.html', label:'Dossier alcool', desc:' \u2014 ce que ça fait, concrètement, et comment réduire les risques.' } };
        var att = { mood: 'bienveillance', text: 'Un chiffre haut, et tu l\u2019as obtenu en répondant honnêtement plutôt qu\u2019en te ménageant — c\u2019est un acte de lucidité, pas un aveu. Ce que ce chiffre dit du produit ne dit rien de ce que tu vaux. Et tu n\u2019as rien à prouver pour avoir droit à de l\u2019aide, si un jour tu en veux.',
          goExercise: { href:'lettre.html', label:'Lettre à ton futur toi', desc:' \u2014 écrire aujourd\u2019hui ce que tu voudras relire un autre jour.' } };
        att.support = true;
        return att;
      }
    },
    {
      id: 'wellbeing', name: 'WHO-5 · la météo de ton moral', desc: 'Cinq questions, validées par l\u2019OMS',
      color: 'var(--rose)', mood: 'serenite',
      intro: 'Cinq questions pensées par l\u2019OMS pour prendre la météo de ton moral. Genre check-up, mais pour la tête. Réponds au feeling, sur les deux dernières semaines — y a pas de bonne réponse.',
      fact: 'Le WHO-5 mesure le bien-être, pas la « performance ». Un score bas ne te définit pas : c\u2019est une photo de l\u2019instant, et une photo, ça se reprend.',
      questions: [
        { q: 'De bonne humeur la plupart du temps ?', opts: ['Pas trop, non', 'Un peu', 'Ça va, moyen', 'Plutôt oui', 'Clairement oui'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, merci pour l\u2019honnêteté.', 'Un peu, c\u2019est déjà ça.', 'Une moyenne correcte.', 'Plutôt bon signe.', 'Belle énergie, ça se sent.'] },
        { q: 'Calme et détendu\u00b7e ces derniers temps ?', opts: ['Pas vraiment', 'Un peu', 'Ça dépend des jours', 'Assez souvent', 'Zen la plupart du temps'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noté.', 'Un peu de calme, tant mieux.', 'Ça varie, comme souvent.', 'Une belle tranquillité.', 'Un bel équilibre, ça.'] },
        { q: 'Plein\u00b7e d\u2019énergie, d\u2019allant ?', opts: ['À plat', 'Un peu de jus', 'Correct', 'En forme', 'Débordant\u00b7e'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, ça arrive d\u2019être à plat.', 'Un peu de jus, c\u2019est un début.', 'Une énergie correcte.', 'Bien, ça se sent.', 'Une belle dose d\u2019énergie.'] },
        { q: 'Tu te réveilles plutôt frais\u00b7che et reposé\u00b7e ?', opts: ['Jamais, ou presque', 'Rarement', 'Un jour sur deux', 'La plupart du temps', 'Systématiquement'], scores: [0, 1, 2, 3, 4],
          reacts: ['Un sommeil qui ne répare pas assez, ça pèse.', 'Rarement reposant, noté.', 'Un jour sur deux, pas mal.', 'Un bon sommeil, la plupart du temps.', 'Un sommeil qui fait vraiment son travail.'] },
        { q: 'Tes journées sont remplies de trucs qui t\u2019intéressent ?', opts: ['Pas trop', 'Un peu', 'Quelques-unes', 'Pas mal, oui', 'Tous les jours ou presque'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noté.', 'Un peu, ça compte.', 'Quelques bons moments.', 'Des journées plutôt remplies.', 'Des journées qui donnent envie, chaque jour.'] }
      ],
      interp: function (s) { return s <= 8 ? { label: 'Moral fatigué', color: 'var(--rose)' } : s <= 14 ? { label: 'Moral en demi-teinte', color: 'var(--rose)' } : { label: 'Moral au beau fixe', color: 'var(--rose)' }; },
      outro: function (it, s) {
        if (s >= 15) return { mood: 'celebration', text: 'Une météo intérieure clémente en ce moment. Ce qui t’y aide existe déjà quelque part dans tes journées — le repérer maintenant sert surtout pour les périodes où il fera moins beau.' };
        if (s >= 9) return { mood: 'bienveillance', text: 'Météo mitigée. Tu as pris deux minutes pour regarder où tu en es, ce qui n\u2019a rien d\u2019évident quand le moral est moyen \u2014 c\u2019est déjà une forme de soin.' };
        var low = Math.random() < 0.5
          ? { mood: 'ecoute', text: 'La météo est un peu grise en ce moment, et ça compte. Tu n\u2019es pas seul\u00b7e — parler à quelqu\u2019un peut faire du bien, vraiment.' }
          : { mood: 'acceptation', text: 'Un moral fatigué en ce moment, tel quel, sans rien à corriger dans l\u2019immédiat. Parler à quelqu\u2019un peut aider \u2014 et tu y as droit parce que tu es un être humain, pas parce que tu irais assez mal pour le mériter.' };
        low.support = true;
        return low;
      }
    },
    {
      id: 'loneliness', name: 'UCLA-3 · le lien qu\u2019on a', desc: 'Trois questions sur la solitude, validées scientifiquement',
      color: 'var(--ocre)', mood: 'ecoute',
      intro: 'Trois questions, utilisées depuis les années 80 pour prendre la mesure d\u2019un facteur qu\u2019on sous-estime souvent : la solitude ressentie. Des études menées spécifiquement chez des personnes en travail sur leur consommation montrent qu\u2019elle pèse autant que la confiance en soi dans le risque de rechute.',
      fact: 'Se sentir seul\u00b7e n\u2019a rien à voir avec être entouré\u00b7e ou non sur le papier. On peut se sentir isolé\u00b7e en pleine foule, et bien accompagné\u00b7e avec très peu de monde autour.',
      questions: [
        { q: 'Ça t\u2019arrive de sentir qu\u2019il te manque quelqu\u2019un à qui vraiment parler ?', opts: ['Presque jamais', 'Parfois', 'Souvent'], scores: [0, 1, 2],
          reacts: ['Ok, noté \u2014 plutôt rare.', 'Ça arrive, donc \u2014 reçu.', 'Souvent, ça pèse. Merci de le dire.'] },
        { q: 'Ça t\u2019arrive de te sentir mis\u00b7e à l\u2019écart ?', opts: ['Presque jamais', 'Parfois', 'Souvent'], scores: [0, 1, 2],
          reacts: ['Rare, tant mieux.', 'Par moments, reçu.', 'Souvent \u2014 ce n\u2019est pas rien.'] },
        { q: 'Ça t\u2019arrive de te sentir isolé\u00b7e des autres, même entouré\u00b7e ?', opts: ['Presque jamais', 'Parfois', 'Souvent'], scores: [0, 1, 2],
          reacts: ['Rare \u2014 bon signe.', 'Parfois, ok.', 'Souvent. C\u2019est précieux que tu le nommes.'] }
      ],
      interp: function (s) { return s <= 1 ? { label: 'Plutôt bien entouré\u00b7e', color: 'var(--ocre)' } : s <= 3 ? { label: 'Un peu de solitude, par moments', color: 'var(--ocre)' } : { label: 'Une solitude bien présente, ces temps-ci', color: 'var(--ocre)' }; },
      outro: function (it, s) {
        if (s <= 1) return { mood: 'celebration', text: 'Des liens plutôt présents en ce moment. Ce sont eux qui rendent une envie plus facile à traverser \u2014 savoir sur qui tu peux compter vaut mieux que d\u2019avoir à le chercher un mauvais soir.' };
        if (s <= 3) return { mood: 'reflexion', text: 'Un peu de solitude par moments. C\u2019est un facteur connu \u2014 plus on se sent isolé·e, plus une envie devient difficile à tenir. Le dire, même à un écran, c\u2019est déjà rompre un peu l\u2019isolement.',
          goExercise: { href:'elan.html', label:'Élan', desc:' \u2014 se reconnecter à ce qui compte pour toi.' } };
        var lonely = { mood: 'ecoute', text: 'Une solitude bien présente ces temps-ci, et ça change beaucoup de choses face à une envie. Se sentir seul·e n\u2019a rien à voir avec ce qu\u2019on vaut ou avec ce qu\u2019on mériterait \u2014 c\u2019est une situation, pas un défaut, et elle bouge. Tu viens d\u2019en parler : c\u2019est le geste le plus difficile de tous.',
          goExercise: { href:'lettre.html', label:'Lettre à ton futur toi', desc:' \u2014 un espace rien qu\u2019à toi, même seul\u00b7e.' } };
        lonely.support = true;
        return lonely;
      }
    },
    {
      id: 'stress', name: 'PSS-4 · la pression du mois', desc: 'Quatre questions sur le stress perçu, utilisées dans le monde entier',
      color: 'var(--fjord)', mood: 'reflexion',
      intro: 'Quatre questions, posées depuis 1983 dans des milliers d\u2019études sur le stress. Pas sur ce qui t\u2019arrive objectivement, mais sur comment tu l\u2019as vécu, ce dernier mois \u2014 ce qui compte souvent plus que les faits eux-mêmes.',
      fact: 'Le stress perçu n\u2019est pas proportionnel aux évènements réels. Deux personnes qui vivent exactement la même semaine peuvent en ressortir avec un niveau de stress très différent.',
      questions: [
        { q: 'Ce dernier mois, tu as eu l\u2019impression de ne plus avoir la main sur des choses importantes de ta vie ?', opts: ['Jamais', 'Rarement', 'Parfois', 'Assez souvent', 'Très souvent'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, rarement voire jamais \u2014 bon signe.', 'Rare, reçu.', 'Par moments, noté.', 'Assez souvent, ça pèse.', 'Très souvent \u2014 merci de le dire clairement.'] },
        { q: 'Ce dernier mois, tu te sentais confiant\u00b7e dans ta capacité à gérer tes soucis personnels ?', opts: ['Jamais', 'Rarement', 'Parfois', 'Assez souvent', 'Très souvent'], scores: [4, 3, 2, 1, 0],
          reacts: ['Ok, noté.', 'Rarement confiant\u00b7e, reçu.', 'Une confiance qui varie.', 'Plutôt confiant\u00b7e, tant mieux.', 'Une belle confiance \u2014 ça se sent.'] },
        { q: 'Ce dernier mois, tu avais l\u2019impression que les choses allaient dans ton sens ?', opts: ['Jamais', 'Rarement', 'Parfois', 'Assez souvent', 'Très souvent'], scores: [4, 3, 2, 1, 0],
          reacts: ['Ok, reçu.', 'Rarement, noté.', 'Un mois en demi-teinte.', 'Plutôt dans le bon sens.', 'Un mois qui a bien tourné, alors.'] },
        { q: 'Ce dernier mois, les difficultés se sont accumulées au point de te sembler ingérables ?', opts: ['Jamais', 'Rarement', 'Parfois', 'Assez souvent', 'Très souvent'], scores: [0, 1, 2, 3, 4],
          reacts: ['Jamais \u2014 très bien.', 'Rarement, tant mieux.', 'Par moments, ça arrive.', 'Assez souvent \u2014 c\u2019est beaucoup à porter.', 'Très souvent. C\u2019est lourd, et c\u2019est reçu comme tel.'] }
      ],
      interp: function (s) { return s <= 4 ? { label: 'Pression plutôt légère', color: 'var(--fjord)' } : s <= 9 ? { label: 'Pression modérée', color: 'var(--fjord)' } : { label: 'Pression élevée en ce moment', color: 'var(--fjord)' }; },
      outro: function (it, s) {
        if (s <= 4) return { mood: 'celebration', text: 'Une pression plutôt légère en ce moment. C\u2019est le genre de période où repérer ce qui te fait tenir coûte peu \u2014 et sert beaucoup plus tard.' };
        if (s <= 9) return { mood: 'reflexion', text: 'Une pression modérée, ce mois-ci. Le stress est l\u2019un des déclencheurs de craving les mieux documentés \u2014 et tu tiens le coup dessous, ce qui n\u2019est pas rien. Souffler quelques minutes n\u2019est pas du luxe : c\u2019est de l\u2019entretien.',
          goExercise: { href:'breathe.html', label:'Souffle', desc:' \u2014 faire redescendre la pression, concrètement.' } };
        var stressed = { mood: 'bienveillance', text: 'Une pression élevée en ce moment. Tenir sous cette pression demande une énergie que personne ne voit et que tu fournis quand même, tous les jours \u2014 ce n\u2019est pas de la faiblesse, c\u2019est une charge. Le stress est l\u2019un des facteurs qui rendent une envie la plus difficile à tenir : t\u2019en occuper compte autant que le reste.',
          goExercise: { href:'filtre.html', label:'Filtre', desc:' \u2014 repérer ce qui met la pression, avant de vouloir la baisser.' } };
        return stressed;
      }
    },
    {
      id: 'mood2', name: 'PHQ-4 · moral & tension, en quatre questions', desc: 'Un repère bref, utilisé en médecine générale dans le monde entier',
      color: 'var(--rose)', mood: 'ecoute',
      intro: 'Quatre questions, deux sur le moral et deux sur la tension intérieure \u2014 le genre de repère bref que les médecins généralistes utilisent en quelques minutes. Sur les deux dernières semaines, au feeling.',
      fact: 'Une tension qui dure et un moral en berne se renforcent souvent l\u2019un l\u2019autre \u2014 c\u2019est pour ça que ce repère regarde les deux à la fois, plutôt qu\u2019un seul.',
      questions: [
        { q: 'Peu d\u2019intérêt ou de plaisir à faire les choses, ces deux dernières semaines ?', opts: ['Jamais', 'Quelques jours', 'Plus de la moitié du temps', 'Presque tous les jours'], scores: [0, 1, 2, 3],
          reacts: ['Ok, jamais \u2014 bon signe.', 'Quelques jours, reçu.', 'Plus de la moitié du temps, noté.', 'Presque tous les jours. Merci de le dire.'] },
        { q: 'Le cafard, la déprime, ou l\u2019impression que rien ne s\u2019arrange, ces deux dernières semaines ?', opts: ['Jamais', 'Quelques jours', 'Plus de la moitié du temps', 'Presque tous les jours'], scores: [0, 1, 2, 3],
          reacts: ['Jamais \u2014 très bien.', 'Quelques jours, ça arrive.', 'Plus de la moitié du temps \u2014 c\u2019est beaucoup.', 'Presque tous les jours. C\u2019est reçu, et ça compte.'] },
        { q: 'Nerveux\u00b7se, anxieux\u00b7se, ou à cran, ces deux dernières semaines ?', opts: ['Jamais', 'Quelques jours', 'Plus de la moitié du temps', 'Presque tous les jours'], scores: [0, 1, 2, 3],
          reacts: ['Ok, rare \u2014 bien.', 'Quelques jours, noté.', 'Plus de la moitié du temps.', 'Presque tous les jours \u2014 une vraie tension de fond.'] },
        { q: 'Incapable d\u2019arrêter ou de contrôler tes inquiétudes, ces deux dernières semaines ?', opts: ['Jamais', 'Quelques jours', 'Plus de la moitié du temps', 'Presque tous les jours'], scores: [0, 1, 2, 3],
          reacts: ['Jamais, tant mieux.', 'Quelques jours, reçu.', 'Plus de la moitié du temps.', 'Presque tous les jours \u2014 des pensées difficiles à lâcher.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Plutôt stable en ce moment', color: 'var(--rose)' } : s <= 5 ? { label: 'Un peu chahuté ces temps-ci', color: 'var(--rose)' } : { label: 'Beaucoup à porter, ces temps-ci', color: 'var(--rose)' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'celebration', text: 'Plutôt stable, côté moral comme côté tension, en ce moment. Ce qui te maintient là existe déjà \u2014 et se repère plus facilement maintenant que dans une période difficile.' };
        if (s <= 5) return { mood: 'reflexion', text: 'Un peu chahuté ces temps-ci. Avoir répondu honnêtement à ces quatre questions, c\u2019est déjà regarder les choses en face \u2014 ce n\u2019est pas rien, et ça t\u2019appartient.',
          goExercise: { href:'recadrage.html', label:'Recadrage', desc:' \u2014 regarder une pensée difficile sous un autre angle.' } };
        var turbulent = { mood: 'bienveillance', text: 'Beaucoup à porter en ce moment, côté moral comme côté tension. Répondre honnêtement à ces quatre questions-là, c\u2019est déjà regarder les choses en face \u2014 ce n\u2019est pas rien. Ce n\u2019est ni un jugement ni un diagnostic : juste un repère, à un moment donné. Et si tu te reproches quelque chose en lisant ça, sache que ce reproche vient de bien plus loin que toi. Tu n\u2019as rien à prouver pour avoir droit à de l\u2019aide.',
          goExercise: { href:'rdr.html?tab=centres', label:'Trouver quelqu\u2019un', desc:' \u2014 les lieux et les lignes de ta région, sans rendez-vous ni explication.' } };
        turbulent.support = true;
        return turbulent;
      }
    }
  ];
  var BILANS_EN = [
    {
      id: 'craving', name: 'Craving, mapped out', desc: 'Intensity, frequency, resistance',
      color: 'var(--terra)', mood: 'ecoute',
      intro: 'Craving — that urge that shows up unannounced and takes over everything. Let\u2019s map it out together — three questions. A familiar enemy is always a little less scary.',
      fact: 'Craving isn\u2019t a lack of willpower: it\u2019s a brain circuit revving up. Naming it is already taking back a bit of control.',
      questions: [
        { q: 'This week, how intense was the urge, on average?', opts: ['Almost absent', 'Fairly light', 'Definitely there', 'Pretty strong', 'Maximum setting'], scores: [1, 2, 3, 4, 5],
          reacts: ['Ok, noted. A fairly quiet week on that front.', 'Ok, noted. Noticeable, without being overwhelming.', 'Ok, noted. Present, quietly.', 'Ok, noted. That must have taken up a fair bit of space.', 'Ok, noted. An intense week, clearly.'] },
        { q: 'How often did it come back this week?', opts: ['Rare', 'A few times', 'Every day', 'Several times a day', 'Almost non-stop'], scores: [1, 2, 3, 4, 5],
          reacts: ['I see. Not much to deal with, then.', 'I see. Now and then, no more.', 'I see. A daily appointment, then.', 'I see. It kept coming back through the day.', 'I see. Almost constant — that weighs on you, understandably.'] },
        { q: 'Did you manage to let urges pass without giving in?', opts: ['Always', 'Often', 'Half the time', 'Rarely', 'Never'], scores: [5, 4, 3, 2, 1],
          reacts: ['Solid control, the whole way through.', 'Held up pretty well, overall.', 'One in two — already something.', 'Tough one this time, and it\u2019s ok to say so.', 'None this week — just remember you\u2019re still here talking about it.'] }
      ],
      interp: function (s) { return s <= 5 ? { label: 'Stable week', color: 'var(--terra)' } : s <= 9 ? { label: 'A week with some movement', color: 'var(--terra)' } : { label: 'Heavy week', color: 'var(--terra)' }; },
      outro: function (it, s) {
        if (s <= 5) return { mood: 'encouragement', text: 'A fairly quiet week on that front. Whatever you already do to get through those moments is still working — worth knowing exactly what it is.' };
        if (s <= 9) return { mood: 'bienveillance', text: 'A week with some movement. You got through those waves and nothing stopped — that’s already something you know how to do. An exercise can make the next one shorter.',
          goExercise: { href:'surf.html', label:'Surfing the urge', desc:' \u2014 let a wave pass, without fighting it.' } };
        return { mood: 'bienveillance', text: 'A heavy week. And you\u2019re still here talking about it, which means you held through every one of those waves \u2014 including the ones nobody saw. If you\u2019re blaming yourself as you read this, that blame comes from a lot further away than you.',
          goExercise: { href:'braise.html', label:'Embers', desc:' \u2014 let a wave pass, without fighting it.' } };
      }
    },
    {
      id: 'audit', name: 'AUDIT-C · the alcohol thermometer', desc: 'The WHO\u2019s reference questionnaire',
      color: 'var(--fjord)', mood: 'curiosite',
      intro: 'AUDIT-C is the short questionnaire the WHO handed to healthcare workers worldwide. Three questions, not one more. No trap, no lecture — just a thermometer to see where you stand.',
      fact: 'A "standard drink" is about 10g of pure alcohol: a half-pint of beer, a glass of wine, a shot of spirits. Poured at home, they\u2019re often stronger.',
      questions: [
        { q: 'Do you find yourself drinking alcohol often these days?', opts: ['Never', 'Once a month, max', '2 to 4 times a month', '2 to 3 times a week', '4 times a week or more'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok. Not really your thing, then.', 'Ok. Occasional, then.', 'Ok. A few times a month.', 'Ok. A good chunk of the week.', 'Ok. Almost a ritual, then.'] },
        { q: 'On a day you drink, how many drinks do you usually stop at?', opts: ['1 or 2', '3 or 4', '5 or 6', '7 to 9', '10 or more'], scores: [0, 1, 2, 3, 4],
          reacts: ['Got it. Fairly light, overall.', 'Got it. A moderate amount.', 'Got it. Starting to add up.', 'Got it. That\u2019s a real quantity.', 'Got it. A substantial amount, noted.'] },
        { q: 'How often do you have six or more drinks on one occasion?', opts: ['Never', 'Less than monthly', 'Monthly', 'Weekly', 'Almost daily'], scores: [0, 1, 2, 3, 4],
          reacts: ['Never happens \u2014 great.', 'Rarely, then \u2014 noted.', 'Once in a while.', 'A weekly habit, then.', 'Almost daily \u2014 a real marker to keep in mind.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Nothing to flag', color: 'var(--fjord)' } : s <= 5 ? { label: 'Worth watching', color: 'var(--fjord)' } : { label: 'A marker worth a closer look', color: 'var(--fjord)' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'encouragement', text: 'The thermometer isn\u2019t flagging anything in particular this month. That doesn\u2019t say what you should do about your drinking — only where this one marker sits, today.' };
        if (s <= 5) return { mood: 'reflexion', text: 'Moderate zone. Answering those three questions without rounding down is already facing things \u2014 plenty of people can\u2019t. What you do with it next is entirely yours.',
          goExercise: { href:'alcool.html', label:'Alcohol file', desc:' \u2014 what it actually does, and how to reduce the risks.' } };
        var att = { mood: 'bienveillance', text: 'A high number, and you got there by answering honestly rather than going easy on yourself — that’s clear-sightedness, not a confession. What this number says about the drink says nothing about what you’re worth. And you don’t have to prove anything to deserve help, if you ever want it.',
          goExercise: { href:'lettre.html', label:'Letter to your future self', desc:' \u2014 writing today what you\u2019ll want to reread another day.' } };
        att.support = true;
        return att;
      }
    },
    {
      id: 'wellbeing', name: 'WHO-5 · your mood forecast', desc: 'Five questions, validated by the WHO',
      color: 'var(--rose)', mood: 'serenite',
      intro: 'Five questions designed by the WHO to take the forecast of your mood. Like a check-up, but for the head. Answer by feel, over the last two weeks — there\u2019s no right answer.',
      fact: 'The WHO-5 measures well-being, not "performance". A low score doesn\u2019t define you: it\u2019s a snapshot of this moment, and a snapshot can always be retaken.',
      questions: [
        { q: 'In good spirits most of the time?', opts: ['Not really, no', 'A bit', 'It\u2019s okay, average', 'Fairly yes', 'Clearly yes'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, thanks for the honesty.', 'A bit, that\u2019s already something.', 'A decent average.', 'A pretty good sign.', 'Great energy, that comes through.'] },
        { q: 'Calm and relaxed lately?', opts: ['Not really', 'A bit', 'Depends on the day', 'Fairly often', 'Zen most of the time'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noted.', 'A bit of calm, good.', 'It varies, as often.', 'A nice sense of calm.', 'A good balance, that.'] },
        { q: 'Full of energy, drive?', opts: ['Running on empty', 'A bit of juice', 'Decent', 'In good shape', 'Overflowing'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, running on empty happens.', 'A bit of juice, that\u2019s a start.', 'Decent energy.', 'Good, that shows.', 'A great dose of energy.'] },
        { q: 'Waking up feeling fresh and rested?', opts: ['Almost never', 'Rarely', 'Every other day', 'Most of the time', 'Consistently'], scores: [0, 1, 2, 3, 4],
          reacts: ['Sleep that doesn\u2019t recharge enough weighs on you.', 'Rarely restful, noted.', 'Every other day, not bad.', 'Good sleep, most of the time.', 'Sleep that\u2019s really doing its job.'] },
        { q: 'Your days filled with things that interest you?', opts: ['Not really', 'A bit', 'A few things', 'Fairly, yes', 'Almost every day'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noted.', 'A bit, that counts.', 'A few good moments.', 'Fairly full days.', 'Days that make you look forward, every day.'] }
      ],
      interp: function (s) { return s <= 8 ? { label: 'Tired mood', color: 'var(--rose)' } : s <= 14 ? { label: 'Mixed mood', color: 'var(--rose)' } : { label: 'Great mood', color: 'var(--rose)' }; },
      outro: function (it, s) {
        if (s >= 15) return { mood: 'celebration', text: 'Mild inner weather right now. Whatever helps with that already exists somewhere in your days — spotting it now mostly serves the stretches when the weather turns.' };
        if (s >= 9) return { mood: 'bienveillance', text: 'Mixed weather. You took two minutes to look at where you\u2019re at, which is far from obvious when your mood is middling \u2014 that\u2019s already a form of care.' };
        var low = Math.random() < 0.5
          ? { mood: 'ecoute', text: 'The weather\u2019s grey right now, and that counts. Answering these questions on a day like this takes more than on other days \u2014 and you just did. Talking to someone can help, and you\u2019re entitled to that because you\u2019re a human being, not because you\u2019d be unwell enough to deserve it.' }
          : { mood: 'acceptation', text: 'A tired mood right now, as it is, nothing to fix immediately. Talking to someone can help \u2014 and you\u2019re entitled to that because you\u2019re a human being, not because you\u2019d be unwell enough to deserve it.' };
        low.support = true;
        return low;
      }
    },
    {
      id: 'loneliness', name: 'UCLA-3 \u00b7 the connection you have', desc: 'Three questions on loneliness, scientifically validated',
      color: 'var(--ocre)', mood: 'ecoute',
      intro: 'Three questions, used since the 1980s to measure a factor that\u2019s often underestimated: felt loneliness. Studies specifically in people working on their substance use show it weighs as much as self-confidence in relapse risk.',
      fact: 'Feeling lonely has little to do with whether you\u2019re surrounded by people on paper. You can feel isolated in a crowd, and well accompanied with very few people around.',
      questions: [
        { q: 'Do you find you miss having someone to really talk to?', opts: ['Hardly ever', 'Sometimes', 'Often'], scores: [0, 1, 2],
          reacts: ['Noted \u2014 fairly rare.', 'It happens, then \u2014 got it.', 'Often, that weighs on you. Thank you for saying so.'] },
        { q: 'Do you find you feel left out?', opts: ['Hardly ever', 'Sometimes', 'Often'], scores: [0, 1, 2],
          reacts: ['Rare, good.', 'At times, got it.', 'Often \u2014 that\u2019s not nothing.'] },
        { q: 'Do you find you feel isolated from others, even when surrounded by people?', opts: ['Hardly ever', 'Sometimes', 'Often'], scores: [0, 1, 2],
          reacts: ['Rare \u2014 good sign.', 'Sometimes, ok.', 'Often. It\u2019s valuable that you name it.'] }
      ],
      interp: function (s) { return s <= 1 ? { label: 'Fairly well connected', color: 'var(--ocre)' } : s <= 3 ? { label: 'Some loneliness, at times', color: 'var(--ocre)' } : { label: 'Loneliness that\u2019s present these days', color: 'var(--ocre)' }; },
      outro: function (it, s) {
        if (s <= 1) return { mood: 'celebration', text: 'Fairly present connections right now. They\u2019re what makes an urge easier to get through \u2014 knowing who you can count on beats having to work it out on a bad night.' };
        if (s <= 3) return { mood: 'reflexion', text: 'Some loneliness at times. It\u2019s a known factor \u2014 the more isolated you feel, the harder an urge becomes to hold. Saying it, even to a screen, already breaks the isolation a little.',
          goExercise: { href:'elan.html', label:'Impulse', desc:' \u2014 reconnect with what matters to you.' } };
        var lonely = { mood: 'ecoute', text: 'Loneliness that\u2019s quite present these days, and that changes a lot in the face of an urge. Feeling alone has nothing to do with what you\u2019re worth or what you\u2019d deserve \u2014 it\u2019s a situation, not a flaw, and situations move. You\u2019ve just named it: that\u2019s the hardest step of all.',
          goExercise: { href:'lettre.html', label:'Letter to your future self', desc:' \u2014 a space just for you, even alone.' } };
        lonely.support = true;
        return lonely;
      }
    },
    {
      id: 'stress', name: 'PSS-4 \u00b7 this month\u2019s pressure', desc: 'Four questions on perceived stress, used worldwide',
      color: 'var(--fjord)', mood: 'reflexion',
      intro: 'Four questions, asked since 1983 in thousands of stress studies. Not about what actually happened, but about how you experienced it this past month \u2014 which often matters more than the facts themselves.',
      fact: 'Perceived stress isn\u2019t proportional to actual events. Two people living through the exact same week can come out of it with very different stress levels.',
      questions: [
        { q: 'This past month, did you feel unable to control the important things in your life?', opts: ['Never', 'Rarely', 'Sometimes', 'Fairly often', 'Very often'], scores: [0, 1, 2, 3, 4],
          reacts: ['Rarely or never \u2014 good sign.', 'Rare, got it.', 'At times, noted.', 'Fairly often, that weighs on you.', 'Very often \u2014 thank you for saying so clearly.'] },
        { q: 'This past month, did you feel confident about your ability to handle your personal problems?', opts: ['Never', 'Rarely', 'Sometimes', 'Fairly often', 'Very often'], scores: [4, 3, 2, 1, 0],
          reacts: ['Got it.', 'Rarely confident, noted.', 'A confidence that varies.', 'Fairly confident, good.', 'A solid confidence \u2014 that shows.'] },
        { q: 'This past month, did you feel that things were going your way?', opts: ['Never', 'Rarely', 'Sometimes', 'Fairly often', 'Very often'], scores: [4, 3, 2, 1, 0],
          reacts: ['Got it.', 'Rarely, noted.', 'A mixed month.', 'Mostly going your way.', 'A month that went well, then.'] },
        { q: 'This past month, did difficulties pile up so high you felt you couldn\u2019t overcome them?', opts: ['Never', 'Rarely', 'Sometimes', 'Fairly often', 'Very often'], scores: [0, 1, 2, 3, 4],
          reacts: ['Never \u2014 very good.', 'Rarely, good.', 'At times, it happens.', 'Fairly often \u2014 that\u2019s a lot to carry.', 'Very often. That\u2019s heavy, and it\u2019s received as such.'] }
      ],
      interp: function (s) { return s <= 4 ? { label: 'Fairly light pressure', color: 'var(--fjord)' } : s <= 9 ? { label: 'Moderate pressure', color: 'var(--fjord)' } : { label: 'High pressure right now', color: 'var(--fjord)' }; },
      outro: function (it, s) {
        if (s <= 4) return { mood: 'celebration', text: 'Fairly light pressure right now. This is the kind of stretch where working out what keeps you steady costs little \u2014 and pays off much later.' };
        if (s <= 9) return { mood: 'reflexion', text: 'Moderate pressure this month. Stress is one of the best-documented craving triggers \u2014 and you\u2019re holding up under it, which is no small thing. Taking a few minutes to breathe isn\u2019t a luxury: it\u2019s maintenance.',
          goExercise: { href:'breathe.html', label:'Breath', desc:' \u2014 bring the pressure down, concretely.' } };
        var stressed = { mood: 'bienveillance', text: 'High pressure right now. Holding up under it takes energy nobody sees and you supply anyway, every day \u2014 that isn\u2019t weakness, it\u2019s a load. Stress is one of the factors that make an urge hardest to hold: dealing with it counts as much as the rest.',
          goExercise: { href:'filtre.html', label:'Filter', desc:' \u2014 spotting what applies the pressure, before trying to lower it.' } };
        return stressed;
      }
    },
    {
      id: 'mood2', name: 'PHQ-4 \u00b7 mood & tension, in four questions', desc: 'A brief benchmark, used in general practice worldwide',
      color: 'var(--rose)', mood: 'ecoute',
      intro: 'Four questions, two on mood and two on inner tension \u2014 the kind of brief benchmark GPs use in a few minutes. Over the past two weeks, going with your gut.',
      fact: 'Ongoing tension and a low mood often reinforce each other \u2014 that\u2019s why this benchmark looks at both at once, rather than just one.',
      questions: [
        { q: 'Little interest or pleasure in doing things, these past two weeks?', opts: ['Never', 'Several days', 'More than half the days', 'Nearly every day'], scores: [0, 1, 2, 3],
          reacts: ['Never \u2014 good sign.', 'A few days, got it.', 'More than half the time, noted.', 'Nearly every day. Thank you for saying so.'] },
        { q: 'Feeling down, low, or like nothing was getting better, these past two weeks?', opts: ['Never', 'Several days', 'More than half the days', 'Nearly every day'], scores: [0, 1, 2, 3],
          reacts: ['Never \u2014 very good.', 'A few days, it happens.', 'More than half the time \u2014 that\u2019s a lot.', 'Nearly every day. That\u2019s received, and it counts.'] },
        { q: 'Feeling nervous, anxious, or on edge, these past two weeks?', opts: ['Never', 'Several days', 'More than half the days', 'Nearly every day'], scores: [0, 1, 2, 3],
          reacts: ['Rare \u2014 good.', 'A few days, noted.', 'More than half the time.', 'Nearly every day \u2014 real background tension.'] },
        { q: 'Unable to stop or control your worrying, these past two weeks?', opts: ['Never', 'Several days', 'More than half the days', 'Nearly every day'], scores: [0, 1, 2, 3],
          reacts: ['Never, good.', 'A few days, got it.', 'More than half the time.', 'Nearly every day \u2014 thoughts that are hard to let go of.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Fairly stable right now', color: 'var(--rose)' } : s <= 5 ? { label: 'A bit rattled these days', color: 'var(--rose)' } : { label: 'A lot to carry, these days', color: 'var(--rose)' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'celebration', text: 'Fairly stable, mood-wise and tension-wise, right now. Whatever keeps you there already exists \u2014 and it\u2019s easier to spot now than during a hard stretch.' };
        if (s <= 5) return { mood: 'reflexion', text: 'A bit rattled these days. Answering those four questions honestly is already facing things \u2014 that\u2019s not nothing, and it\u2019s yours.',
          goExercise: { href:'recadrage.html', label:'Reframe', desc:' \u2014 look at a hard thought from another angle.' } };
        var turbulent = { mood: 'bienveillance', text: 'A lot to carry right now, mood-wise and tension-wise. Answering those four questions honestly is already facing things \u2014 that\u2019s not nothing. It isn\u2019t a judgment or a diagnosis: just a marker, at one moment. And if you\u2019re blaming yourself as you read this, know that the blame comes from a lot further away than you. You don\u2019t have to prove anything to deserve help.',
          goExercise: { href:'rdr.html?tab=centres', label:'Finding someone', desc:' \u2014 places and lines in your region, no appointment, nothing to explain.' } };
        turbulent.support = true;
        return turbulent;
      }
    }
  ];
  function BILANS() { return lang() === 'en' ? BILANS_EN : BILANS_FR; }

  function byId(id) { var bl = BILANS(); for (var i = 0; i < bl.length; i++) if (bl[i].id === id) return bl[i]; return null; }

  /* Pioche UNE anecdote fraîche dans MDAnecdotes (52 entrées) — aléatoire à chaque appel,
     donc à chaque passage dans un bilan. Anti-répétition immédiate via sessionStorage
     (jamais deux fois la même anecdote lors de deux bilans consécutifs dans la même session). */
  function pickAnecdote() {
    var region = null;
    try { region = window.MDCore && MDCore.regionCode ? MDCore.regionCode() : null; } catch (e) {}
    // ~20 % de chances de proposer une anecdote de jonction entre deux régions (si possible),
    // pour inviter à découvrir qu'un thème proche existe ailleurs — jamais systématique.
    if (region && window.pickBridgeAnecdote && Math.random() < 0.2) {
      try {
        var bridge = window.pickBridgeAnecdote(region);
        if (bridge) return bridge;
      } catch (e) {}
    }
    var pool = (window.getAnecdotePool ? window.getAnecdotePool(region) : window.MDAnecdotes) || [];
    if (!pool.length) return null;
    // Moteur partagé : mémoire persistante (pas juste sessionStorage) sur les ~60 dernières
    // anecdotes vues, au lieu de n'exclure que la toute dernière. Repli sur l'ancienne logique
    // si le moteur n'est pas chargé sur cette page, pour ne jamais casser le bilan.
    if (window.MDMascotteMemoire) {
      try {
        var chosen = window.MDMascotteMemoire.pick('anecdotes', pool);
        if (chosen) return chosen;
      } catch (e) {}
    }
    var lastT = null;
    try { lastT = sessionStorage.getItem('mdBilanLastAnecdote'); } catch (e) {}
    var candidates = lastT ? pool.filter(function (a) { return a.t !== lastT; }) : pool;
    if (!candidates.length) candidates = pool;
    var a = candidates[Math.floor(Math.random() * candidates.length)];
    try { sessionStorage.setItem('mdBilanLastAnecdote', a.t); } catch (e) {}
    return a;
  }

  /* — LA GRANDE DISCUSSION —
     Une seule conversation qui mélange les 3 questionnaires (envie/alcool/moral) avec
     des anecdotes science & pop culture et des questions d'ambiance. Seules les étapes
     `ask` (rattachées à un bilan) sont scorées ; le reste « noie le poisson ».
     Types d'étape :
       {say, mood, fact?}                 -> le héros raconte (bouton Continuer)
       {ask:'craving'|'audit'|'wellbeing', qi} -> question scorée du bilan
       {vibe, mood, opts:[], reacts:[]}   -> question d'ambiance non scorée (réaction du héros)
       {result:true}                       -> synthèse + enregistrement */
  var VIBE_POOL_FR = [
    { vibe: 'Coupure : team lève-tôt ou couche-tard ?', mood: 'serenite', opts: ['Lève-tôt', 'Couche-tard', 'Ça dépend des jours'], reacts: ['Le monde t\u2019appartient au petit matin.', 'La nuit, c\u2019est ton terrain de jeu.', 'Flexible, j\u2019aime bien.'] },
    { vibe: 'Pour décompresser, tu es plutôt\u2026', mood: 'respiration', opts: ['Bouger', 'Cocooner', 'Voir du monde'], reacts: ['Le corps qui bouge, la tête qui se vide.', 'Le cocon, valeur sûre.', 'Les autres, ça recharge.'] },
    { vibe: 'Un truc qui te fait du bien en ce moment ?', mood: 'gratitude', opts: ['La musique', 'La nature', 'Les gens', 'Le calme'], reacts: ['La bande-son de tes journées.', 'Le vert, ça répare.', 'Le lien, ça tient chaud.', 'Le silence, ce luxe.'] },
    { vibe: 'Plutôt sucré ou salé, dans la vraie vie ?', mood: 'curiosite', opts: ['Sucré', 'Salé', 'Les deux, sans hésiter'], reacts: ['Un\u00b7e vrai\u00b7e romantique.', 'Simple et efficace.', 'Pourquoi choisir ?'] },
    { vibe: 'Ta saison préférée ?', mood: 'serenite', opts: ['Été', 'Hiver', 'Entre les deux'], reacts: ['Chaleur et lumière, toujours.', 'Le cocon et le calme.', 'Les transitions ont leur charme.'] },
    { vibe: 'Un film ou une série que tu reverrais en boucle ?', mood: 'curiosite', opts: ['Oui, toujours le même', 'Non, jamais deux fois', 'Ça dépend de l\u2019humeur'], reacts: ['Il y a un charme au connu.', 'Toujours du neuf, ça se comprend.', 'Le feeling du moment, logique.'] },
    { vibe: 'Plutôt silence ou musique de fond, pour te concentrer ?', mood: 'respiration', opts: ['Silence total', 'Musique de fond', 'Bruit ambiant, genre café'], reacts: ['Le calme, condition non négociable.', 'Un fond sonore, ça porte.', 'L\u2019agitation légère, étrangement efficace.'] },
    { vibe: 'Ce qui te fait le plus rire, en ce moment ?', mood: 'gratitude', opts: ['Les gens autour de moi', 'Des vidéos bêtes', 'L\u2019humour noir', 'Pas grand-chose, en ce moment'], reacts: ['Les proches, le meilleur remède.', 'Un peu de légèreté, ça fait du bien.', 'Rire du pire, une vraie soupape.', 'Ça arrive, et c\u2019est ok de le dire.'] },
    { vibe: 'Café ou thé pour démarrer la journée ?', mood: 'curiosite', opts: ['Café', 'Thé', 'Ni l\u2019un ni l\u2019autre'], reacts: ['Le rituel qui lance la machine.', 'Douceur et patience, dès le matin.', 'Un\u00b7e affranchi\u00b7e des habitudes.'] },
    { vibe: 'Plutôt mer ou montagne, si tu devais choisir ?', mood: 'serenite', opts: ['La mer', 'La montagne', 'Aucune des deux, en vrai'], reacts: ['L\u2019horizon qui ouvre la tête.', 'Le sommet, pour la perspective.', 'Chacun son terrain.'] },
    { vibe: 'Tu es plutôt du genre à tout planifier, ou à improviser ?', mood: 'reflexion', opts: ['Tout est prévu à l\u2019avance', 'Je vois sur le moment', 'Un mélange des deux'], reacts: ['Le contrôle, ça rassure.', 'Le lâcher-prise a du bon.', 'Le juste équilibre, pas facile à tenir.'] },
    { vibe: 'Une odeur qui te ramène direct à un souvenir ?', mood: 'gratitude', opts: ['Oui, tout de suite', 'Plutôt un son ou une musique', 'Plutôt une image'], reacts: ['L\u2019odorat, le sens le plus direct à la mémoire.', 'Le son, une machine à remonter le temps.', 'Une image qui reste gravée, ça arrive.'] },
    { vibe: 'Ton animal de compagnie idéal, même en rêve ?', mood: 'curiosite', opts: ['Un chien', 'Un chat', 'Quelque chose de plus original', 'Aucun, très bien comme ça'], reacts: ['La loyauté inconditionnelle.', 'L\u2019indépendance qui respecte la tienne.', 'Toujours des goûts qui sortent du lot.', 'Pas besoin de tout le monde pour se sentir bien.'] },
    { vibe: 'Une compétence que t\u2019aimerais avoir, sans effort ?', mood: 'motivation', opts: ['Parler une langue de plus', 'Jouer d\u2019un instrument', 'Un talent artistique', 'Rester calme en toute situation'], reacts: ['Le monde s\u2019ouvre avec les mots.', 'La musique, un langage à part.', 'Créer quelque chose de ses mains, précieux.', 'Ça, ça vaudrait de l\u2019or au quotidien.'] },
    { vibe: 'Plutôt lève-rideau ou dernière minute, pour préparer les choses ?', mood: 'reflexion', opts: ['J\u2019anticipe large', 'Je m\u2019y mets au dernier moment', 'Ça dépend vraiment du sujet'], reacts: ['L\u2019avance, ça évite bien des soucis.', 'La pression, un vrai moteur pour certains.', 'Le discernement au cas par cas, sous-estimé.'] }
  ];
  var VIBE_POOL_EN = [
    { vibe: 'Downtime: early bird or night owl?', mood: 'serenite', opts: ['Early bird', 'Night owl', 'Depends on the day'], reacts: ['The world belongs to you at dawn.', 'The night is your playground.', 'Flexible, I like it.'] },
    { vibe: 'To unwind, you\u2019re more of a\u2026', mood: 'respiration', opts: ['Move about', 'Cocoon at home', 'See people'], reacts: ['Body moving, mind clearing.', 'The cocoon, a safe bet.', 'Others, that recharges you.'] },
    { vibe: 'Something that\u2019s doing you good right now?', mood: 'gratitude', opts: ['Music', 'Nature', 'People', 'Quiet'], reacts: ['The soundtrack of your days.', 'Green, it repairs.', 'Connection keeps you warm.', 'Silence, that luxury.'] },
    { vibe: 'Sweet or savoury, in real life?', mood: 'curiosite', opts: ['Sweet', 'Savoury', 'Both, no question'], reacts: ['A true romantic.', 'Simple and efficient.', 'Why choose?'] },
    { vibe: 'Your favourite season?', mood: 'serenite', opts: ['Summer', 'Winter', 'Somewhere in between'], reacts: ['Warmth and light, always.', 'The cocoon and the calm.', 'Transitions have their charm.'] },
    { vibe: 'A film or show you\u2019d rewatch on loop?', mood: 'curiosite', opts: ['Yes, always the same one', 'No, never twice', 'Depends on the mood'], reacts: ['There\u2019s a charm to the familiar.', 'Always something new, makes sense.', 'Following the mood of the moment, logical.'] },
    { vibe: 'Silence or background music, to focus?', mood: 'respiration', opts: ['Total silence', 'Background music', 'Ambient noise, café-style'], reacts: ['Calm, a non-negotiable condition.', 'A sound bed, it carries you.', 'Light bustle, oddly effective.'] },
    { vibe: 'What makes you laugh the most, right now?', mood: 'gratitude', opts: ['People around me', 'Silly videos', 'Dark humour', 'Not much, right now'], reacts: ['Loved ones, the best remedy.', 'A bit of lightness does good.', 'Laughing at the worst, a real release valve.', 'That happens, and it\u2019s ok to say so.'] },
    { vibe: 'Coffee or tea to start the day?', mood: 'curiosite', opts: ['Coffee', 'Tea', 'Neither'], reacts: ['The ritual that starts the engine.', 'Softness and patience, from the morning.', 'Free from the usual habits.'] },
    { vibe: 'Sea or mountains, if you had to choose?', mood: 'serenite', opts: ['The sea', 'The mountains', 'Neither, honestly'], reacts: ['The horizon that opens the mind.', 'The summit, for the perspective.', 'To each their own ground.'] },
    { vibe: 'Are you more the type to plan everything, or improvise?', mood: 'reflexion', opts: ['Everything\u2019s planned ahead', 'I figure it out on the spot', 'A mix of both'], reacts: ['Control, that\u2019s reassuring.', 'Letting go has its merits.', 'The right balance, not easy to hold.'] },
    { vibe: 'A smell that takes you straight to a memory?', mood: 'gratitude', opts: ['Yes, instantly', 'More a sound or a song', 'More an image'], reacts: ['Smell, the most direct sense to memory.', 'Sound, a time machine.', 'An image that stays etched, that happens.'] },
    { vibe: 'Your ideal pet, even just in a dream?', mood: 'curiosite', opts: ['A dog', 'A cat', 'Something more original', 'None, perfectly happy as is'], reacts: ['Unconditional loyalty.', 'Independence that respects yours.', 'Always tastes that stand out.', 'No need for everyone to feel good.'] },
    { vibe: 'A skill you\u2019d love to have, effortlessly?', mood: 'motivation', opts: ['Speak another language', 'Play an instrument', 'An artistic talent', 'Stay calm in any situation'], reacts: ['The world opens up with words.', 'Music, a language of its own.', 'Creating something with your hands, precious.', 'That would be worth gold day to day.'] },
    { vibe: 'Early planner or last minute, to get things ready?', mood: 'reflexion', opts: ['I plan well ahead', 'I get to it at the last moment', 'Really depends on the topic'], reacts: ['Being ahead avoids a lot of trouble.', 'Pressure, a real driver for some.', 'Case-by-case judgment, underrated.'] }
  ];
  function VIBE_POOL() { return lang() === 'en' ? VIBE_POOL_EN : VIBE_POOL_FR; }
  function pickVibes(n) {
    var pool = VIBE_POOL().slice();
    for (var s = pool.length - 1; s > 0; s--) { var j = Math.floor(Math.random() * (s + 1)); var tmp = pool[s]; pool[s] = pool[j]; pool[j] = tmp; }
    return pool.slice(0, n);
  }

  var SEQ_FR = [
    { say: 'On va papoter deux minutes. Pas un interrogatoire — une discussion. Je glisse quelques questions utiles au milieu, et des trucs rigolos. Ça reste entre nous, sur ton téléphone.', mood: 'curiosite' },
    { ask: 'craving', qi: 0 },
    { ask: 'craving', qi: 1 },
    { say: 'Petite parenthèse : la bière et le cannabis sont cousins botaniques. Le houblon et le chanvre font partie de la même famille, les Cannabaceae. La nature a de l\u2019humour.', mood: 'explication' },
    { ask: 'craving', qi: 2 },
    { vibeSlot: 0 },
    { ask: 'audit', qi: 0 },
    { say: 'Info discrète mais utile : qu\u2019on parle de bière, de vin ou de spiritueux, la molécule qui agit est toujours la même — l\u2019éthanol. Un « verre standard », c\u2019est ~10 g d\u2019alcool pur.', mood: 'explication' },
    { ask: 'audit', qi: 1 },
    { ask: 'audit', qi: 2 },
    { vibeSlot: 1 },
    { say: 'Le 19 avril 1943, un chimiste suisse, Albert Hofmann, teste sur lui une molécule qu\u2019il vient de créer — le LSD — puis rentre chez lui à vélo. Depuis, les curieux appellent ça le « Bicycle Day ». L\u2019histoire des sciences est pleine de virages.', mood: 'reflexion' },
    { ask: 'wellbeing', qi: 0 },
    { ask: 'wellbeing', qi: 1 },
    { say: 'Anecdote pop : à sa création en 1886, le Coca-Cola contenait vraiment un extrait de feuille de coca. La cocaïne en a été retirée au tout début du XXe siècle. Le nom, lui, est resté.', mood: 'curiosite' },
    { ask: 'wellbeing', qi: 2 },
    { vibeSlot: 2 },
    { ask: 'wellbeing', qi: 3 },
    { ask: 'wellbeing', qi: 4 },
    { say: 'Tu savais que le fameux « high » du coureur ne vient pas que des endorphines ? Ton corps fabrique aussi ses propres endocannabinoïdes. Une petite pharmacie interne, gratuite et légale.', mood: 'motivation' },
    { say: 'On continue un peu, si ça te va — deux ou trois autres trucs qui comptent souvent plus qu\u2019on ne le pense.', mood: 'ecoute' },
    { ask: 'loneliness', qi: 0 },
    { ask: 'loneliness', qi: 1 },
    { say: 'Un fait qui surprend souvent : se sentir seul\u00b7e n\u2019a presque rien à voir avec le nombre de gens autour. On peut se sentir isolé\u00b7e en pleine foule.', mood: 'ecoute' },
    { ask: 'loneliness', qi: 2 },
    { vibeSlot: 3 },
    { ask: 'stress', qi: 0 },
    { ask: 'stress', qi: 1 },
    { say: 'Le stress perçu n\u2019est pas proportionnel aux évènements réels : deux personnes qui vivent la même semaine peuvent en ressortir avec un niveau de stress très différent.', mood: 'reflexion' },
    { ask: 'stress', qi: 2 },
    { ask: 'stress', qi: 3 },
    { vibeSlot: 4 },
    { ask: 'mood2', qi: 0 },
    { ask: 'mood2', qi: 1 },
    { say: 'Une tension qui dure et un moral en berne se renforcent souvent l\u2019un l\u2019autre — c\u2019est pour ça qu\u2019on regarde les deux à la fois, plutôt qu\u2019un seul isolément.', mood: 'ecoute' },
    { ask: 'mood2', qi: 2 },
    { ask: 'mood2', qi: 3 },
    { result: true }
  ];
  var SEQ_EN = [
    { say: 'Let\u2019s chat for a couple of minutes. Not an interrogation — a conversation. I\u2019ll slip in a few useful questions along the way, and some fun stuff. It stays between us, on your phone.', mood: 'curiosite' },
    { ask: 'craving', qi: 0 },
    { ask: 'craving', qi: 1 },
    { say: 'Quick aside: beer and cannabis are botanical cousins. Hops and hemp belong to the same family, the Cannabaceae. Nature has a sense of humour.', mood: 'explication' },
    { ask: 'craving', qi: 2 },
    { vibeSlot: 0 },
    { ask: 'audit', qi: 0 },
    { say: 'Quiet but useful fact: whether it\u2019s beer, wine, or spirits, the molecule doing the work is always the same — ethanol. A "standard drink" is about 10g of pure alcohol.', mood: 'explication' },
    { ask: 'audit', qi: 1 },
    { ask: 'audit', qi: 2 },
    { vibeSlot: 1 },
    { say: 'On April 19, 1943, a Swiss chemist named Albert Hofmann tested a molecule he\u2019d just created — LSD — on himself, then cycled home. Since then, the curious have called it "Bicycle Day." The history of science is full of twists.', mood: 'reflexion' },
    { ask: 'wellbeing', qi: 0 },
    { ask: 'wellbeing', qi: 1 },
    { say: 'Pop fact: when Coca-Cola was created in 1886, it really did contain coca leaf extract. Cocaine was removed from it in the very early 1900s. The name, though, stayed.', mood: 'curiosite' },
    { ask: 'wellbeing', qi: 2 },
    { vibeSlot: 2 },
    { ask: 'wellbeing', qi: 3 },
    { ask: 'wellbeing', qi: 4 },
    { say: 'Did you know the famous runner\u2019s "high" doesn\u2019t come only from endorphins? Your body also makes its own endocannabinoids. A small internal pharmacy, free and legal.', mood: 'motivation' },
    { say: 'Let\u2019s keep going a little, if that works for you — a couple more things that often matter more than we think.', mood: 'ecoute' },
    { ask: 'loneliness', qi: 0 },
    { ask: 'loneliness', qi: 1 },
    { say: 'A fact that often surprises: feeling lonely has almost nothing to do with how many people are around. You can feel isolated in a crowd.', mood: 'ecoute' },
    { ask: 'loneliness', qi: 2 },
    { vibeSlot: 3 },
    { ask: 'stress', qi: 0 },
    { ask: 'stress', qi: 1 },
    { say: 'Perceived stress isn\u2019t proportional to actual events: two people living through the same week can come out of it with very different stress levels.', mood: 'reflexion' },
    { ask: 'stress', qi: 2 },
    { ask: 'stress', qi: 3 },
    { vibeSlot: 4 },
    { ask: 'mood2', qi: 0 },
    { ask: 'mood2', qi: 1 },
    { say: 'Ongoing tension and a low mood often reinforce each other — that\u2019s why we look at both at once, rather than just one on its own.', mood: 'ecoute' },
    { ask: 'mood2', qi: 2 },
    { ask: 'mood2', qi: 3 },
    { result: true }
  ];
  function SEQ() { return lang() === 'en' ? SEQ_EN : SEQ_FR; }

  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mbh-ov{z-index:var(--z-modal-3,4200);align-items:center;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.5);font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mbh-card{position:relative;z-index:var(--z-base,1);border-radius:20px;' +
      'max-width:420px;width:100%;padding:24px 22px 20px;box-shadow:0 20px 55px rgba(31,43,37,.28);max-height:92vh;overflow:auto}' +
      '.mbh-prog{display:flex;gap:5px;margin-bottom:14px}' +
      '.mbh-dot{flex:1;height:5px;border-radius:3px;background:var(--line,#E2DCD0)}' +
      '.mbh-dot.on{background:var(--mc,#7A8F72)}' +
      '.mbh-hero{display:flex;align-items:flex-start;gap:11px;margin-bottom:14px}' +
      '.mbh-qav{display:flex;justify-content:center;margin-bottom:8px}' +
      '.mbh-qav .mdc-ava{opacity:.92}' +
      '.mbh-hero .mdc-ava{margin:0}' +
      '.mbh-bub{flex:1;min-width:0;background:var(--mc50,#EEF1E9);border-radius:14px 14px 14px 4px;padding:11px 13px}' +
      '.mbh-bub p{margin:0;font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-sm,14.5px);line-height:var(--lh-normal,1.45)}' +
      '.mbh-fact{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-xs,12.5px);line-height:var(--lh-normal,1.5);' +
      'color:var(--ink-2,#58635E);background:var(--bg-2,#FBF8F1);border-left:3px solid var(--mc,#7A8F72);' +
      'border-radius:8px;padding:8px 11px;margin:0 0 14px}' +
      '.mbh-fact b{color:var(--mc,#33463E)}' +
      '.mbh-q{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-lead,18px);line-height:var(--lh-tight,1.3);margin:0 0 12px}' +
      '.mbh-opt{display:block;width:100%;text-align:left;border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);' +
      'color:var(--ink,#1F2B25);border-radius:12px;padding:12px 14px;margin-bottom:8px;font-size:var(--fs-sm,14.5px);cursor:pointer;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);-webkit-tap-highlight-color:transparent}' +
      '.mbh-opt:hover{border-color:var(--mc,#7A8F72);background:var(--surface,#fff)}' +
      '.mbh-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);' +
      'font-size:var(--fs-ui,15px);padding:13px;cursor:pointer;margin-top:4px;font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mbh-2{display:flex;gap:10px;margin-top:10px}' +
      '.mbh-2 .mbh-go{margin-top:0}' +
      '.mbh-skip{display:block;width:100%;text-align:center;background:none;border:none;color:var(--ink-2,#58635E);' +
      'text-decoration:underline;font-size:var(--fs-xs,13px);padding:11px 0 2px;cursor:pointer;font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mbh-res{text-align:center}' +
      '.mbh-res-badge{display:inline-flex;align-items:center;gap:7px;font-weight:var(--w-bold,700);font-size:var(--fs-sm,14px);' +
      'color:var(--ink,#1F2B25);padding:3px 2px;margin-bottom:8px}' +
      '.mbh-res-badge::before{content:"";display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--dot,#7A8F72);flex:none}' +
      '.mbh-res-score{font-size:var(--fs-xs,13px);color:var(--ink-2,#58635E);margin-bottom:14px}' +
      '.mbh-support{display:block;background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:12px;' +
      'padding:11px 13px;margin:0 0 14px;font-size:var(--fs-xs,13px);line-height:var(--lh-normal,1.5);color:var(--ink,#1F2B25);text-decoration:none}' +
      '.mbh-support b{color:var(--terra,#C7765C)}' +
      '.mbh-goex b{color:var(--sauge,#7A8F72)}' +
      '.mbh-syn{display:flex;flex-direction:column;gap:8px;margin:4px 0 14px}' +
      '.mbh-syn-row{display:flex;align-items:center;justify-content:space-between;gap:10px;' +
      'background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:12px;padding:9px 12px}' +
      '.mbh-syn-lbl{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-sm,14px);font-weight:var(--w-bold,700)}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function accentVars(color) {
    /* La couleur d'un bilan est toujours un token de famille Atlas (var(--terra)…).
       On en dérive la variante claire par son token -50, pour que le thème sombre
       suive automatiquement — un color-mix avec du blanc en dur ne le ferait pas.
       Voir 20_DESIGN_SYSTEM.md : aucune valeur hors tokens.css. */
    var c = color || 'var(--sauge)';
    var m = /var\(--([a-z]+)\)/.exec(c);
    var c50 = m ? 'var(--' + m[1] + '-50)' : 'color-mix(in srgb,' + c + ' 14%,var(--surface,#fff))';
    return '--mc:' + c + ';--mc50:' + c50;
  }
  function heroBlock(mood, color, html) {
    var av = (window.MDCompagnon) ? window.MDCompagnon.avatarHTML(mood, { size: 'md' }) : '';
    return '<div class="mbh-hero">' + av + '<div class="mbh-bub"><p>' + html + '</p></div></div>';
  }
  /* Petit avatar seul, sans bulle — pour que la mascotte reste visible sur les écrans de
     question eux-mêmes (avant réponse), pas seulement sur les écrans de transition. Mise
     en page unifiée : aucun type d'écran du questionnaire ne doit en être dépourvu. */
  function avatarTag(mood) {
    return (window.MDCompagnon) ? '<div class="mbh-qav">' + window.MDCompagnon.avatarHTML(mood, { size: 'sm' }) + '</div>' : '';
  }

  function overlay() {
    inject();
    var ov = document.createElement('div'); ov.className = 'mbh-ov md-ov';
    var card = document.createElement('div'); card.className = 'mbh-card md-card';
    ov.appendChild(card);
    ov.addEventListener('click', function (e) { if (e.target === ov) closeOv(ov); });
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: ui('faire_le_point'), onClose: function(){ closeOv(ov); } });
    return { ov: ov, card: card };
  }
  function closeOv(ov) { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); }

  /* Préambule : le héros propose de faire le point, sans pression. */
  function openMenu(opts) {
    opts = opts || {};
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars('var(--sauge)');
    var listHtml = BILANS().map(function (b) {
      return '<button class="mbh-opt" data-bid="' + b.id + '"><b>' + esc(b.name) + '</b><br>' +
        '<span style="color:var(--ink-2,#58635E);font-size:var(--fs-xs,12.5px)">' + esc(b.desc) + '</span></button>';
    }).join('');
    card.innerHTML =
      heroBlock('curiosite', '#7A8F72', ui('menu_intro')) +
      '<button class="mbh-opt" data-act="grande" style="border-color:var(--sauge,#7A8F72)"><b>' + esc(ui('full_conv')) + '</b><br>' +
      '<span style="color:var(--ink-2,#58635E);font-size:var(--fs-xs,12.5px)">' + esc(ui('full_conv_desc')) + '</span></button>' +
      '<div style="font-size:var(--fs-caps,11px);color:var(--ink-2,#58635E);text-transform:uppercase;letter-spacing:var(--ls-caps,.08em);margin:12px 2px 8px">' + esc(ui('or_precise')) + '</div>' +
      listHtml +
      '<button class="mbh-skip" data-act="later">' + esc(ui('later')) + '</button>';
    card.querySelector('[data-act="grande"]').addEventListener('click', function () { closeOv(o.ov); openGrande(opts); });
    card.querySelectorAll('[data-bid]').forEach(function (btn) {
      btn.addEventListener('click', function () { closeOv(o.ov); open(btn.getAttribute('data-bid')); });
    });
    var later = card.querySelector('[data-act="later"]');
    if (later) later.addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(); });
  }

  /* Discussion d'un bilan : intro -> questions -> résultat. */
  function open(id, opts) {
    opts = opts || {};
    var b = byId(id); if (!b) return;
    inject();
    var answers = [];
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars(b.color);

    function intro() {
      card.innerHTML =
        heroBlock(b.mood, b.color, esc(b.intro)) +
        (b.fact ? '<p class="mbh-fact"><b>' + esc(ui('for_info')) + '</b> ' + esc(b.fact) + '</p>' : '') +
        '<div class="mbh-2"><button class="mbh-go" data-act="go">' + esc(ui('lets_go')) + '</button></div>' +
        '<button class="mbh-skip" data-act="later">' + esc(ui('later')) + '</button>';
      card.querySelector('[data-act="go"]').addEventListener('click', function () { step(0); });
      card.querySelector('[data-act="later"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    var anecdoteAt = Math.floor(b.questions.length / 2); // insérée après la question du milieu
    var anecdoteShown = false;

    function step(i) {
      var qn = b.questions[i];
      var dots = b.questions.map(function (_, k) { return '<div class="mbh-dot' + (k <= i ? ' on' : '') + '"></div>'; }).join('');
      card.innerHTML =
        '<div class="mbh-prog">' + dots + '</div>' + avatarTag(b.mood) +
        '<p class="mbh-q">' + esc(qn.q) + '</p>' +
        qn.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
        '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
      card.querySelectorAll('[data-k]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var k = parseInt(btn.getAttribute('data-k'), 10);
          answers.push(qn.scores[k]);
          var advance = function () {
            if (i + 1 >= b.questions.length) { result(); return; }
            if (i === anecdoteAt - 1 && !anecdoteShown) { anecdoteShown = true; anecdoteBreak(i + 1); }
            else step(i + 1);
          };
          var reactTxt = (qn.reacts && qn.reacts[k]) ? qn.reacts[k] : qn.t;
          if (reactTxt) {
            card.innerHTML = heroBlock(b.mood, b.color, esc(reactTxt)) +
              '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
            card.querySelector('[data-act="next"]').addEventListener('click', advance);
          } else { advance(); }
        });
      });
      card.querySelector('[data-act="quit"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function anecdoteBreak(nextI) {
      var a = pickAnecdote();
      if (!a) { step(nextI); return; }
      card.innerHTML =
        heroBlock(a.mood || b.mood, b.color, esc((window.MDCore && MDCore.lang && MDCore.lang()==='en' && a.en) ? a.en : a.t)) +
        '<button class="mbh-go" data-act="next">' + esc(ui('continue_btn')) + '</button>' +
        '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
      card.querySelector('[data-act="next"]').addEventListener('click', function () { step(nextI); });
      card.querySelector('[data-act="quit"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function result() {
      var total = answers.reduce(function (a, c) { return a + c; }, 0);
      var it = b.interp(total);
      var out = b.outro ? b.outro(it, total) : { mood: b.mood, text: '' };
      // enregistrement compatible historique (sessions type 'q')
      try {
        var d = read();
        d.sessions = Array.isArray(d.sessions) ? d.sessions : [];
        d.sessions.push({ type: 'q', id: b.id, name: b.name, date: Date.now(), label: it.label, color: it.color, score: total });
        if (d.parcours) d.parcours.dernierJourActif = Date.now();
        save(d);
      } catch (e) { }
      var support = out.support
        ? '<a class="mbh-support" href="rdr.html?tab=centres"><b>' + esc(ui('want_to_talk')) + '</b>' + esc(ui('support_line_centres')) + '</a>'
        : '';
      var goEx = out.goExercise
        ? '<a class="mbh-support mbh-goex" href="' + esc(out.goExercise.href) + '"><b>' + esc(out.goExercise.label) + '</b>' + esc(out.goExercise.desc || '') + '</a>'
        : '';
      var scaleMax = Math.max.apply(null, b.questions[0].scores);
      var resMood = out.mood || b.mood;
      var resAv = window.MDMascotte
        ? window.MDMascotte.avatar('bilan', { humeur: resMood })
        : ((window.MDCompagnon) ? window.MDCompagnon.avatarHTML(resMood, { size: 'md' }) : '');
      card.innerHTML =
        '<div class="mbh-hero">' + resAv + '<div class="mbh-bub"><p>' + esc(out.text) + '</p></div></div>' +
        '<div class="mbh-res">' +
        '<span class="mbh-res-badge" style="--dot:' + it.color + '">' + esc(it.label) + '</span>' +
        '<div class="mbh-res-score">' + ui('score_lbl', total, (b.questions.length * scaleMax)) + '</div>' +
        support + goEx +
        '<button class="mbh-go" data-act="done">' + esc(ui('finish')) + '</button>' +
        '</div>';
      card.querySelector('[data-act="done"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(total); });
    }

    intro();
  }

  /* La grande discussion : déroule SEQ, collecte les réponses scorées par bilan,
     puis calcule/enregistre les 3 scores et fait une synthèse. */
  function openGrande(opts) {
    opts = opts || {};
    inject();
    var answers = { craving: [], audit: [], wellbeing: [], loneliness: [], stress: [], mood2: [] };
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars('var(--sauge)');

    // Construit la séquence du jour : chaque « anecdote » de SEQ est remplacée par une
    // anecdote piochée au hasard dans MDAnecdotes -> renouvellement à chaque passage.
    var __region = null;
    try { __region = window.MDCore && MDCore.regionCode ? MDCore.regionCode() : null; } catch (e) {}
    var pool = (window.getAnecdotePool ? window.getAnecdotePool(__region) : (window.MDAnecdotes || [])).slice();
    if (__region && window.pickBridgeAnecdote && Math.random() < 0.3) {
      try {
        var __bridge = window.pickBridgeAnecdote(__region);
        if (__bridge) pool.push(__bridge);
      } catch (e) {}
    }
    for (var s1 = pool.length - 1; s1 > 0; s1--) { var j = Math.floor(Math.random() * (s1 + 1)); var tmp = pool[s1]; pool[s1] = pool[j]; pool[j] = tmp; }
    var pi = 0;
    var chosenVibes = pickVibes(5);
    var seq = SEQ().map(function (st, idx) {
      if (st.say && idx > 0 && pool.length) { var a = pool[pi % pool.length]; pi++; return { say: (window.MDCore && MDCore.lang && MDCore.lang()==='en' && a.en) ? a.en : a.t, mood: a.mood }; }
      if (st.vibeSlot != null) { return chosenVibes[st.vibeSlot] || chosenVibes[0]; }
      return st;
    });
    var nAsk = seq.filter(function (s) { return s.ask; }).length, askDone = 0;

    function progress() {
      var pct = Math.round((askDone / nAsk) * 100);
      return '<div class="mbh-prog"><div class="mbh-dot on" style="flex:' + pct + '"></div><div class="mbh-dot" style="flex:' + (100 - pct) + '"></div></div>';
    }

    function render(i) {
      if (i >= seq.length) return;
      var stp = seq[i];

      if (stp.result) { result(); return; }

      if (stp.say) {
        card.style.cssText += accentVars('var(--sauge)');
        card.innerHTML = progress() +
          heroBlock(stp.mood || 'curiosite', '#7A8F72', esc(stp.say)) +
          (stp.fact ? '<p class="mbh-fact">' + esc(stp.fact) + '</p>' : '') +
          '<button class="mbh-go" data-act="next">' + esc(ui('continue_btn')) + '</button>' +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
        bindQuit(card);
        return;
      }

      if (stp.vibe) {
        card.style.cssText += accentVars('var(--sauge)');
        card.innerHTML = progress() + avatarTag(stp.mood || 'serenite') +
          '<p class="mbh-q">' + esc(stp.vibe) + '</p>' +
          stp.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelectorAll('[data-k]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var k = parseInt(btn.getAttribute('data-k'), 10);
            var react = (stp.reacts && stp.reacts[k]) ? stp.reacts[k] : ui('noted');
            card.innerHTML = heroBlock(stp.mood || 'serenite', '#7A8F72', esc(react)) +
              '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
            card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
          });
        });
        bindQuit(card);
        return;
      }

      if (stp.ask) {
        var b = byId(stp.ask); var qn = b.questions[stp.qi];
        card.style.cssText += accentVars(b.color);
        card.innerHTML = progress() + avatarTag(b.mood) +
          '<p class="mbh-q">' + esc(qn.q) + '</p>' +
          qn.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelectorAll('[data-k]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var k = parseInt(btn.getAttribute('data-k'), 10);
            answers[stp.ask].push(qn.scores[k]);
            askDone++;
            var reactTxt = (qn.reacts && qn.reacts[k]) ? qn.reacts[k] : qn.t;
            if (reactTxt) {
              card.innerHTML = heroBlock(b.mood, b.color, esc(reactTxt)) +
                '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
              card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
            } else {
              render(i + 1);
            }
          });
        });
        bindQuit(card);
        return;
      }
    }

    function bindQuit(c) {
      var q = c.querySelector('[data-act="quit"]');
      if (q) q.addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function result() {
      var saved = [], sensible = false;
      try {
        var d = read(); d.sessions = Array.isArray(d.sessions) ? d.sessions : [];
        BILANS().forEach(function (b) {
          var a = answers[b.id];
          if (a.length === b.questions.length) { // bilan complété
            var total = a.reduce(function (x, y) { return x + y; }, 0);
            var it = b.interp(total);
            d.sessions.push({ type: 'q', id: b.id, name: b.name, date: Date.now(), label: it.label, color: it.color, score: total });
            var out = b.outro ? b.outro(it, total) : null;
            if (out && out.support) sensible = true;
            saved.push({ b: b, it: it, out: out });
          }
        });
        if (d.parcours) d.parcours.dernierJourActif = Date.now();
        save(d);
      } catch (e) { }

      var rows = saved.map(function (r) {
        return '<div class="mbh-syn-row"><span class="mbh-syn-lbl">' + esc(shortAxis(r.b.id)) + '</span>' +
          '<span class="mbh-res-badge" style="--dot:' + r.it.color + '">' + esc(r.it.label) + '</span></div>';
      }).join('');
      var support = sensible
        ? '<a class="mbh-support" href="rdr.html?tab=centres"><b>' + esc(ui('want_to_talk')) + '</b>' + esc(ui('support_line_reflexes')) + '</a>'
        : '';
      var headMood = sensible ? 'ecoute' : 'celebration';
      var headText = saved.length
        ? ui('thanks_moment')
        : ui('no_worries_stop');
      card.style.cssText += accentVars('var(--sauge)');
      card.innerHTML =
        heroBlock(headMood, '#7A8F72', esc(headText)) +
        (rows ? '<div class="mbh-syn">' + rows + '</div>' : '') +
        support +
        '<button class="mbh-go" data-act="done">' + esc(ui('finish')) + '</button>';
      card.querySelector('[data-act="done"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(saved.length); });
    }

    function shortAxis(id) {
      return id === 'craving' ? ui('axis_craving') : id === 'audit' ? ui('axis_audit') : id === 'wellbeing' ? ui('axis_wellbeing') :
        id === 'loneliness' ? ui('axis_loneliness') : id === 'stress' ? ui('axis_stress') : ui('axis_mood2');
    }

    render(0);
  }

  return { data: BILANS(), list: function () { return BILANS(); }, open: open, openMenu: openMenu, openGrande: openGrande };
})();
