/* bilan-hero.js — « Faire le point » version discussion avec le compagnon Atlas.
   Reprend le FOND des bilans validés (Bilan Craving, AUDIT-C Alcool OMS, Bien-être WHO-5)
   mais noyé dans une conversation chaleureuse, didactique, un brin punk/pop culture —
   sans jamais moraliser ni juger. Le scoring et l'interprétation sont IDENTIQUES aux
   bilans cliniques d'origine, et l'enregistrement est compatible avec l'historique
   existant (sessions type 'q'), donc ça alimente le profil / la carte neurocognitive
   comme avant.

   API :
     MDBilanHero.data            -> tableau des bilans (structure compatible avec l'ancien QS)
     MDBilanHero.list()          -> idem (pour afficher les cartes)
     MDBilanHero.open(id)        -> lance la discussion d'un bilan
     MDBilanHero.openMenu(opts)  -> préambule : le héros propose de faire le point
   Dépend de MDCompagnon (avatars) si présent ; dégrade proprement sinon.
   100 % local. Respecte prefers-reduced-motion (via MDCompagnon). */
window.MDBilanHero = (function () {
  'use strict';

  function lang() { try { return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; } catch (e) { return 'fr'; } }
  var UI = {
    lets_go:{fr:'C\u2019est parti',en:'Let\u2019s go'}, later:{fr:'Plus tard',en:'Later'},
    go_on:{fr:'On continue',en:'Let\u2019s continue'}, stop_here:{fr:'Arrêter là',en:'Stop here'},
    continue_btn:{fr:'Continuer',en:'Continue'}, finish:{fr:'Terminer',en:'Finish'},
    for_info:{fr:'Pour info \u2014',en:'For context \u2014'},
    score_lbl:{fr:function(t,m){return 'Score : '+t+' / '+m+' \u00b7 ajouté à ton profil';}, en:function(t,m){return 'Score: '+t+' / '+m+' \u00b7 added to your profile';}},
    want_to_talk:{fr:'Envie d\u2019en parler ?',en:'Want to talk about it?'},
    support_line_centres:{fr:' Des lignes d\u2019écoute et des assos près de chez toi, dans Réduire les risques \u203A Centres.',
                           en:' Helplines and local support groups, in Reduce risks \u203A Centres.'},
    support_line_reflexes:{fr:' Des lignes d\u2019écoute et des assos près de chez toi, dans Réflexes \u203A Centres.',
                            en:' Helplines and local support groups, in Reflexes \u203A Centres.'},
    noted:{fr:'Noté !',en:'Noted!'},
    faire_le_point:{fr:'Faire le point',en:'Check in'},
    menu_intro:{fr:'On fait le point ensemble ? Le plus sympa, c\u2019est la discussion complète — je mêle les questions utiles à des anecdotes et des trucs légers. Ou tu prends juste un repère précis.',
                en:'Want to check in together? The nicest way is the full conversation — I mix the useful questions with anecdotes and light stuff. Or you can just grab one specific reading.'},
    full_conv:{fr:'La discussion complète',en:'The full conversation'},
    full_conv_desc:{fr:'Envie, alcool, moral \u2014 en une conversation détendue',en:'Craving, alcohol, mood \u2014 in one relaxed conversation'},
    or_precise:{fr:'Ou un repère précis',en:'Or one specific reading'},
    thanks_moment:{fr:'Merci pour ce moment. Voilà ce que j\u2019en retiens — sans jugement, juste des repères qui nourrissent ton profil.',
                   en:'Thanks for this moment. Here\u2019s what I\u2019m taking from it — no judgment, just readings that feed your profile.'},
    no_worries_stop:{fr:'Pas de souci, on s\u2019arrête là. Reviens quand tu veux.',en:'No worries, we\u2019ll stop here. Come back whenever you want.'},
    axis_craving:{fr:'Ton envie',en:'Your craving'}, axis_audit:{fr:'Alcool',en:'Alcohol'}, axis_wellbeing:{fr:'Ton moral',en:'Your mood'}
  };
  function ui(k, a, b) { var e = UI[k]; if (!e) return k; var v = lang() === 'en' ? e.en : e.fr; return (typeof v === 'function') ? v(a, b) : v; }

  var KEY = 'ctc_v6';
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function save(d) { try { if (window.MDData && MDData.write) { MDData.write(d); } else { localStorage.setItem(KEY, JSON.stringify(d)); } } catch (e) { } }
  function read() { return (window.MDData && MDData.read) ? MDData.read() : load(); }

  /* — Les 3 bilans. `questions/opts/scores/interp` = fidèles aux versions validées.
     Champs d'habillage en plus : mood (avatar), intro (le héros pose le décor),
     fact (encart didactique « pour info »), transitions (petites relances entre Q),
     outro(interp,total) (mot de fin humain). BILANS_FR/BILANS_EN : même structure et
     mêmes scores/seuils cliniques dans les deux langues — seul le texte change. — */
  var BILANS_FR = [
    {
      id: 'craving', name: 'Le craving, on le cartographie', desc: 'Intensité, fréquence, résistance',
      color: '#C7765C', mood: 'ecoute',
      intro: 'Le craving, cette envie qui débarque sans frapper et prend toute la place. On va la cartographier ensemble — trois questions. Un ennemi qu\u2019on connaît fait toujours moins peur.',
      fact: 'Le craving n\u2019est pas un manque de volonté : c\u2019est un circuit cérébral qui s\u2019emballe. Le nommer, c\u2019est déjà reprendre un peu la main.',
      questions: [
        { q: 'Cette semaine, l\u2019envie tapait à quelle intensité, en moyenne ?', opts: ['Quasi absente', 'Plutôt légère', 'Bien là', 'Assez forte', 'Version maximale'], scores: [1, 2, 3, 4, 5],
          reacts: ['Ok, noté. Une semaine plutôt tranquille de ce côté-là.', 'Ok, noté. Ça se sent, sans être envahissant.', 'Ok, noté. Présente, mine de rien.', 'Ok, noté. Ça a dû prendre pas mal de place.', 'Ok, noté. Une semaine intense, clairement.'] },
        { q: 'Cette envie, elle revenait à quelle fréquence, cette semaine ?', opts: ['Rare', 'Quelques fois', 'Tous les jours', 'Plusieurs fois/jour', 'Quasi non-stop'], scores: [1, 2, 3, 4, 5],
          reacts: ['Je vois. Pas grand-chose à gérer, alors.', 'Je vois. De temps en temps, sans plus.', 'Je vois. Un rendez-vous quotidien, donc.', 'Je vois. Ça revient souvent dans la journée.', 'Je vois. Presque en continu — ça pèse, forcément.'] },
        { q: 'Tu as réussi à laisser passer des envies sans céder ?', opts: ['Toujours', 'Souvent', 'La moitié du temps', 'Rarement', 'Jamais'], scores: [5, 4, 3, 2, 1],
          reacts: ['Un contrôle solide, tout du long.', 'Plutôt bien tenu, dans l\u2019ensemble.', 'Un coup sur deux — déjà pas rien.', 'Difficile cette fois, et c\u2019est ok de le dire.', 'Aucune, cette semaine — retiens juste que tu es encore là à en parler.'] }
      ],
      interp: function (s) { return s <= 5 ? { label: 'Semaine stable', color: '#69889A' } : s <= 9 ? { label: 'Semaine remuante', color: '#b05800' } : { label: 'Semaine chargée', color: '#C7765C' }; },
      outro: function (it, s) {
        if (s <= 5) return { mood: 'encouragement', text: 'Semaine plutôt stable. Tu tiens ton cap — c\u2019est du concret, pas de la chance.' };
        if (s <= 9) return { mood: 'bienveillance', text: 'Semaine chargée. Rien d\u2019anormal : les vagues montent, puis redescendent. Un exercice « anti-craving » peut aider à surfer.' };
        return { mood: 'bienveillance', text: 'Semaine chargée, et c\u2019est ok. Les vagues finissent toujours par redescendre. Un exercice « surf de l\u2019envie » peut t\u2019accompagner, quand tu veux.' };
      }
    },
    {
      id: 'audit', name: 'AUDIT-C · le thermomètre alcool', desc: 'Le questionnaire de référence de l\u2019OMS',
      color: '#69889A', mood: 'curiosite',
      intro: 'L\u2019AUDIT-C, c\u2019est le petit questionnaire que l\u2019OMS a filé aux soignants du monde entier. Trois questions, pas une de plus. Pas de piège, pas de morale — juste un thermomètre pour situer où tu en es.',
      fact: 'Un « verre standard », c\u2019est ~10 g d\u2019alcool pur : un demi de bière, un ballon de vin, une dose de spiritueux. Servis maison, ils sont souvent plus costauds.',
      questions: [
        { q: 'Et l\u2019alcool, ça t\u2019arrive d\u2019en boire souvent ces temps-ci ?', opts: ['Jamais', 'Une fois par mois, grand max', '2 à 4 fois par mois', '2 à 3 fois par semaine', '4 fois par semaine ou plus'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok. Pas vraiment ton truc, alors.', 'Ok. Occasionnel, donc.', 'Ok. Quelques fois dans le mois.', 'Ok. Une bonne partie de la semaine.', 'Ok. Presque un rituel, alors.'] },
        { q: 'Et un jour où tu bois, tu t\u2019arrêtes généralement à combien de verres ?', opts: ['1 ou 2', '3 ou 4', '5 ou 6', '7 à 9', '10 ou plus'], scores: [0, 1, 2, 3, 4],
          reacts: ['Reçu. Plutôt sobre, dans l\u2019ensemble.', 'Reçu. Une consommation modérée.', 'Reçu. Ça commence à compter.', 'Reçu. C\u2019est une vraie quantité.', 'Reçu. Une quantité conséquente, notée.'] },
        { q: 'À quelle fréquence ça t\u2019arrive de boire six verres ou plus en une seule occasion ?', opts: ['Jamais', 'Moins d\u2019une fois par mois', 'Une fois par mois', 'Une fois par semaine', 'Presque tous les jours'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ça n\u2019arrive jamais \u2014 très bien.', 'Rarement, donc \u2014 noté.', 'Une fois de temps en temps.', 'Une habitude hebdomadaire, alors.', 'Quasi quotidien \u2014 un vrai repère à garder en tête.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Rien à signaler', color: '#7A8F72' } : s <= 5 ? { label: 'À garder à l\u2019œil', color: '#b05800' } : { label: 'Point de vigilance', color: '#C7765C' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'encouragement', text: 'Zone faible risque. Rien à signaler côté thermomètre — tu gères.' };
        if (s <= 5) return { mood: 'reflexion', text: 'Zone modérée. Pas d\u2019alarme, juste un repère : ça vaut le coup de garder un œil dessus, à ton rythme.' };
        return { mood: 'bienveillance', text: 'Juste un repère qui mérite ton attention, à ton rythme. Si tu veux en parler un jour, des gens bienveillants sont là — c\u2019est une force.' };
      }
    },
    {
      id: 'wellbeing', name: 'WHO-5 · la météo de ton moral', desc: 'Cinq questions, validées par l\u2019OMS',
      color: '#8E7CB8', mood: 'serenite',
      intro: 'Cinq questions pensées par l\u2019OMS pour prendre la météo de ton moral. Genre check-up, mais pour la tête. Réponds au feeling, sur les deux dernières semaines — y a pas de bonne réponse.',
      fact: 'Le WHO-5 mesure le bien-être, pas la « performance ». Un score bas ne te définit pas : c\u2019est une photo de l\u2019instant, et une photo, ça se reprend.',
      questions: [
        { q: 'De bonne humeur la plupart du temps ?', opts: ['Pas trop, non', 'Un peu', 'Ça va, moyen', 'Plutôt oui', 'Clairement oui'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, merci pour l\u2019honnêteté.', 'Un peu, c\u2019est déjà ça.', 'Une moyenne correcte.', 'Plutôt bon signe.', 'Belle énergie, ça se sent.'] },
        { q: 'Calme et détendu\u00b7e ces derniers temps ?', opts: ['Pas vraiment', 'Un peu', 'Ça dépend des jours', 'Assez souvent', 'Zen la plupart du temps'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noté.', 'Un peu de calme, tant mieux.', 'Ça varie, comme souvent.', 'Une belle tranquillité.', 'Un bel équilibre, ça.'] },
        { q: 'Plein\u00b7e d\u2019énergie, d\u2019allant ?', opts: ['À plat', 'Un peu de jus', 'Correct', 'En forme', 'Débordant\u00b7e'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, ça arrive d\u2019être à plat.', 'Un peu de jus, c\u2019est un début.', 'Une énergie correcte.', 'Bien, ça se sent.', 'Une belle dose d\u2019énergie.'] },
        { q: 'Tu te réveilles plutôt frais\u00b7che et reposé\u00b7e ?', opts: ['Jamais, ou presque', 'Rarement', 'Un jour sur deux', 'La plupart du temps', 'Systématiquement'], scores: [0, 1, 2, 3, 4],
          reacts: ['Un sommeil qui ne répare pas assez, ça pèse.', 'Rarement reposant, noté.', 'Un jour sur deux, pas mal.', 'Un bon sommeil, la plupart du temps.', 'Un sommeil qui fait vraiment son travail.'] },
        { q: 'Tes journées sont remplies de trucs qui t\u2019intéressent ?', opts: ['Pas trop', 'Un peu', 'Quelques-unes', 'Pas mal, oui', 'Tous les jours ou presque'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noté.', 'Un peu, ça compte.', 'Quelques bons moments.', 'Des journées plutôt remplies.', 'Des journées qui donnent envie, chaque jour.'] }
      ],
      interp: function (s) { return s <= 8 ? { label: 'Moral fatigué', color: '#C7765C' } : s <= 14 ? { label: 'Moral en demi-teinte', color: '#b05800' } : { label: 'Moral au beau fixe', color: '#7A8F72' }; },
      outro: function (it, s) {
        if (s >= 15) return { mood: 'celebration', text: 'Belle météo intérieure en ce moment. Savoure — et note ce qui te fait du bien, ça se cultive.' };
        if (s >= 9) return { mood: 'bienveillance', text: 'Météo mitigée. Rien d\u2019alarmant, mais prends soin de toi : un peu de souffle, de sommeil, de choses qui te font vibrer.' };
        var low = Math.random() < 0.5
          ? { mood: 'ecoute', text: 'La météo est un peu grise en ce moment, et ça compte. Tu n\u2019es pas seul\u00b7e — parler à quelqu\u2019un peut faire du bien, vraiment.' }
          : { mood: 'acceptation', text: 'Un moral fatigué en ce moment, tel quel, sans rien à corriger dans l\u2019immédiat. Parler à quelqu\u2019un peut faire du bien, vraiment.' };
        low.support = true;
        return low;
      }
    }
  ];
  var BILANS_EN = [
    {
      id: 'craving', name: 'Craving, mapped out', desc: 'Intensity, frequency, resistance',
      color: '#C7765C', mood: 'ecoute',
      intro: 'Craving — that urge that shows up unannounced and takes over everything. Let\u2019s map it out together — three questions. A familiar enemy is always a little less scary.',
      fact: 'Craving isn\u2019t a lack of willpower: it\u2019s a brain circuit revving up. Naming it is already taking back a bit of control.',
      questions: [
        { q: 'This week, how intense was the urge, on average?', opts: ['Almost absent', 'Fairly light', 'Definitely there', 'Pretty strong', 'Maximum setting'], scores: [1, 2, 3, 4, 5],
          reacts: ['Ok, noted. A fairly quiet week on that front.', 'Ok, noted. Noticeable, without being overwhelming.', 'Ok, noted. Present, quietly.', 'Ok, noted. That must have taken up a fair bit of space.', 'Ok, noted. An intense week, clearly.'] },
        { q: 'How often did it come back this week?', opts: ['Rare', 'A few times', 'Every day', 'Several times a day', 'Almost non-stop'], scores: [1, 2, 3, 4, 5],
          reacts: ['I see. Not much to deal with, then.', 'I see. Now and then, no more.', 'I see. A daily appointment, then.', 'I see. It kept coming back through the day.', 'I see. Almost constant — that weighs on you, understandably.'] },
        { q: 'Did you manage to let urges pass without giving in?', opts: ['Always', 'Often', 'Half the time', 'Rarely', 'Never'], scores: [5, 4, 3, 2, 1],
          reacts: ['Solid control, the whole way through.', 'Held up pretty well, overall.', 'One in two — already something.', 'Tough one this time, and it\u2019s ok to say so.', 'None this week — just remember you\u2019re still here talking about it.'] }
      ],
      interp: function (s) { return s <= 5 ? { label: 'Stable week', color: '#69889A' } : s <= 9 ? { label: 'Turbulent week', color: '#b05800' } : { label: 'Heavy week', color: '#C7765C' }; },
      outro: function (it, s) {
        if (s <= 5) return { mood: 'encouragement', text: 'A fairly stable week. You\u2019re holding your course — that\u2019s solid work, not luck.' };
        if (s <= 9) return { mood: 'bienveillance', text: 'A heavy week. Nothing unusual: waves rise, then fall again. An "anti-craving" exercise might help you ride it out.' };
        return { mood: 'bienveillance', text: 'A heavy week, and that\u2019s okay. Waves always come back down eventually. A "surfing the urge" exercise can accompany you, whenever you\u2019re ready.' };
      }
    },
    {
      id: 'audit', name: 'AUDIT-C · the alcohol thermometer', desc: 'The WHO\u2019s reference questionnaire',
      color: '#69889A', mood: 'curiosite',
      intro: 'AUDIT-C is the short questionnaire the WHO handed to healthcare workers worldwide. Three questions, not one more. No trap, no lecture — just a thermometer to see where you stand.',
      fact: 'A "standard drink" is about 10g of pure alcohol: a half-pint of beer, a glass of wine, a shot of spirits. Poured at home, they\u2019re often stronger.',
      questions: [
        { q: 'Do you find yourself drinking alcohol often these days?', opts: ['Never', 'Once a month, max', '2 to 4 times a month', '2 to 3 times a week', '4 times a week or more'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok. Not really your thing, then.', 'Ok. Occasional, then.', 'Ok. A few times a month.', 'Ok. A good chunk of the week.', 'Ok. Almost a ritual, then.'] },
        { q: 'On a day you drink, how many drinks do you usually stop at?', opts: ['1 or 2', '3 or 4', '5 or 6', '7 to 9', '10 or more'], scores: [0, 1, 2, 3, 4],
          reacts: ['Got it. Fairly light, overall.', 'Got it. A moderate amount.', 'Got it. Starting to add up.', 'Got it. That\u2019s a real quantity.', 'Got it. A substantial amount, noted.'] },
        { q: 'How often do you have six or more drinks on one occasion?', opts: ['Never', 'Less than monthly', 'Monthly', 'Weekly', 'Almost daily'], scores: [0, 1, 2, 3, 4],
          reacts: ['Never happens \u2014 great.', 'Rarely, then \u2014 noted.', 'Once in a while.', 'A weekly habit, then.', 'Almost daily \u2014 a real marker to keep in mind.'] }
      ],
      interp: function (s) { return s <= 2 ? { label: 'Nothing to flag', color: '#7A8F72' } : s <= 5 ? { label: 'Worth keeping an eye on', color: '#b05800' } : { label: 'Point of attention', color: '#C7765C' }; },
      outro: function (it, s) {
        if (s <= 2) return { mood: 'encouragement', text: 'Low-risk zone. Nothing to flag on the thermometer — you\u2019ve got this.' };
        if (s <= 5) return { mood: 'reflexion', text: 'Moderate zone. No alarm, just a marker: worth keeping an eye on it, at your own pace.' };
        return { mood: 'bienveillance', text: 'Just a marker that deserves your attention, at your own pace. If you ever want to talk about it, caring people are there — reaching out is a strength.' };
      }
    },
    {
      id: 'wellbeing', name: 'WHO-5 · your mood forecast', desc: 'Five questions, validated by the WHO',
      color: '#8E7CB8', mood: 'serenite',
      intro: 'Five questions designed by the WHO to take the forecast of your mood. Like a check-up, but for the head. Answer by feel, over the last two weeks — there\u2019s no right answer.',
      fact: 'The WHO-5 measures well-being, not "performance". A low score doesn\u2019t define you: it\u2019s a snapshot of this moment, and a snapshot can always be retaken.',
      questions: [
        { q: 'In good spirits most of the time?', opts: ['Not really, no', 'A bit', 'It\u2019s okay, average', 'Fairly yes', 'Clearly yes'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, thanks for the honesty.', 'A bit, that\u2019s already something.', 'A decent average.', 'A pretty good sign.', 'Great energy, that comes through.'] },
        { q: 'Calm and relaxed lately?', opts: ['Not really', 'A bit', 'Depends on the day', 'Fairly often', 'Zen most of the time'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noted.', 'A bit of calm, good.', 'It varies, as often.', 'A nice sense of calm.', 'A good balance, that.'] },
        { q: 'Full of energy, drive?', opts: ['Running on empty', 'A bit of juice', 'Decent', 'In good shape', 'Overflowing'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, running on empty happens.', 'A bit of juice, that\u2019s a start.', 'Decent energy.', 'Good, that shows.', 'A great dose of energy.'] },
        { q: 'Waking up feeling fresh and rested?', opts: ['Almost never', 'Rarely', 'Every other day', 'Most of the time', 'Consistently'], scores: [0, 1, 2, 3, 4],
          reacts: ['Sleep that doesn\u2019t recharge enough weighs on you.', 'Rarely restful, noted.', 'Every other day, not bad.', 'Good sleep, most of the time.', 'Sleep that\u2019s really doing its job.'] },
        { q: 'Your days filled with things that interest you?', opts: ['Not really', 'A bit', 'A few things', 'Fairly, yes', 'Almost every day'], scores: [0, 1, 2, 3, 4],
          reacts: ['Ok, noted.', 'A bit, that counts.', 'A few good moments.', 'Fairly full days.', 'Days that make you look forward, every day.'] }
      ],
      interp: function (s) { return s <= 8 ? { label: 'Tired mood', color: '#C7765C' } : s <= 14 ? { label: 'Mixed mood', color: '#b05800' } : { label: 'Great mood', color: '#7A8F72' }; },
      outro: function (it, s) {
        if (s >= 15) return { mood: 'celebration', text: 'Great inner weather right now. Savour it — and note what does you good, it\u2019s worth cultivating.' };
        if (s >= 9) return { mood: 'bienveillance', text: 'Mixed weather. Nothing alarming, but take care of yourself: a bit of breathing, sleep, things that light you up.' };
        var low = Math.random() < 0.5
          ? { mood: 'ecoute', text: 'The weather\u2019s a bit grey right now, and that counts. You\u2019re not alone \u2014 talking to someone can really help.' }
          : { mood: 'acceptation', text: 'A tired mood right now, as it is, nothing to fix immediately. Talking to someone can really help.' };
        low.support = true;
        return low;
      }
    }
  ];
  function BILANS() { return lang() === 'en' ? BILANS_EN : BILANS_FR; }

  function byId(id) { var bl = BILANS(); for (var i = 0; i < bl.length; i++) if (bl[i].id === id) return bl[i]; return null; }

  /* Pioche UNE anecdote fraîche dans MDAnecdotes (52 entrées) — aléatoire à chaque appel,
     donc à chaque passage dans un bilan. Anti-répétition immédiate via sessionStorage
     (jamais deux fois la même anecdote lors de deux bilans consécutifs dans la même session). */
  function pickAnecdote() {
    var region = null;
    try { region = window.MDCore && MDCore.regionCode ? MDCore.regionCode() : null; } catch (e) {}
    // ~20 % de chances de proposer une anecdote de jonction entre deux régions (si possible),
    // pour inviter à découvrir qu'un thème proche existe ailleurs — jamais systématique.
    if (region && window.pickBridgeAnecdote && Math.random() < 0.2) {
      try {
        var bridge = window.pickBridgeAnecdote(region);
        if (bridge) return bridge;
      } catch (e) {}
    }
    var pool = (window.getAnecdotePool ? window.getAnecdotePool(region) : window.MDAnecdotes) || [];
    if (!pool.length) return null;
    // Moteur partagé : mémoire persistante (pas juste sessionStorage) sur les ~60 dernières
    // anecdotes vues, au lieu de n'exclure que la toute dernière. Repli sur l'ancienne logique
    // si le moteur n'est pas chargé sur cette page, pour ne jamais casser le bilan.
    if (window.MDMascotteMemoire) {
      try {
        var chosen = window.MDMascotteMemoire.pick('anecdotes', pool);
        if (chosen) return chosen;
      } catch (e) {}
    }
    var lastT = null;
    try { lastT = sessionStorage.getItem('mdBilanLastAnecdote'); } catch (e) {}
    var candidates = lastT ? pool.filter(function (a) { return a.t !== lastT; }) : pool;
    if (!candidates.length) candidates = pool;
    var a = candidates[Math.floor(Math.random() * candidates.length)];
    try { sessionStorage.setItem('mdBilanLastAnecdote', a.t); } catch (e) {}
    return a;
  }

  /* — LA GRANDE DISCUSSION —
     Une seule conversation qui mélange les 3 questionnaires (envie/alcool/moral) avec
     des anecdotes science & pop culture et des questions d'ambiance. Seules les étapes
     `ask` (rattachées à un bilan) sont scorées ; le reste « noie le poisson ».
     Types d'étape :
       {say, mood, fact?}                 -> le héros raconte (bouton Continuer)
       {ask:'craving'|'audit'|'wellbeing', qi} -> question scorée du bilan
       {vibe, mood, opts:[], reacts:[]}   -> question d'ambiance non scorée (réaction du héros)
       {result:true}                       -> synthèse + enregistrement */
  var VIBE_POOL_FR = [
    { vibe: 'Coupure : team lève-tôt ou couche-tard ?', mood: 'serenite', opts: ['Lève-tôt', 'Couche-tard', 'Ça dépend des jours'], reacts: ['Le monde t\u2019appartient au petit matin.', 'La nuit, c\u2019est ton terrain de jeu.', 'Flexible, j\u2019aime bien.'] },
    { vibe: 'Pour décompresser, tu es plutôt\u2026', mood: 'respiration', opts: ['Bouger', 'Cocooner', 'Voir du monde'], reacts: ['Le corps qui bouge, la tête qui se vide.', 'Le cocon, valeur sûre.', 'Les autres, ça recharge.'] },
    { vibe: 'Un truc qui te fait du bien en ce moment ?', mood: 'gratitude', opts: ['La musique', 'La nature', 'Les gens', 'Le calme'], reacts: ['La bande-son de tes journées.', 'Le vert, ça répare.', 'Le lien, ça tient chaud.', 'Le silence, ce luxe.'] },
    { vibe: 'Plutôt sucré ou salé, dans la vraie vie ?', mood: 'curiosite', opts: ['Sucré', 'Salé', 'Les deux, sans hésiter'], reacts: ['Un\u00b7e vrai\u00b7e romantique.', 'Simple et efficace.', 'Pourquoi choisir ?'] },
    { vibe: 'Ta saison préférée ?', mood: 'serenite', opts: ['Été', 'Hiver', 'Entre les deux'], reacts: ['Chaleur et lumière, toujours.', 'Le cocon et le calme.', 'Les transitions ont leur charme.'] },
    { vibe: 'Un film ou une série que tu reverrais en boucle ?', mood: 'curiosite', opts: ['Oui, toujours le même', 'Non, jamais deux fois', 'Ça dépend de l\u2019humeur'], reacts: ['Il y a un charme au connu.', 'Toujours du neuf, ça se comprend.', 'Le feeling du moment, logique.'] },
    { vibe: 'Plutôt silence ou musique de fond, pour te concentrer ?', mood: 'respiration', opts: ['Silence total', 'Musique de fond', 'Bruit ambiant, genre café'], reacts: ['Le calme, condition non négociable.', 'Un fond sonore, ça porte.', 'L\u2019agitation légère, étrangement efficace.'] },
    { vibe: 'Ce qui te fait le plus rire, en ce moment ?', mood: 'gratitude', opts: ['Les gens autour de moi', 'Des vidéos bêtes', 'L\u2019humour noir', 'Pas grand-chose, en ce moment'], reacts: ['Les proches, le meilleur remède.', 'Un peu de légèreté, ça fait du bien.', 'Rire du pire, une vraie soupape.', 'Ça arrive, et c\u2019est ok de le dire.'] },
    { vibe: 'Café ou thé pour démarrer la journée ?', mood: 'curiosite', opts: ['Café', 'Thé', 'Ni l\u2019un ni l\u2019autre'], reacts: ['Le rituel qui lance la machine.', 'Douceur et patience, dès le matin.', 'Un\u00b7e affranchi\u00b7e des habitudes.'] },
    { vibe: 'Plutôt mer ou montagne, si tu devais choisir ?', mood: 'serenite', opts: ['La mer', 'La montagne', 'Aucune des deux, en vrai'], reacts: ['L\u2019horizon qui ouvre la tête.', 'Le sommet, pour la perspective.', 'Chacun son terrain.'] },
    { vibe: 'Tu es plutôt du genre à tout planifier, ou à improviser ?', mood: 'reflexion', opts: ['Tout est prévu à l\u2019avance', 'Je vois sur le moment', 'Un mélange des deux'], reacts: ['Le contrôle, ça rassure.', 'Le lâcher-prise a du bon.', 'Le juste équilibre, pas facile à tenir.'] },
    { vibe: 'Une odeur qui te ramène direct à un souvenir ?', mood: 'gratitude', opts: ['Oui, tout de suite', 'Plutôt un son ou une musique', 'Plutôt une image'], reacts: ['L\u2019odorat, le sens le plus direct à la mémoire.', 'Le son, une machine à remonter le temps.', 'Une image qui reste gravée, ça arrive.'] },
    { vibe: 'Ton animal de compagnie idéal, même en rêve ?', mood: 'curiosite', opts: ['Un chien', 'Un chat', 'Quelque chose de plus original', 'Aucun, très bien comme ça'], reacts: ['La loyauté inconditionnelle.', 'L\u2019indépendance qui respecte la tienne.', 'Toujours des goûts qui sortent du lot.', 'Pas besoin de tout le monde pour se sentir bien.'] },
    { vibe: 'Une compétence que t\u2019aimerais avoir, sans effort ?', mood: 'motivation', opts: ['Parler une langue de plus', 'Jouer d\u2019un instrument', 'Un talent artistique', 'Rester calme en toute situation'], reacts: ['Le monde s\u2019ouvre avec les mots.', 'La musique, un langage à part.', 'Créer quelque chose de ses mains, précieux.', 'Ça, ça vaudrait de l\u2019or au quotidien.'] },
    { vibe: 'Plutôt lève-rideau ou dernière minute, pour préparer les choses ?', mood: 'reflexion', opts: ['J\u2019anticipe large', 'Je m\u2019y mets au dernier moment', 'Ça dépend vraiment du sujet'], reacts: ['L\u2019avance, ça évite bien des soucis.', 'La pression, un vrai moteur pour certains.', 'Le discernement au cas par cas, sous-estimé.'] }
  ];
  var VIBE_POOL_EN = [
    { vibe: 'Downtime: early bird or night owl?', mood: 'serenite', opts: ['Early bird', 'Night owl', 'Depends on the day'], reacts: ['The world belongs to you at dawn.', 'The night is your playground.', 'Flexible, I like it.'] },
    { vibe: 'To unwind, you\u2019re more of a\u2026', mood: 'respiration', opts: ['Move about', 'Cocoon at home', 'See people'], reacts: ['Body moving, mind clearing.', 'The cocoon, a safe bet.', 'Others, that recharges you.'] },
    { vibe: 'Something that\u2019s doing you good right now?', mood: 'gratitude', opts: ['Music', 'Nature', 'People', 'Quiet'], reacts: ['The soundtrack of your days.', 'Green, it repairs.', 'Connection keeps you warm.', 'Silence, that luxury.'] },
    { vibe: 'Sweet or savoury, in real life?', mood: 'curiosite', opts: ['Sweet', 'Savoury', 'Both, no question'], reacts: ['A true romantic.', 'Simple and efficient.', 'Why choose?'] },
    { vibe: 'Your favourite season?', mood: 'serenite', opts: ['Summer', 'Winter', 'Somewhere in between'], reacts: ['Warmth and light, always.', 'The cocoon and the calm.', 'Transitions have their charm.'] },
    { vibe: 'A film or show you\u2019d rewatch on loop?', mood: 'curiosite', opts: ['Yes, always the same one', 'No, never twice', 'Depends on the mood'], reacts: ['There\u2019s a charm to the familiar.', 'Always something new, makes sense.', 'Following the mood of the moment, logical.'] },
    { vibe: 'Silence or background music, to focus?', mood: 'respiration', opts: ['Total silence', 'Background music', 'Ambient noise, café-style'], reacts: ['Calm, a non-negotiable condition.', 'A sound bed, it carries you.', 'Light bustle, oddly effective.'] },
    { vibe: 'What makes you laugh the most, right now?', mood: 'gratitude', opts: ['People around me', 'Silly videos', 'Dark humour', 'Not much, right now'], reacts: ['Loved ones, the best remedy.', 'A bit of lightness does good.', 'Laughing at the worst, a real release valve.', 'That happens, and it\u2019s ok to say so.'] },
    { vibe: 'Coffee or tea to start the day?', mood: 'curiosite', opts: ['Coffee', 'Tea', 'Neither'], reacts: ['The ritual that starts the engine.', 'Softness and patience, from the morning.', 'Free from the usual habits.'] },
    { vibe: 'Sea or mountains, if you had to choose?', mood: 'serenite', opts: ['The sea', 'The mountains', 'Neither, honestly'], reacts: ['The horizon that opens the mind.', 'The summit, for the perspective.', 'To each their own ground.'] },
    { vibe: 'Are you more the type to plan everything, or improvise?', mood: 'reflexion', opts: ['Everything\u2019s planned ahead', 'I figure it out on the spot', 'A mix of both'], reacts: ['Control, that\u2019s reassuring.', 'Letting go has its merits.', 'The right balance, not easy to hold.'] },
    { vibe: 'A smell that takes you straight to a memory?', mood: 'gratitude', opts: ['Yes, instantly', 'More a sound or a song', 'More an image'], reacts: ['Smell, the most direct sense to memory.', 'Sound, a time machine.', 'An image that stays etched, that happens.'] },
    { vibe: 'Your ideal pet, even just in a dream?', mood: 'curiosite', opts: ['A dog', 'A cat', 'Something more original', 'None, perfectly happy as is'], reacts: ['Unconditional loyalty.', 'Independence that respects yours.', 'Always tastes that stand out.', 'No need for everyone to feel good.'] },
    { vibe: 'A skill you\u2019d love to have, effortlessly?', mood: 'motivation', opts: ['Speak another language', 'Play an instrument', 'An artistic talent', 'Stay calm in any situation'], reacts: ['The world opens up with words.', 'Music, a language of its own.', 'Creating something with your hands, precious.', 'That would be worth gold day to day.'] },
    { vibe: 'Early planner or last minute, to get things ready?', mood: 'reflexion', opts: ['I plan well ahead', 'I get to it at the last moment', 'Really depends on the topic'], reacts: ['Being ahead avoids a lot of trouble.', 'Pressure, a real driver for some.', 'Case-by-case judgment, underrated.'] }
  ];
  function VIBE_POOL() { return lang() === 'en' ? VIBE_POOL_EN : VIBE_POOL_FR; }
  function pickVibes(n) {
    var pool = VIBE_POOL().slice();
    for (var s = pool.length - 1; s > 0; s--) { var j = Math.floor(Math.random() * (s + 1)); var tmp = pool[s]; pool[s] = pool[j]; pool[j] = tmp; }
    return pool.slice(0, n);
  }

  var SEQ_FR = [
    { say: 'On va papoter deux minutes. Pas un interrogatoire — une discussion. Je glisse quelques questions utiles au milieu, et des trucs rigolos. Ça reste entre nous, sur ton téléphone.', mood: 'curiosite' },
    { ask: 'craving', qi: 0 },
    { ask: 'craving', qi: 1 },
    { say: 'Petite parenthèse : la bière et le cannabis sont cousins botaniques. Le houblon et le chanvre font partie de la même famille, les Cannabaceae. La nature a de l\u2019humour.', mood: 'explication' },
    { ask: 'craving', qi: 2 },
    { vibeSlot: 0 },
    { ask: 'audit', qi: 0 },
    { say: 'Info discrète mais utile : qu\u2019on parle de bière, de vin ou de spiritueux, la molécule qui agit est toujours la même — l\u2019éthanol. Un « verre standard », c\u2019est ~10 g d\u2019alcool pur.', mood: 'explication' },
    { ask: 'audit', qi: 1 },
    { ask: 'audit', qi: 2 },
    { vibeSlot: 1 },
    { say: 'Le 19 avril 1943, un chimiste suisse, Albert Hofmann, teste sur lui une molécule qu\u2019il vient de créer — le LSD — puis rentre chez lui à vélo. Depuis, les curieux appellent ça le « Bicycle Day ». L\u2019histoire des sciences est pleine de virages.', mood: 'reflexion' },
    { ask: 'wellbeing', qi: 0 },
    { ask: 'wellbeing', qi: 1 },
    { say: 'Anecdote pop : à sa création en 1886, le Coca-Cola contenait vraiment un extrait de feuille de coca. La cocaïne en a été retirée au tout début du XXe siècle. Le nom, lui, est resté.', mood: 'curiosite' },
    { ask: 'wellbeing', qi: 2 },
    { vibeSlot: 2 },
    { ask: 'wellbeing', qi: 3 },
    { ask: 'wellbeing', qi: 4 },
    { say: 'Tu savais que le fameux « high » du coureur ne vient pas que des endorphines ? Ton corps fabrique aussi ses propres endocannabinoïdes. Une petite pharmacie interne, gratuite et légale.', mood: 'motivation' },
    { result: true }
  ];
  var SEQ_EN = [
    { say: 'Let\u2019s chat for a couple of minutes. Not an interrogation — a conversation. I\u2019ll slip in a few useful questions along the way, and some fun stuff. It stays between us, on your phone.', mood: 'curiosite' },
    { ask: 'craving', qi: 0 },
    { ask: 'craving', qi: 1 },
    { say: 'Quick aside: beer and cannabis are botanical cousins. Hops and hemp belong to the same family, the Cannabaceae. Nature has a sense of humour.', mood: 'explication' },
    { ask: 'craving', qi: 2 },
    { vibeSlot: 0 },
    { ask: 'audit', qi: 0 },
    { say: 'Quiet but useful fact: whether it\u2019s beer, wine, or spirits, the molecule doing the work is always the same — ethanol. A "standard drink" is about 10g of pure alcohol.', mood: 'explication' },
    { ask: 'audit', qi: 1 },
    { ask: 'audit', qi: 2 },
    { vibeSlot: 1 },
    { say: 'On April 19, 1943, a Swiss chemist named Albert Hofmann tested a molecule he\u2019d just created — LSD — on himself, then cycled home. Since then, the curious have called it "Bicycle Day." The history of science is full of twists.', mood: 'reflexion' },
    { ask: 'wellbeing', qi: 0 },
    { ask: 'wellbeing', qi: 1 },
    { say: 'Pop fact: when Coca-Cola was created in 1886, it really did contain coca leaf extract. Cocaine was removed from it in the very early 1900s. The name, though, stayed.', mood: 'curiosite' },
    { ask: 'wellbeing', qi: 2 },
    { vibeSlot: 2 },
    { ask: 'wellbeing', qi: 3 },
    { ask: 'wellbeing', qi: 4 },
    { say: 'Did you know the famous runner\u2019s "high" doesn\u2019t come only from endorphins? Your body also makes its own endocannabinoids. A small internal pharmacy, free and legal.', mood: 'motivation' },
    { result: true }
  ];
  function SEQ() { return lang() === 'en' ? SEQ_EN : SEQ_FR; }

  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mbh-ov{z-index:var(--z-modal-3,4200);align-items:center;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.5);font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mbh-card{position:relative;z-index:var(--z-base,1);border-radius:20px;' +
      'max-width:420px;width:100%;padding:24px 22px 20px;box-shadow:0 20px 55px rgba(31,43,37,.28);max-height:92vh;overflow:auto}' +
      '.mbh-prog{display:flex;gap:5px;margin-bottom:14px}' +
      '.mbh-dot{flex:1;height:5px;border-radius:3px;background:var(--line,#E2DCD0)}' +
      '.mbh-dot.on{background:var(--mc,#7A8F72)}' +
      '.mbh-hero{display:flex;align-items:flex-start;gap:11px;margin-bottom:14px}' +
      '.mbh-qav{display:flex;justify-content:center;margin-bottom:8px}' +
      '.mbh-qav .mdc-ava{opacity:.92}' +
      '.mbh-hero .mdc-ava{margin:0}' +
      '.mbh-bub{flex:1;min-width:0;background:var(--mc50,#EEF1E9);border-radius:14px 14px 14px 4px;padding:11px 13px}' +
      '.mbh-bub p{margin:0;font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-sm,14.5px);line-height:var(--lh-normal,1.45)}' +
      '.mbh-fact{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-xs,12.5px);line-height:var(--lh-normal,1.5);' +
      'color:var(--ink-2,#58635E);background:var(--bg-2,#FBF8F1);border-left:3px solid var(--mc,#7A8F72);' +
      'border-radius:8px;padding:8px 11px;margin:0 0 14px}' +
      '.mbh-fact b{color:var(--mc,#33463E)}' +
      '.mbh-q{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-lead,18px);line-height:var(--lh-tight,1.3);margin:0 0 12px}' +
      '.mbh-opt{display:block;width:100%;text-align:left;border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);' +
      'color:var(--ink,#1F2B25);border-radius:12px;padding:12px 14px;margin-bottom:8px;font-size:var(--fs-sm,14.5px);cursor:pointer;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);-webkit-tap-highlight-color:transparent}' +
      '.mbh-opt:hover{border-color:var(--mc,#7A8F72);background:var(--surface,#fff)}' +
      '.mbh-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);' +
      'font-size:var(--fs-ui,15px);padding:13px;cursor:pointer;margin-top:4px;font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mbh-2{display:flex;gap:10px;margin-top:10px}' +
      '.mbh-2 .mbh-go{margin-top:0}' +
      '.mbh-skip{display:block;width:100%;text-align:center;background:none;border:none;color:var(--ink-2,#58635E);' +
      'text-decoration:underline;font-size:var(--fs-xs,13px);padding:11px 0 2px;cursor:pointer;font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mbh-res{text-align:center}' +
      '.mbh-res-badge{display:inline-block;font-weight:var(--w-bold,700);font-size:var(--fs-sm,14px);padding:5px 14px;border-radius:999px;' +
      'color:#fff;margin-bottom:8px}' +
      '.mbh-res-score{font-size:var(--fs-xs,13px);color:var(--ink-2,#58635E);margin-bottom:14px}' +
      '.mbh-support{display:block;background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:12px;' +
      'padding:11px 13px;margin:0 0 14px;font-size:var(--fs-xs,13px);line-height:var(--lh-normal,1.5);color:var(--ink,#1F2B25);text-decoration:none}' +
      '.mbh-support b{color:var(--terra,#C7765C)}' +
      '.mbh-syn{display:flex;flex-direction:column;gap:8px;margin:4px 0 14px}' +
      '.mbh-syn-row{display:flex;align-items:center;justify-content:space-between;gap:10px;' +
      'background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:12px;padding:9px 12px}' +
      '.mbh-syn-lbl{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-sm,14px);font-weight:var(--w-bold,700)}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function accentVars(mood, fallbackColor) {
    // s'appuie sur la palette du compagnon si dispo, sinon couleur du bilan
    var c = fallbackColor || '#7A8F72';
    return '--mc:' + c + ';--mc50:color-mix(in srgb,' + c + ' 14%,#fff)';
  }
  function heroBlock(mood, color, html) {
    var av = (window.MDCompagnon) ? window.MDCompagnon.avatarHTML(mood, { size: 'md' }) : '';
    return '<div class="mbh-hero">' + av + '<div class="mbh-bub"><p>' + html + '</p></div></div>';
  }
  /* Petit avatar seul, sans bulle — pour que la mascotte reste visible sur les écrans de
     question eux-mêmes (avant réponse), pas seulement sur les écrans de transition. Mise
     en page unifiée : aucun type d'écran du questionnaire ne doit en être dépourvu. */
  function avatarTag(mood) {
    return (window.MDCompagnon) ? '<div class="mbh-qav">' + window.MDCompagnon.avatarHTML(mood, { size: 'sm' }) + '</div>' : '';
  }

  function overlay() {
    inject();
    var ov = document.createElement('div'); ov.className = 'mbh-ov md-ov';
    var card = document.createElement('div'); card.className = 'mbh-card md-card';
    ov.appendChild(card);
    ov.addEventListener('click', function (e) { if (e.target === ov) closeOv(ov); });
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: ui('faire_le_point') });
    return { ov: ov, card: card };
  }
  function closeOv(ov) { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); }

  /* Préambule : le héros propose de faire le point, sans pression. */
  function openMenu(opts) {
    opts = opts || {};
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars('curiosite', '#7A8F72');
    var listHtml = BILANS().map(function (b) {
      return '<button class="mbh-opt" data-bid="' + b.id + '"><b>' + esc(b.name) + '</b><br>' +
        '<span style="color:var(--ink-2,#58635E);font-size:var(--fs-xs,12.5px)">' + esc(b.desc) + '</span></button>';
    }).join('');
    card.innerHTML =
      heroBlock('curiosite', '#7A8F72', ui('menu_intro')) +
      '<button class="mbh-opt" data-act="grande" style="border-color:var(--sauge,#7A8F72)"><b>' + esc(ui('full_conv')) + '</b><br>' +
      '<span style="color:var(--ink-2,#58635E);font-size:var(--fs-xs,12.5px)">' + esc(ui('full_conv_desc')) + '</span></button>' +
      '<div style="font-size:var(--fs-caps,11px);color:var(--ink-2,#58635E);text-transform:uppercase;letter-spacing:var(--ls-caps,.08em);margin:12px 2px 8px">' + esc(ui('or_precise')) + '</div>' +
      listHtml +
      '<button class="mbh-skip" data-act="later">' + esc(ui('later')) + '</button>';
    card.querySelector('[data-act="grande"]').addEventListener('click', function () { closeOv(o.ov); openGrande(opts); });
    card.querySelectorAll('[data-bid]').forEach(function (btn) {
      btn.addEventListener('click', function () { closeOv(o.ov); open(btn.getAttribute('data-bid')); });
    });
    var later = card.querySelector('[data-act="later"]');
    if (later) later.addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(); });
  }

  /* Discussion d'un bilan : intro -> questions -> résultat. */
  function open(id, opts) {
    opts = opts || {};
    var b = byId(id); if (!b) return;
    inject();
    var answers = [];
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars(b.mood, b.color);

    function intro() {
      card.innerHTML =
        heroBlock(b.mood, b.color, esc(b.intro)) +
        (b.fact ? '<p class="mbh-fact"><b>' + esc(ui('for_info')) + '</b> ' + esc(b.fact) + '</p>' : '') +
        '<div class="mbh-2"><button class="mbh-go" data-act="go">' + esc(ui('lets_go')) + '</button></div>' +
        '<button class="mbh-skip" data-act="later">' + esc(ui('later')) + '</button>';
      card.querySelector('[data-act="go"]').addEventListener('click', function () { step(0); });
      card.querySelector('[data-act="later"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    var anecdoteAt = Math.floor(b.questions.length / 2); // insérée après la question du milieu
    var anecdoteShown = false;

    function step(i) {
      var qn = b.questions[i];
      var dots = b.questions.map(function (_, k) { return '<div class="mbh-dot' + (k <= i ? ' on' : '') + '"></div>'; }).join('');
      card.innerHTML =
        '<div class="mbh-prog">' + dots + '</div>' + avatarTag(b.mood) +
        '<p class="mbh-q">' + esc(qn.q) + '</p>' +
        qn.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
        '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
      card.querySelectorAll('[data-k]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var k = parseInt(btn.getAttribute('data-k'), 10);
          answers.push(qn.scores[k]);
          var advance = function () {
            if (i + 1 >= b.questions.length) { result(); return; }
            if (i === anecdoteAt - 1 && !anecdoteShown) { anecdoteShown = true; anecdoteBreak(i + 1); }
            else step(i + 1);
          };
          var reactTxt = (qn.reacts && qn.reacts[k]) ? qn.reacts[k] : qn.t;
          if (reactTxt) {
            card.innerHTML = heroBlock(b.mood, b.color, esc(reactTxt)) +
              '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
            card.querySelector('[data-act="next"]').addEventListener('click', advance);
          } else { advance(); }
        });
      });
      card.querySelector('[data-act="quit"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function anecdoteBreak(nextI) {
      var a = pickAnecdote();
      if (!a) { step(nextI); return; }
      card.innerHTML =
        heroBlock(a.mood || b.mood, b.color, esc(a.t)) +
        '<button class="mbh-go" data-act="next">' + esc(ui('continue_btn')) + '</button>' +
        '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
      card.querySelector('[data-act="next"]').addEventListener('click', function () { step(nextI); });
      card.querySelector('[data-act="quit"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function result() {
      var total = answers.reduce(function (a, c) { return a + c; }, 0);
      var it = b.interp(total);
      var out = b.outro ? b.outro(it, total) : { mood: b.mood, text: '' };
      // enregistrement compatible historique (sessions type 'q')
      try {
        var d = read();
        d.sessions = Array.isArray(d.sessions) ? d.sessions : [];
        d.sessions.push({ type: 'q', id: b.id, name: b.name, date: Date.now(), label: it.label, color: it.color, score: total });
        if (d.parcours) d.parcours.dernierJourActif = Date.now();
        save(d);
      } catch (e) { }
      var support = out.support
        ? '<a class="mbh-support" href="rdr.html?tab=centres"><b>' + esc(ui('want_to_talk')) + '</b>' + esc(ui('support_line_centres')) + '</a>'
        : '';
      card.innerHTML =
        heroBlock(out.mood || b.mood, it.color, esc(out.text)) +
        '<div class="mbh-res">' +
        '<span class="mbh-res-badge" style="background:' + it.color + '">' + esc(it.label) + '</span>' +
        '<div class="mbh-res-score">' + ui('score_lbl', total, (b.questions.length * (b.id === 'craving' ? 5 : 4))) + '</div>' +
        support +
        '<button class="mbh-go" data-act="done">' + esc(ui('finish')) + '</button>' +
        '</div>';
      card.querySelector('[data-act="done"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(total); });
    }

    intro();
  }

  /* La grande discussion : déroule SEQ, collecte les réponses scorées par bilan,
     puis calcule/enregistre les 3 scores et fait une synthèse. */
  function openGrande(opts) {
    opts = opts || {};
    inject();
    var answers = { craving: [], audit: [], wellbeing: [] };
    var o = overlay(); var card = o.card;
    card.style.cssText += accentVars('curiosite', '#7A8F72');

    // Construit la séquence du jour : chaque « anecdote » de SEQ est remplacée par une
    // anecdote piochée au hasard dans MDAnecdotes -> renouvellement à chaque passage.
    var __region = null;
    try { __region = window.MDCore && MDCore.regionCode ? MDCore.regionCode() : null; } catch (e) {}
    var pool = (window.getAnecdotePool ? window.getAnecdotePool(__region) : (window.MDAnecdotes || [])).slice();
    if (__region && window.pickBridgeAnecdote && Math.random() < 0.3) {
      try {
        var __bridge = window.pickBridgeAnecdote(__region);
        if (__bridge) pool.push(__bridge);
      } catch (e) {}
    }
    for (var s1 = pool.length - 1; s1 > 0; s1--) { var j = Math.floor(Math.random() * (s1 + 1)); var tmp = pool[s1]; pool[s1] = pool[j]; pool[j] = tmp; }
    var pi = 0;
    var chosenVibes = pickVibes(3);
    var seq = SEQ().map(function (st, idx) {
      if (st.say && idx > 0 && pool.length) { var a = pool[pi % pool.length]; pi++; return { say: a.t, mood: a.mood }; }
      if (st.vibeSlot != null) { return chosenVibes[st.vibeSlot] || chosenVibes[0]; }
      return st;
    });
    var nAsk = seq.filter(function (s) { return s.ask; }).length, askDone = 0;

    function progress() {
      var pct = Math.round((askDone / nAsk) * 100);
      return '<div class="mbh-prog"><div class="mbh-dot on" style="flex:' + pct + '"></div><div class="mbh-dot" style="flex:' + (100 - pct) + '"></div></div>';
    }

    function render(i) {
      if (i >= seq.length) return;
      var stp = seq[i];

      if (stp.result) { result(); return; }

      if (stp.say) {
        card.style.cssText += accentVars(stp.mood || 'curiosite', '#7A8F72');
        card.innerHTML = progress() +
          heroBlock(stp.mood || 'curiosite', '#7A8F72', esc(stp.say)) +
          (stp.fact ? '<p class="mbh-fact">' + esc(stp.fact) + '</p>' : '') +
          '<button class="mbh-go" data-act="next">' + esc(ui('continue_btn')) + '</button>' +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
        bindQuit(card);
        return;
      }

      if (stp.vibe) {
        card.style.cssText += accentVars(stp.mood || 'serenite', '#7A8F72');
        card.innerHTML = progress() + avatarTag(stp.mood || 'serenite') +
          '<p class="mbh-q">' + esc(stp.vibe) + '</p>' +
          stp.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelectorAll('[data-k]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var k = parseInt(btn.getAttribute('data-k'), 10);
            var react = (stp.reacts && stp.reacts[k]) ? stp.reacts[k] : ui('noted');
            card.innerHTML = heroBlock(stp.mood || 'serenite', '#7A8F72', esc(react)) +
              '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
            card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
          });
        });
        bindQuit(card);
        return;
      }

      if (stp.ask) {
        var b = byId(stp.ask); var qn = b.questions[stp.qi];
        card.style.cssText += accentVars(b.mood, b.color);
        card.innerHTML = progress() + avatarTag(b.mood) +
          '<p class="mbh-q">' + esc(qn.q) + '</p>' +
          qn.opts.map(function (opt, k) { return '<button class="mbh-opt" data-k="' + k + '">' + esc(opt) + '</button>'; }).join('') +
          '<button class="mbh-skip" data-act="quit">' + esc(ui('stop_here')) + '</button>';
        card.querySelectorAll('[data-k]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var k = parseInt(btn.getAttribute('data-k'), 10);
            answers[stp.ask].push(qn.scores[k]);
            askDone++;
            var reactTxt = (qn.reacts && qn.reacts[k]) ? qn.reacts[k] : qn.t;
            if (reactTxt) {
              card.innerHTML = heroBlock(b.mood, b.color, esc(reactTxt)) +
                '<button class="mbh-go" data-act="next">' + esc(ui('go_on')) + '</button>';
              card.querySelector('[data-act="next"]').addEventListener('click', function () { render(i + 1); });
            } else {
              render(i + 1);
            }
          });
        });
        bindQuit(card);
        return;
      }
    }

    function bindQuit(c) {
      var q = c.querySelector('[data-act="quit"]');
      if (q) q.addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(null); });
    }

    function result() {
      var saved = [], sensible = false;
      try {
        var d = read(); d.sessions = Array.isArray(d.sessions) ? d.sessions : [];
        BILANS().forEach(function (b) {
          var a = answers[b.id];
          if (a.length === b.questions.length) { // bilan complété
            var total = a.reduce(function (x, y) { return x + y; }, 0);
            var it = b.interp(total);
            d.sessions.push({ type: 'q', id: b.id, name: b.name, date: Date.now(), label: it.label, color: it.color, score: total });
            var out = b.outro ? b.outro(it, total) : null;
            if (out && out.support) sensible = true;
            saved.push({ b: b, it: it, out: out });
          }
        });
        if (d.parcours) d.parcours.dernierJourActif = Date.now();
        save(d);
      } catch (e) { }

      var rows = saved.map(function (r) {
        return '<div class="mbh-syn-row"><span class="mbh-syn-lbl">' + esc(shortAxis(r.b.id)) + '</span>' +
          '<span class="mbh-res-badge" style="background:' + r.it.color + '">' + esc(r.it.label) + '</span></div>';
      }).join('');
      var support = sensible
        ? '<a class="mbh-support" href="rdr.html?tab=centres"><b>' + esc(ui('want_to_talk')) + '</b>' + esc(ui('support_line_reflexes')) + '</a>'
        : '';
      var headMood = sensible ? 'ecoute' : 'celebration';
      var headText = saved.length
        ? ui('thanks_moment')
        : ui('no_worries_stop');
      card.style.cssText += accentVars(headMood, '#7A8F72');
      card.innerHTML =
        heroBlock(headMood, '#7A8F72', esc(headText)) +
        (rows ? '<div class="mbh-syn">' + rows + '</div>' : '') +
        support +
        '<button class="mbh-go" data-act="done">' + esc(ui('finish')) + '</button>';
      card.querySelector('[data-act="done"]').addEventListener('click', function () { closeOv(o.ov); if (typeof opts.onClose === 'function') opts.onClose(saved.length); });
    }

    function shortAxis(id) { return id === 'craving' ? ui('axis_craving') : id === 'audit' ? ui('axis_audit') : ui('axis_wellbeing'); }

    render(0);
  }

  return { data: BILANS(), list: function () { return BILANS(); }, open: open, openMenu: openMenu, openGrande: openGrande };
})();
