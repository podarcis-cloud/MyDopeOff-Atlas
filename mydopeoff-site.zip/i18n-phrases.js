/* MyDope Off — i18n-phrases.js : traduction de fond FR<->EN du texte codé en dur.
   window.MD_PHRASES = dictionnaire FR->EN. window.MDTranslateDOM(toEN) applique/restaure. */
window.MD_PHRASES = {
"12 niveaux · détourne l'imagerie mentale de l'envie": "12 levels · redirects the mental imagery of craving",
"3 min · occupe la mémoire visuospatiale (Oxford 2015)": "3 min · occupies visuospatial memory (Oxford 2015)",
"Accélérer": "Speed up",
"Activation du capteur…": "Activating sensor…",
"Alcool, stupéfiants & conduite — MyDope Off": "Alcohol, drugs & driving — MyDope Off",
"Allonger l'expiration renforce l'effet (nerf vague). La fréquence idéale varie d'une personne à l'autre (4,5–7/min) : ajuste si besoin.": "Lengthening the exhale strengthens the effect (vagus nerve). The ideal rate varies from person to person (4.5–7/min): adjust if needed.",
"Après l'alcool, laisse passer le temps d'élimination réel (plusieurs heures) — rien d'autre ne marche.": "After alcohol, let the real elimination time pass (several hours) — nothing else works.",
"Après une drogue, la détection dure plus longtemps que les effets ressentis : positif possible bien après te sentir « clair ».": "After a drug, detection lasts longer than the effects you feel: you can test positive long after feeling “clear”.",
"Après usage, seul le temps protège : ne pas conduire.": "After use, only time protects you: do not drive.",
"Auto-éval conso": "Use self-check",
"Autorise la caméra puis lance la lecture quand tu es prêt·e.": "Allow the camera, then start reading when you're ready.",
"Besoin d'un coup de pouce ? Touche une amorce pour l'insérer :": "Need a nudge? Tap a starter to insert it:",
"Besoin de parler à quelqu'un ?": "Need to talk to someone?",
"Capte le son de ta respiration": "Picks up the sound of your breathing",
"Capteur en cours d'activation…": "Sensor activating…",
"Ce dont je suis fier·e…": "What I'm proud of…",
"Ce qui m'a poussé…": "What pushed me…",
"Ce qui pousse à consommer — pour mieux le voir venir.": "What drives use — so you can see it coming.",
"Ces durées sont des": "These durations are",
"Cher futur moi, Je t'écris parce que…": "Dear future me, I'm writing to you because…",
"Cohérence cardiaque guidée — pose le téléphone sur ton thorax, respire avec l'orbe.": "Guided heart coherence — place the phone on your chest and breathe with the orb.",
"Comment se déroulent les contrôles, ce qu'ils détectent et combien de temps. Le seul moyen fiable de « passer » un contrôle est de ne pas conduire après avoir consommé : aucune astuce ne supprime une substance déjà présente.": "How roadside checks work, what they detect and for how long. The only reliable way to “pass” a check is not to drive after using: no trick removes a substance already present.",
"Continuer le suivi": "Continue tracking",
"Continuer sans capteur": "Continue without sensor",
"Crise / craving immédiat": "Crisis / immediate craving",
"Dans": "In",
"Dans six mois…": "In six months…",
"Des questions simples, des réponses pour toi seul·e.": "Simple questions, answers for you alone.",
"Durée de la séance": "Session length",
"Détection": "Detection",
"Elle est dans ton parcours, sur ce téléphone. Reviens la relire quand l'envie monte.": "It's in your journey, on this phone. Come back and reread it when craving rises.",
"Embout perso, ne partage pas pipe ou joint. Laisse refroidir la vapeur, évite les chasses répétées. Hydrate-toi : la fumée assèche et irrite.": "Your own mouthpiece, don't share a pipe or joint. Let the vapour cool, avoid repeated hits. Stay hydrated: smoke dries out and irritates.",
"En cohérence": "In coherence",
"Espacer pour protéger": "Space it out to protect yourself",
"Exercices anti-craving et auto-évaluations validées, à ton rythme.": "Anti-craving exercises and validated self-checks, at your own pace.",
"Fenêtres salivaires indicatives (usage unique). La détection dure bien plus longtemps dans l'urine et le sang. Voir Suivi → Détection pour le détail.": "Indicative saliva windows (single use). Detection lasts far longer in urine and blood. See Tracking → Detection for the detail.",
"Fiches, mélanges et fenêtres de détection — info claire, sans jugement.": "Fact sheets, mixes and detection windows — clear info, no judgment.",
"Garde TON verre, ne le laisse jamais sans surveillance. Pour le GHB : doser à la pipette/seringue graduée, écart d'au moins 2–3 h, jamais avec de l'alcool — la marge entre effet et coma est minuscule.": "Keep YOUR drink, never leave it unattended. For GHB: measure with a graduated pipette/syringe, at least 2–3 h apart, never with alcohol — the margin between effect and coma is tiny.",
"Garder le texte seul (sans enregistrement)": "Keep the text only (no recording)",
"Guide d'utilisation et lexique": "User guide and glossary",
"Jours de suivi sans interruption": "Days tracked without a break",
"Jours sans une substance": "Days without a substance",
"La": "The",
"La descente / récupération": "The comedown / recovery",
"Le contrôle peut être aléatoire. Il se fait en deux temps : un": "The check can be random. It happens in two stages: a",
"Le pic d'alcoolémie arrive 30 min (à jeun) à 1 h (après repas) après le dernier verre : tu peux être plus alcoolisé en reprenant la route qu'en quittant la table. Le seul calcul fiable, c'est le temps.": "Peak blood alcohol comes 30 min (empty stomach) to 1 h (after a meal) after the last drink: you can be more intoxicated getting back on the road than when you left the table. The only reliable calculation is time.",
"Le texte défile en bas de l'écran pendant que tu parles.": "The text scrolls at the bottom of the screen while you speak.",
"Les sprays « purifiant » ne masquent au mieux le THC salivaire que très brièvement et sans fiabilité ; aucun effet sur l'analyse sanguine. Compter dessus, c'est risquer le délit.": "“Detox” sprays at best mask salivary THC only very briefly and unreliably; no effect on a blood test. Relying on them means risking the offence.",
"Lettre gardée": "Letter saved",
"Lettre à ton futur toi": "Letter to your future self",
"Limiter les usages par semaine": "Limit uses per week",
"MDMA : maximum une fois toutes les 6–8 semaines (neurotoxicité). Kétamine : usage répété = vessie abîmée. Plus tu espaces, plus tu protèges ton cerveau et ton corps.": "MDMA: at most once every 6–8 weeks (neurotoxicity). Ketamine: repeated use = damaged bladder. The more you space it out, the more you protect your brain and body.",
"Matériel & contexte": "Equipment & context",
"Matériel stérile à usage unique (programmes d'échange de seringues gratuits). Jamais de partage de seringue, cuillère, filtre ou eau. Filtre, désinfecte le point d'injection, tourne les sites. Teste toujours une petite dose d'abord.": "Sterile single-use equipment (free needle-exchange programmes). Never share a syringe, spoon, filter or water. Filter, disinfect the injection site, rotate sites. Always test a small dose first.",
"Mes déclencheurs": "My triggers",
"Mouvement du thorax": "Chest movement",
"MyDope Off n'a pas de compte ni de serveur. Tout ce que tu saisis est stocké": "MyDope Off has no account and no server. Everything you enter is stored",
"MyDope Off · Soutenir le projet": "MyDope Off · Support the project",
"MyDope Off — Comprendre les substances": "MyDope Off — Understanding substances",
"MyDope Off — Faire le point": "MyDope Off — Check in",
"MyDope Off — Fenêtres de détection": "MyDope Off — Detection windows",
"MyDope Off — Lettre à ton futur toi": "MyDope Off — Letter to your future self",
"MyDope Off — Ton suivi": "MyDope Off — Your tracking",
"Niveau du jour": "Today's level",
"Noter une journée": "Log a day",
"Objectif personnalisé": "Custom goal",
"Objectif que tu t'es fixé : 14 jours.": "The goal you set yourself: 14 days.",
"Oral / gobelet (GHB, kétamine…)": "Oral / cup (GHB, ketamine…)",
"Outils validés": "Validated tools",
"Ouvrir le dossier ›": "Open the file ›",
"Où j'en suis": "Where I'm at",
"Pas de note, pas de verdict. Tu réponds quand tu veux, tu refais le point quand ça t'aide. Rien ne quitte ton téléphone.": "No grade, no verdict. You answer whenever you want, you check in again when it helps. Nothing leaves your phone.",
"Pendant & après": "During & after",
"Personne ne « doit » consommer. Sous substance, le consentement reste indispensable et révocable. Veille sur les autres : un·e ami·e qui décroche, vomit allongé·e ou devient inconscient·e = urgence.": "No one “has to” use. Under the influence, consent stays essential and can be withdrawn. Look out for others: a friend who fades out, vomits lying down or becomes unconscious = emergency.",
"Plafond de dépense (30 j)": "Spending cap (30 d)",
"Plasticité cérébrale": "Brain plasticity",
"Pose le téléphone à plat sur ta poitrine": "Lay the phone flat on your chest",
"Pose le téléphone à plat sur ton ventre, entre le sternum et le nombril. Respire normalement : la forme suit ton souffle.": "Lay the phone flat on your belly, between the sternum and the navel. Breathe normally: the shape follows your breath.",
"Pourquoi tu fais ce point — à relire les jours moins faciles.": "Why you're checking in — to reread on the harder days.",
"Projection sur 12 mois": "12-month projection",
"Préviens une personne de confiance. En cas de malaise, il faut quelqu'un sur place.": "Tell someone you trust. If something goes wrong, you need someone on the spot.",
"Prévois le retour avant de consommer : conducteur sobre désigné, VTC, transports, ou dormir sur place.": "Plan your way home before using: a designated sober driver, a ride-hail, public transport, or sleeping over.",
"Prêt": "Ready",
"Quantité": "Quantity",
"Rechercher une substance (alias acceptés : coke, weed, keta…)": "Search for a substance (aliases accepted: coke, weed, keta…)",
"Refuser le dépistage est sanctionné aussi lourdement qu'un résultat positif. Demander la confirmation est un droit.": "Refusing the test is punished as harshly as a positive result. Asking for a confirmation is your right.",
"Repérer les habitudes qui s'installent.": "Spot the habits that are settling in.",
"Respiration guidée 6/min · gyroscope & micro · anti-stress": "Guided breathing 6/min · gyroscope & mic · anti-stress",
"Respirer à environ": "Breathe at about",
"Rien pour l'instant. Touche un jour du calendrier ou « Ajouter une entrée » — ça reste entre toi et ton téléphone.": "Nothing yet. Tap a day on the calendar or “Add an entry” — it stays between you and your phone.",
"Rythme guidé": "Guided pace",
"Réduire les risques › Centres": "Reduce risks › Centres",
"Safer use — selon la voie": "Safer use — by route",
"Salive, urine et sang — selon un usage unique ou régulier. Estimations, jamais une garantie.": "Saliva, urine and blood — for single or regular use. Estimates, never a guarantee.",
"Sans capteur, l'orbe te guide quand même. Rien n'est enregistré ni envoyé : tout reste sur ton téléphone, en direct.": "Without a sensor, the orb still guides you. Nothing is recorded or sent: everything stays on your phone, live.",
"Se projeter et s'adresser à son": "Projecting yourself and speaking to your",
"Sommeil, repas riches, magnésium et vitamine C peuvent aider après une session. Prévois un jour sans obligations. La déprime du lendemain est chimique et passagère — ne prends pas de décisions lourdes à ce moment-là.": "Sleep, hearty meals, magnesium and vitamin C can help after a session. Plan a day with no obligations. The next-day low is chemical and temporary — don't make big decisions then.",
"Souffle — cohérence cardiaque": "Breath — heart coherence",
"Stimulants/MDMA en milieu festif : ~250–500 ml d'eau par heure si tu danses, pas plus (risque d'hyponatrémie). Fais des pauses au frais. Repère les signes de surchauffe : confusion, crampes, peau brûlante.": "Stimulants/MDMA in party settings: ~250–500 ml of water per hour if you're dancing, no more (risk of hyponatremia). Take breaks in a cool spot. Watch for overheating signs: confusion, cramps, burning skin.",
"Suis l'orbe : inspire quand il grandit, expire quand il rétrécit.": "Follow the orb: breathe in as it grows, breathe out as it shrinks.",
"Supprimer cette entrée": "Delete this entry",
"Séance terminée": "Session complete",
"Ta cagnotte potentielle — pas pour culpabiliser, juste pour voir ce que tu pourrais récupérer autrement. Seules les entrées avec un coût renseigné sont comptées.": "Your potential savings — not to guilt-trip you, just to show what you could get back instead. Only entries with a recorded cost are counted.",
"Ta lettre est prête": "Your letter is ready",
"Ta respiration": "Your breathing",
"Température & hydratation": "Temperature & hydration",
"Tes points de repère": "Your landmarks",
"Ton journal, ton rythme — rien ne sort de ton téléphone.": "Your journal, your pace — nothing leaves your phone.",
"Ton propre matériel, jamais partagé (hépatite C / VIH se transmettent par le sang sur les pailles). Écrase finement, alterne les narines, rince au sérum physiologique après. Évite les billets.": "Your own gear, never shared (hepatitis C / HIV spread through blood on straws). Crush finely, switch nostrils, rinse with saline afterwards. Avoid banknotes.",
"Ton rythme": "Your pace",
"Ton suivi": "Your tracking",
"Touche un jour pour noter": "Tap a day to log",
"Toutes les substances": "All substances",
"Tu as pris un moment pour toi.": "You took a moment for yourself.",
"Tu écriras quelques lignes, puis tu pourras les lire à voix haute (vidéo ou audio) en mode téléprompteur. Tout est enregistré localement, rien n'est envoyé.": "You'll write a few lines, then read them aloud (video or audio) in teleprompter mode. Everything is saved locally, nothing is sent.",
"Un état des lieux rapide, sans filtre.": "A quick, unfiltered status check.",
"Une page dédiée explique comment se déroulent les contrôles alcool et stupéfiants au volant, les seuils légaux (France, Belgique), et pourquoi la seule façon fiable de les passer est de ne pas conduire après avoir consommé.": "A dedicated page explains how roadside alcohol and drug checks work, the legal limits (France, Belgium), and why the only reliable way to pass them is not to drive after using.",
"Urgences, overdose, safer use, légal — l'essentiel pour limiter la casse, sans jugement.": "Emergencies, overdose, safer use, legal — the essentials to limit harm, without judgment.",
"Usage régulier / quotidien": "Regular / daily use",
"Vérificateur d'": "Checker of",
"analyse de confirmation": "confirmation test",
"cohérence cardiaque": "heart coherence",
"couvrent des mois. Dose, fréquence et métabolisme changent tout.": "cover months. Dose, frequency and metabolism change everything.",
"dure plus longtemps, surtout en usage régulier. Les": "lasts longer, especially with regular use. The",
"dépistage": "screening test",
"grâce à toi.": "thanks to you.",
"liste les lignes d'écoute et les assos près de chez toi.": "lists helplines and support groups near you.",
"rapide (éthylotest pour l'alcool, test salivaire pour les stupéfiants), puis, si positif, une": "quick one (breathalyser for alcohol, saliva test for drugs), then, if positive, a",
"reflète l'usage récent (souvent 5–48 h). L'": "reflects recent use (often 5–48 h). The",
"renforce l'engagement et réduit l'impulsivité : en reliant le présent à un objectif concret, on résiste mieux à l'envie de l'instant.": "strengthens commitment and reduces impulsivity: by linking the present to a concrete goal, you resist the urge of the moment better.",
"retomber le stress et le craving": "bring stress and craving back down",
"réussie !": "completed!",
"séances réalisées": "sessions done",
"uniquement sur cet appareil": "only on this device",
"À lire.": "Worth reading.",
"À savoir —": "Good to know —",
"Écris, puis dis-la à voix haute face caméra ou au micro. Elle reste sur ton téléphone.": "Write it, then say it aloud to the camera or mic. It stays on your phone.",
"Écris, récite face caméra ou au micro · garde-la dans ton parcours": "Write, recite to camera or mic · keep it in your journey",
"État d'esprit et environnement façonnent l'expérience, surtout avec les psychédéliques. Lieu sûr, personnes de confiance, pas de moment de crise émotionnelle. Garde un·e « sitter » sobre pour les hautes doses.": "Mindset and setting shape the experience, especially with psychedelics. Safe place, people you trust, not during an emotional crisis. Keep a sober “sitter” for high doses.",
"— cette semaine": "— this week",
"— estimations sourcées (Verstraete 2004, SAMHSA Oral Fluid 2023/24, NIDA). Information de réduction des risques ; ne remplace pas un avis médical ou juridique.": "— sourced estimates (Verstraete 2004, SAMHSA Oral Fluid 2023/24, NIDA). Harm-reduction information; not a substitute for medical or legal advice.",
"— info ; ne remplace pas un avis médical. Tes réponses restent sur ton appareil.": "— info; not a substitute for medical advice. Your answers stay on your device.",
"🎥 Vidéo": "🎥 Video",
"Manche": "Round",
"Recommencer": "Restart"
};

Object.assign(window.MD_PHRASES, {
  "Suivi":"Tracking","Audio":"Audio","Recommencer":"Restart","Retour":"Back","Continuer":"Continue",
  "Accueil":"Home","Substances":"Substances","Parcours":"Journey","Mon Parcours":"My Journey","Sécurité":"Safety",
  "Jour":"Day","Niveau":"Level","Manche":"Round","Cycle":"Cycle","Semaine":"Week","semaine":"week","jours":"days","jour":"day"
});
Object.assign(window.MD_PHRASES, {"Salive": "Saliva", "Sang": "Blood", "Occasionnel": "Occasional", "Régulier": "Regular", "Type d'usage": "Type of use", "Non détecté en test de routine.": "Not detected in routine testing.", "Usage unique / occasionnel": "Single / occasional use", "Usage régulier / quotidien": "Regular / daily use", "— estimations sourcées (SAMHSA Oral Fluid Mandatory Guidelines 2023 · manuel SAMHSA 2024 · Cone & Huestis 2007 · Verstraete 2004 · NIDA). Information de réduction des risques ; ne remplace pas un avis médical ou juridique.": "— sourced estimates (SAMHSA Oral Fluid Mandatory Guidelines 2023 · SAMHSA Handbook 2024 · Cone & Huestis 2007 · Verstraete 2004 · NIDA). Harm-reduction information; not a substitute for medical or legal advice."});

Object.assign(window.MD_PHRASES, {"Estimations pour un usage OCCASIONNEL, jamais une garantie — et souvent sous-estimées. En usage RÉGULIER ou à FORTE DOSE, la salive peut rester positive PLUSIEURS JOURS : pour le cannabis, des études documentent des positifs jusqu’à ~8 jours chez l’usager chronique, parfois en dents de scie (négatif puis re-positif). Les tests actuels (DrugWipe, Dräger, labo LC-MS/MS ; seuils SAMHSA : THC 4 ng/mL, amphét/MDMA 50, cocaïne + benzoylecgonine) détectent des traces très faibles. En Belgique et en France, un test salivaire positif suffit à la sanction au volant. La seule certitude, c’est le temps — et plus tu consommes souvent, plus il en faut. Ne pas conduire après usage.": "Estimates for OCCASIONAL use, never a guarantee — and often underestimated. With REGULAR or HIGH-DOSE use, saliva can stay positive for SEVERAL DAYS: for cannabis, studies document positives up to ~8 days in chronic users, sometimes intermittently (negative then positive again). Current tests (DrugWipe, Dräger, lab LC-MS/MS; SAMHSA cutoffs: THC 4 ng/mL, amphetamines/MDMA 50, cocaine + benzoylecgonine) detect very faint traces. In Belgium and France, a positive saliva test is enough for a driving penalty. The only certainty is time — and the more often you use, the more you need. Don't drive after use.", "La salive reflète l'usage récent, mais ce n'est PAS une garantie : en usage occasionnel souvent < 24–48 h, mais en usage régulier ou à forte dose jusqu'à plusieurs jours (cannabis : ~8 j documentés, parfois en dents de scie — « négatif hier » ne garantit rien). Les tests actuels (DrugWipe, Dräger, labo) détectent des traces infimes. L'urine dure plus longtemps ; les cheveux couvrent des mois. En Belgique et en France, un test salivaire positif suffit à la sanction.": "Saliva reflects recent use, but it's NOT a guarantee: with occasional use often < 24–48 h, but with regular or high-dose use up to several days (cannabis: ~8 days documented, sometimes intermittently — 'negative yesterday' guarantees nothing). Current tests (DrugWipe, Dräger, lab) detect tiny traces. Urine lasts longer; hair covers months. In Belgium and France, a positive saliva test is enough for a penalty.", "TRÈS VARIABLE. Usage OCCASIONNEL : pic ~10 min puis chute, souvent négatif en < 24 h. Usage RÉGULIER/CHRONIQUE ou forte dose : salive positive plusieurs jours — études jusqu'à ~8 j, parfois en dents de scie (négatif puis re-positif). « Négatif hier » ne garantit rien. Tests routiers 10 ng/mL, seuil labo SAMHSA 4 ng/mL. Urine (THC-COOH) : usage régulier jusqu'à ~30 j.": "VERY VARIABLE. OCCASIONAL use: peaks ~10 min then drops, often negative within < 24 h. REGULAR/CHRONIC or high-dose use: saliva positive for several days — studies up to ~8 days, sometimes intermittently (negative then positive again). 'Negative yesterday' guarantees nothing. Roadside tests 10 ng/mL, SAMHSA lab cutoff 4 ng/mL. Urine (THC-COOH): regular use up to ~30 days.", "Analyte ciblé par les tests salivaires (delta-9-THC). Identique au cannabis : occasionnel < 24 h, mais usage régulier/chronique jusqu'à plusieurs jours (~8 j documentés).": "The analyte targeted by saliva tests (delta-9-THC). Same as cannabis: occasional < 24 h, but regular/chronic use up to several days (~8 days documented).", "Profil proche du THC (données limitées). Usage régulier : salive possiblement positive plusieurs jours.": "Profile close to THC (limited data). Regular use: saliva possibly positive for several days.", "Très lipophile : fenêtre potentiellement plus longue que le THC, surtout en usage régulier (plusieurs jours).": "Very lipophilic: window potentially longer than THC, especially with regular use (several days)."});

Object.assign(window.MD_PHRASES, {"SAMHSA Oral Fluid Mandatory Guidelines (Federal Register, oct. 2023, eff. 2023) · SAMHSA Oral Fluid Specimen Collection Handbook 2024 · Cone & Huestis 2007 (interprétation salive) · Verstraete 2004": "SAMHSA Oral Fluid Mandatory Guidelines (Federal Register, Oct. 2023) · SAMHSA Oral Fluid Specimen Collection Handbook 2024 · Cone & Huestis 2007 (oral fluid interpretation) · Verstraete 2004", "Estimations, pas une garantie. La salive reflète l'usage RÉCENT : la plupart des substances ~24–50 h, cocaïne et héroïne souvent quelques heures seulement. Les tests routiers actuels (DrugWipe 6S, Dräger DrugTest 5000) et de labo (LC-MS/MS) ciblent cet usage récent — seuils SAMHSA oral fluid : THC 4 ng/mL, amphétamines/MDMA 50 ng/mL, cocaïne + benzoylecgonine. En Belgique et en France, un test salivaire positif suffit à la sanction au volant. L'urine est plus longue, les cheveux couvrent des mois. Dose, fréquence et métabolisme changent tout. Après usage, seul le temps protège : ne pas conduire.": "Estimates, not a guarantee. Saliva reflects RECENT use: most substances ~24–50 h, cocaine and heroin often only a few hours. Current roadside tests (DrugWipe 6S, Dräger DrugTest 5000) and lab tests (LC-MS/MS) target this recent use — SAMHSA oral fluid cutoffs: THC 4 ng/mL, amphetamines/MDMA 50 ng/mL, cocaine + benzoylecgonine. In Belgium and France, a positive saliva test is enough for a driving penalty. Urine lasts longer, hair covers months. Dose, frequency and metabolism change everything. After use, only time protects you: do not drive.", "La salive reflète l'usage récent : la plupart des substances ~24–50 h, cocaïne et héroïne quelques heures. Les tests routiers (DrugWipe, Dräger) et de labo ciblent l'usage récent. L'urine dure plus longtemps ; les cheveux couvrent des mois. En Belgique et en France, un test salivaire positif suffit à la sanction.": "Saliva reflects recent use: most substances ~24–50 h, cocaine and heroin a few hours. Roadside tests (DrugWipe, Dräger) and lab tests target recent use. Urine lasts longer; hair covers months. In Belgium and France, a positive saliva test is enough for a penalty.", "Salive : pic ~10 min après usage puis chute rapide ; usage ponctuel souvent < 24 h, usage lourd/chronique parfois jusqu'à ~72 h (contamination orale résiduelle). Tests routiers à 10 ng/mL (DrugWipe/Dräger), seuil labo SAMHSA 4 ng/mL. Urine (THC-COOH) : usage régulier jusqu'à ~30 j.": "Saliva: peaks ~10 min after use then drops fast; occasional use often < 24 h, heavy/chronic use sometimes up to ~72 h (residual oral contamination). Roadside tests at 10 ng/mL (DrugWipe/Dräger), SAMHSA lab cutoff 4 ng/mL. Urine (THC-COOH): regular use up to ~30 days.", "Analyte ciblé par les tests salivaires (delta-9-THC). Profil identique au cannabis : surtout usage récent.": "The analyte targeted by saliva tests (delta-9-THC). Same profile as cannabis: mostly recent use.", "Salive : cocaïne + benzoylecgonine (consensus 12–48 h, souvent quelques heures seulement). Urine 1–4 j, usage lourd ~1 sem. Cheveux : plusieurs mois. NB : « semaines » = cheveux/urine, PAS salive.": "Saliva: cocaine + benzoylecgonine (consensus 12–48 h, often only a few hours). Urine 1–4 days, heavy use ~1 week. Hair: several months. Note: 'weeks' = hair/urine, NOT saliva."});

Object.assign(window.MD_PHRASES, {"(5 s d'inspiration, 5 s d'expiration) synchronise cœur et respiration : c'est la": "(5 s in, 5 s out) synchronizes heart and breath — this is", "(sang/salive) qui seule a valeur juridique.": "(blood/saliva), which alone has legal standing.", "(usage unique, métabolisme moyen). Elles ne garantissent pas un résultat de test et ne sont pas un avis médical ou juridique.": "(single use, average metabolism). They don't guarantee a test result and are not medical or legal advice.", ", touche « Ajouter une entrée ». Renseigne la substance, l'intensité, et un coût ou une note si tu veux.": ", tap “Add an entry”. Enter the substance, the intensity, and a cost or a note if you like.", ". Si tu effaces les données du navigateur ou désinstalles l'app, le journal est perdu.": ". If you clear your browser data or uninstall the app, the journal is lost.", ". Ça augmente la variabilité du rythme cardiaque et active le système parasympathique — un outil étudié pour faire": ". It increases heart-rate variability and activates the parasympathetic system — a tool studied to"});

window.MD_PATTERNS=[
  [/^Jour (\d+)$/,"Day $1"],
  [/^Niveau (\d+)\s*\/\s*(\d+)$/,"Level $1 / $2"],
  [/^Niveau (\d+)$/,"Level $1"],
  [/^Manche (\d+)$/,"Round $1"],
  [/^Cycle (\d+)$/,"Cycle $1"],
  [/^Semaine (\d+)$/,"Week $1"],
  [/^(\d+) jours?$/,"$1 days"]
];
(function(){
  var _cache=null, _ORIG=new WeakMap();
  function fr2en(){
    if(_cache) return _cache;
    var m={}, d=window.MD_DICT||{}, k;
    for(k in d){ if(d[k]&&d[k].fr&&d[k].en&&typeof d[k].fr==='string'){ m[d[k].fr.replace(/\s+/g,' ').trim()]=d[k].en; } }
    var p=window.MD_PHRASES||{};
    for(k in p){ m[k.replace(/\s+/g,' ').trim()]=p[k]; }
    _cache=m; return m;
  }
  function tNodes(){ var out=[]; (function rec(node){ for(var c=node.firstChild;c;c=c.nextSibling){ if(c.nodeType===3){ out.push(c); } else if(c.nodeType===1){ var nn=c.nodeName; if(nn!=='SCRIPT'&&nn!=='STYLE'&&nn!=='TEXTAREA') rec(c); } } })(document.body); return out; }
  window.MDTranslateDOM=function(toEN){
    if(!document.body) return;
    var map=fr2en();
    tNodes().forEach(function(node){
      var p=node.parentNode; if(p){ var tn=p.nodeName; if(tn==='SCRIPT'||tn==='STYLE'||tn==='TEXTAREA') return; }
      if(toEN){
        var raw=node.nodeValue, key=raw.replace(/\s+/g,' ').trim();
        if(!key) return;
        var rep=null;
        if(map[key]) rep=map[key];
        else { var P=window.MD_PATTERNS||[]; for(var i=0;i<P.length;i++){ if(P[i][0].test(key)){ rep=key.replace(P[i][0],P[i][1]); break; } } }
        if(rep!==null && rep!==key){ if(!_ORIG.has(node))_ORIG.set(node,raw); var L=raw.match(/^\s*/)[0],T=raw.match(/\s*$/)[0]; node.nodeValue=L+rep+T; }
      } else if(_ORIG.has(node)){ node.nodeValue=_ORIG.get(node); }
    });
    ['placeholder','aria-label','title','alt'].forEach(function(attr){
      Array.prototype.forEach.call(document.querySelectorAll('['+attr+']'),function(el){
        if(toEN){ var v=el.getAttribute(attr), key=(v||'').replace(/\s+/g,' ').trim(); if(key&&map[key]){ if(!el.hasAttribute('data-o-'+attr))el.setAttribute('data-o-'+attr,v); el.setAttribute(attr,map[key]); } }
        else if(el.hasAttribute('data-o-'+attr)){ el.setAttribute(attr,el.getAttribute('data-o-'+attr)); }
      });
    });
  };
})();

(function(){
  function autoApply(){ try{ var l=localStorage.getItem('mydopeoff_lang')||'fr'; if(l==='en' && window.MDTranslateDOM) window.MDTranslateDOM(true); }catch(e){} }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(autoApply,60); });
  else setTimeout(autoApply,60);
  window.addEventListener('load', function(){ setTimeout(autoApply,150); });
})();
