/* MyDope Off — page-audition.js
   Seul besoin de la page : MDCore.init(). Sans lui elle reste en français quelle que soit
   la langue choisie (piège 4 du protocole 36). */
(function () {
  function start() {
    try { MDCore.init({ page: 'audition', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
