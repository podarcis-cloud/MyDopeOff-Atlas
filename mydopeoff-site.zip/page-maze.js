/* MyDope Off — page-maze.js
   Scripts inline de maze.html regroupés pour permettre une CSP stricte.
   Les gestionnaires inline (onclick, onmousedown…) ont été convertis en
   attributs data-* + délégation, incluse ici. Ordre d'origine préservé. */

const params = new URLSearchParams(location.search);
const userName = params.get('name') || '';
const userRegion = params.get('region') || 'BE';
function goBack(){ location.href=(window.LUCIDE?LUCIDE.link('fiches.html'):'fiches.html'); }

// ===== MAZE ENGINE =====
/* ── Génération procédurale : 12 niveaux, difficulté graduelle ──
   Grille de murs sur un espace de 360. La bille démarre toujours dans
   une case ouverte (coin haut-gauche dégagé), la cible dans le coin opposé. */
const FIELD = 360, BORDER = 20, WT = 8; // bord & épaisseur des murs
function rngFor(seed){ let s=seed>>>0; return ()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; }; }

function genLevel(idx){
  // difficulté : nombre de murs internes croît avec le niveau
  const rnd = rngFor(1000+idx*97);
  const inner = FIELD - BORDER*2;            // zone jouable
  const cols = 3 + Math.min(5, Math.floor(idx/2)); // 3 → 8 colonnes de segments
  const cell = inner / cols;
  const density = Math.min(0.62, 0.30 + idx*0.027);
  const walls = [
    {x:BORDER,y:BORDER,w:inner,h:WT},
    {x:BORDER,y:FIELD-BORDER-WT,w:inner,h:WT},
    {x:BORDER,y:BORDER,w:WT,h:inner},
    {x:FIELD-BORDER-WT,y:BORDER,w:WT,h:inner}
  ];
  // zones protégées : départ (haut-gauche) et arrivée (bas-droite)
  const safe = (gx,gy)=> (gx<=0&&gy<=0) || (gx>=cols-1&&gy>=cols-1);
  for(let gy=0; gy<cols; gy++){
    for(let gx=0; gx<cols; gx++){
      if(safe(gx,gy)) continue;
      if(rnd() > density) continue;
      const cx = BORDER + gx*cell, cy = BORDER + gy*cell;
      // segment horizontal ou vertical, longueur ~ 0.55–0.9 d'une cellule
      const horiz = rnd() < 0.5;
      const len = cell * (0.55 + rnd()*0.35);
      if(horiz) walls.push({x:cx + (cell-len)/2, y:cy + cell/2, w:len, h:WT});
      else      walls.push({x:cx + cell/2, y:cy + (cell-len)/2, w:WT, h:len});
    }
  }
  // départ : centre de la 1re cellule (dégagé) ; cible : centre de la dernière
  const start = { x: BORDER + cell*0.5, y: BORDER + cell*0.5 };
  const target = { x: FIELD - BORDER - cell*0.5, y: FIELD - BORDER - cell*0.5,
                   radius: Math.max(11, 15 - idx*0.3) };
  return { walls, start, target };
}

const LEVELS = Array.from({length:12}, (_,i)=>genLevel(i));

let currentScreen = 'intro';
let levelIndex = 0;
let levelScores = [];
let gameRunning = false;
let useGyro = false;
let useArrows = false;

// Physics
const ballRadius = 11;
const damping = 0.975;
const accelFactor = 0.7;
const maxVel = 9;
let ballX, ballY, velX, velY;
let tiltGamma = 0, tiltBeta = 0;
let gyroEventReceived = false, gyroFallbackTimer = null;
let arrowState = {up:false,down:false,left:false,right:false};
let penaltyCount = 0;
let startTime = null;
let timeElapsed = 0;
let timerInterval = null;
let animFrame = null;
let flashWalls = {};
let scaledWalls = [];
let scaledTarget = {};
let canvasEl = null, canvasCtx = null;
let lastTs = 0;

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + id).classList.add('active');
  currentScreen = id;
}
document.getElementById('screen-ready').addEventListener('click', function (e) {
  if (e.target.closest('button')) return; // ne pas court-circuiter "Démarrer"/"Changer de mode"
  startPlaying();
});

function getCanvasSize() {
  return Math.min(360, window.innerWidth - 40);
}

function scaleLevel(idx) {
  const lvl = LEVELS[idx];
  const size = getCanvasSize();
  const sc = size / 360;
  scaledWalls = lvl.walls.map(w => ({ x:w.x*sc, y:w.y*sc, w:w.w*sc, h:w.h*sc }));
  scaledTarget = { x:lvl.target.x*sc, y:lvl.target.y*sc, r:lvl.target.radius*sc };
  ballX = lvl.start.x * sc;
  ballY = lvl.start.y * sc;
  // filet de sécurité : si le départ chevauche un mur, on repousse la bille
  const r = ballRadius;
  scaledWalls.forEach(w=>{
    if(ballX+r>w.x && ballX-r<w.x+w.w && ballY+r>w.y && ballY-r<w.y+w.h){
      ballX = w.x + w.w + r + 2; ballY = w.y + w.h + r + 2;
    }
  });
  velX = 0; velY = 0;
  penaltyCount = 0;
  flashWalls = {};
}

function capsuleFill(ctx,x,y,w,h){ var r=Math.min(w,h)/2; ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); ctx.fill(); }
function drawMaze(ctx, size, status) {
  ctx.clearRect(0, 0, size, size);
  ctx.fillStyle = '#F5F2EA';
  ctx.fillRect(0, 0, size, size);

  const now = Date.now();

  // Walls
  for (let i = 0; i < scaledWalls.length; i++) {
    const w = scaledWalls[i];
    const flashing = flashWalls[i] && (now - flashWalls[i] < 300);
    ctx.fillStyle = flashing ? '#B23A1E' : '#283A31';
    capsuleFill(ctx, w.x, w.y, w.w, w.h);
  }

  // Target
  ctx.beginPath();
  ctx.arc(scaledTarget.x, scaledTarget.y, scaledTarget.r, 0, Math.PI*2);
  ctx.fillStyle = '#B23A1E';
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.font = `bold ${Math.round(scaledTarget.r)}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('', scaledTarget.x, scaledTarget.y);

  // Ball
  ctx.beginPath();
  ctx.arc(ballX, ballY, ballRadius, 0, Math.PI*2);
  ctx.fillStyle = '#8A6258';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(ballX - 3, ballY - 3, 4, 0, Math.PI*2);
  ctx.fillStyle = 'rgba(255,255,255,0.4)';
  ctx.fill();

  // Timer overlay
  if (status === 'playing' && startTime) {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    ctx.font = 'bold 13px Syne, sans-serif';
    ctx.fillStyle = '#1F2B25';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'top';
    ctx.fillText(`${elapsed}s`, size - 10, 8);
    ctx.fillStyle = '#B23A1E';
    ctx.fillText(` ${penaltyCount}`, size - 10, 24);
  }
}

function circleRectCollide(cx, cy, r, rect, idx) {
  const clX = Math.max(rect.x, Math.min(cx, rect.x + rect.w));
  const clY = Math.max(rect.y, Math.min(cy, rect.y + rect.h));
  const dx = cx - clX, dy = cy - clY;
  if (dx*dx + dy*dy < r*r) {
    const angle = Math.atan2(dy, dx);
    const overlap = r - Math.sqrt(dx*dx + dy*dy);
    return { hit: true, angle, overlap };
  }
  return { hit: false };
}

function resolveCollisions(x, y) {
  let nx = x, ny = y;
  for (let iter = 0; iter < 6; iter++) {
    let any = false;
    for (let i = 0; i < scaledWalls.length; i++) {
      const res = circleRectCollide(nx, ny, ballRadius, scaledWalls[i], i);
      if (res.hit) {
        any = true;
        nx += Math.cos(res.angle) * (res.overlap + 0.5);
        ny += Math.sin(res.angle) * (res.overlap + 0.5);
        // Penalty
        const now = Date.now();
        if (!flashWalls[i] || now - flashWalls[i] > 600) {
          flashWalls[i] = now;
          penaltyCount++;
          if (startTime) startTime -= 1000; // +1s penalty
          updatePlayStats();
        }
        velX *= -0.3; velY *= -0.3;
      }
    }
    if (!any) break;
  }
  return { nx, ny };
}

function checkWin() {
  const dx = ballX - scaledTarget.x, dy = ballY - scaledTarget.y;
  return Math.hypot(dx, dy) < ballRadius + scaledTarget.r - 4;
}

function updatePlayStats() {
  document.getElementById('play-level').textContent = (levelIndex+1)+'/'+LEVELS.length;
  const elapsed = startTime ? Math.floor((Date.now() - startTime) / 1000) : 0;
  document.getElementById('play-time').textContent = elapsed + 's';
  document.getElementById('play-penalty').textContent = penaltyCount;
}

function computeScore() {
  const elapsed = startTime ? Math.floor((Date.now() - startTime) / 1000) : 99;
  const s = Math.max(1, 5 - Math.floor(elapsed / 8) - Math.floor(penaltyCount / 2));
  return Math.min(5, Math.max(1, s));
}

function gameLoop(ts) {
  if (!gameRunning) return;
  if (lastTs === 0) lastTs = ts;
  const dt = Math.min(50, ts - lastTs) / 16;
  lastTs = ts;

  // Acceleration
  let ax = 0, ay = 0;
  if (useGyro) { ax = tiltGamma * accelFactor; ay = tiltBeta * accelFactor; }
  if (useArrows) {
    if (arrowState.left) ax = -accelFactor * 0.8;
    if (arrowState.right) ax = accelFactor * 0.8;
    if (arrowState.up) ay = -accelFactor * 0.8;
    if (arrowState.down) ay = accelFactor * 0.8;
  }

  velX = Math.min(maxVel, Math.max(-maxVel, (velX + ax * dt) * damping));
  velY = Math.min(maxVel, Math.max(-maxVel, (velY + ay * dt) * damping));

  const proposed = { nx: ballX + velX * dt, ny: ballY + velY * dt };
  const { nx, ny } = resolveCollisions(proposed.nx, proposed.ny);
  ballX = nx; ballY = ny;

  drawMaze(canvasCtx, canvasEl.width, 'playing');

  if (canvasEl === document.getElementById('maze-canvas-play') && startTime) {
    updatePlayStats();
  }

  if (checkWin()) {
    winLevel();
    return;
  }
  animFrame = requestAnimationFrame(gameLoop);
}

function winLevel() {
  if(window.MDData){MDData.logSession('maze',{});}else{try{var _k='ctc_v6',_d=JSON.parse(localStorage.getItem(_k)||'{}');_d.sessions=Array.isArray(_d.sessions)?_d.sessions:[];_d.sessions.push({type:'maze',date:Date.now()});localStorage.setItem(_k,JSON.stringify(_d));}catch(e){}}
  gameRunning = false;
  lastTs = 0;
  if (animFrame) cancelAnimationFrame(animFrame);
  if (timerInterval) clearInterval(timerInterval);
  const s = computeScore();
  levelScores[levelIndex] = s;
  document.getElementById('win-level').textContent = levelIndex + 1;
  document.getElementById('win-sub').textContent = `Score : ${s}/5 · Pénalités : ${penaltyCount} · Temps : ~${Math.floor((Date.now()-startTime)/1000)}s`;
  var _msgs=[
    'Guider la bille mobilise l\u2019équilibre et la navigation spatiale \u2014 des circuits distincts de celui de l\u2019envie. C\u2019est ce qui aide \u00e0 couper un craving.',
    'Se concentrer sur un geste fin laisse moins de place \u00e0 la rumination : l\u2019envie perd en intensit\u00e9 quand l\u2019attention se d\u00e9place.',
    'Chaque manche r\u00e9ussie est une preuve concr\u00e8te : tu peux rediriger ton attention quand tu le d\u00e9cides.'
  ];
  var _fb=document.getElementById('win-feedback'); if(_fb) _fb.textContent=_msgs[levelIndex % _msgs.length];
  try{ var _o=JSON.parse(localStorage.getItem('ctc_v6')||'{}'); var _ss=Array.isArray(_o.sessions)?_o.sessions:[]; var _now=Date.now();
    var _tot=_ss.filter(function(x){return x.type==='maze';}).length;
    var _wk=_ss.filter(function(x){return x.type==='maze' && _now-(x.date||0)<=6048e5;}).length;
    var _ac=document.getElementById('win-accomplish'); if(_ac) _ac.textContent='\u2726 '+_tot+' manche'+(_tot>1?'s':'')+' r\u00e9ussie'+(_tot>1?'s':'')+' au total \u00b7 '+_wk+' cette semaine';
  }catch(e){}
  const btnNext = document.getElementById('btn-next-level');
  if (levelIndex + 1 < LEVELS.length) {
    btnNext.textContent = `Niveau ${levelIndex+2} →`;
    btnNext.style.display = '';
  } else {
    btnNext.style.display = 'none';
  }
  showScreen('win');
  // Show finish button
  if (levelIndex + 1 >= LEVELS.length) {
    document.getElementById('btn-next-level').textContent = 'Voir le score final';
    document.getElementById('btn-next-level').style.display = '';
    document.getElementById('btn-next-level').onclick = showFinished;
  }
}

function nextLevel() {
  if (levelIndex + 1 >= LEVELS.length) { showFinished(); return; }
  levelIndex++;
  setupReadyScreen();
  showScreen('ready');
}

function showFinished() {
  const total = levelScores.reduce((a,b) => a+b, 0);
  const max = LEVELS.length * 5;
  let html = '';
  levelScores.forEach((s, i) => {
    const stars = ''.repeat(s) + ''.repeat(5-s);
    html += `<div class="score-row"><span>Niveau ${i+1}</span><span>${stars} ${s}/5</span></div>`;
  });
  html += `<div class="score-row" style="font-weight:var(--w-bold);"><span>Total</span><span>${total}/${max}</span></div>`;
  document.getElementById('score-list').innerHTML = html;
  try{ /* screen-finished accomplish */ var _o=JSON.parse(localStorage.getItem('ctc_v6')||'{}'); var _ss=Array.isArray(_o.sessions)?_o.sessions:[]; var _tot=_ss.filter(function(x){return x.type==='maze';}).length;
    var _sl=document.getElementById('score-list'); if(_sl){ var _d=document.createElement('div'); _d.style.cssText='text-align:center;font-family:var(--font-human);font-weight:var(--w-medium);font-size:var(--fs-xs);color:var(--purple);margin-top:10px'; _d.textContent='\u2726 '+_tot+' manches r\u00e9ussies au total'; _sl.parentNode.insertBefore(_d,_sl.nextSibling); } }catch(e){}
  showScreen('finished');
  if(window.MDExercise){
    MDExercise.after('maze',{avant:window.__mdAvant, meta:{completed:true, score:total, max:max},
      title:'Labyrinthe gyroscope', stats:[{label:'score total',value:total+'/'+max}],
      nav:{ primary:{label:'Rejouer'}, secondary:{label:'Retour aux exercices', onClick:goBack} },
      onClose:function(){ window.__mdAvant=null; resetToIntro(); }});
  }

  // Save
  try {
    const KEY = 'ctc_v6';
    const d = JSON.parse(localStorage.getItem(KEY)) || {};
    const sessions = d.sessions || [];
    sessions.push({ type: 'ex', name: 'Gyro Labyrinthe', score: total, date: Date.now() });
    d.sessions = sessions;
    d.score = (d.score || 0) + total;
    localStorage.setItem(KEY, JSON.stringify(d));
  } catch(e) {}
}

function setupReadyScreen() {
  scaleLevel(levelIndex);
  const size = getCanvasSize();
  const c = document.getElementById('maze-canvas');
  c.width = size; c.height = size;
  const ctx = c.getContext('2d');
  drawMaze(ctx, size, 'ready');
  document.getElementById('level-badge').textContent = `Niveau ${levelIndex+1} / ${LEVELS.length}`;
  const dbg = document.getElementById('debug-bar');
  if (dbg) dbg.textContent = useArrows ? 'Mode flèches — touche « Démarrer » puis maintiens une direction' : 'Gyro en attente…';
}

function mazeBegin(){
  if(window.MDJeuHero){
    MDJeuHero.rules({mood:'concentration', title:'Labyrinthe gyroscope',
      lines:['Incline le téléphone pour faire rouler la bille jusqu\u2019à la cible.',
             'Touche un mur = +1 seconde de pénalité. Score max : 5/5 par niveau.',
             '12 niveaux — la bille part en haut à gauche, la cible rouge est en bas à droite.'],
      why:"Suivre et corriger la position d'une bille en temps réel occupe la même mémoire de travail visuospatiale que l'imagerie mentale d'une envie \u2014 le même principe qui rend Tetris efficace contre le craving (Skorka-Brown, Oxford 2015), ici via l'équilibre et le geste plutôt que la rotation de formes.",
      startLabel:'Activer le gyroscope',
      onStart:function(avant){ window.__mdAvant=avant; requestGyro(); },
      skipLabel:'Utiliser les flèches',
      onSkip:function(){ startWithArrows(); }});
  }
}
function startPlaying() {
  scaleLevel(levelIndex);
  const size = getCanvasSize();
  canvasEl = document.getElementById('maze-canvas-play');
  canvasEl.width = size; canvasEl.height = size;
  canvasCtx = canvasEl.getContext('2d');
  document.getElementById('play-level').textContent = (levelIndex+1)+'/'+LEVELS.length;
  document.getElementById('play-time').textContent = '0s';
  document.getElementById('play-penalty').textContent = '0';
  document.getElementById('play-score').textContent = '—';
  if (useArrows) {
    document.getElementById('arrow-controls').style.display = 'grid';
    document.getElementById('arrow-hint').style.display = 'block';
  }
  showScreen('playing');
  gameRunning = true;
  lastTs = 0;
  startTime = Date.now();
  timerInterval = setInterval(updatePlayStats, 500);
  animFrame = requestAnimationFrame(gameLoop);
}

function requestGyro() {
  if (window.isSecureContext === false) {
    // Cause la plus fréquente et la plus silencieuse sur Android : DeviceOrientationEvent exige HTTPS.
    // Sans cette vérification, le capteur ne répond jamais et rien ne l'explique — écran figé sans indice.
    startWithArrows('Le gyroscope exige une connexion sécurisée (https://) — passage aux flèches.');
    return;
  }
  if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
    DeviceOrientationEvent.requestPermission().then(state => {
      if (state === 'granted') {
        activateGyro();
      } else {
        startWithArrows('Permission gyroscope refusée — passage aux flèches.');
      }
    }).catch(() => {
      startWithArrows('Permission gyroscope refusée — passage aux flèches.');
    });
  } else {
    activateGyro();
  }
}

function activateGyro() {
  useGyro = true;
  gyroEventReceived = false;
  window.addEventListener('deviceorientation', handleOrientation);
  window.addEventListener('deviceorientationabsolute', handleOrientation); // repli Chrome/Android, même si 'deviceorientation' ne se déclenche jamais
  clearTimeout(gyroFallbackTimer);
  gyroFallbackTimer = setTimeout(function () {
    if (!gyroEventReceived) {
      // Aucun événement reçu après 5s (certains capteurs Android se calibrent lentement, d'où un délai généreux) :
      // le capteur ne répond pas sur cet appareil, on bascule proprement sur les flèches plutôt que de laisser l'écran figé.
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('deviceorientationabsolute', handleOrientation);
      useGyro = false; useArrows = true;
      var err = document.getElementById('perm-error');
      if (err) { err.querySelector('span').textContent = 'Le gyroscope ne répond pas sur cet appareil — passage aux flèches.'; err.style.display = 'block'; }
      if (window.MDCompagnon) MDCompagnon.toast({ mood: 'adaptation', text: 'Le gyroscope ne répond pas ici \u2014 les flèches prennent le relais, sans rien changer au reste.' });
      setupReadyScreen();
    }
  }, 5000);
  setupReadyScreen(); showScreen('ready');
}

function startWithArrows(errorMsg) {
  clearTimeout(gyroFallbackTimer);
  useArrows = true;
  useGyro = false;
  setupReadyScreen(); showScreen('ready');
  if (errorMsg) {
    var err = document.getElementById('perm-error');
    if (err) { err.querySelector('span').textContent = errorMsg; err.style.display = 'block'; }
    if (window.MDCompagnon) MDCompagnon.toast({ mood: 'adaptation', text: 'Les flèches prennent le relais \u2014 le jeu reste exactement le même.' });
  }
}

function handleOrientation(e) {
  if (e.gamma != null || e.beta != null) gyroEventReceived = true;
  const maxTilt = 40;
  tiltGamma = Math.min(1, Math.max(-1, (e.gamma || 0) / maxTilt));
  tiltBeta = Math.min(1, Math.max(-1, (e.beta || 0) / maxTilt));
  const txt = gyroEventReceived ? `\u03b3:${(e.gamma||0).toFixed(0)}\u00b0 \u03b2:${(e.beta||0).toFixed(0)}\u00b0` : 'Gyro en attente\u2026';
  const dbg = document.getElementById('debug-bar-play'); if (dbg) dbg.textContent = txt;
  const dbgReady = document.getElementById('debug-bar'); if (dbgReady) dbgReady.textContent = gyroEventReceived ? ('Gyro d\u00e9tect\u00e9 \u2014 ' + txt) : 'Gyro en attente\u2026';
}

// Arrow touch controls
/* Délégation des commandes (ex-attributs inline, retirés pour permettre une CSP stricte).
   Les flèches doivent réagir à l'appui ET au relâchement pour que le maintien fonctionne :
   pointerdown/pointerup couvrent souris et tactile d'un seul jeu d'écouteurs. */
document.addEventListener('pointerdown', function(e){
  var el = e.target.closest && e.target.closest('[data-dir]');
  if (el) { e.preventDefault(); arrowDown(el.getAttribute('data-dir')); }
});
function releaseAll(e){
  var el = e.target.closest && e.target.closest('[data-dir]');
  if (el) { arrowUp(el.getAttribute('data-dir')); return; }
  ['up','down','left','right'].forEach(function(d){ arrowUp(d); }); // relâchement hors bouton
}
document.addEventListener('pointerup', releaseAll);
document.addEventListener('pointercancel', releaseAll);
document.addEventListener('click', function(e){
  var el = e.target.closest && e.target.closest('[data-act]');
  if (!el) return;
  var a = el.getAttribute('data-act');
  if (a === 'nextLevel') nextLevel();
  else if (a === 'quitMidGame') quitMidGame();
  else if (a === 'resetToIntro') resetToIntro();
  else if (a === 'startPlaying') startPlaying();
});

function arrowDown(dir) { arrowState[dir] = true; }
function arrowUp(dir) { arrowState[dir] = false; }

// Keyboard fallback
document.addEventListener('keydown', e => {
  if (e.key === 'ArrowLeft') arrowState.left = true;
  if (e.key === 'ArrowRight') arrowState.right = true;
  if (e.key === 'ArrowUp') arrowState.up = true;
  if (e.key === 'ArrowDown') arrowState.down = true;
});
document.addEventListener('keyup', e => {
  if (e.key === 'ArrowLeft') arrowState.left = false;
  if (e.key === 'ArrowRight') arrowState.right = false;
  if (e.key === 'ArrowUp') arrowState.up = false;
  if (e.key === 'ArrowDown') arrowState.down = false;
});

function quitMidGame() {
  gameRunning = false;
  if (timerInterval) clearInterval(timerInterval);
  var doneLevels = levelScores.length;
  var elapsedSec = startTime ? Math.round((Date.now() - startTime) / 1000) : 0;
  if (window.MDExercise && (doneLevels > 0 || elapsedSec >= 10)) {
    // Une vraie tentative a eu lieu (au moins 10s ou un niveau bouclé) : la mascotte
    // referme la séance plutôt que de la laisser disparaître sans un mot.
    MDExercise.after('maze', {
      avant: window.__mdAvant, meta: { completed: false, niveauxFaits: doneLevels },
      title: 'Labyrinthe gyroscope',
      stats: doneLevels ? [{ label: 'manches réussies', value: doneLevels + '/' + LEVELS.length }] : [],
      nav: { primary: { label: 'Recommencer' }, secondary: { label: 'Retour aux exercices', onClick: goBack } },
      onClose: function () { window.__mdAvant = null; resetToIntro(); }
    });
  } else {
    // Sortie quasi immédiate, rien à refléter — retour direct, sans débrief artificiel.
    resetToIntro();
  }
}

function resetToIntro() {
  gameRunning = false;
  lastTs = 0;
  if (animFrame) cancelAnimationFrame(animFrame);
  if (timerInterval) clearInterval(timerInterval);
  window.removeEventListener('deviceorientation', handleOrientation);
  levelIndex = 0;
  levelScores = [];
  useGyro = false;
  useArrows = false;
  arrowState = {up:false,down:false,left:false,right:false};
  tiltGamma = 0; tiltBeta = 0;
  mazeBegin();
}

/* ---- bloc suivant ---- */

(function(){
  try{
    var d=JSON.parse(localStorage.getItem('ctc_v6'));
    if(d&&d.user&&d.user.name){
      var p='';
    }
  }catch(e){}
})();

/* ---- bloc suivant ---- */

(function(){function a(){if(!window.LUCIDE)return false;try{LUCIDE.applyI18n();}catch(e){}return true;}if(!a()){var n=0,iv=setInterval(function(){if(a()||++n>50)clearInterval(iv);},50);}document.addEventListener("langchange",function(){try{LUCIDE.applyI18n();}catch(e){}});})();

/* ---- bloc suivant ---- */

mazeBegin(); /* tuto mascotte au chargement — le choix gyro/flèches y est intégré (voir mazeBegin) */

/* ---- bloc suivant ---- */

try{MDCore.init({page:'maze',section:'equilibre'});}catch(e){}
