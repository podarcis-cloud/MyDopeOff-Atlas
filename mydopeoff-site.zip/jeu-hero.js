/* jeu-hero.js — Accompagnement des jeux par le compagnon Atlas (LOT J0).
   Brique commune réutilisée par tous les jeux du Labo, pour l'unité :
     • MDJeuHero.rules(opts) : popup où l'avatar explique les règles + « pourquoi
       ça aide » (la fonction cérébrale entraînée), avant de lancer le jeu.
     • MDJeuHero.debrief(opts) : même carte, à la fin — bilan, récap, navigation.
   100 % local. Dépend de MDCompagnon (avatars).
   Respecte prefers-reduced-motion (via MDCompagnon). */
window.MDJeuHero = (function () {
  'use strict';

  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdj-ov{z-index:var(--z-modal-2,4100);align-items:flex-start;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.55);backdrop-filter:blur(3px);font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mdj-card{position:relative;border:1px solid var(--line,#E2DCD0);' +
      'border-radius:22px;max-width:400px;width:100%;padding:24px 22px 20px;box-shadow:0 22px 60px rgba(31,43,37,.3);text-align:left}' +
      '.mdj-hero{display:flex;align-items:flex-start;gap:11px;margin-bottom:14px}' +
      '.mdj-ava{flex:0 0 auto;display:block;width:var(--avatar-md,52px);height:var(--avatar-md,52px);border-radius:50%;overflow:hidden;' +
      'background:var(--sauge-50,#EEF1E9);border:1px solid var(--line,#E2DCD0)}' +
      '.mdj-ava img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdj-bub{flex:1;min-width:0;background:var(--bg-2,#FBF8F1);border-radius:14px 14px 14px 4px;padding:10px 13px;margin-top:2px}' +
      '.mdj-title{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,23px);margin:0}' +
      '.mdj-lines{text-align:left;margin:0 0 12px}' +
      '.mdj-lines p{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-ui,15px);line-height:var(--lh-normal,1.5);margin:0 0 8px;' +
      'padding-left:22px;position:relative}' +
      '.mdj-lines p::before{content:"";position:absolute;left:2px;top:8px;width:8px;height:8px;border-radius:50%;background:var(--c,#7A8F72)}' +
      '.mdj-why{background:var(--bg-2,#FBF8F1);border-left:3px solid var(--c,#7A8F72);border-radius:8px;padding:10px 12px;margin:0 0 16px;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-xs,13px);line-height:var(--lh-normal,1.5);color:var(--ink-2,#58635E);text-align:left}' +
      '.mdj-why b{color:var(--ink,#1F2B25)}' +
      '.mdj-go{width:100%;border:none;border-radius:14px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);font-size:var(--fs-ui,15.5px);' +
      'padding:14px;cursor:pointer}' +
      '.mdj-skip{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);text-decoration:underline;' +
      'font-size:var(--fs-xs,13px);padding:10px 0 2px;cursor:pointer}' +
      /* écran de fin (débrief) : récap chiffré + navigation à deux niveaux (hiérarchie boutons, §8 design system) */
      '.mdj-stats{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 14px}' +
      '.mdj-stat{flex:1 1 auto;background:var(--bg-2,#FBF8F1);border-radius:10px;padding:8px 11px;text-align:center;' +
      'font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E)}' +
      '.mdj-stat b{display:block;font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-ui,16px);' +
      'font-weight:var(--w-bold,700);color:var(--ink,#1F2B25)}' +
      '.mdj-note{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-sm,13.5px);' +
      'color:var(--ink-2,#58635E);line-height:var(--lh-normal,1.5);margin:-6px 0 14px}' +
      '.mdj-nav{display:flex;flex-direction:column;gap:8px;margin-top:4px}' +
      '.mdj-secondary{width:100%;border:1px solid var(--line,#E2DCD0);border-radius:14px;background:transparent;' +
      'color:var(--ink,#1F2B25);font-family:var(--font-technical,Inter,sans-serif);font-weight:var(--w-bold,700);' +
      'font-size:var(--fs-ui,15px);padding:13px;cursor:pointer}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function accent(mood) {
    var m = { ecoute: 'sauge', respiration: 'fjord', reflexion: 'sauge', explication: 'ocre', motivation: 'terra',
      curiosite: 'sauge', action: 'fjord', celebration: 'rose', encouragement: 'ocre' };
    return 'var(--' + (m[mood] || 'sauge') + ',#7A8F72)';
  }
  /* Un scan d'intensité récent (mode urgence, <10 min) : si présent, on évite de redemander
     la jauge sur l'écran de démarrage. Consommé une seule fois (comme l'ancien mdBefore). */
  function recentScan() {
    try {
      var sc = JSON.parse(sessionStorage.getItem('mdScan') || 'null');
      if (sc && sc.envie != null && (Date.now() - (sc.ts || 0)) < 600000) {
        sessionStorage.removeItem('mdScan');
        return { envie: sc.envie, type: sc.type || null };
      }
    } catch (e) {}
    return null;
  }

  /* rules(opts) : opts = { mood, title, lines:[..], why, base, onStart(avant), onSkip, hideGauge }
     Écran UNIQUE de démarrage : avatar + règles + pourquoi ça aide + jauge « avant » + un seul bouton.
     Si un scan récent existe (mode urgence), la jauge est masquée et sa valeur réutilisée directement. */
  function rules(opts) {
    opts = opts || {};
    inject();
    var scan = opts.hideGauge ? null : recentScan();
    var showGauge = false; // la jauge ne s'affiche plus qu'en mode urgence craving (voir scanner.js) — jamais en accès normal à un jeu
    var mood = opts.mood || 'explication';
    var base = opts.base || 'avatars/';
    var ov = document.createElement('div'); ov.className = 'mdj-ov md-ov';
    var card = document.createElement('div'); card.className = 'mdj-card md-card'; card.style.setProperty('--c', accent(mood));
    var avHTML = window.MDCompagnon ? ('<div class="mdj-ava"><img src="' + base + mood + '.png" alt="" width="52" height="52"></div>') : '';
    card.innerHTML =
      '<div class="mdj-hero">' + avHTML + '<div class="mdj-bub"><p class="mdj-title">' + esc(opts.title || 'On y va ?') + '</p></div></div>' +
      '<div class="mdj-lines">' + (opts.lines || []).map(function (l) { return '<p>' + esc(l) + '</p>'; }).join('') + '</div>' +
      (opts.why ? '<div class="mdj-why"><b>Pourquoi ça aide —</b> ' + esc(opts.why) + '</div>' : '') +
      (opts.extraHTML || '') +
      '<button class="mdj-go" type="button" data-act="go">' + esc(opts.startLabel || 'Commencer') + '</button>' +
      (opts.onSkip ? '<button class="mdj-skip" type="button" data-act="skip">' + esc(opts.skipLabel || 'Passer les règles') + '</button>' : '');
    ov.appendChild(card); document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Avant de commencer' });
    if (typeof opts.onRender === 'function') opts.onRender(card); // le DOM (dont extraHTML) est prêt : câbler les contrôles perso ici
    function close() { if (ov.parentNode) ov.parentNode.removeChild(ov); }
    card.querySelector('[data-act="go"]').addEventListener('click', function () {
      var avant = scan ? scan.envie : null;
      if (scan && scan.type) window.__mdCravingType = scan.type;
      close();
      if (typeof opts.onStart === 'function') opts.onStart(avant);
    });
    var sk = card.querySelector('[data-act="skip"]'); if (sk) sk.addEventListener('click', function () { close(); if (typeof opts.onSkip === 'function') opts.onSkip(); });
  }

  /* debrief(opts) : écran UNIQUE de fin d'exercice — même carte, même compagnon, même grammaire
     visuelle que rules() (symétrie début/fin voulue). Remplace toute modale ou écran de résultat
     maison : un seul endroit pour dire ce qui vient de se passer et proposer la suite.
     Pas de jauge ici : la mesure d'intensité ne vit que dans le bouton craving (scanner.js),
     jamais en début ni en fin de jeu — cf. protocole de travail.
     opts = {
       mood, title,              // avatar + nom de l'exercice, comme sur l'écran de règles
       lines:[...],              // débrief mascotte (MDDebriefs), phrases élaborées et sourcées
       why,                      // encart « Pour info » optionnel — c'est ici que vit l'anecdote
                                  // contextualisée à l'exercice (pas une anecdote générique à part)
       stats:[{label,value}],    // récap chiffré optionnel (score, justesse, etc.)
       note,                     // ligne d'insight ponctuelle optionnelle (ex. comparaison de conditions)
       nav:{ primary:{label,onClick}, secondary:{label,href,onClick} },
       onPick()                  // toujours appelé (log de séance), avant l'action du bouton choisi
     } */
  function debrief(opts) {
    opts = opts || {};
    inject();
    var mood = opts.mood || 'encouragement';
    var base = opts.base || 'avatars/';
    var ov = document.createElement('div'); ov.className = 'mdj-ov md-ov';
    var card = document.createElement('div'); card.className = 'mdj-card md-card'; card.style.setProperty('--c', accent(mood));
    var avHTML = '<div class="mdj-ava"><img src="' + base + mood + '.png" alt="" width="52" height="52"></div>';
    var statsHTML = '';
    if (opts.stats && opts.stats.length) {
      statsHTML = '<div class="mdj-stats">' + opts.stats.map(function (s) {
        return '<span class="mdj-stat"><b>' + esc(s.value) + '</b>' + esc(s.label) + '</span>';
      }).join('') + '</div>';
    }
    var nav = opts.nav || {};
    var primaryLabel = (nav.primary && nav.primary.label) || 'Continuer';
    var secondaryLabel = (nav.secondary && nav.secondary.label) || 'Retour au labo';
    card.innerHTML =
      '<div class="mdj-hero">' + avHTML + '<div class="mdj-bub"><p class="mdj-title">' + esc(opts.title || 'Séance terminée') + '</p></div></div>' +
      '<div class="mdj-lines">' + (opts.lines || []).map(function (l) { return '<p>' + esc(l) + '</p>'; }).join('') + '</div>' +
      statsHTML +
      (opts.note ? '<p class="mdj-note">' + esc(opts.note) + '</p>' : '') +
      (opts.why ? '<div class="mdj-why"><b>Pour info \u2014</b> ' + esc(opts.why) + '</div>' : '') +
      '<div class="mdj-nav">' +
      '<button class="mdj-go" type="button" data-act="primary">' + esc(primaryLabel) + '</button>' +
      '<button class="mdj-secondary" type="button" data-act="secondary">' + esc(secondaryLabel) + '</button>' +
      '</div>';
    ov.appendChild(card); document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Avant de commencer' });

    function close() { if (ov.parentNode) ov.parentNode.removeChild(ov); }
    function commit(proceed) {
      if (typeof opts.onPick === 'function') {
        if (opts.onPick.length > 0) { opts.onPick(proceed); } // nouveau contrat : onPick(done) attend une fête (trophée) avant de continuer
        else { opts.onPick(); proceed(); } // ancien contrat, inchangé (ex. identite.js)
      } else { proceed(); }
    }
    card.querySelector('[data-act="primary"]').addEventListener('click', function () {
      close();
      commit(function () {
        if (nav.primary && typeof nav.primary.onClick === 'function') nav.primary.onClick();
      });
    });
    card.querySelector('[data-act="secondary"]').addEventListener('click', function () {
      close();
      commit(function () {
        if (nav.secondary && typeof nav.secondary.onClick === 'function') nav.secondary.onClick();
        else location.href = (nav.secondary && nav.secondary.href) || 'fiches.html';
      });
    });
  }

  return { rules: rules, debrief: debrief };
})();
