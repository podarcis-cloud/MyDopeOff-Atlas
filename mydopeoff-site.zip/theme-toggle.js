/* theme-toggle.js — Câblage du bouton clair/sombre de l'accueil.
   Externalisé (au lieu d'un <script> inline) car la CSP stricte de la page
   (script-src 'self', sans 'unsafe-inline') bloque silencieusement tout
   script inline — un inline ici ne s'exécutait jamais. */
(function () {
  var btn = document.getElementById('theme-toggle');
  if (!btn || !window.MDCore) return;
  var sun = btn.querySelector('.th-sun'), moon = btn.querySelector('.th-moon');
  function effective() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }
  function sync() {
    var dark = effective() === 'dark';
    sun.style.display = dark ? 'none' : 'block';
    moon.style.display = dark ? 'block' : 'none';
    btn.setAttribute('aria-label', dark ? 'Passer au thème clair' : 'Passer au thème sombre');
  }
  btn.addEventListener('click', function () { MDCore.toggleTheme(); sync(); });
  document.addEventListener('themechange', sync);
  sync();
})();
