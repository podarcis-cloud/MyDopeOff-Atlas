/* MyDope Off — page-psychochecker.js
   Init/affichage de la page (i18n, branchement MDInteractions, MDCore.init). Doit charger
   APRÈS toutes les sources de substances (psychochecker-data.js, new-substances.js,
   custom-substances.js...) car ce code rend la liste complète. Contenu inchangé. */

(function(){
  try{
    var d=JSON.parse(localStorage.getItem('ctc_v6'));
    if(d&&d.user&&d.user.name){
      var p='';
      var bl=document.getElementById('back-link'); if(bl) bl.href='index.html'+p;
    }
  }catch(e){}
  if(window.MDCore){
    MDCore.applyI18n();
    document.addEventListener('langchange',function(){
      MDCore.applyI18n();
      try{ _renderAll(); _renderCanna(); }catch(e){}
    });
  }
})();

(function(){
  function apply(){
    if(window.MDCore){
      try{ MDCore.applyI18n(); }catch(e){}
      try{ _renderAll(); _renderCanna(); }catch(e){}
      return true;
    }
    return false;
  }
  // Re-rendu immédiat (les grilles ont été rendues plus haut AVANT le chargement de
  // core.js, donc avec des clés brutes ps.* et du contenu FR : on refait le rendu ici).
  if(!apply()){
    // Filet de sécurité si core.js charge en différé
    var tries=0, iv=setInterval(function(){ if(apply()||++tries>50) clearInterval(iv); },50);
  }
  document.addEventListener('langchange',function(){
    try{ MDCore.applyI18n(); }catch(e){}
    try{ _renderAll(); _renderCanna(); }catch(e){}
  });
})();

(function(){
    if(!window.MDInteractions) return;
    // Brancher le moteur sur les données de la page :
    window.MDInteractions.configure({
      resolveId: function(raw){
        var k = String(raw||'').trim().toLowerCase();
        return aliases.get(k) ? aliases.get(k).toLowerCase() : k;
      },
      getCategories: function(id){
        var hit = null;
        substances.forEach(function(v, nom){ if(nom.toLowerCase() === id) hit = v; });
        return hit ? hit.categories : [];
      }
    });
    // new-substances.js a ajouté poppers/solvants via addSub : rafraîchir la grille.
    try{ if(typeof _renderAll==='function'){ _renderAll(); } }catch(e){}
    try{ if(typeof _renderCanna==='function'){ _renderCanna(); } }catch(e){}
  })();

try{MDCore.init({page:'psychochecker',section:'securite'});}catch(e){}try{MDPageIntro.init('psychochecker');}catch(e){}
