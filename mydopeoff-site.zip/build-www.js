/* build-www.js — Copie le site statique dans www/, prêt pour Capacitor.
   Reprend les mêmes exclusions que l'export zip habituel : fichiers de dev,
   prototypes et sources du handbook ne sont jamais embarqués dans l'app. */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const DEST = path.join(ROOT, 'www');

const EXCLUDE_EXACT = new Set([
  'build_handbook.py', 'mockup-jauge-envie.html',
  'package.json', 'package-lock.json', 'capacitor.config.json', 'build-www.js',
  '.gitignore', 'node_modules', 'www', 'ios', 'android'
]);
const EXCLUDE_PREFIX = ['MyDopeOff_Handbook', 'planche_', 'batch_', 'shot_tetris', '.'];
const EXCLUDE_DIRS = new Set(['handbook_md', 'node_modules', 'www', 'ios', 'android', '.git']);

function shouldSkip(name) {
  if (EXCLUDE_EXACT.has(name)) return true;
  return EXCLUDE_PREFIX.some(function (p) { return name.startsWith(p); });
}

function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    const base = path.basename(src);
    if (EXCLUDE_DIRS.has(base)) return;
    fs.mkdirSync(dest, { recursive: true });
    fs.readdirSync(src).forEach(function (entry) {
      if (shouldSkip(entry)) return;
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
}

if (fs.existsSync(DEST)) fs.rmSync(DEST, { recursive: true, force: true });
fs.mkdirSync(DEST, { recursive: true });

fs.readdirSync(ROOT).forEach(function (entry) {
  if (shouldSkip(entry)) return;
  copyRecursive(path.join(ROOT, entry), path.join(DEST, entry));
});

console.log('www/ prêt — site copié pour Capacitor.');
