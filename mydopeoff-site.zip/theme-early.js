/* theme-early.js — Applique le thème sauvegardé avant le premier rendu, pour éviter
   un flash du mauvais thème. Externalisé (la CSP stricte de la page bloque tout
   script inline) ; chargé tôt dans <head>, avant les feuilles de style, pour
   conserver le même effet qu'un script inline synchrone. */
(function () {
  try {
    var v = localStorage.getItem('mydopeoff_theme');
    if (v === 'dark' || v === 'light') document.documentElement.setAttribute('data-theme', v);
  } catch (e) {}
})();
