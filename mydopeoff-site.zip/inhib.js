/* inhib.js — Contrôle inhibiteur (M4) : tâche Go/No-Go adaptative, 100 % local.
   Entraîne l'inhibition de réponse : taper sur « Go », bloquer sur « No-Go » (plus rare).
   Mesure : justesse, erreurs de commission, temps de réaction. Journalise une séance 'inhib'
   (meta) qui nourrit l'axe Contrôle inhibiteur de la carte. Stimuli abstraits (pas d'indice
   produit) — conforme au garde-fou éthique. Expose window.MDInhib. */
window.MDInhib = (function () {
  var INJ = false, ov = null;
  var TOTAL = 24, NOGO_RATE = 0.3;
  var st;  // état de session

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdi-ov{z-index:var(--z-modal-4,4300);flex-direction:column;' +
      'padding:22px;background:var(--bg,#F5F2EA);font-family:var(--font-technical,Inter,system-ui,sans-serif);text-align:center}' +
      '.mdi-card{position:relative;z-index:var(--z-base,1);flex:1;display:flex;flex-direction:column;width:100%;max-width:480px;margin:0 auto;min-height:0;color:var(--ink,#1F2B25)}' +
      '.mdi-q{font-family:var(--font-editorial,Newsreader,Georgia,serif);font-size:var(--fs-h3,22px);margin:0 0 6px}' +
      '.mdi-sub{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,14px);color:var(--ink-2,#58635E);margin:0 0 18px}' +
      '.mdi-legend{display:flex;gap:18px;justify-content:center;margin:0 0 18px;font-size:var(--fs-xs,13px)}' +
      '.mdi-legend b{font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mdi-zone{position:relative;flex:1;min-height:240px;width:100%;border-radius:20px;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);touch-action:none;' +
      'display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;overflow:hidden}' +
      '.mdi-zone.ok{box-shadow:inset 0 0 0 4px var(--sauge,#7A8F72)}.mdi-zone.bad{box-shadow:inset 0 0 0 4px var(--terra,#C7765C)}' +
      '.mdi-go{width:130px;height:130px;border-radius:50%;background:radial-gradient(circle at 38% 34%,#9db4a6,var(--sauge,#7A8F72) 70%);transition:background .08s,box-shadow .08s}' +
      '.mdi-go.stop{background:var(--terra,#C7765C);box-shadow:0 0 0 9px rgba(199,118,92,.28)}' +
      '.mdi-nogo{width:120px;height:120px;border-radius:18px;background:transparent;border:10px solid var(--terra,#C7765C)}' +
      '.mdi-hint{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,14px);color:var(--ink-2,#58635E);margin-top:14px;min-height:20px}' +
      '.mdi-prog{height:6px;border-radius:4px;background:var(--line,#E2DCD0);overflow:hidden;margin:14px 0 0}' +
      '.mdi-progf{display:block;height:100%;background:var(--foret,#33463E)}' +
      '.mdi-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer;margin-top:14px}';
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(s);
  }
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  var prevOverscroll = null, prevTouchAction = null;
  function lockScroll() {
    if (prevOverscroll != null) return; // déjà verrouillé
    prevOverscroll = document.documentElement.style.overscrollBehavior;
    prevTouchAction = document.documentElement.style.touchAction;
    document.documentElement.style.overscrollBehavior = 'none';
    document.documentElement.style.touchAction = 'manipulation';
  }
  function unlockScroll() {
    if (prevOverscroll == null) return;
    document.documentElement.style.overscrollBehavior = prevOverscroll;
    document.documentElement.style.touchAction = prevTouchAction;
    prevOverscroll = null; prevTouchAction = null;
  }
  function close() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; unlockScroll(); }
  function shell() { close(); inject(); lockScroll(); ov = E('div', 'mdi-ov md-ov'); var c = E('div', 'mdi-card'); ov.appendChild(c); document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Exercice' }); return c; }

  function open() {
    if (window.MDJeuHero) {
      MDJeuHero.rules({ mood:'concentration', title:'Contrôle du frein',
        lines:['Rond plein : TAPE vite.',
               'Carré : NE TAPE PAS — retiens ton geste.',
               '24 essais, rythme qui s\u2019accélère si tu réussis.'],
        why:'Agir vite ou se retenir sollicite le contrôle inhibiteur — la même ressource qui aide à ne pas suivre un automatisme de consommation.',
        onStart:function(avant){ window.__mdAvant=avant; run(); } });
    } else { run(); }
  }

  function run() {
    // séquence de trials : ~30 % No-Go, jamais 2 No-Go d'affilée
    var types = [];
    for (var i = 0; i < TOTAL; i++) {
      var nogo = Math.random() < NOGO_RATE && (i === 0 || types[i - 1] !== 'nogo');
      types.push(nogo ? 'nogo' : 'go');
    }
    st = { types: types, idx: 0, win: 850, hits: 0, omissions: 0, commissions: 0, correctInhib: 0, rts: [], nogo: types.filter(function (t) { return t === 'nogo'; }).length };
    var c = shell();
    var zone = E('div', 'mdi-zone'); c.appendChild(zone);
    var hint = E('div', 'mdi-hint', 'Prêt\u2026'); c.appendChild(hint);
    var prog = E('div', 'mdi-prog'); var pf = E('span', 'mdi-progf'); prog.appendChild(pf); c.appendChild(prog);
    var x = E('button', 'mdi-exit', 'Arrêter'); x.type = 'button'; x.onclick = close; c.appendChild(x);
    st.zone = zone; st.hint = hint; st.pf = pf;
    setTimeout(nextTrial, 700);
  }

  function clearZone() { st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; }
  function nextTrial() {
    if (!ov) return;                          // fermé entre-temps
    if (st.idx >= TOTAL) { finish(); return; }
    st.pf.style.width = Math.round(st.idx / TOTAL * 100) + '%';
    var isNoGo = st.types[st.idx] === 'nogo';
    clearZone(); st.hint.textContent = '';
    var responded = false, winTimer = null, t0 = 0;
    function settle(outcome, rt) {
      if (responded) return; responded = true;
      if (winTimer) clearTimeout(winTimer);
      st.zone.onclick = null;
      if (outcome === 'hit') { st.hits++; st.rts.push(rt); st.win = Math.max(450, st.win - 25); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'commission') { st.commissions++; st.win = Math.min(1000, st.win + 50); st.zone.className = 'mdi-zone bad'; st.hint.textContent = 'Stop ! C\u2019était un carré.'; }
      else if (outcome === 'omission') { st.omissions++; st.win = Math.min(1000, st.win + 50); st.hint.textContent = 'Trop lent.'; }
      else if (outcome === 'inhib') { st.correctInhib++; st.zone.className = 'mdi-zone ok'; }
      st.idx++;
      setTimeout(function () { clearZone(); st.hint.textContent = ''; setTimeout(nextTrial, 350); }, 280);
    }
    // ISI puis stimulus
    setTimeout(function () {
      if (!ov || responded) return;
      st.zone.innerHTML = ''; st.zone.appendChild(E('div', isNoGo ? 'mdi-nogo' : 'mdi-go'));
      t0 = performance.now();
      st.zone.onclick = function () { if (responded) return; settle(isNoGo ? 'commission' : 'hit', performance.now() - t0); };
      winTimer = setTimeout(function () { settle(isNoGo ? 'inhib' : 'omission'); }, st.win);
    }, 480);
  }

  function finish() {
    var totalRep = st.hits + st.omissions + st.commissions + st.correctInhib;
    var justesse = totalRep ? (st.hits + st.correctInhib) / TOTAL : 0;
    var commission = st.nogo ? st.commissions / st.nogo : 0;
    var rtMoyen = st.rts.length ? Math.round(st.rts.reduce(function (a, b) { return a + b; }, 0) / st.rts.length) : 600;
    var niveau = Math.max(1, Math.min(5, Math.round((1000 - st.win) / 110) + 1));
    if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    if (window.MDExercise) {
      MDExercise.after('inhib', { avant: window.__mdAvant, dureeSec: TOTAL * 2, meta: { tache:'gng', justesse: Math.round(justesse*100)/100, commission: Math.round(commission*100)/100, niveau: niveau },
        title:'Contrôle du frein', stats:[{label:'justesse',value:Math.round(justesse*100)+'%'},{label:'réaction',value:rtMoyen+' ms'},{label:'niveau',value:niveau}],
        nav:{ primary:{label:'Recommencer'} },
        onClose: function(){ window.__mdAvant = null; open(); } });
    } else {
      try { if (window.MDData) window.MDData.logSession('inhib', { dureeSec: TOTAL * 2, meta: { tache: 'gng', justesse: Math.round(justesse * 100) / 100, commission: Math.round(commission * 100) / 100, ssrt: rtMoyen, niveau: niveau } }); } catch (e) { }
    }
    close();
  }
  function stat(v, l) { var d = E('div', 'mdi-stat'); d.appendChild(E('div', 'mdi-statv', v)); d.appendChild(E('div', 'mdi-statl', l)); return d; }

  /* ---- Stop-Signal (SSRT) : agir vite, mais bloquer si le rond vire au rouge ---- */
  function openStop() {
    if (window.MDJeuHero) {
      MDJeuHero.rules({ mood:'concentration', title:'Stop-Signal',
        lines:['Tape vite sur le rond dès qu\u2019il appara\u00eet.',
               'Mais s\u2019il vire au rouge, retiens ton geste — ne tape pas.',
               '24 essais, mesure la vitesse de ton frein (SSRT).'],
        why:'Retenir un geste déjà lancé est un test plus exigeant que juste réagir : c\u2019est ce même frein qui aide à interrompre un automatisme de consommation en plein élan.',
        onStart:function(avant){ window.__mdAvant=avant; runStop(); } });
    } else { runStop(); }
  }
  function runStop() {
    var types = [];
    for (var i = 0; i < TOTAL; i++) { var stp = Math.random() < 0.3 && (i === 0 || types[i - 1] !== 'stop'); types.push(stp ? 'stop' : 'go'); }
    st = { types: types, idx: 0, ssd: 250, win: 1000, goRT: [], ssdUsed: [], stopOK: 0, stopFail: 0, goHit: 0, goMiss: 0, nstop: types.filter(function (t) { return t === 'stop'; }).length };
    var c = shell();
    var zone = E('div', 'mdi-zone'); c.appendChild(zone);
    var hint = E('div', 'mdi-hint', 'Prêt\u2026'); c.appendChild(hint);
    var prog = E('div', 'mdi-prog'); var pf = E('span', 'mdi-progf'); prog.appendChild(pf); c.appendChild(prog);
    var x = E('button', 'mdi-exit', 'Arrêter'); x.type = 'button'; x.onclick = close; c.appendChild(x);
    st.zone = zone; st.hint = hint; st.pf = pf;
    setTimeout(nextStop, 700);
  }
  function nextStop() {
    if (!ov) return;
    if (st.idx >= TOTAL) { finishStop(); return; }
    st.pf.style.width = Math.round(st.idx / TOTAL * 100) + '%';
    var isStop = st.types[st.idx] === 'stop';
    st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; st.hint.textContent = '';
    var responded = false, winTimer = null, stopTimer = null, t0 = 0, stopShown = false;
    function settle(outcome, rt) {
      if (responded) return; responded = true;
      if (winTimer) clearTimeout(winTimer); if (stopTimer) clearTimeout(stopTimer); st.zone.onclick = null;
      if (outcome === 'gohit') { st.goHit++; st.goRT.push(rt); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'gomiss') { st.goMiss++; st.hint.textContent = 'Trop lent.'; }
      else if (outcome === 'stopok') { st.stopOK++; st.ssdUsed.push(st.ssd); st.ssd = Math.min(600, st.ssd + 50); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'stopfail') { st.stopFail++; st.ssdUsed.push(st.ssd); st.ssd = Math.max(50, st.ssd - 50); st.zone.className = 'mdi-zone bad'; st.hint.textContent = 'Rouge ! Il fallait stopper.'; }
      st.idx++;
      setTimeout(function () { st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; st.hint.textContent = ''; setTimeout(nextStop, 340); }, 300);
    }
    setTimeout(function () {
      if (!ov || responded) return;
      var go = E('div', 'mdi-go'); st.zone.innerHTML = ''; st.zone.appendChild(go); t0 = performance.now();
      st.zone.onclick = function () { if (responded) return; settle(stopShown ? 'stopfail' : 'gohit', performance.now() - t0); };
      if (isStop) stopTimer = setTimeout(function () { stopShown = true; go.className = 'mdi-go stop'; }, st.ssd);
      winTimer = setTimeout(function () { if (responded) return; settle(isStop ? 'stopok' : 'gomiss'); }, st.win);
    }, 480);
  }
  function finishStop() {
    var goRTmean = st.goRT.length ? st.goRT.reduce(function (a, b) { return a + b; }, 0) / st.goRT.length : 500;
    var ssdMean = st.ssdUsed.length ? st.ssdUsed.reduce(function (a, b) { return a + b; }, 0) / st.ssdUsed.length : 250;
    var ssrt = Math.max(120, Math.min(500, Math.round(goRTmean - ssdMean)));
    var stopAcc = st.nstop ? st.stopOK / st.nstop : 0;
    var goAcc = (st.goHit + st.goMiss) ? st.goHit / (st.goHit + st.goMiss) : 0;
    var justesse = Math.round(((stopAcc + goAcc) / 2) * 100) / 100;
    var niveau = Math.max(1, Math.min(5, Math.round((500 - ssrt) / 76) + 1));
    if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    if (window.MDExercise) {
      MDExercise.after('inhib', { avant: window.__mdAvant, dureeSec: TOTAL * 2, meta: { tache:'sst', justesse: justesse, ssrt: ssrt, niveau: niveau },
        title:'Stop-Signal', stats:[{label:'vitesse du frein',value:ssrt+' ms'},{label:'arrêts réussis',value:Math.round(stopAcc*100)+'%'},{label:'niveau',value:niveau}],
        nav:{ primary:{label:'Recommencer'} },
        onClose: function(){ window.__mdAvant = null; openStop(); } });
    } else {
      try { if (window.MDData) window.MDData.logSession('inhib', { dureeSec: TOTAL * 2, meta: { tache: 'sst', justesse: justesse, ssrt: ssrt, niveau: niveau } }); } catch (e) { }
    }
    close();
  }

  return { open: open, openStop: openStop };
})();
