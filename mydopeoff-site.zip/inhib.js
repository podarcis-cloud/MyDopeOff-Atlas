/* inhib.js — Contrôle inhibiteur (M4) : tâche Go/No-Go adaptative, 100 % local.
   Entraîne l'inhibition de réponse : taper sur « Go », bloquer sur « No-Go » (plus rare).
   Mesure : justesse, erreurs de commission, temps de réaction. Journalise une séance 'inhib'
   (meta) qui nourrit l'axe Contrôle inhibiteur de la carte. Stimuli abstraits (pas d'indice
   produit) — conforme au garde-fou éthique. Expose window.MDInhib. */
window.MDInhib = (function () {
  var INJ = false, ov = null;
  var TOTAL = 24, NOGO_RATE = 0.3;
  var st;  // état de session

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdi-ov{position:fixed;inset:0;z-index:4300;display:flex;flex-direction:column;align-items:center;justify-content:center;' +
      'padding:22px;background:var(--bg,#F5F2EA);font-family:var(--ui,Inter,system-ui,sans-serif);text-align:center}' +
      '.mdi-card{max-width:380px;width:100%;color:var(--ink,#1F2B25)}' +
      '.mdi-q{font-family:var(--title,Newsreader,Georgia,serif);font-size:22px;margin:0 0 6px}' +
      '.mdi-sub{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14px;color:var(--ink-2,#58635E);margin:0 0 18px}' +
      '.mdi-legend{display:flex;gap:18px;justify-content:center;margin:0 0 18px;font-size:13px}' +
      '.mdi-legend b{font-family:var(--ui,Inter,sans-serif)}' +
      '.mdi-zone{position:relative;width:100%;height:300px;border-radius:20px;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);' +
      'display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;overflow:hidden}' +
      '.mdi-zone.ok{box-shadow:inset 0 0 0 4px var(--sauge,#7A8F72)}.mdi-zone.bad{box-shadow:inset 0 0 0 4px var(--terra,#C7765C)}' +
      '.mdi-go{width:130px;height:130px;border-radius:50%;background:radial-gradient(circle at 38% 34%,#9db4a6,var(--sauge,#7A8F72) 70%);transition:background .08s,box-shadow .08s}' +
      '.mdi-go.stop{background:var(--terra,#C7765C);box-shadow:0 0 0 9px rgba(199,118,92,.28)}' +
      '.mdi-nogo{width:120px;height:120px;border-radius:18px;background:transparent;border:10px solid var(--terra,#C7765C)}' +
      '.mdi-hint{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14px;color:var(--ink-2,#58635E);margin-top:14px;min-height:20px}' +
      '.mdi-prog{height:6px;border-radius:4px;background:var(--line,#E2DCD0);overflow:hidden;margin:14px 0 0}' +
      '.mdi-progf{display:block;height:100%;background:var(--foret,#33463E)}' +
      '.mdi-btn{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:700;font-size:15px;padding:14px;cursor:pointer;margin-top:8px}' +
      '.mdi-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:13px;text-decoration:underline;cursor:pointer;margin-top:14px}' +
      '.mdi-res{display:flex;gap:12px;justify-content:center;margin:6px 0 14px}' +
      '.mdi-stat{background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:12px 14px;min-width:92px}' +
      '.mdi-statv{font-family:var(--title,Newsreader,serif);font-size:26px;color:var(--foret,#33463E)}' +
      '.mdi-statl{font-size:11px;color:var(--ink-2,#58635E)}';
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(s);
  }
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function close() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function shell() { close(); inject(); ov = E('div', 'mdi-ov'); var c = E('div', 'mdi-card'); ov.appendChild(c); document.body.appendChild(ov); return c; }

  function open() {
    var c = shell();
    c.appendChild(E('p', 'mdi-q', 'Contrôle du frein'));
    c.appendChild(E('p', 'mdi-sub', 'Entraîne ton inhibition : agis vite quand il faut, retiens-toi quand il faut.'));
    var lg = E('div', 'mdi-legend');
    var g = document.createElement('div'); g.innerHTML = '<span style="display:inline-block;width:22px;height:22px;border-radius:50%;background:#7A8F72;vertical-align:middle"></span> <b>Rond plein</b> : TAPE vite';
    var n = document.createElement('div'); n.innerHTML = '<span style="display:inline-block;width:20px;height:20px;border-radius:5px;border:4px solid #C7765C;vertical-align:middle"></span> <b>Carré</b> : NE TAPE PAS';
    lg.appendChild(g); lg.appendChild(n); c.appendChild(lg);
    var b = E('button', 'mdi-btn', 'Commencer'); b.type = 'button'; b.onclick = run; c.appendChild(b);
    var x = E('button', 'mdi-exit', 'Plus tard'); x.type = 'button'; x.onclick = close; c.appendChild(x);
  }

  function run() {
    // séquence de trials : ~30 % No-Go, jamais 2 No-Go d'affilée
    var types = [];
    for (var i = 0; i < TOTAL; i++) {
      var nogo = Math.random() < NOGO_RATE && (i === 0 || types[i - 1] !== 'nogo');
      types.push(nogo ? 'nogo' : 'go');
    }
    st = { types: types, idx: 0, win: 850, hits: 0, omissions: 0, commissions: 0, correctInhib: 0, rts: [], nogo: types.filter(function (t) { return t === 'nogo'; }).length };
    var c = shell();
    var zone = E('div', 'mdi-zone'); c.appendChild(zone);
    var hint = E('div', 'mdi-hint', 'Prêt\u2026'); c.appendChild(hint);
    var prog = E('div', 'mdi-prog'); var pf = E('span', 'mdi-progf'); prog.appendChild(pf); c.appendChild(prog);
    var x = E('button', 'mdi-exit', 'Arrêter'); x.type = 'button'; x.onclick = close; c.appendChild(x);
    st.zone = zone; st.hint = hint; st.pf = pf;
    setTimeout(nextTrial, 700);
  }

  function clearZone() { st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; }
  function nextTrial() {
    if (!ov) return;                          // fermé entre-temps
    if (st.idx >= TOTAL) { finish(); return; }
    st.pf.style.width = Math.round(st.idx / TOTAL * 100) + '%';
    var isNoGo = st.types[st.idx] === 'nogo';
    clearZone(); st.hint.textContent = '';
    var responded = false, winTimer = null, t0 = 0;
    function settle(outcome, rt) {
      if (responded) return; responded = true;
      if (winTimer) clearTimeout(winTimer);
      st.zone.onclick = null;
      if (outcome === 'hit') { st.hits++; st.rts.push(rt); st.win = Math.max(450, st.win - 25); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'commission') { st.commissions++; st.win = Math.min(1000, st.win + 50); st.zone.className = 'mdi-zone bad'; st.hint.textContent = 'Stop ! C\u2019était un carré.'; }
      else if (outcome === 'omission') { st.omissions++; st.win = Math.min(1000, st.win + 50); st.hint.textContent = 'Trop lent.'; }
      else if (outcome === 'inhib') { st.correctInhib++; st.zone.className = 'mdi-zone ok'; }
      st.idx++;
      setTimeout(function () { clearZone(); st.hint.textContent = ''; setTimeout(nextTrial, 350); }, 280);
    }
    // ISI puis stimulus
    setTimeout(function () {
      if (!ov || responded) return;
      st.zone.innerHTML = ''; st.zone.appendChild(E('div', isNoGo ? 'mdi-nogo' : 'mdi-go'));
      t0 = performance.now();
      st.zone.onclick = function () { if (responded) return; settle(isNoGo ? 'commission' : 'hit', performance.now() - t0); };
      winTimer = setTimeout(function () { settle(isNoGo ? 'inhib' : 'omission'); }, st.win);
    }, 480);
  }

  function finish() {
    var totalRep = st.hits + st.omissions + st.commissions + st.correctInhib;
    var justesse = totalRep ? (st.hits + st.correctInhib) / TOTAL : 0;
    var commission = st.nogo ? st.commissions / st.nogo : 0;
    var rtMoyen = st.rts.length ? Math.round(st.rts.reduce(function (a, b) { return a + b; }, 0) / st.rts.length) : 600;
    var niveau = Math.max(1, Math.min(5, Math.round((1000 - st.win) / 110) + 1));
    try { if (window.MDData) window.MDData.logSession('inhib', { dureeSec: TOTAL * 2, meta: { tache: 'gng', justesse: Math.round(justesse * 100) / 100, commission: Math.round(commission * 100) / 100, ssrt: rtMoyen, niveau: niveau } }); } catch (e) { }
    if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    var c = shell();
    c.appendChild(E('p', 'mdi-q', 'Frein entraîné'));
    var res = E('div', 'mdi-res');
    res.appendChild(stat(Math.round(justesse * 100) + '%', 'Justesse'));
    res.appendChild(stat(rtMoyen + ' ms', 'Réaction'));
    res.appendChild(stat('niv. ' + niveau, 'Niveau'));
    c.appendChild(res);
    c.appendChild(E('p', 'mdi-sub', commission <= 0.2
      ? 'Beau contrôle : tu t\u2019es retenu·e quand il fallait.'
      : 'L\u2019inhibition se muscle avec la répétition. Recommence quand tu veux.'));
    var again = E('button', 'mdi-btn', 'Recommencer'); again.type = 'button'; again.onclick = open; c.appendChild(again);
    var x = E('button', 'mdi-exit', 'Terminer'); x.type = 'button'; x.onclick = close; c.appendChild(x);
  }
  function stat(v, l) { var d = E('div', 'mdi-stat'); d.appendChild(E('div', 'mdi-statv', v)); d.appendChild(E('div', 'mdi-statl', l)); return d; }

  /* ---- Stop-Signal (SSRT) : agir vite, mais bloquer si le rond vire au rouge ---- */
  function openStop() {
    var c = shell();
    c.appendChild(E('p', 'mdi-q', 'Stop-Signal'));
    c.appendChild(E('p', 'mdi-sub', 'Tape vite sur le rond. Mais s\u2019il vire au rouge, retiens ton geste.'));
    var b = E('button', 'mdi-btn', 'Commencer'); b.type = 'button'; b.onclick = runStop; c.appendChild(b);
    var x = E('button', 'mdi-exit', 'Plus tard'); x.type = 'button'; x.onclick = close; c.appendChild(x);
  }
  function runStop() {
    var types = [];
    for (var i = 0; i < TOTAL; i++) { var stp = Math.random() < 0.3 && (i === 0 || types[i - 1] !== 'stop'); types.push(stp ? 'stop' : 'go'); }
    st = { types: types, idx: 0, ssd: 250, win: 1000, goRT: [], ssdUsed: [], stopOK: 0, stopFail: 0, goHit: 0, goMiss: 0, nstop: types.filter(function (t) { return t === 'stop'; }).length };
    var c = shell();
    var zone = E('div', 'mdi-zone'); c.appendChild(zone);
    var hint = E('div', 'mdi-hint', 'Prêt\u2026'); c.appendChild(hint);
    var prog = E('div', 'mdi-prog'); var pf = E('span', 'mdi-progf'); prog.appendChild(pf); c.appendChild(prog);
    var x = E('button', 'mdi-exit', 'Arrêter'); x.type = 'button'; x.onclick = close; c.appendChild(x);
    st.zone = zone; st.hint = hint; st.pf = pf;
    setTimeout(nextStop, 700);
  }
  function nextStop() {
    if (!ov) return;
    if (st.idx >= TOTAL) { finishStop(); return; }
    st.pf.style.width = Math.round(st.idx / TOTAL * 100) + '%';
    var isStop = st.types[st.idx] === 'stop';
    st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; st.hint.textContent = '';
    var responded = false, winTimer = null, stopTimer = null, t0 = 0, stopShown = false;
    function settle(outcome, rt) {
      if (responded) return; responded = true;
      if (winTimer) clearTimeout(winTimer); if (stopTimer) clearTimeout(stopTimer); st.zone.onclick = null;
      if (outcome === 'gohit') { st.goHit++; st.goRT.push(rt); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'gomiss') { st.goMiss++; st.hint.textContent = 'Trop lent.'; }
      else if (outcome === 'stopok') { st.stopOK++; st.ssdUsed.push(st.ssd); st.ssd = Math.min(600, st.ssd + 50); st.zone.className = 'mdi-zone ok'; }
      else if (outcome === 'stopfail') { st.stopFail++; st.ssdUsed.push(st.ssd); st.ssd = Math.max(50, st.ssd - 50); st.zone.className = 'mdi-zone bad'; st.hint.textContent = 'Rouge ! Il fallait stopper.'; }
      st.idx++;
      setTimeout(function () { st.zone.className = 'mdi-zone'; st.zone.innerHTML = ''; st.hint.textContent = ''; setTimeout(nextStop, 340); }, 300);
    }
    setTimeout(function () {
      if (!ov || responded) return;
      var go = E('div', 'mdi-go'); st.zone.innerHTML = ''; st.zone.appendChild(go); t0 = performance.now();
      st.zone.onclick = function () { if (responded) return; settle(stopShown ? 'stopfail' : 'gohit', performance.now() - t0); };
      if (isStop) stopTimer = setTimeout(function () { stopShown = true; go.className = 'mdi-go stop'; }, st.ssd);
      winTimer = setTimeout(function () { if (responded) return; settle(isStop ? 'stopok' : 'gomiss'); }, st.win);
    }, 480);
  }
  function finishStop() {
    var goRTmean = st.goRT.length ? st.goRT.reduce(function (a, b) { return a + b; }, 0) / st.goRT.length : 500;
    var ssdMean = st.ssdUsed.length ? st.ssdUsed.reduce(function (a, b) { return a + b; }, 0) / st.ssdUsed.length : 250;
    var ssrt = Math.max(120, Math.min(500, Math.round(goRTmean - ssdMean)));
    var stopAcc = st.nstop ? st.stopOK / st.nstop : 0;
    var goAcc = (st.goHit + st.goMiss) ? st.goHit / (st.goHit + st.goMiss) : 0;
    var justesse = Math.round(((stopAcc + goAcc) / 2) * 100) / 100;
    var niveau = Math.max(1, Math.min(5, Math.round((500 - ssrt) / 76) + 1));
    try { if (window.MDData) window.MDData.logSession('inhib', { dureeSec: TOTAL * 2, meta: { tache: 'sst', justesse: justesse, ssrt: ssrt, niveau: niveau } }); } catch (e) { }
    if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    var c = shell();
    c.appendChild(E('p', 'mdi-q', 'Frein mesuré'));
    var res = E('div', 'mdi-res');
    res.appendChild(stat(ssrt + ' ms', 'Vitesse du frein'));
    res.appendChild(stat(Math.round(stopAcc * 100) + '%', 'Arrêts réussis'));
    res.appendChild(stat('niv. ' + niveau, 'Niveau'));
    c.appendChild(res);
    c.appendChild(E('p', 'mdi-sub', 'Plus le « frein » est rapide (ms bas), plus tu inhibes vite une impulsion. Ça se muscle.'));
    var again = E('button', 'mdi-btn', 'Recommencer'); again.type = 'button'; again.onclick = openStop; c.appendChild(again);
    var x = E('button', 'mdi-exit', 'Terminer'); x.type = 'button'; x.onclick = close; c.appendChild(x);
  }

  return { open: open, openStop: openStop };
})();
