/* MyDope Off — page-lettre.js
   Init + logique de lettre, extraits des scripts inline de lettre.html pour permettre
   une CSP stricte (script-src 'self'). Contenu inchangé, ordre préservé. */

try{MDCore.init({page:'lettre',section:'equilibre'});}catch(e){}

/* ---- logique de la page ---- */

(function(){
  "use strict";
  var $=function(id){return document.getElementById(id);};
  function show(id){ var els=document.querySelectorAll('.scr'); for(var i=0;i<els.length;i++) els[i].classList.toggle('on', els[i].id===id); window.scrollTo(0,0); }

  /* ---------- IndexedDB (médias volumineux) ---------- */
  var DBP=null;
  function db(){ if(DBP) return DBP; DBP=new Promise(function(res,rej){
    var r=indexedDB.open('mdletters',1);
    r.onupgradeneeded=function(){ var d=r.result; if(!d.objectStoreNames.contains('letters')) d.createObjectStore('letters',{keyPath:'id'}); };
    r.onsuccess=function(){ res(r.result); }; r.onerror=function(){ rej(r.error); };
  }); return DBP; }
  function dbPut(rec){ return db().then(function(d){ return new Promise(function(res,rej){ var tx=d.transaction('letters','readwrite'); tx.objectStore('letters').put(rec); tx.oncomplete=function(){res();}; tx.onerror=function(){rej(tx.error);}; }); }); }
  function dbAll(){ return db().then(function(d){ return new Promise(function(res){ try{ var rq=d.transaction('letters','readonly').objectStore('letters').getAll(); rq.onsuccess=function(){ res((rq.result||[]).sort(function(a,b){return b.date-a.date;})); }; rq.onerror=function(){res([]);}; }catch(e){res([]);} }); }); }
  function dbDel(id){ return db().then(function(d){ return new Promise(function(res){ var tx=d.transaction('letters','readwrite'); tx.objectStore('letters').delete(id); tx.oncomplete=function(){res();}; tx.onerror=function(){res();}; }); }); }

  function logSession(rec){
    try{
      // séance normalisée via MDData ; métadonnée lettre conservée pour « Mes lettres »
      if(window.MDData){ MDData.logSession('lettre',{date:rec.date, meta:{letterId:rec.id, kind:rec.kind, preview:rec.preview}}); }
      var k='ctc_v6', o=JSON.parse(localStorage.getItem(k)||'{}');
      o.sessions=Array.isArray(o.sessions)?o.sessions:[];
      if(!window.MDData) o.sessions.push(rec); // fallback si MDData absent
      o.letters=Array.isArray(o.letters)?o.letters:[]; o.letters.push({id:rec.id,date:rec.date,type:rec.kind,preview:(rec.preview||'').slice(0,80)});
      localStorage.setItem(k,JSON.stringify(o));
      return o.sessions.filter(function(x){return x.type==='lettre';}).length;
    }catch(e){ return 1; }
  }

  /* ---------- état ---------- */
  var stream=null, recorder=null, chunks=[], blob=null, mode='video', recId=null, editRec=null, audioRAF=null, audioCtx=null, analyser=null, adata=null;

  /* ---------- intro : liste des lettres ---------- */
  function fmtDate(ts){ try{ return new Date(ts).toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'}); }catch(e){ return ''; } }
  function loadPast(){
    dbAll().then(function(list){
      var wrap=$('past-wrap'), box=$('past-list');
      if(!list.length){ wrap.style.display='none'; return; }
      wrap.style.display='block'; box.innerHTML='';
      list.forEach(function(rec){
        var row=document.createElement('div'); row.className='letter-row';
        var ic = rec.kind==='video'?'🎥':(rec.kind==='audio'?'🎙️':'✎');
        row.innerHTML='<div class="letter-ic">'+ic+'</div><div style="flex:1;min-width:0"><div style="font-weight:var(--w-bold);font-family:var(--font-technical);font-size:var(--fs-sm);color:var(--ink)">'+fmtDate(rec.date)+'</div><div class="muted" style="font-size:var(--fs-xs);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+(rec.preview||'Lettre').replace(/</g,'&lt;')+'</div></div>';
        var play=document.createElement('button'); play.className='btn btn-outline'; play.style.cssText='padding:8px 12px;font-size:var(--fs-xs)'; play.textContent='Ouvrir';
        play.onclick=function(){ openLetter(rec); };
        var del=document.createElement('button'); del.className='btn btn-ghost'; del.style.cssText='padding:8px 10px;font-size:var(--fs-xs);color:var(--danger)'; del.textContent='✕';
        del.onclick=function(){ if(confirm('Supprimer cette lettre ?')){ dbDel(rec.id).then(function(){ removeMeta(rec.id); loadPast(); }); } };
        row.appendChild(play); row.appendChild(del); box.appendChild(row);
      });
    });
  }
  function removeMeta(id){ try{ var k='ctc_v6', o=JSON.parse(localStorage.getItem(k)||'{}'); if(Array.isArray(o.letters)){ o.letters=o.letters.filter(function(x){return x.id!==id;}); localStorage.setItem(k,JSON.stringify(o)); } }catch(e){} }
  /* met à jour la métadonnée d'une lettre éditée (sans créer de nouvelle séance) */
  function updateMeta(id,txt){ try{ var k='ctc_v6', o=JSON.parse(localStorage.getItem(k)||'{}'); if(Array.isArray(o.letters)){ o.letters.forEach(function(x){ if(x.id===id){ x.preview=(txt||'').slice(0,80); x.date=Date.now(); } }); localStorage.setItem(k,JSON.stringify(o)); } }catch(e){} }
  function letterCount(){ try{ var o=JSON.parse(localStorage.getItem('ctc_v6')||'{}'); return (o.sessions||[]).filter(function(x){return x.type==='lettre';}).length||1; }catch(e){ return 1; } }
  /* média : reconstruit une URL depuis le nouveau format (data ArrayBuffer + mime) ou l'ancien (blob) */
  function recURL(rec){ if(rec.data){ try{ return URL.createObjectURL(new Blob([rec.data],{type:rec.mime||'application/octet-stream'})); }catch(e){} } if(rec.blob){ try{ return URL.createObjectURL(rec.blob); }catch(e){} } return null; }
  /* Blob -> ArrayBuffer (stockage IndexedDB fiable sur iOS, contrairement aux Blob média) */
  function blobToBuffer(b){ if(b.arrayBuffer) return b.arrayBuffer(); return new Promise(function(res,rej){ var fr=new FileReader(); fr.onload=function(){res(fr.result);}; fr.onerror=function(){rej(fr.error);}; fr.readAsArrayBuffer(b); }); }
  /* entrer en édition d'une lettre existante */
  function enterEditText(rec){ recId=rec.id; editRec=rec; mode=(rec.kind==='audio')?'audio':'video'; blob=null; $('lt-text').value=rec.text||''; resetReviewButtons(); show('scr-write'); $('lt-text').focus(); }
  function enterEditRecord(rec){ recId=rec.id; editRec=rec; mode=(rec.kind==='audio')?'audio':'video'; blob=null; $('lt-text').value=rec.text||''; $('tele').textContent=rec.text||''; resetReviewButtons(); show('scr-rec'); setMode(mode); initCam(); }
  function openLetter(rec){
    show('scr-review');
    var v=$('pv-video'), a=$('pv-audio'); v.style.display='none'; a.style.display='none';
    var url=recURL(rec);
    if(url && rec.kind==='video'){ v.src=url; v.style.display='block'; }
    else if(url && rec.kind==='audio'){ a.src=url; a.style.display='block'; }
    var card=$('pv-video').parentNode;
    var old=card.querySelector('.lt-readback'); if(old) old.remove();
    if(rec.text){ var p=document.createElement('p'); p.className='lt-readback'; p.style.cssText='font-family:var(--font-human);font-size:var(--fs-ui);line-height:1.6;color:var(--ink);white-space:pre-wrap;text-align:left;margin:12px 0 0'; p.textContent=rec.text; card.appendChild(p); }
    /* actions d'édition */
    var oldAct=card.querySelector('.lt-edit-actions'); if(oldAct) oldAct.remove();
    var act=document.createElement('div'); act.className='lt-edit-actions'; act.style.cssText='display:flex;gap:10px;flex-wrap:wrap;margin-top:14px';
    var eTxt=document.createElement('button'); eTxt.className='btn btn-outline'; eTxt.style.cssText='flex:1;min-width:130px'; eTxt.textContent='✎ Modifier le texte';
    eTxt.onclick=function(){ act.remove(); enterEditText(rec); };
    var eRec=document.createElement('button'); eRec.className='btn btn-outline'; eRec.style.cssText='flex:1;min-width:130px'; eRec.textContent=(rec.kind==='audio'?'🎙️ Réenregistrer':'🎥 Réenregistrer');
    eRec.onclick=function(){ act.remove(); enterEditRecord(rec); };
    act.appendChild(eTxt); act.appendChild(eRec); card.appendChild(act);
    $('rv-save').style.display='none'; $('rv-redo').textContent='Fermer'; $('rv-redo').onclick=function(){ resetReviewButtons(); show('scr-intro'); loadPast(); };
  }
  function resetReviewButtons(){ $('rv-save').style.display=''; $('rv-redo').textContent='Refaire'; $('rv-redo').onclick=goRedo; var rb=document.querySelector('.lt-readback'); if(rb) rb.remove(); var ea=document.querySelector('.lt-edit-actions'); if(ea) ea.remove(); }

  /* ---------- écriture ---------- */
  try{
    var lt_vals = window.MDData ? MDData.getValeurs() : [];
    if (lt_vals.length){
      var lt_v = lt_vals[Math.floor(Math.random()*lt_vals.length)];
      var lt_host = document.querySelector('#scr-write div');
      if (lt_host){
        var lt_chip = document.createElement('button');
        lt_chip.className='prompt-chip'; lt_chip.type='button';
        lt_chip.setAttribute('data-p', '\u00ab '+lt_v+' \u00bb compte pour moi parce que ');
        lt_chip.textContent = '\u00ab '+lt_v+' \u00bb\u2026';
        lt_host.appendChild(lt_chip);
      }
    }
  }catch(e){}
  $('btn-write').onclick=function(){ recId=null; editRec=null; blob=null; $('lt-text').value=''; show('scr-write'); $('lt-text').focus(); };
  Array.prototype.forEach.call(document.querySelectorAll('.prompt-chip'),function(b){
    b.onclick=function(){ var t=$('lt-text'); var ins=b.getAttribute('data-p'); var v=t.value; t.value=v+(v && !/\n$/.test(v)?'\n':'')+ins; t.focus(); };
  });
  $('w-back').onclick=function(){ recId=null; editRec=null; show('scr-intro'); };
  $('w-saveonly').onclick=function(){ var txt=$('lt-text').value.trim(); if(!txt){ $('lt-text').focus(); return; }
    if(recId && editRec){ /* édition d'une lettre existante : garder le média, mettre à jour le texte */
      var rec=Object.assign({},editRec,{text:txt,preview:txt,date:Date.now()});
      dbPut(rec).then(function(){ updateMeta(recId,txt); var n=letterCount(); recId=null; editRec=null; finishDone(n); });
      return;
    }
    var id='l'+Date.now(); dbPut({id:id,date:Date.now(),kind:'text',text:txt,preview:txt}).then(function(){ var n=logSession({type:'lettre',date:Date.now(),id:id,kind:'text',preview:txt}); finishDone(n); }); };
  $('w-next').onclick=function(){ var txt=$('lt-text').value.trim(); if(!txt){ $('lt-text').focus(); $('lt-text').placeholder='Écris au moins quelques mots avant de continuer…'; return; }
    $('tele').textContent=txt; show('scr-rec'); setMode(mode); initCam(); };

  /* ---------- enregistrement ---------- */
  Array.prototype.forEach.call(document.querySelectorAll('#mode-seg button'),function(b){
    b.onclick=function(){ Array.prototype.forEach.call(document.querySelectorAll('#mode-seg button'),function(x){x.classList.toggle('on',x===b);}); setMode(b.getAttribute('data-mode')); initCam(); };
  });
  function setMode(m){ mode=m; $('cam-wrap').style.display=(m==='video')?'flex':'none'; $('audio-wrap').style.display=(m==='audio')?'flex':'none'; }
  function stopStream(){ if(stream){ stream.getTracks().forEach(function(t){t.stop();}); stream=null; } if(audioRAF) cancelAnimationFrame(audioRAF); if(audioCtx){ try{audioCtx.close();}catch(e){} audioCtx=null; } }
  function initCam(){
    stopStream();
    var constraints = mode==='video' ? {video:{facingMode:'user'},audio:true} : {audio:true};
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){ $('rec-status').innerHTML='Capture indisponible sur ce navigateur. <b>Garde le texte seul</b> en revenant en arrière.'; return; }
    navigator.mediaDevices.getUserMedia(constraints).then(function(s){
      stream=s; $('rec-status').textContent='Prêt·e ? Lance l\u2019enregistrement et lis ta lettre.';
      if(mode==='video'){ var v=$('cam'); v.srcObject=s; }
      else { setupAudioMeter(s); }
    }).catch(function(){ $('rec-status').innerHTML=(mode==='video'?'Caméra':'Micro')+' refusé·e ou indisponible. Essaie l\u2019autre mode, ou garde le texte seul.'; });
  }
  function setupAudioMeter(s){
    try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); var src=audioCtx.createMediaStreamSource(s); analyser=audioCtx.createAnalyser(); analyser.fftSize=64; adata=new Uint8Array(analyser.frequencyBinCount); src.connect(analyser);
      var bars=document.querySelectorAll('#audio-wrap .bar');
      (function loop(){ analyser.getByteFrequencyData(adata); for(var i=0;i<bars.length;i++){ var v=adata[i*2]||0; bars[i].style.height=(8+v/255*70)+'px'; } audioRAF=requestAnimationFrame(loop); })();
    }catch(e){}
  }
  // téléprompteur : défilement doux pendant l'enregistrement
  var teleRAF=null;
  function startTele(){ var el=$('tele'); el.scrollTop=0; var t0=performance.now();
    (function step(){ var sec=(performance.now()-t0)/1000; if(sec>2){ el.scrollTop = (sec-2)*14; } teleRAF=requestAnimationFrame(step); })(); }
  function stopTele(){ if(teleRAF) cancelAnimationFrame(teleRAF); }

  function startRec(){
    if(!stream){ initCam(); return; }
    var cb=$('countbig'), n=3; if(mode==='video'){ cb.style.display='flex'; cb.textContent=n; }
    var iv=setInterval(function(){ n--; if(n<=0){ clearInterval(iv); cb.style.display='none'; actuallyRecord(); } else cb.textContent=n; }, 800);
  }
  function actuallyRecord(){
    chunks=[]; var opts={};
    try{ recorder=new MediaRecorder(stream); }catch(e){ try{ recorder=new MediaRecorder(stream,{mimeType:'video/webm'}); }catch(e2){ $('rec-status').textContent='Enregistrement non supporté ici.'; return; } }
    recorder.ondataavailable=function(ev){ if(ev.data && ev.data.size) chunks.push(ev.data); };
    recorder.onstop=function(){ var mt=(recorder&&recorder.mimeType)||(chunks[0]&&chunks[0].type)||(mode==='video'?'video/mp4':'audio/mp4'); blob=new Blob(chunks,{type:mt}); stopTele(); toReview(); };
    recorder.start(); startTele();
    $('r-rec').innerHTML='<span class="rec-dot"></span>Arrêter'; $('r-rec').classList.add('btn-danger');
    $('rec-status').textContent='Enregistrement… lis ta lettre à voix haute.';
    recState=true;
  }
  var recState=false;
  $('r-rec').onclick=function(){ if(!recState){ startRec(); } else { recState=false; if(recorder && recorder.state!=='inactive') recorder.stop(); $('r-rec').innerHTML='● Enregistrer'; $('r-rec').classList.remove('btn-danger'); } };
  $('r-back').onclick=function(){ stopStream(); stopTele(); show('scr-write'); };

  function toReview(){
    show('scr-review'); resetReviewButtons();
    var v=$('pv-video'), a=$('pv-audio'); v.style.display='none'; a.style.display='none';
    var url=URL.createObjectURL(blob);
    if(mode==='video'){ v.src=url; v.style.display='block'; } else { a.src=url; a.style.display='block'; }
  }
  function goRedo(){ blob=null; show('scr-rec'); initCam(); }
  $('rv-redo').onclick=goRedo;
  $('rv-save').onclick=function(){
    if(!blob){ return; }
    var id=recId||('l'+Date.now()), txt=$('lt-text').value.trim();
    var btn=$('rv-save'); btn.disabled=true;
    blobToBuffer(blob).then(function(buf){
      return dbPut({id:id,date:Date.now(),kind:mode,text:txt,preview:txt,data:buf,mime:blob.type});
    }).then(function(){
      if(recId){ updateMeta(id,txt); } else { logSession({type:'lettre',date:Date.now(),id:id,kind:mode,preview:txt}); }
      var n=letterCount(); recId=null; editRec=null; btn.disabled=false; stopStream(); finishDone(n);
    }).catch(function(){ btn.disabled=false; alert('Impossible d\u2019enregistrer (espace de stockage ?).'); });
  };

  function finishDone(n){ $('done-total').textContent = n>1 ? ('✦ '+n+' lettres dans ton parcours') : 'Première lettre gardée'; show('scr-done'); }
  $('d-again').onclick=function(){ recId=null; editRec=null; $('lt-text').value=''; blob=null; show('scr-write'); };

  /* nettoyage en quittant */
  window.addEventListener('pagehide', stopStream);
  document.addEventListener('visibilitychange', function(){ if(document.hidden) stopStream(); });

  loadPast();
})();
