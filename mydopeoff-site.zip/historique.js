/* historique.js — Mémoire long terme du suivi.
   Ouvre un calendrier MENSUEL navigable (mois précédents inclus) + une vue de
   tendance sur les 6 derniers mois, à partir de ctc_v6 (entries + sessions).
   Le compagnon commente la tendance (si MDCompagnon présent).
   Autonome, 100 % local. Respecte prefers-reduced-motion (pas d'anim lourde).
   API : MDHistorique.open()  — ouvre l'overlay. */
window.MDHistorique = (function () {
  'use strict';

  var KEY = 'ctc_v6';
  function store() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function entries() { var s = store(); return Array.isArray(s.entries) ? s.entries : []; }
  function sessions() { var s = store(); return Array.isArray(s.sessions) ? s.sessions : []; }

  var MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  var DOW = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function iso(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }

  // couleur d'un jour selon le niveau de conso max (0 = sans conso, 1-2 = léger, 3 = notable)
  function levelColor(lv) {
    if (lv === 0) return { bg: 'var(--sauge,#7A8F72)', fg: '#fff' };      // sans conso
    if (lv <= 2) return { bg: 'var(--ocre,#D5A84A)', fg: '#3a2e12' };     // léger
    return { bg: 'var(--terra,#C7765C)', fg: '#fff' };                    // notable
  }

  function entriesByDate(dateStr) { return entries().filter(function (e) { return e.date === dateStr; }); }
  function sessionsOn(y, m, d) {
    var start = new Date(y, m, d, 0, 0, 0).getTime(), end = start + 86400000;
    return sessions().filter(function (s) { return (s.date || 0) >= start && (s.date || 0) < end; });
  }

  var INJ = false;
  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdh-ov{z-index:var(--z-modal-4,4300);align-items:center;justify-content:center;padding:16px;' +
      'background:rgba(31,43,37,.5);font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mdh-card{position:relative;z-index:var(--z-base,1);border-radius:20px;' +
      'max-width:420px;width:100%;padding:18px 18px 16px;box-shadow:0 20px 55px rgba(31,43,37,.28);max-height:94vh;overflow:auto}' +
      '.mdh-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}' +
      '.mdh-title{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,20px)}' +
      '.mdh-x{border:none;background:none;font-size:var(--fs-h3,20px);color:var(--ink-2,#58635E);cursor:pointer;padding:2px 4px}' +
      '.mdh-nav{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}' +
      '.mdh-nav b{font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-ui,15px)}' +
      '.mdh-arr{border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);border-radius:10px;width:38px;height:34px;' +
      'font-size:var(--fs-lead,17px);color:var(--ink,#1F2B25);cursor:pointer}' +
      '.mdh-arr:disabled{opacity:.35;cursor:default}' +
      '.mdh-dow{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:4px}' +
      '.mdh-dow span{text-align:center;font-size:var(--fs-caps,10px);color:var(--ink-2,#58635E);font-weight:var(--w-bold,700)}' +
      '.mdh-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}' +
      '.mdh-cell{position:relative;aspect-ratio:1;border-radius:9px;border:1px solid var(--line,#E2DCD0);background:var(--bg-2,#FBF8F1);' +
      'font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);display:flex;align-items:center;justify-content:center;cursor:default;padding:0}' +
      '.mdh-cell.has{cursor:pointer;font-weight:var(--w-bold,700);border-color:transparent}' +
      '.mdh-cell.empty{background:none;border:none}' +
      '.mdh-cell .dot{position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:var(--foret,#33463E)}' +
      '.mdh-cell.today{outline:2px solid var(--foret,#33463E);outline-offset:1px}' +
      '.mdh-legend{display:flex;flex-wrap:wrap;gap:10px;margin:10px 0 4px;font-size:var(--fs-caps,11px);color:var(--ink-2,#58635E)}' +
      '.mdh-legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:4px;vertical-align:-1px}' +
      '.mdh-sum{background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:12px;padding:10px 12px;margin:10px 0;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible Next",sans-serif);font-size:var(--fs-xs,13px);line-height:var(--lh-airy,1.6)}' +
      '.mdh-sum b{color:var(--ink,#1F2B25)}' +
      '.mdh-trend-t{font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-caps,11px);font-weight:var(--w-bold,700);text-transform:uppercase;letter-spacing:var(--ls-caps,.08em);color:var(--ink-2,#58635E);margin:14px 0 8px}' +
      '.mdh-trend{display:grid;grid-template-columns:repeat(6,1fr);gap:6px;align-items:end;height:74px}' +
      '.mdh-bar{display:flex;flex-direction:column;align-items:center;gap:4px;justify-content:flex-end;height:100%}' +
      '.mdh-bar .b{width:70%;min-height:3px;background:var(--sauge,#7A8F72);border-radius:4px 4px 0 0}' +
      '.mdh-bar .l{font-size:var(--fs-caps,11px);color:var(--ink-2,#58635E)}' +
      '.mdh-bar .v{font-size:var(--fs-caps,10px);font-weight:var(--w-bold,700);color:var(--ink,#1F2B25)}' +
      '.mdh-day{margin-top:8px}' +
      '.mdh-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);' +
      'font-size:var(--fs-ui,15px);padding:12px;cursor:pointer;margin-top:12px;font-family:var(--font-technical,Inter,sans-serif)}';
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  }

  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  var view; // {y, m}
  function monthSummary(y, m) {
    var days = new Date(y, m + 1, 0).getDate();
    var sansConso = 0, avecConso = 0, renseignes = 0, cout = 0;
    for (var d = 1; d <= days; d++) {
      var es = entriesByDate(iso(y, m, d));
      if (!es.length) continue;
      renseignes++;
      var mx = es.reduce(function (a, e) { return Math.max(a, Number(e.level) || 0); }, 0);
      if (mx === 0) sansConso++; else avecConso++;
      cout += es.reduce(function (a, e) { return a + (Number(e.cost) || 0); }, 0);
    }
    var start = new Date(y, m, 1).getTime(), end = new Date(y, m + 1, 1).getTime();
    var sess = sessions().filter(function (s) { return (s.date || 0) >= start && (s.date || 0) < end; });
    var nbSeances = sess.filter(function (s) { return s.type !== 'q'; }).length;
    var nbBilans = sess.filter(function (s) { return s.type === 'q'; }).length;
    return { days: days, sansConso: sansConso, avecConso: avecConso, renseignes: renseignes, cout: Math.round(cout), nbSeances: nbSeances, nbBilans: nbBilans };
  }

  function render(card) {
    card.innerHTML = '';
    var top = el('div', 'mdh-top');
    top.appendChild(el('div', 'mdh-title', 'Ma mémoire'));
    var x = el('button', 'mdh-x', '\u2715'); x.type = 'button';
    x.onclick = function () { var ov = card.parentNode; if (ov && ov.parentNode) ov.parentNode.removeChild(ov); };
    top.appendChild(x); card.appendChild(top);

    // Navigation mensuelle
    var nav = el('div', 'mdh-nav');
    var prev = el('button', 'mdh-arr', '\u2039'); prev.type = 'button';
    var lbl = el('b', null, MONTHS[view.m] + ' ' + view.y);
    var next = el('button', 'mdh-arr', '\u203A'); next.type = 'button';
    var now = new Date();
    // pas de futur au-delà du mois courant
    next.disabled = (view.y > now.getFullYear() || (view.y === now.getFullYear() && view.m >= now.getMonth()));
    prev.onclick = function () { view.m--; if (view.m < 0) { view.m = 11; view.y--; } render(card); };
    next.onclick = function () { if (next.disabled) return; view.m++; if (view.m > 11) { view.m = 0; view.y++; } render(card); };
    nav.appendChild(prev); nav.appendChild(lbl); nav.appendChild(next); card.appendChild(nav);

    // Jours de la semaine
    var dow = el('div', 'mdh-dow'); DOW.forEach(function (x) { dow.appendChild(el('span', null, x)); }); card.appendChild(dow);

    // Grille du mois
    var grid = el('div', 'mdh-grid');
    var first = new Date(view.y, view.m, 1);
    var lead = (first.getDay() + 6) % 7; // lundi=0
    var days = new Date(view.y, view.m + 1, 0).getDate();
    var todayStr = iso(now.getFullYear(), now.getMonth(), now.getDate());
    for (var i = 0; i < lead; i++) grid.appendChild(el('div', 'mdh-cell empty'));
    for (var d = 1; d <= days; d++) {
      var key = iso(view.y, view.m, d);
      var es = entriesByDate(key);
      var cell = el('button', 'mdh-cell'); cell.type = 'button'; cell.textContent = d;
      if (es.length) {
        var mx = es.reduce(function (a, e) { return Math.max(a, Number(e.level) || 0); }, 0);
        var c = levelColor(mx);
        cell.className = 'mdh-cell has'; cell.style.background = c.bg; cell.style.color = c.fg;
        (function (k) { cell.onclick = function () { showDay(card, k); }; })(key);
      }
      if (sessionsOn(view.y, view.m, d).length) { var dot = el('span', 'dot'); cell.appendChild(dot); }
      if (key === todayStr) cell.classList.add('today');
      grid.appendChild(cell);
    }
    card.appendChild(grid);

    // Légende
    var lg = el('div', 'mdh-legend');
    lg.innerHTML = '<span><i style="background:var(--sauge,#7A8F72)"></i>Sans conso</span>' +
      '<span><i style="background:var(--ocre,#D5A84A)"></i>Léger</span>' +
      '<span><i style="background:var(--terra,#C7765C)"></i>Notable</span>' +
      '<span><i style="background:var(--foret,#33463E)"></i>Séance/bilan</span>';
    card.appendChild(lg);

    // Résumé du mois
    var s = monthSummary(view.y, view.m);
    var sum = el('div', 'mdh-sum');
    if (!s.renseignes) {
      sum.innerHTML = 'Aucune donnée ce mois-là. Le suivi se remplit jour après jour.';
    } else {
      sum.innerHTML = '<b>' + s.sansConso + '</b> jour' + (s.sansConso > 1 ? 's' : '') + ' sans conso \u00B7 ' +
        '<b>' + s.avecConso + '</b> avec' +
        (s.cout ? ' \u00B7 <b>' + s.cout + ' \u20AC</b>' : '') +
        ((s.nbSeances || s.nbBilans) ? '<br><b>' + s.nbSeances + '</b> séance' + (s.nbSeances > 1 ? 's' : '') + ' \u00B7 <b>' + s.nbBilans + '</b> bilan' + (s.nbBilans > 1 ? 's' : '') : '');
    }
    card.appendChild(sum);

    // Tendance 6 mois (jours sans conso par mois)
    card.appendChild(el('div', 'mdh-trend-t', 'Tendance \u00B7 jours sans conso / mois'));
    var months = [];
    var ry = now.getFullYear(), rm = now.getMonth();
    for (var k = 5; k >= 0; k--) {
      var mm = rm - k, yy = ry;
      while (mm < 0) { mm += 12; yy--; }
      months.push({ y: yy, m: mm });
    }
    var vals = months.map(function (mo) { return monthSummary(mo.y, mo.m).sansConso; });
    var maxV = Math.max(1, Math.max.apply(null, vals));
    var trend = el('div', 'mdh-trend');
    months.forEach(function (mo, idx) {
      var b = el('div', 'mdh-bar');
      b.appendChild(el('div', 'v', vals[idx] ? String(vals[idx]) : ''));
      var bar = el('div', 'b'); bar.style.height = Math.round((vals[idx] / maxV) * 52) + 'px';
      if (mo.y === view.y && mo.m === view.m) bar.style.background = 'var(--foret,#33463E)';
      b.appendChild(bar);
      b.appendChild(el('div', 'l', MONTHS[mo.m].slice(0, 3)));
      trend.appendChild(b);
    });
    card.appendChild(trend);

    // Mot du héros sur la tendance
    if (window.MDCompagnon) {
      var last = vals[5], prevV = vals[4];
      var mood = 'reflexion', text = 'Ta mémoire se construit ici. Reviens quand tu veux prendre du recul.';
      if (last > prevV) { mood = 'encouragement'; text = 'Plus de jours sans conso que le mois d\u2019avant. C\u2019est un vrai mouvement — bravo.'; }
      else if (last < prevV && prevV > 0) { mood = 'bienveillance'; text = 'Un mois un peu plus chargé que le précédent. Pas un échec : une info pour ajuster, en douceur.'; }
      else if (last > 0) { mood = 'serenite'; text = 'Tu tiens ton cap, mois après mois. La régularité, c\u2019est ça qui compte.'; }
      var hero = el('div', 'mdh-day'); card.appendChild(hero);
      window.MDCompagnon.render(hero, { mood: mood, text: text, size: 'sm' });
    }

    var done = el('button', 'mdh-go', 'Fermer'); done.type = 'button';
    done.onclick = function () { var ov = card.parentNode; if (ov && ov.parentNode) ov.parentNode.removeChild(ov); };
    card.appendChild(done);
  }

  function showDay(card, dateStr) {
    var es = entriesByDate(dateStr);
    var host = card.querySelector('.mdh-day-detail') || (function () { var d = el('div', 'mdh-sum mdh-day-detail'); card.querySelector('.mdh-legend').after(d); return d; })();
    var dt = new Date(dateStr + 'T00:00:00');
    var head = dt.getDate() + ' ' + MONTHS[dt.getMonth()] + ' ' + dt.getFullYear();
    if (!es.length) { host.innerHTML = '<b>' + head + '</b> \u2014 rien noté.'; return; }
    var lines = es.map(function (e) {
      var lv = Number(e.level) || 0;
      if (lv === 0) return 'Sans conso';
      var q = (e.qty != null && e.qty !== '') ? (String(e.qty).replace('.', ',') + ' ' + (e.unit || '')).trim() : '';
      var c = (Number(e.cost) || 0) ? ' \u00B7 ' + Math.round(e.cost) + ' \u20AC' : '';
      return esc((e.substance || '\u2014')) + (q ? ' \u00B7 ' + esc(q) : '') + c;
    });
    host.innerHTML = '<b>' + head + '</b><br>' + lines.join('<br>');
  }

  function open() {
    inject();
    var now = new Date();
    view = { y: now.getFullYear(), m: now.getMonth() };
    var ov = el('div', 'mdh-ov md-ov');
    var card = el('div', 'mdh-card md-card');
    ov.appendChild(card);
    ov.addEventListener('click', function (e) { if (e.target === ov && ov.parentNode) ov.parentNode.removeChild(ov); });
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Historique', onClose: function(){ if (ov.parentNode) ov.parentNode.removeChild(ov); } });
    render(card);
  }

  return { open: open };
})();
