/* MyDope Off — page-guide.js
   Scripts inline de guide.html regroupés ici pour permettre une CSP stricte
   (script-src 'self'). Contenu inchangé, ordre d'origine préservé. */


/* ---- bloc suivant ---- */

/* ===== LEXIQUE RDR ===== */
const LEXIQUE = [
  ["Réduction des risques (RDR)","approche","Ensemble de pratiques visant à diminuer les dommages liés à un usage de drogues sans forcément exiger l'arrêt : tester son produit, ne pas être seul·e, doser, espacer. On part de la personne là où elle en est."],
  ["Agoniste","pharmacologie","Molécule qui active un récepteur du corps pour produire un effet (ex. un opioïde agoniste des récepteurs mu produit l'analgésie et l'euphorie). Un agoniste « complet » active à fond, un « partiel » seulement en partie."],
  ["Antagoniste","pharmacologie","Molécule qui bloque un récepteur sans l'activer. La naloxone est un antagoniste des opioïdes : elle déloge l'opioïde et stoppe l'overdose."],
  ["Récepteur","pharmacologie","Serrure biologique sur les cellules. Les substances agissent comme des clés qui ouvrent (agonistes) ou bloquent (antagonistes) ces serrures (ex. récepteurs 5-HT2A pour les psychédéliques, mu pour les opioïdes, GABA pour les sédatifs)."],
  ["Demi-vie","pharmacologie","Temps que met le corps à éliminer la moitié d'une substance. Une demi-vie longue = effets et risques d'accumulation prolongés (important pour le redose et les interactions)."],
  ["Onset","durée","Délai avant l'apparition des premiers effets après la prise. Une montée lente pousse parfois à reprendre trop tôt (« redose »), d'où des surdoses."],
  ["Plateau","durée","Phase où les effets sont à leur maximum et stables, avant la descente."],
  ["Biodisponibilité","pharmacologie","Fraction de la dose qui atteint réellement la circulation selon la voie (avaler, sniffer, fumer, injecter). Une même dose n'a pas le même effet selon la voie."],
  ["Tolérance","usage","Besoin d'augmenter la dose pour retrouver le même effet, car le corps s'adapte. La tolérance croisée touche des substances de la même famille."],
  ["Dépendance","usage","État où l'arrêt provoque un manque physique (sevrage) et/ou psychique (craving). Différente de l'addiction, qui inclut la perte de contrôle malgré les conséquences."],
  ["Craving","usage","Envie irrépressible de consommer. Les exercices courts de l'app visent à occuper l'esprit le temps qu'une vague de craving redescende."],
  ["Sevrage","usage","Ensemble des symptômes à l'arrêt d'une substance dont on est dépendant. Pour l'alcool et les benzodiazépines, le sevrage brutal peut être dangereux (convulsions) et doit être encadré."],
  ["Redose","usage","Reprendre une dose pendant que la précédente agit encore. Source fréquente de surdose, surtout quand la montée est lente (on croit que « ça ne marche pas »)."],
  ["Surdose / overdose","risque","Dose qui dépasse ce que le corps tolère. Pour les opioïdes, elle se traduit par une dépression respiratoire (la respiration ralentit puis s'arrête)."],
  ["Dépression respiratoire","risque","Ralentissement dangereux de la respiration, principal mécanisme de décès par opioïdes et par mélanges de dépresseurs (alcool + benzo + opioïde)."],
  ["Naloxone","RDR","Antidote des opioïdes (spray nasal ou injection) qui inverse temporairement une overdose. N'agit pas sur les non-opioïdes (xylazine, benzos). À garder à portée si on est concerné."],
  ["Dépresseur","famille","Substance qui ralentit le système nerveux (alcool, benzodiazépines, GHB, opioïdes). Cumuler deux dépresseurs additionne le risque respiratoire."],
  ["Stimulant","famille","Substance qui accélère le système nerveux (cocaïne, amphétamines, cathinones). Risques cardiovasculaires, hyperthermie, redose compulsif."],
  ["Opioïde","famille","Substance agissant sur les récepteurs opioïdes (héroïne, morphine, fentanyl, nitazènes). Analgésie et euphorie, mais dépression respiratoire mortelle en cas de surdose."],
  ["Psychédélique","famille","Substance modifiant la perception via les récepteurs 5-HT2A (LSD, psilocybine, mescaline, 2C-B). Risque surtout psychologique (bad trip) et d'interactions."],
  ["Dissociatif","famille","Substance qui « déconnecte » le corps et l'esprit (kétamine, MXE, PCP). Risque de chutes, de fausses routes en cas de vomissement, et de cystite à usage répété."],
  ["Empathogène / entactogène","famille","Substance qui amplifie l'empathie et le lien (MDMA et apparentés). Risques : hyperthermie, déshydratation, contre-coup sérotoninergique."],
  ["Cathinone","famille","Stimulants de synthèse dérivés de la cathinone du khat (méphédrone, MDPV, alpha-PVP). Souvent vendus sous le nom « sels de bain ». Redose compulsif, charge cardiaque."],
  ["Cannabinoïde de synthèse","famille","Molécules imitant le THC mais souvent bien plus puissantes et dangereuses (« noids » type ADB-, MDMB-). Réparties inégalement sur l'herbe : dosage imprévisible."],
  ["Delirant / anticholinergique","famille","Substances provoquant un vrai délire confus et dangereux (datura, belladone, forte dose de certains antihistaminiques). Très différentes des psychédéliques, et toxiques."],
  ["IMAO","pharmacologie","Inhibiteur de la monoamine oxydase : bloque une enzyme qui dégrade la sérotonine et d'autres messagers. Présent dans l'ayahuasca. Interactions potentiellement mortelles (MDMA, certains stimulants, antidépresseurs, tyramine)."],
  ["ISRS / IRSNa","médicament","Antidépresseurs courants (fluoxétine, sertraline, venlafaxine…) qui augmentent la sérotonine. Atténuent souvent les effets de la MDMA et exposent au syndrome sérotoninergique avec d'autres sérotoninergiques."],
  ["Syndrome sérotoninergique","risque","Excès dangereux de sérotonine (agitation, tremblements, fièvre, rigidité, parfois mortel). Survient en cumulant des substances sérotoninergiques, surtout avec un IMAO."],
  ["Speedball","risque","Mélange d'un stimulant et d'un opioïde. Le stimulant masque la dépression respiratoire de l'opioïde : la surdose frappe quand le stimulant retombe."],
  ["Cocaéthylène","risque","Substance cardiotoxique formée quand cocaïne et alcool sont pris ensemble. Plus durable et plus dur pour le cœur que la cocaïne seule."],
  ["Tranq","produit","Surnom de la xylazine, sédatif vétérinaire qui contamine le fentanyl. La naloxone ne lève pas sa sédation et elle provoque des plaies nécrotiques."],
  ["Lean / purple drank","produit","Sirop codéine + prométhazine mélangé à du soda. Dépression respiratoire potentialisée, surtout avec alcool ou benzos."],
  ["Nitazène","produit","Famille d'opioïdes de synthèse très puissants (iso-, méto-, protonitazène), parfois plus que le fentanyl. Marge dose/overdose minuscule."],
  ["Fenêtre de détection","test","Durée pendant laquelle une substance reste repérable par un test (salive, urine, sang). Varie selon la substance, la dose, la fréquence et le métabolisme."],
  ["Métabolite","pharmacologie","Produit de transformation d'une substance par le corps. Certains tests détectent les métabolites bien après la disparition des effets."],
  ["Adultérant / produit de coupe","risque","Substance ajoutée pour augmenter le volume ou l'effet d'une drogue. Parfois plus dangereuse que le produit attendu (ex. fentanyl dans l'héroïne, lévamisole dans la cocaïne)."],
  ["Analyse de produit (drug checking)","RDR","Faire tester la composition réelle de son produit (bandelettes, services spécialisés). La seule façon de savoir ce qu'on a vraiment entre les mains."],
  ["Sitter","RDR","Personne sobre et de confiance qui veille sur quelqu'un sous l'effet d'une substance, surtout pour les psychédéliques et dissociatifs."],
  ["Set and setting","RDR","L'état d'esprit (set) et l'environnement (setting) dans lesquels on consomme. Déterminants majeurs de la qualité et de la sécurité d'une expérience psychédélique."],
  ["Bad trip","risque","Expérience psychédélique difficile (angoisse, panique, paranoïa). Atténuée par un bon set and setting, un sitter, et le fait de ne pas lutter contre."],
  ["RC (research chemical)","produit","« Produit de recherche » : nouvelle molécule de synthèse vendue pour contourner la loi, souvent mal connue, aux risques peu documentés."],
  ["NPS","produit","Nouvelles substances psychoactives : terme officiel pour la vague de molécules récentes (cathinones, cannabinoïdes de synthèse, nitazènes…) apparaissant plus vite que les législations."],
  ["Vasoconstriction","risque","Resserrement des vaisseaux sanguins (fréquent avec certains stimulants et psychédéliques type DOx). À forte dose ou usage répété, risque pour les extrémités et le cœur."],
  ["Hyperthermie","risque","Montée dangereuse de la température corporelle, fréquente avec MDMA et stimulants, aggravée par la danse, la chaleur et le manque d'eau. Peut être mortelle."],
  ["Mémoire de travail","cerveau","Capacité à garder et manipuler des informations en tête sur quelques secondes à minutes. La saturer avec une tâche visuospatiale (comme le Tetris) laisse moins de place à l'imagerie mentale d'un craving — d'où l'effet mesuré du « paradigme Tetris » (Oxford, 2015)."],
  ["Urge surfing","cerveau","Technique qui consiste à observer une envie sans y céder ni la combattre, en sachant qu'elle monte, culmine puis redescend toujours — comme une vague. Formalisée par le psychologue Alan Marlatt."],
  ["Effet Stroop","cerveau","Difficulté à ignorer une information automatique (comme lire un mot) pour répondre à une autre (comme sa couleur d'encre). Sert à mesurer et entraîner le contrôle attentionnel — la capacité à filtrer un automatisme."],
  ["Flexibilité cognitive","cerveau","Capacité à changer de règle ou de stratégie quand le contexte change, plutôt que de rester sur un automatisme. À l'inverse, la rigidité mentale nourrit les rituels de consommation."],
  ["Delay discounting","cerveau","Tendance à sous-évaluer une récompense future par rapport à une récompense immédiate plus petite. Plus ce biais est marqué, plus l'impulsivité — et le risque addictif — sont élevés."],
  ["Cohérence cardiaque","cerveau","État où le rythme cardiaque et la respiration se synchronisent, obtenu en respirant à un rythme lent et régulier (environ 6 cycles/minute). Active le système parasympathique et fait retomber le stress."],
  ["Système parasympathique","cerveau","Partie du système nerveux qui ralentit le corps et favorise le calme, à l'inverse du système sympathique qui l'active. Le nerf vague en est un acteur central."],
  ["Circuit de la récompense","cerveau","Réseau cérébral, impliquant la dopamine, qui motive à rechercher une récompense. Les substances le détournent ; des petits plaisirs du quotidien, vécus et savourés, peuvent le réentraîner à répondre à la vie sans elles."],
];

(function(){
  const box=document.getElementById('lexique');
  const search=document.getElementById('lx-search');
  if(!box) return;
  function L(){ return window.MDCore ? MDCore.lang() : 'fr'; }
  // Liste localisée : EN/ES/DE depuis MD_LEX_I18N (même ordre), sinon FR
  function localized(){
    const l=L();
    if(l==='fr') return LEXIQUE;
    const dict=(window.MD_LEX_I18N||{})[l];
    if(!dict) return LEXIQUE;
    return LEXIQUE.map((row,i)=> dict[i] ? dict[i] : row);
  }
  function emptyMsg(){ return window.MDCore ? MDCore.t('gd.lex_empty') : 'Aucun terme ne correspond.'; }
  function render(q){
    q=(q||'').trim().toLowerCase();
    const items=localized().filter(([t,,d])=> !q || t.toLowerCase().includes(q) || d.toLowerCase().includes(q))
      .sort((a,b)=>a[0].localeCompare(b[0],L()));
    if(!items.length){ box.innerHTML='<div class="lx-empty">'+emptyMsg()+'</div>'; return; }
    box.innerHTML=items.map(([t,tag,d])=>
      '<details class="lx-item"><summary><span>'+t+'<span class="lx-tag">'+tag+'</span></span>'+
      '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></summary>'+
      '<div class="lx-body">'+d+'</div></details>').join('');
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
  document.addEventListener('langchange',()=>render(search?search.value:''));
})();

/* ===== SOURCES & RÉFÉRENCES — un dossier par ligne, FR+EN co-localisés (volume modeste,
   pas besoin d'un fichier i18n séparé comme pour le lexique) ===== */
const SOURCES = [
  { t:"Alcool", t_en:"Alcohol", href:"alcool.html",
    fr:"Sources : CEN Neurologie (complications neurologiques de l'alcoolisme) · Manuel MSD, édition professionnelle · ScienceDirect (Delirium tremens, mise au point) · Santé sur le Net.",
    en:"Sources: CEN Neurology (neurological complications of alcoholism) · MSD Manual, professional edition · ScienceDirect (Delirium tremens, review) · Santé sur le Net." },
  { t:"Auto-sabotage", t_en:"Self-sabotage", href:"autosabotage.html",
    fr:"Sources principales : Berglas & Jones (1978, Journal of Personality and Social Psychology) · Baumeister (1990, Psychological Review) · Baumeister & Scher (1988, Psychological Bulletin) · Marlatt & Gordon (1985) · Khantzian (1997, Harvard Review of Psychiatry) · Kirchner, Shiffman & Wileyto (2011) · Gollwitzer (1999, American Psychologist) · Gollwitzer & Sheeran (2006) · Oettingen (2014). Bibliographie complète dans le mémoire de référence.",
    en:"Main sources: Berglas & Jones (1978, Journal of Personality and Social Psychology) · Baumeister (1990, Psychological Review) · Baumeister & Scher (1988, Psychological Bulletin) · Marlatt & Gordon (1985) · Khantzian (1997, Harvard Review of Psychiatry) · Kirchner, Shiffman & Wileyto (2011) · Gollwitzer (1999, American Psychologist) · Gollwitzer & Sheeran (2006) · Oettingen (2014). Full bibliography in the reference dissertation." },
  { t:"Benzodiazépines", t_en:"Benzodiazepines", href:"benzodiazepines.html",
    fr:"Sources : ANSM, décision du 10/07/2025 · Conseil National de l'Ordre des Pharmaciens · Addict Aide, RESPADD (juin 2025) · Pharmacovigilance Île-de-France.",
    en:"Sources: ANSM, decision of 10/07/2025 · French National Council of the Order of Pharmacists · Addict Aide, RESPADD (June 2025) · Île-de-France Pharmacovigilance." },
  { t:"Cannabis", t_en:"Cannabis", href:"cannabis.html",
    fr:"Sources : info.gouv.fr (entretien addictologue, 2025) · Centre d'Addictovigilance (alerte edibles, avril 2025) · ANSES/ANSM (alerte CBD, juin 2025) · Agence régionale de santé Occitanie · Stop-Cannabis.ch (revue de littérature sur le THC).",
    en:"Sources: info.gouv.fr (interview with an addiction specialist, 2025) · Addictovigilance Centre (edibles alert, April 2025) · ANSES/ANSM (CBD alert, June 2025) · Occitanie Regional Health Agency · Stop-Cannabis.ch (literature review on THC)." },
  { t:"Cocaïne", t_en:"Cocaine", href:"cocaine.html",
    fr:"Sources : OFDT (janvier 2025) · Infirmiers.com, expertise collective · Revues Générales Cœur et addictions (Réalités Cardiologiques) · Manuel MSD grand public (avril 2025) · EUDA, European Drug Report 2025-2026 · PMC/NIH (revues sur le traitement du trouble de l'usage de cocaïne).",
    en:"Sources: OFDT (January 2025) · Infirmiers.com, collective expert review · Revues Générales Cœur et addictions (Réalités Cardiologiques) · MSD Manual consumer version (April 2025) · EUDA, European Drug Report 2025-2026 · PMC/NIH (reviews on the treatment of cocaine use disorder)." },
  { t:"Crack", t_en:"Crack", href:"crack.html",
    fr:"Sources : mécanisme dopaminergique et risques cardiovasculaires — mêmes références que le dossier Cocaïne (OFDT, EUDA, PMC/NIH) · matériel d'inhalation à moindre risque — CATIE (Canada) et National Harm Reduction Coalition · histoire du ratio de peines 100 pour 1 — Anti-Drug Abuse Act (1986), Fair Sentencing Act (2010).",
    en:"Sources: dopaminergic mechanism and cardiovascular risks — same references as the Cocaine file (OFDT, EUDA, PMC/NIH) · lower-risk smoking equipment — CATIE (Canada) and the National Harm Reduction Coalition · history of the 100-to-1 sentencing ratio — Anti-Drug Abuse Act (1986), Fair Sentencing Act (2010)." },
  { t:"Environnement & nature", t_en:"Environment & nature", href:"environnement.html",
    fr:"Sources principales : Alexander, Coambs & Hadaway (1978, Psychopharmacology) · Robins, Davis & Nurco (1974, American Journal of Public Health) · Robins et coll. (2010, American Journal on Addictions) · Wikler · Siegel (1983) · Stewart, de Wit & Eikelboom (1984, Psychological Review) · Bouton (2002, 2004) · Sinha (2001, Psychopharmacology) · Kaplan (1995, Journal of Environmental Psychology) · Ulrich et coll. (1991, Journal of Environmental Psychology) · Solinas et coll. (2008, PNAS ; 2009, Neuropsychopharmacology) · Bardo et coll. (2001). Bibliographie complète (32 références) dans le mémoire de référence.",
    en:"Main sources: Alexander, Coambs & Hadaway (1978, Psychopharmacology) · Robins, Davis & Nurco (1974, American Journal of Public Health) · Robins et al. (2010, American Journal on Addictions) · Wikler · Siegel (1983) · Stewart, de Wit & Eikelboom (1984, Psychological Review) · Bouton (2002, 2004) · Sinha (2001, Psychopharmacology) · Kaplan (1995, Journal of Environmental Psychology) · Ulrich et al. (1991, Journal of Environmental Psychology) · Solinas et al. (2008, PNAS; 2009, Neuropsychopharmacology) · Bardo et al. (2001). Full bibliography (32 references) in the reference dissertation." },
  { t:"MDMA", t_en:"MDMA", href:"mdma.html",
    fr:"Sources : Drogues Info Service · Manuel MSD grand public (avril 2025) · PsychoWiki/Psychoactif · GREA (Suisse) · NBC News, The Conversation (couverture de la décision FDA, août 2024) · PMC/NIH (revues sur la thérapie assistée par MDMA, 2025-2026).",
    en:"Sources: Drogues Info Service · MSD Manual consumer version (April 2025) · PsychoWiki/Psychoactif · GREA (Switzerland) · NBC News, The Conversation (coverage of the FDA decision, August 2024) · PMC/NIH (reviews on MDMA-assisted therapy, 2025-2026)." },
  { t:"Protoxyde d'azote", t_en:"Nitrous oxide", href:"nitreux.html",
    fr:"Sources : OFDT (données d'usage 2022-2025) · ANSM (signalements d'intoxications graves) · Légifrance (loi du 1ᵉʳ juin 2021) · Sénat (proposition de loi, février 2026) · projet de loi RIPOST (mars 2026, en discussion parlementaire au moment de la rédaction).",
    en:"Sources: OFDT (2022-2025 usage data) · ANSM (serious intoxication reports) · Légifrance (law of 1 June 2021) · French Senate (bill, February 2026) · RIPOST draft law (March 2026, under parliamentary debate at the time of writing)." },
  { t:"Opioïdes de synthèse", t_en:"Synthetic opioids", href:"opioides-synthese.html",
    fr:"Sources : OFDT (Sintes, fiche xylazine) · Agence européenne des drogues — EUDA, European Drug Report 2025-2026 · National Harm Reduction Coalition · Santé publique Ottawa · UC Davis Health.",
    en:"Sources: OFDT (Sintes, xylazine factsheet) · European Union Drugs Agency — EUDA, European Drug Report 2025-2026 · National Harm Reduction Coalition · Ottawa Public Health · UC Davis Health." },
  { t:"Polyconsommation", t_en:"Polydrug use", href:"polyconsommation.html",
    fr:"Sources : OFDT (données 2023, chiffres clés 2025) · ANPAA · F-N-A-S / CESPHARM · Nuit Blanche (Suisse) · Infodrog (fiche médicaments et polyconsommation, 2026) · Revol et coll., JAMA Network Open 2023 (registre DRAMES).",
    en:"Sources: OFDT (2023 data, key figures 2025) · ANPAA · F-N-A-S / CESPHARM · Nuit Blanche (Switzerland) · Infodrog (medicines and polydrug use factsheet, 2026) · Revol et al., JAMA Network Open 2023 (DRAMES register)." },
  { t:"Psychédéliques & micro-dosage", t_en:"Psychedelics & microdosing", href:"psychedeliques.html",
    fr:"Sources : Szigeti et coll., eLife (2021, essai auto-aveuglé sur le micro-dosage) · Carhart-Harris et coll., New England Journal of Medicine (2021, psilocybine vs escitalopram) · Bogenschutz et coll., JAMA Psychiatry (2022, psilocybine et trouble de l'usage d'alcool) · décision FDA sur la MDMA (2024) · littérature sur les récepteurs 5-HT2B et valvulopathies · OFDT · MILDECA.",
    en:"Sources: Szigeti et al., eLife (2021, self-blinded microdosing trial) · Carhart-Harris et al., New England Journal of Medicine (2021, psilocybin vs escitalopram) · Bogenschutz et al., JAMA Psychiatry (2022, psilocybin and alcohol use disorder) · FDA decision on MDMA (2024) · literature on 5-HT2B receptors and valvulopathy · OFDT · MILDECA." },
  { t:"Quand ça se passe mal (crise psychédélique)", t_en:"When it goes badly (psychedelic crisis)", href:"crise-psychedelique.html",
    fr:"Sources : Zendo Project (MAPS), quatre principes de l'accompagnement par les pairs — espace sûr, être là sans diriger, parler avec et non d'en haut, difficile n'est pas mauvais ; plus de 1 900 personnes accompagnées depuis 2012 sans contention ni sédation · Kosmicare (Portugal), « Your trip. Our support. » · Manuel communautaire MAPS sur les services d'accompagnement en festival (licence Creative Commons).",
    en:"Sources: Zendo Project (MAPS), four principles of psychedelic peer support — safe space, sitting not guiding, talking through not down, difficult is not the same as bad; over 1,900 people supported since 2012 without restraint or sedation · Kosmicare (Portugal), “Your trip. Our support.” · MAPS community manual on festival peer-support services (Creative Commons)." },
  { t:"Quand les conseils habituels ne collent pas", t_en:"When the usual advice doesn\u2019t fit", href:"situations.html",
    fr:"Sources : rapport C-EHRN « Full Spectrum Harm Reduction in Europe » (publics à l'intersection) · Médecins du Monde, cadre d'intervention sur le travail du sexe et définition retenue des échanges économico-sexuels · enquête Alias (Bruxelles) auprès de travailleur·ses du sexe HSH et trans : une personne sur cinq déclare un rapport en échange de produits, besoin n°1 exprimé = information sans jugement · EUDA, rapport européen sur les drogues, chapitre réduction des risques (2024 et 2025) · AIDES, réduction des risques et publics communautaires.",
    en:"Sources: C-EHRN report “Full Spectrum Harm Reduction in Europe” (populations at the intersections) · Médecins du Monde framework on sex work and its definition of economic-sexual exchange · Alias survey (Brussels) of gay and trans sex workers: one in five reports sex in exchange for substances, with non-judgmental information named as the top need · EUDA European Drug Report, harm reduction chapter (2024 and 2025) · AIDES, harm reduction and community-based services." },
  { t:"Après une pause (tolérance)", t_en:"After a break (tolerance)", href:"apres-une-pause.html",
    fr:"Sources : EUDA, mini-guide « Décès liés aux opioïdes : réponses sanitaires et sociales » (continuité des soins prison-ville, naloxone à emporter, surrisque après une sortie de traitement fondé sur l'abstinence) · essai randomisé N-ALIVE (MRC / King's College London, Addiction, 2016) sur la remise de naloxone à la libération · Peyret, prévention des overdoses en sortie d'incarcération, centre pénitentiaire de Béziers (2023) · étude qualitative sur le retour à l'usage après libération (PMC).",
    en:"Sources: EUDA mini-guide on opioid-related deaths (prison-to-community continuity of care, take-home naloxone, elevated risk after leaving abstinence-based treatment) · N-ALIVE randomised trial (MRC / King's College London, Addiction, 2016) on naloxone-on-release · Peyret, overdose prevention on release from custody, Béziers prison (2023) · qualitative study on return to drug use after release (PMC)." },
  { t:"Quand on est une femme", t_en:"When you\u2019re a woman", href:"femmes.html",
    fr:"Sources : Fédération Addiction et MILDECA, guide « Femmes et addictions » · RESPADD, vulnérabilité biologique et barrières d'accès · BEH / Santé publique France, numéro femmes et addictions · Harm Reduction Journal, étude avec Metzineres (400 femmes : 100 % survivantes de violences, 86 % sans-abri, 59 % ayant perdu la garde d'un enfant, 74 % avec un diagnostic de santé mentale) · Psychotropes, « Être une femme qui a consommé et travaille sur les drogues » (2026) · Psychologies, Genre et Société, analyse critique du concept d'« alcoolisme féminin ».",
    en:"Sources: Fédération Addiction and MILDECA, “Women and addictions” guide · RESPADD, biological vulnerability and access barriers · Santé publique France epidemiological bulletin on women and addiction · Harm Reduction Journal, study with Metzineres (400 women: all survivors of violence, 86% homeless, 59% having lost custody of a child, 74% with a mental health diagnosis) · Psychotropes journal, on being a woman who used drugs and works in the field (2026) · Psychologies, Genre et Société, critical analysis of the “female alcoholism” concept." },
  { t:"Grossesse et santé sexuelle", t_en:"Pregnancy and sexual health", href:"grossesse.html",
    fr:"Sources : Société des obstétriciens et gynécologues du Canada, directive n° 349 « Consommation de substances psychoactives pendant la grossesse » et directive n° 443b sur les opioïdes · Société canadienne de pédiatrie, prise en charge du syndrome d'abstinence néonatale (Paediatrics & Child Health, 2025) · Harm Reduction Journal, étude avec Metzineres sur les barrières d'accès aux soins des femmes usagères · Rave It Safe (Berne), contraception d'urgence sans condition d'âge.",
    en:"Sources: Society of Obstetricians and Gynaecologists of Canada, guideline no. 349 on substance use in pregnancy and no. 443b on opioids · Canadian Paediatric Society, management of neonatal abstinence syndrome (Paediatrics & Child Health, 2025) · Harm Reduction Journal, study with Metzineres on access barriers for women who use drugs · Rave It Safe (Bern), emergency contraception with no age requirement." },
  { t:"Le creux qui vient après (PAWS)", t_en:"The dip that comes afterwards (PAWS)", href:"paws.html",
    fr:"Sources : PsychoWiki / Psychoactif, « PAWS, le syndrome prolongé de sevrage » · Ashton, benzo.org.uk, syndrome post-sevrage aux benzodiazépines (10 à 15 % des usagers au long cours) · preuves présentées à la Chambre des communes britannique, commission Santé, 1999 · littérature sur les systèmes CRF et dynorphine-κ dans le sevrage prolongé. L'existence et les contours exacts du syndrome restent débattus : le dossier le dit.",
    en:"Sources: PsychoWiki / Psychoactif, protracted withdrawal syndrome · Ashton, benzo.org.uk, benzodiazepine post-withdrawal syndrome (10 to 15% of long-term users) · evidence submitted to the UK House of Commons Health Committee, 1999 · literature on CRF and dynorphin-κ systems in protracted withdrawal. The syndrome's existence and exact boundaries remain debated: the piece says so." },
  { t:"Tes oreilles", t_en:"Your ears", href:"audition.html",
    fr:"Sources : décret n° 2017-1244 du 7 août 2017 relatif à la prévention des risques liés aux bruits et aux sons amplifiés · Bruitparif, effets sur l'audition · ARS Île-de-France et Bruitparif, campagne d'observation en lieux musicaux · ARS Auvergne-Rhône-Alpes · Agi-son et Ear We Are (campagne de prévention des risques auditifs) · Agison (protections auditives).",
    en:"Sources: French decree no. 2017-1244 of 7 August 2017 on preventing risks from noise and amplified sound · Bruitparif, effects on hearing · Île-de-France regional health agency and Bruitparif, observation campaign in music venues · Auvergne-Rhône-Alpes regional health agency · Agi-son and Ear We Are (hearing risk prevention campaign) · Agison (hearing protection)." },
  { t:"Chemsex", t_en:"Chemsex", href:"chemsex.html",
    fr:"Sources : rapport Benyamina remis à la ministre de la Santé (20 février 2026) · Fédération Addiction et AIDES, projet ARPA-Chemsex et guide « Aller vers les chemsexeurs » (2024) · ANSM / réseau d'addictovigilance (CEIP-A), actualisation des données chemsex, revue Psychotropes · Larabi et coll., étude nationale SFTA (2024) · proposition de loi Sénat n° 368 (session 2025-2026) · Association Addictions France · chemsex.be (Alias, Ex Aequo, Observatoire du sida) · Mainline (Pays-Bas).",
    en:"Sources: Benyamina report submitted to the French Health Minister (20 February 2026) · Fédération Addiction and AIDES, ARPA-Chemsex project and the 2024 outreach guide · ANSM / addiction surveillance network (CEIP-A), updated chemsex data, Psychotropes journal · Larabi et al., national SFTA study (2024) · French Senate bill no. 368 (2025-2026 session) · Association Addictions France · chemsex.be (Alias, Ex Aequo, Observatoire du sida) · Mainline (Netherlands)." },
  { t:"RDR vs abstinence", t_en:"Harm reduction vs abstinence", href:"rdr-vs-abstinence.html",
    fr:"Sources : MILDECA, « L'essentiel sur la réduction des risques et des dommages » · Évaluation INSERM des salles de Paris et Strasbourg (commande MILDECA) · Santé publique France, revue La Santé en action (juillet 2025) · ReachLink, revue comparative RDR/abstinence.",
    en:"Sources: MILDECA, \"The essentials on harm reduction\" · INSERM evaluation of the Paris and Strasbourg facilities (commissioned by MILDECA) · Santé publique France, La Santé en action review (July 2025) · ReachLink, comparative review of harm reduction and abstinence." },
  { t:"Rechute", t_en:"Relapse", href:"rechute.html",
    fr:"Sources : OFDT · Marlatt & Gordon (1985) · Kirchner, Shiffman & Wileyto (2011) · Tabac Info Service (statistiques de rechute tabagique) · Circea-addictions (fiche mémo rechute) · Fréquence Médicale (mécanismes neurologiques) · Option Zero.",
    en:"Sources: OFDT · Marlatt & Gordon (1985) · Kirchner, Shiffman & Wileyto (2011) · Tabac Info Service (smoking relapse statistics) · Circea-addictions (relapse briefing note) · Fréquence Médicale (neurological mechanisms) · Option Zero." },
  { t:"Tabac & vapotage", t_en:"Tobacco & vaping", href:"tabac-vapotage.html",
    fr:"Sources : Institut national du cancer · MILDECA (drogues.gouv.fr) · Haut Conseil de Santé Publique, avis novembre 2021 · Loi n° 2025-175 du 24 février 2025 · Décret n° 2025-898 · Échosciences Grenoble · EditorialWeb (chiffres lycéens 2026).",
    en:"Sources: French National Cancer Institute · MILDECA (drogues.gouv.fr) · High Council for Public Health, opinion of November 2021 · Law no. 2025-175 of 24 February 2025 · Decree no. 2025-898 · Échosciences Grenoble · EditorialWeb (secondary school figures 2026)." },
  { t:"Vérificateur d'interactions", t_en:"Interaction checker", href:"psychochecker.html",
    fr:"S'appuie sur la littérature clinique disponible plutôt que sur des témoignages — chaque fiche n'a pas de bibliographie individuelle publiée. Pour vérifier une interaction de façon indépendante : le combinateur de TripSit (tripsit.me/combo) et PsychonautWiki (psychonautwiki.org) sont des références de référence dans le champ RDR.",
    en:"Draws on available clinical literature rather than anecdotal reports — individual entries do not each carry a published bibliography. To check an interaction independently: the TripSit combination tool (tripsit.me/combo) and PsychonautWiki (psychonautwiki.org) are standard reference points in the harm reduction field." },
  { t:"Fenêtres de détection", t_en:"Detection windows", href:"detection.html",
    fr:"Sources : SAMHSA Oral Fluid Mandatory Guidelines (2023) · manuel SAMHSA de prélèvement salivaire (2024) · Cone & Huestis (2007) · Verstraete (2004) · NIDA.",
    en:"Sources: SAMHSA Oral Fluid Mandatory Guidelines (2023) · SAMHSA Oral Fluid Specimen Collection Handbook (2024) · Cone & Huestis (2007) · Verstraete (2004) · NIDA." },
];

(function(){
  const box=document.getElementById('sources');
  const search=document.getElementById('src-search');
  if(!box) return;
  function L(){ return window.MDCore ? MDCore.lang() : 'fr'; }
  function emptyMsg(){ return window.MDCore ? MDCore.t('gd.lex_empty') : 'Aucun terme ne correspond.'; }
  function render(q){
    q=(q||'').trim().toLowerCase();
    const l=L();
    const items=SOURCES.map(s=>({ t: (l==='en' && s.t_en) ? s.t_en : s.t, href:s.href, d: l==='en' ? s.en : s.fr }))
      .filter(s=> !q || s.t.toLowerCase().includes(q) || s.d.toLowerCase().includes(q))
      .sort((a,b)=>a.t.localeCompare(b.t,l));
    if(!items.length){ box.innerHTML='<div class="lx-empty">'+emptyMsg()+'</div>'; return; }
    box.innerHTML=items.map(s=>
      '<div class="card card-pad" style="margin-bottom:10px">'+
      '<a href="'+s.href+'" style="font-family:var(--font-editorial);font-weight:var(--w-medium);font-size:var(--fs-sm);color:var(--ink);text-decoration:underline">'+s.t+'</a>'+
      '<p class="note-sm m0" style="margin-top:4px">'+s.d+'</p></div>'
    ).join('');
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
  document.addEventListener('langchange',()=>render(search?search.value:''));
})();

/* ===== ANECDOTES — toutes régions ===== */
(function(){
  const box=document.getElementById('anecdotes');
  const search=document.getElementById('an-search');
  if(!box || !window.MDAnecdotes) return;

  function myRegion(){
    try{
      const o=JSON.parse(localStorage.getItem('ctc_v6')||'{}');
      const c=(o.user && o.user.region) || 'BE';
      return (window.MDRegions && window.MDRegions.exists && window.MDRegions.exists(c)) ? c : 'BE';
    }catch(e){ return 'BE'; }
  }
  function regionLabel(code){
    try{ return window.MDRegions ? (window.MDRegions.labelOf ? window.MDRegions.labelOf(code) : window.MDRegions.get(code).label) : code; }catch(e){ return code; }
  }

  function T(k, fb){ return window.MDCore ? MDCore.t(k) : fb; }

  function aT(a){ return (window.MDCore && MDCore.lang()==='en' && a.en) ? a.en : a.t; }

  function buildGroups(){
    const groups=[];
    const mine=myRegion();
    const regionCodes=Object.keys(window.MDAnecdotesRegion||{});

    if(window.MDAnecdotesRegion[mine]){
      groups.push({ key:'mine', label:T('gd.anec_my_region','Ta région — ')+regionLabel(mine), items:window.MDAnecdotesRegion[mine].map(aT) });
    }
    if(window.MDAnecdoteBridges){
      const bridges=Object.values(window.MDAnecdoteBridges).map(aT);
      if(bridges.length) groups.push({ key:'bridges', label:T('gd.anec_bridges','Croisements entre régions'), items:bridges });
    }
    regionCodes.filter(c=>c!==mine).sort((a,b)=>regionLabel(a).localeCompare(regionLabel(b),'fr')).forEach(code=>{
      groups.push({ key:'r-'+code, label:regionLabel(code), items:window.MDAnecdotesRegion[code].map(aT) });
    });
    groups.push({ key:'general', label:T('gd.anec_general','Anecdotes générales'), items:(window.MDAnecdotes||[]).map(aT) });
    return groups;
  }

  function emptyMsg(){ return T('gd.anec_empty','Aucune anecdote ne correspond.'); }

  function render(q){
    q=(q||'').trim().toLowerCase();
    const groups=buildGroups();
    let html='';
    groups.forEach(g=>{
      const items=q ? g.items.filter(t=>t.toLowerCase().includes(q)) : g.items;
      if(!items.length) return;
      html += '<details class="lx-item"'+(g.key==='mine'?' open':'')+'><summary><span>'+g.label+'<span class="lx-tag">'+items.length+'</span></span>'+
        '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></summary>'+
        '<div class="lx-body">'+items.map(t=>'<p style="margin:0 0 10px">'+t+'</p>').join('')+'</div></details>';
    });
    box.innerHTML = html || '<div class="lx-empty">'+emptyMsg()+'</div>';
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
  document.addEventListener('langchange',()=>render(search?search.value:''));
})();

/* ---- bloc suivant ---- */

/* ---- bloc suivant ---- */

/* Onglets */
document.querySelectorAll('.tab-btn').forEach(function(btn){
  btn.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
    document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
    btn.classList.add('active'); btn.setAttribute('aria-selected','true');
    document.getElementById('tab-'+btn.getAttribute('data-tab')).classList.add('active');
  });
});
(function(){ var m=/[?&]tab=([a-z]+)/.exec(location.search); if(m){ var b=document.querySelector('.tab-btn[data-tab="'+m[1]+'"]'); if(b) b.click(); } })();

document.querySelectorAll('[data-tab-goto]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var b = document.querySelector('.tab-btn[data-tab="'+btn.getAttribute('data-tab-goto')+'"]');
    if (b) b.click();
  });
});

try{MDCore.init({page:'guide',section:'equilibre'});}catch(e){}try{MDPageIntro.init('guide');}catch(e){}

/* ---- bloc suivant ---- */


