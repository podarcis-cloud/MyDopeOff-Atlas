/* MyDope Off — page-guide.js
   Scripts inline de guide.html regroupés ici pour permettre une CSP stricte
   (script-src 'self'). Contenu inchangé, ordre d'origine préservé. */

/* ============================================================
   LUCIDE — Socle partagé (navigation, profil, logo)
   ============================================================ */
window.LUCIDE = (function () {

  const KEY = 'ctc_v6';
  const LANG_KEY = 'mydopeoff_lang';
  const LANGS = ['fr', 'en'];
  const LANG_NAMES = { fr: 'Français', en: 'English' };

  /* ============================================================
     I18N — dictionnaire du "cadre" (UI partagée).
     Pour traduire le contenu (fiches) plus tard : remplir
     window.LUCIDE_FICHES_I18N (voir docs en bas) — aucune
     modification d'architecture nécessaire.
     ============================================================ */
  const DICT = {
    // Navigation
    'nav.home':        { fr: 'Accueil',      en: 'Home' },
    'nav.tracking':    { fr: 'Suivi conso',  en: 'Tracking' },
    'nav.substances':  { fr: 'Substances',   en: 'Substances' },
    'nav.protocols':   { fr: 'Protocoles',   en: 'Protocols' },
    'nav.rdr':         { fr: 'RDR',          en: 'Harm red.' },
    // Commun
    'common.back':     { fr: 'Accueil',      en: 'Home' },
    'common.back_prev':{ fr: 'Retour',       en: 'Back' },
    'common.close':    { fr: 'Fermer',       en: 'Close' },
    'common.save':     { fr: 'Enregistrer',  en: 'Save' },
    'common.cancel':   { fr: 'Annuler',      en: 'Cancel' },
    'common.add':      { fr: 'Ajouter',      en: 'Add' },
    'common.delete':   { fr: 'Supprimer',    en: 'Delete' },
    'common.search':   { fr: 'Rechercher…',  en: 'Search…' },
    'common.language': { fr: 'Langue',       en: 'Language' },
    // Accueil
    'home.intro':      { fr: "Ici, tu n'es pas un dossier : tu gardes les commandes. MyDope Off t'aide à comprendre les substances, mesurer ta consommation et couper la boucle quand tu le décides — sans jugement, sans compte, tout reste sur ton appareil.",
                         en: "Here you're not a case file — you stay in control. MyDope Off helps you understand substances, track your use and break the loop when you decide — no judgement, no account, everything stays on your device." },
    'home.spaces':     { fr: 'Les 5 espaces', en: 'The 5 spaces' },
    'home.welcome':    { fr: 'Bienvenue',    en: 'Welcome' },
    'home.welcome_sub':{ fr: 'Commence par tenir ton journal dans Suivi conso.',
                         en: 'Start by keeping your journal in Tracking.' },
    'home.tile_track': { fr: 'Journal, coûts, détection, objectifs',
                         en: 'Journal, costs, detection, goals' },
    'home.tile_subs':  { fr: '270 fiches, interactions, risques',
                         en: '270 substances, interactions, risks' },
    'home.tile_proto': { fr: 'Exercices et jeux anti-craving',
                         en: 'Anti-craving exercises and games' },
    'home.tile_rdr':   { fr: 'Urgences, centres, conseils',
                         en: 'Emergencies, centres, advice' },
    'home.edit_info':  { fr: 'Modifier mes infos', en: 'Edit my info' },
    'home.support':    { fr: 'Soutenir le projet', en: 'Support the project' },
    'home.guide_link': { fr: 'Guide d\'utilisation', en: 'User guide' },
    // Suivi
    'track.title':     { fr: 'Suivi conso',  en: 'Tracking' },
    'track.tab_board': { fr: 'Tableau',      en: 'Board' },
    'track.tab_journal':{ fr: 'Journal',     en: 'Journal' },
    'track.tab_costs': { fr: 'Coûts',        en: 'Costs' },
    'track.tab_goals': { fr: 'Objectifs',    en: 'Goals' },
    // RDR / interactions génériques
    'inter.title':     { fr: "Vérificateur d'interactions", en: 'Interaction checker' },
    'inter.analyze':   { fr: 'Analyser les interactions', en: 'Check interactions' },
    // Inscription (1er lancement)
    'reg.sub':         { fr: "Ici, tu gardes les commandes. Comprendre, mesurer, couper la boucle — tes données restent sur ton appareil.",
                         en: "Here, you stay in control. Understand, track, break the loop — your data stays on your device." },
    'reg.name':        { fr: 'Prénom ou pseudo', en: 'First name or nickname' },
    'reg.name_ph':     { fr: 'Ton prénom', en: 'Your name' },
    'reg.age':         { fr: 'Âge', en: 'Age' },
    'reg.region':      { fr: 'Région', en: 'Region' },
    'reg.enter':       { fr: 'Entrer', en: 'Enter' },
    'reg.back_home':   { fr: "← Revenir à l'accueil", en: '← Back to home' },
    'reg.note':        { fr: 'Aucun compte · aucune inscription en ligne · 100 % local',
                         en: 'No account · no online sign-up · 100% local' },
    'reg.choose_lang': { fr: 'Choisis ta langue', en: 'Choose your language' },
    // Consentement
    'consent.title':   { fr: 'Avant de commencer', en: 'Before you start' },
    'consent.p1':      { fr: "MyDope Off est un outil de <b>réduction des risques</b> à visée éducative. Il ne remplace ni un avis médical, ni un traitement, ni un service d'urgence.",
                         en: "MyDope Off is an educational <b>harm-reduction</b> tool. It does not replace medical advice, treatment, or emergency services." },
    'consent.p2':      { fr: "Les informations sur les substances, interactions et durées de détection sont des <b>estimations</b> qui varient selon chaque personne. En cas d'urgence, appelle le 112.",
                         en: "Information on substances, interactions and detection times are <b>estimates</b> that vary from person to person. In an emergency, call 112." },
    'consent.p3':      { fr: "Tes données restent uniquement sur cet appareil. Si tu vides le cache, elles disparaissent.",
                         en: "Your data stays only on this device. If you clear the cache, it's gone." },
    'consent.ok':      { fr: "J'ai compris", en: 'I understand' },
    // Suivi conso — détail
    'tr.day':          { fr: 'Journée', en: 'Day' },
    'tr.edit_entry':   { fr: "Modifier l'entrée", en: 'Edit entry' },
    'tr.date':         { fr: 'Date', en: 'Date' },
    'tr.substance':    { fr: 'Substance', en: 'Substance' },
    'tr.substance_search': { fr: 'Substance (recherche dans les fiches)', en: 'Substance (search the database)' },
    'tr.intensity':    { fr: 'Intensité', en: 'Intensity' },
    'tr.note':         { fr: 'Note', en: 'Note' },
    'tr.note_ph':      { fr: 'Contexte, ressenti…', en: 'Context, feelings…' },
    'tr.cost':         { fr: 'Coût (€)', en: 'Cost (€)' },
    'tr.sober':        { fr: 'Sobre', en: 'Sober' },
    'tr.light':        { fr: 'Léger', en: 'Light' },
    'tr.moderate':     { fr: 'Modéré', en: 'Moderate' },
    'tr.intense':      { fr: 'Intensif', en: 'Intense' },
    'tr.add_entry':    { fr: 'Ajouter une entrée', en: 'Add entry' },
    'tr.add_to_day':   { fr: 'Ajouter à ce jour', en: 'Add to this day' },
    'tr.add_entry_btn':{ fr: "Ajouter l'entrée", en: 'Add the entry' },
    'tr.day_sober':    { fr: 'Journée sobre', en: 'Sober day' },
    'tr.sobers':       { fr: 'Sobres', en: 'Sober' },
    'tr.logged':       { fr: 'Journalisés', en: 'Logged' },
    'tr.intenses':     { fr: 'Intenses', en: 'Intense' },
    'tr.cal_hint':     { fr: "30 derniers jours · touche un jour pour l'éditer", en: 'Last 30 days · tap a day to edit' },
    'tr.new_goal':     { fr: 'Nouvel objectif', en: 'New goal' },
    'tr.create_goal':  { fr: "Créer l'objectif", en: 'Create goal' },
    'tr.goal_type':    { fr: "Type d'objectif", en: 'Goal type' },
    'tr.goal_reduce':  { fr: "Réduction d'une substance", en: 'Reduce a substance' },
    'tr.goal_streak':  { fr: 'Jours consécutifs sobres', en: 'Consecutive sober days' },
    'tr.goal_max_week':{ fr: 'Maximum de prises / semaine (toutes substances)', en: 'Max uses / week (all substances)' },
    'tr.goal_no_heavy':{ fr: 'Aucune séance intensive', en: 'No intense sessions' },
    'tr.per_day':      { fr: 'par jour', en: 'per day' },
    'tr.per_week':     { fr: 'par semaine', en: 'per week' },
    'tr.per_month':    { fr: 'par mois', en: 'per month' },
    'tr.per_sub':      { fr: 'Par substance · 30 jours', en: 'Per substance · 30 days' },
    'tr.lottery':      { fr: 'Ta cagnotte potentielle', en: 'Reverse lottery' },
    'tr.lottery_sub':  { fr: 'Ce que ça représente autrement. Pas pour culpabiliser — juste pour voir ce que tu pourrais récupérer.', en: "What it could be instead. Not to guilt-trip — just to see what you could get back." },
    'tr.proj_annual':  { fr: 'Projection annuelle', en: 'Annual projection' },
    'tr.cost_empty':   { fr: 'Renseigne un coût dans tes entrées pour voir les projections.', en: 'Add a cost to your entries to see projections.' },
    'tr.cost_note':    { fr: 'Seules les entrées avec un coût renseigné sont comptabilisées.', en: 'Only entries with a cost are counted.' },
    'tr.record':       { fr: 'Record', en: 'Record' },
    'tr.del_confirm':  { fr: 'Supprimer cette entrée ?', en: 'Delete this entry?' },
    'tr.max':          { fr: 'maximum', en: 'maximum' },
    'tr.empty':        { fr: 'Vide', en: 'Empty' },
    'tr.cons_8w':      { fr: 'Consommations · 8 semaines', en: 'Use · 8 weeks' },
    'tr.subs_30d':     { fr: 'Substances · 30 jours', en: 'Substances · 30 days' },
    'tr.mark_sober':   { fr: "Marquer aujourd'hui sobre", en: 'Mark today sober' },
    'tr.history':      { fr: 'Historique', en: 'History' },
    'tr.limit_set':    { fr: 'Limite que tu te fixes', en: 'Limit you set' },
    'tr.target_num':   { fr: 'Cible (nombre)', en: 'Target (number)' },
    'tr.sub_ph':       { fr: 'ex. Tabac, Alcool, Cannabis…', en: 'e.g. Tobacco, Alcohol, Cannabis…' },
    // Guide
    'gd.title':        { fr: 'Bien utiliser MyDope Off', en: 'Getting the most from MyDope Off' },
    'gd.tab_guide':    { fr: 'Guide', en: 'Guide' },
    'gd.tab_lex':      { fr: 'Lexique', en: 'Glossary' },
    'gd.tab_src':      { fr: 'Sources', en: 'Sources' },
    'gd.tab_anec':     { fr: 'Anecdotes', en: 'Anecdotes' },
    'gd.tab_apropos':  { fr: 'À propos', en: 'About' },
    'gd.ap_title':     { fr: 'Le projet', en: 'The project' },
    'gd.ap_desc':      { fr: "MyDope Off est un outil gratuit de réduction des risques, développé de façon indépendante, sans structure commerciale. Aucune donnée n'est collectée, aucune publicité n'est affichée.",
                         en: "MyDope Off is a free harm-reduction tool, developed independently, with no commercial structure behind it. No data is collected, no advertising is shown." },
    'gd.ap_support':   { fr: "Voir ce que contient le projet et comment le soutenir", en: "See what the project includes and how to support it" },
    'gd.ap_legal_title': { fr: 'Mentions légales', en: 'Legal notice' },
    'gd.ap_publisher_t': { fr: 'Éditeur', en: 'Publisher' },
    'gd.ap_publisher_d': { fr: "Projet individuel, indépendant, à but non commercial. Aucune société ni personne morale derrière ce site.",
                           en: "An independent, non-commercial individual project. No company or legal entity is behind this site." },
    'gd.ap_hosting_t': { fr: 'Hébergement', en: 'Hosting' },
    'gd.ap_hosting_d': { fr: "GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. St, San Francisco, CA 94107, États-Unis.",
                         en: "GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. St, San Francisco, CA 94107, USA." },
    'gd.ap_liability_t': { fr: 'Responsabilité', en: 'Liability' },
    'gd.ap_liability_d': { fr: "MyDope Off fournit une information générale de réduction des risques. Ce n'est ni un avis médical, ni un avis juridique, ni un avis psychologique. En cas d'urgence, contacte toujours les secours de ton pays.",
                           en: "MyDope Off provides general harm-reduction information. It is not medical, legal, or psychological advice. In an emergency, always contact your country's emergency services." },
    'gd.ap_contact_title': { fr: 'Contact', en: 'Contact' },
    'gd.ap_contact_desc': { fr: "Un bug, une idée, une source à corriger ?", en: "A bug, an idea, a source to fix?" },
    'gd.ap_contact_link_t': { fr: "Ouvrir un signalement sur GitHub", en: "Open an issue on GitHub" },
    'gd.ap_contact_link_d': { fr: "Réponse publique, visible par tous", en: "Public reply, visible to everyone" },
    'gd.ap_sources_title': { fr: 'Sources générales', en: 'General sources' },
    'gd.ap_sources_desc': { fr: "Toutes les sources utilisées dans MyDope Off, dossier par dossier, ainsi que les liens vers les organismes officiels, sont réunies dans l'onglet Sources de cette page.",
                            en: "Every source used in MyDope Off, file by file, along with links to the official organisations, is gathered in this page's Sources tab." },
    'gd.ap_sources_btn': { fr: "Aller à l'onglet Sources", en: "Go to the Sources tab" },
    'gd.intro':        { fr: "MyDope Off rassemble des informations scientifiques et des outils pour comprendre les substances et réduire les risques. Tout fonctionne hors-ligne et reste sur ton téléphone.",
                         en: "MyDope Off gathers scientific information and tools to understand substances and reduce risks. Everything works offline and stays on your phone." },
    'gd.spaces':       { fr: 'Les cinq espaces', en: 'The five spaces' },
    'gd.subs_desc':    { fr: "270 fiches détaillées et le vérificateur d'interactions. Cherche une substance pour voir risques, durée et précautions.",
                         en: "270 detailed entries and the interaction checker. Search a substance to see risks, duration and precautions." },
    'gd.ex_desc':      { fr: "Des tâches visuelles courtes (labyrinthe, etc.) qui aident à faire retomber une envie pressante en quelques minutes.",
                         en: "Short visual tasks (maze, etc.) that help a pressing urge subside within minutes." },
    'gd.track_desc':   { fr: "Ton journal, tes coûts, tes objectifs, et la durée de détection estimée par test.",
                         en: "Your journal, your costs, your goals, and the estimated detection time per test." },
    'gd.rdr_desc':     { fr: "Réduction des risques : numéros d'urgence, centres et bonnes pratiques.",
                         en: "Harm reduction: emergency numbers, centres and best practices." },
    'gd.journal_title':{ fr: 'Tenir ton journal en 3 gestes', en: 'Keep your journal in 3 steps' },
    'gd.j1_t':         { fr: 'Ajouter une entrée', en: 'Add an entry' },
    'gd.j1_d':         { fr: 'Suivi › Journal', en: 'Tracking › Journal' },
    'gd.j2_t':         { fr: 'Plusieurs entrées le même jour', en: 'Several entries the same day' },
    'gd.j2_d':         { fr: "Sur une journée déjà présente, touche « Ajouter à ce jour ». Tu peux empiler autant d'entrées que nécessaire sur la même date.",
                         en: "On a day already logged, tap \"Add to this day\". You can stack as many entries as needed on the same date." },
    'gd.j3_t':         { fr: 'Modifier ou supprimer', en: 'Edit or delete' },
    'gd.j3_d':         { fr: "Touche une entrée pour la rouvrir et la corriger, ou la croix pour la supprimer. Depuis le calendrier, touche un jour pour l'éditer directement.",
                         en: "Tap an entry to reopen and fix it, or the cross to delete it. From the calendar, tap a day to edit it directly." },
    'gd.detect_title': { fr: 'Comprendre la détection', en: 'Understanding detection' },
    'gd.detect_intro': { fr: "Quand tu choisis une substance, MyDope Off estime la fenêtre de détection selon trois types de test :",
                         en: "When you pick a substance, MyDope Off estimates the detection window for three test types:" },
    'gd.saliva':       { fr: 'Salive', en: 'Saliva' },
    'gd.saliva_d':     { fr: "Test oral rapide — fenêtre courte, reflète l'usage récent.", en: "Quick oral test — short window, reflects recent use." },
    'gd.urine':        { fr: 'Urine', en: 'Urine' },
    'gd.urine_d':      { fr: "Le plus répandu — fenêtre la plus longue, surtout en usage régulier.", en: "Most common — longest window, especially with regular use." },
    'gd.blood':        { fr: 'Sang', en: 'Blood' },
    'gd.blood_d':      { fr: "Fenêtre la plus courte — mais la plus précise sur le moment.", en: "Shortest window — but the most accurate in the moment." },
    'gd.backup_title': { fr: 'Sauvegarder tes données', en: 'Back up your data' },
    'gd.backup_desc':  { fr: "Tout reste uniquement sur ton téléphone — donc si tu vides le cache, changes de navigateur ou d'appareil, tout peut disparaître. Un export régulier te met à l'abri : depuis ton Profil, un bouton télécharge un fichier de sauvegarde, et un autre te permet de le restaurer.",
                         en: "Everything stays only on your phone — so clearing your cache or switching browser or device can wipe it all. A regular export keeps you safe: from your Profile, one button downloads a backup file, and another lets you restore it." },
    'gd.backup_link_t':{ fr: 'Aller dans Profil', en: 'Go to Profile' },
    'gd.backup_link_d':{ fr: 'Sauvegarder ou restaurer tes données', en: 'Back up or restore your data' },
    'gd.lex_title':    { fr: 'Lexique réduction des risques', en: 'Harm-reduction glossary' },
    'gd.lex_intro':    { fr: "Les termes scientifiques et le jargon que tu croises dans l'app et autour du sujet, expliqués simplement. Touche un mot pour dérouler.",
                         en: "The scientific terms and jargon you meet in the app and around the topic, explained simply. Tap a word to expand." },
    'gd.lex_note':     { fr: "Ce lexique est pédagogique et simplifié. Il ne remplace pas un avis médical.", en: "This glossary is educational and simplified. It does not replace medical advice." },
    'gd.src_title':    { fr: 'Sources & références', en: 'Sources & references' },
    'gd.src_intro':    { fr: "Chaque dossier et chaque outil de MyDope Off s'appuie sur des sources identifiables. Toutes sont réunies ici, au même endroit, pour que tu puisses les vérifier toi-même.",
                         en: "Every file and every tool in MyDope Off draws on identifiable sources. They're all gathered here, in one place, so you can check them yourself." },
    'gd.src_search':   { fr: "Rechercher une source, un dossier…", en: "Search a source, a topic…" },
    'gd.src_note':     { fr: "Le vérificateur d'interactions n'a pas de bibliographie publiée fiche par fiche — des références indépendantes pour vérifier sont indiquées à sa fiche.",
                         en: "The interaction checker doesn't have a published bibliography entry by entry — independent references to check against are listed on its own entry." },
    'gd.links_title':  { fr: 'Liens utiles', en: 'Useful links' },
    'gd.links_intro':  { fr: "Les sites officiels des organismes les plus cités dans MyDope Off — pour aller directement à la source.",
                         en: "The official websites of the organisations most cited in MyDope Off — to go straight to the source." },
    'gd.links_note':   { fr: "Liens externes, hors du contrôle de MyDope Off — leur contenu peut changer indépendamment de cette page.",
                         en: "External links, outside MyDope Off's control — their content may change independently of this page." },
    'gd.link_ofdt':    { fr: "Observatoire français des drogues et des tendances addictives", en: "French Monitoring Centre for Drugs and Drug Addiction" },
    'gd.link_mildeca': { fr: "Mission interministérielle de lutte contre les drogues et les conduites addictives", en: "French interministerial mission against drugs and addictive behaviours" },
    'gd.link_euda':    { fr: "Agence de l'Union européenne sur les drogues", en: "European Union Drugs Agency" },
    'gd.link_samhsa':  { fr: "Agence fédérale américaine (santé mentale et addictions)", en: "US federal agency (mental health and substance use)" },
    'gd.link_nida':    { fr: "Institut américain sur l'abus de drogues", en: "US National Institute on Drug Abuse" },
    'gd.link_catie':   { fr: "Référence canadienne sur le VIH et l'hépatite C, dont la réduction des risques liée au tabagisme de substances", en: "Canadian reference on HIV and hepatitis C, including harm reduction for smoking substances" },
    'gd.link_tripsit': { fr: "Combinateur d'interactions entre substances, référence indépendante du secteur RDR", en: "Substance interaction checker, an independent reference in the harm reduction field" },
    'gd.link_pnw':     { fr: "Encyclopédie communautaire sourcée sur les substances psychoactives", en: "Community-sourced encyclopedia on psychoactive substances" },
    'gd.link_dis':     { fr: "Ligne d'écoute et d'information française, anonyme et gratuite", en: "French helpline and information line, anonymous and free" },
    'gd.link_modus':   { fr: "Association bruxelloise de réduction des risques, déjà citée comme ressource dans le site", en: "Brussels-based harm reduction association, already cited as a resource on this site" },
    'gd.link_feda':    { fr: "Réseau français des acteurs de l'addictologie et de la réduction des risques", en: "French network of addiction and harm reduction professionals" },
    'gd.anec_title':   { fr: "Anecdotes — toutes les régions", en: "Anecdotes — all regions" },
    'gd.anec_intro':   { fr: "Celles que la mascotte glisse au fil de « Faire le point » — surprenantes, peu connues, toujours sourcées. Ta région est mise en avant en premier si elle est couverte.", en: "The ones the mascot slips into \"Check-in\" — surprising, little-known, always sourced. Your region is highlighted first if covered." },
    'gd.anec_search':  { fr: "Rechercher une anecdote…", en: "Search an anecdote…" },
    'gd.anec_note':    { fr: "Les jonctions entre régions relient deux faits déjà sourcés — jamais une information inventée pour combler un rapprochement.", en: "Cross-region links connect two already-sourced facts — never invented information to fill a gap." },
    'gd.data_title':   { fr: 'Tes données', en: 'Your data' },
    'gd.support':      { fr: 'Soutenir le projet', en: 'Support the project' },
    'gd.lex_search':   { fr: 'Rechercher un terme…', en: 'Search a term…' },
    'gd.lex_empty':    { fr: 'Aucun terme ne correspond.', en: 'No matching term.' },
    // Page Substances (psychochecker) — interface
    'ps.subtag':       { fr: '270 substances', en: '270 substances' },
    'ps.checker_intro':{ fr: 'Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Enter 2 or 3 substances — every pair will be analysed.' },
    'ps.recognized':   { fr: 'Noms reconnus : Valium, Xanax, Coke, MDMA, Éthanol…', en: 'Recognised names: Valium, Xanax, Coke, MDMA, Ethanol…' },
    'ps.sub1':         { fr: 'Substance 1', en: 'Substance 1' },
    'ps.sub2':         { fr: 'Substance 2', en: 'Substance 2' },
    'ps.sub3':         { fr: 'Substance 3 (optionnel)', en: 'Substance 3 (optional)' },
    'ps.analyze':      { fr: 'Analyser les interactions', en: 'Check interactions' },
    'ps.result_empty': { fr: 'Saisir au moins 2 substances pour voir les interactions documentées.', en: 'Enter at least 2 substances to see documented interactions.' },
    'ps.tab_classic':  { fr: 'Substances classiques', en: 'Classic substances' },
    'ps.tab_canna':    { fr: 'Cannabinoïdes', en: 'Cannabinoids' },
    'ps.search':       { fr: 'Rechercher…', en: 'Search…' },
    'ps.all_classes':  { fr: 'Toutes classes', en: 'All classes' },
    'ps.cl_stimulant': { fr: 'Stimulant', en: 'Stimulant' },
    'ps.cl_depressant':{ fr: 'Dépresseur', en: 'Depressant' },
    'ps.cl_opioid':    { fr: 'Opioïde', en: 'Opioid' },
    'ps.cl_psyche':    { fr: 'Psychédélique', en: 'Psychedelic' },
    'ps.cl_dissoc':    { fr: 'Dissociatif', en: 'Dissociative' },
    'ps.cl_enta':      { fr: 'Entactogène', en: 'Entactogen' },
    'ps.addiction':    { fr: 'Addiction', en: 'Addiction' },
    'ps.effects':      { fr: 'Effets', en: 'Effects' },
    'ps.dose':         { fr: 'Dosage', en: 'Dosage' },
    'ps.duration':     { fr: 'Durée', en: 'Duration' },
    'ps.dose_low':     { fr: 'Faible', en: 'Low' },
    'ps.dose_mod':     { fr: 'Modéré', en: 'Moderate' },
    'ps.dose_high':    { fr: 'Fort', en: 'Strong' },
    'ps.danger_label': { fr: 'Danger', en: 'Risk' },
    'ps.no_result':    { fr: 'Aucun résultat', en: 'No results' },
    'ps.count_subs':   { fr: '{n} substances', en: '{n} substances' },
    'ps.testimony':    { fr: 'Témoignage', en: 'Report' },
    'ps.info':         { fr: 'Info', en: 'Info' },
    'ps.none_found':   { fr: 'Aucune substance trouvée.', en: 'No substance found.' },
    'ps.footer':       { fr: 'Réduction des risques', en: 'Harm reduction' },
    // Jeux (maze + tetris)
    'gm.back':         { fr: 'Retour', en: 'Back' },
    'gm.maze_title':   { fr: 'Labyrinthe', en: 'Maze' },
    'gm.maze_intro':   { fr: "12 niveaux · Incline le téléphone pour déplacer la bille jusqu'à la cible.", en: "12 levels · Tilt your phone to roll the ball to the target." },
    'gm.ready_round':  { fr: 'Prêt pour la manche ?', en: 'Ready for the round?' },
    'gm.maze_ready_d': { fr: 'La bille apparaît en haut à gauche. La cible rouge est en bas à droite.', en: 'The ball starts top-left. The red target is bottom-right.' },
    'gm.gyro_wait':    { fr: 'Gyro en attente…', en: 'Gyro waiting…' },
    'gm.give_up':      { fr: 'Abandonner', en: 'Give up' },
    'gm.level':        { fr: 'Niveau', en: 'Level' },
    'gm.time':         { fr: 'Temps', en: 'Time' },
    'gm.penalties':    { fr: 'Pénalités', en: 'Penalties' },
    'gm.score':        { fr: 'Score', en: 'Score' },
    'gm.gyro_on':      { fr: 'Gyro actif', en: 'Gyro on' },
    'gm.hold_move':    { fr: 'Maintiens pour déplacer la bille', en: 'Hold to move the ball' },
    'gm.round':        { fr: 'Manche', en: 'Round' },
    'gm.next_level':   { fr: 'Niveau suivant →', en: 'Next level →' },
    'gm.restart':      { fr: 'Recommencer depuis le début', en: 'Restart from the beginning' },
    'gm.maze_done':    { fr: 'Labyrinthe complété !', en: 'Maze completed!' },
    'gm.maze_done_d':  { fr: 'Tu as activé cervelet, cortex pariétal et système vestibulaire.', en: 'You activated the cerebellum, parietal cortex and vestibular system.' },
    'gm.replay':       { fr: 'Rejouer', en: 'Play again' },
    'gm.home':         { fr: "Retour à l'accueil", en: 'Back to home' },
    'gm.start':        { fr: 'Commencer', en: 'Start' },
    'gm.ready':        { fr: 'Prêt ?', en: 'Ready?' },
    'gm.tetris_title': { fr: 'Tetris anti-craving', en: 'Anti-craving Tetris' },
    'gm.tetris_intro': { fr: "Complète des lignes pendant 3 minutes. Chaque palier de 10 lignes accélère la chute. L'objectif n'est pas le score : c'est d'occuper ton esprit.", en: "Clear lines for 3 minutes. Every 10 lines speeds up the fall. The goal isn't the score — it's to occupy your mind." },
    'gm.lines':        { fr: 'Lignes', en: 'Lines' },
    'gm.urge':         { fr: "Intensité de l'envie", en: 'Urge intensity' },
    'gm.tetris_ctrl':  { fr: 'Glisse sur la grille : ← → déplacer · tap = pivoter · ↓ chute rapide', en: 'Swipe on the grid: ← → move · tap = rotate · ↓ fast drop' }
  };

  function lang() {
    let l = null;
    try { l = localStorage.getItem(LANG_KEY); } catch (e) {}
    if (l && LANGS.indexOf(l) !== -1) return l;
    const nav = (navigator.language || 'fr').slice(0, 2).toLowerCase();
    return LANGS.indexOf(nav) !== -1 ? nav : 'fr';
  }

  function setLang(l) {
    if (LANGS.indexOf(l) === -1) return;
    try { localStorage.setItem(LANG_KEY, l); } catch (e) {}
    applyI18n();
    document.documentElement.setAttribute('lang', l);
    // notifier les pages qui ont du contenu dynamique à re-rendre
    document.dispatchEvent(new CustomEvent('langchange', { detail: { lang: l } }));
  }

  function t(keyOrObj, vars) {
    const l = lang();
    let s;
    if (keyOrObj && typeof keyOrObj === 'object') {
      // objet {fr,en,es,de} fourni directement
      s = keyOrObj[l] || keyOrObj.fr || '';
    } else {
      const entry = DICT[keyOrObj];
      s = entry ? (entry[l] || entry.fr) : keyOrObj;
    }
    if (vars) Object.keys(vars).forEach(k => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }

  /* Traduit tous les éléments porteurs d'attributs i18n */
  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      if (DICT[k]) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const k = el.getAttribute('data-i18n-html');
      if (DICT[k]) el.innerHTML = t(k);
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const k = el.getAttribute('data-i18n-ph');
      if (DICT[k]) el.setAttribute('placeholder', t(k));
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const k = el.getAttribute('data-i18n-aria');
      if (DICT[k]) el.setAttribute('aria-label', t(k));
    });
    // re-render nav (libellés traduits)
    const navEl = document.querySelector('.bottom-nav');
    if (navEl && navEl.getAttribute('data-page') !== null) {
      navEl.outerHTML = renderNav(navEl.getAttribute('data-page') || '');
    }
  }

  /* Sélecteur de langue : remplit tout [data-langselect] */
  function renderLangSelect() {
    document.querySelectorAll('[data-langselect]').forEach(host => {
      const cur = lang();
      host.innerHTML = '<div class="lang-select" style="display:inline-flex;gap:4px;background:var(--soft,#FBF8F1);padding:4px;border-radius:11px;">' +
        LANGS.map(l => '<button type="button" data-setlang="' + l + '" style="border:none;cursor:pointer;font-family:var(--font-editorial,Atkinson Hyperlegible Next,sans-serif);font-weight:var(--w-bold,700);font-size:var(--fs-xs,12px);padding:6px 11px;border-radius:8px;background:' +
          (l === cur ? 'var(--surface)' : 'transparent') + ';color:' + (l === cur ? 'var(--foret)' : 'var(--ink-2)') +
          (l === cur ? ';box-shadow:0 1px 3px rgba(31,43,37,.08)' : '') + ';">' + l.toUpperCase() + '</button>').join('') +
        '</div>';
      host.querySelectorAll('[data-setlang]').forEach(b => {
        b.addEventListener('click', () => { setLang(b.getAttribute('data-setlang')); renderLangSelect(); });
      });
    });
  }

  function user() {
    try { return (JSON.parse(localStorage.getItem(KEY)) || {}).user || null; }
    catch (e) { return null; }
  }

  function qs() {
    const u = user();
    if (!u || !u.name) return '';
    return '';
  }

  function link(href) {
    const q = qs();
    if (!q) return href;
    const i = href.indexOf('#');
    return i === -1 ? href + q : href.slice(0, i) + q + href.slice(i);
  }

  function logoSVG(size, mono) {
    size = size || 32;
    const ring = mono ? '#fff' : '#33463E';
    const bar  = mono ? '#fff' : '#1F2B25';
    return '<svg viewBox="0 0 48 48" width="' + size + '" height="' + size + '" fill="none" aria-label="MyDope Off">' +
      '<path d="M15.2 13.6a14 14 0 1 0 17.6 0" stroke="' + ring + '" stroke-width="5" stroke-linecap="round"/>' +
      '<line x1="24" y1="6" x2="24" y2="22" stroke="' + bar + '" stroke-width="5" stroke-linecap="round"/>' +
      '</svg>';
  }

  function appIcon(size) {
    size = size || 56;
    return '<span style="display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;border-radius:' + Math.round(size * .28) + 'px;background:linear-gradient(140deg,#33463E,#283A31);box-shadow:0 6px 18px rgba(51,70,62,.28);">' +
      logoSVG(Math.round(size * .56), true) + '</span>';
  }

  function wordmark() {
    return '<span style="font-family:var(--font-editorial,Atkinson Hyperlegible Next,sans-serif);font-weight:var(--w-medium,800);letter-spacing:var(--ls-title,-.02em);color:var(--ink,#1F2B25);white-space:nowrap;">MyDope <b style="color:var(--foret,#33463E);font-weight:var(--w-medium,800);">Off</b></span>';
  }

  /* Navigation — libellés via clés i18n */
  const NAV = [
    { k: 'index', href: 'index.html', tkey: 'nav.home',
      icon: '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { k: 'suivi', href: 'suivi.html', tkey: 'nav.tracking',
      icon: '<path d="M22 7L13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>' },
    { k: 'psychochecker', href: 'psychochecker.html', tkey: 'nav.substances',
      icon: '<path d="M11 11m-8 0a8 8 0 1 0 16 0 8 8 0 1 0-16 0"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' },
    { k: 'fiches', href: 'fiches.html', tkey: 'nav.protocols',
      icon: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
    { k: 'rdr', href: 'rdr.html', tkey: 'nav.rdr',
      icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
  ];

  function renderNav(active){ return window.MDNav ? MDNav.render(active||'') : ''; }

  function init(opts) {
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());

    document.querySelectorAll('[data-logo]').forEach(el => {
      el.innerHTML = logoSVG(parseInt(el.getAttribute('data-logo')) || 32, el.hasAttribute('data-mono'));
    });
    document.querySelectorAll('[data-appicon]').forEach(el => {
      el.innerHTML = appIcon(parseInt(el.getAttribute('data-appicon')) || 56);
    });
    document.querySelectorAll('[data-wordmark]').forEach(el => { el.innerHTML = wordmark(); });

    const nav = document.querySelector('[data-nav]');
    if (nav) if (nav && window.MDNav) nav.outerHTML = renderNav(opts.page || '');

    document.querySelectorAll('[data-go]').forEach(a => {
      a.setAttribute('href', link(a.getAttribute('data-go')));
    });

    document.querySelectorAll('[data-back]').forEach(b => {
      b.addEventListener('click', () => {
        if (window.history.length > 1 && document.referrer && document.referrer.indexOf(location.origin) === 0) {
          window.history.back();
        } else {
          location.href = link('index.html');
        }
      });
    });

    applyI18n();
    renderLangSelect();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  return { user, qs, link, logoSVG, appIcon, wordmark, renderNav, init,
           t, lang, setLang, applyI18n, renderLangSelect, LANGS, LANG_NAMES, DICT };
})();

/* ---- bloc suivant ---- */

/* ===== LEXIQUE RDR ===== */
const LEXIQUE = [
  ["Réduction des risques (RDR)","approche","Ensemble de pratiques visant à diminuer les dommages liés à un usage de drogues sans forcément exiger l'arrêt : tester son produit, ne pas être seul·e, doser, espacer. On part de la personne là où elle en est."],
  ["Agoniste","pharmacologie","Molécule qui active un récepteur du corps pour produire un effet (ex. un opioïde agoniste des récepteurs mu produit l'analgésie et l'euphorie). Un agoniste « complet » active à fond, un « partiel » seulement en partie."],
  ["Antagoniste","pharmacologie","Molécule qui bloque un récepteur sans l'activer. La naloxone est un antagoniste des opioïdes : elle déloge l'opioïde et stoppe l'overdose."],
  ["Récepteur","pharmacologie","Serrure biologique sur les cellules. Les substances agissent comme des clés qui ouvrent (agonistes) ou bloquent (antagonistes) ces serrures (ex. récepteurs 5-HT2A pour les psychédéliques, mu pour les opioïdes, GABA pour les sédatifs)."],
  ["Demi-vie","pharmacologie","Temps que met le corps à éliminer la moitié d'une substance. Une demi-vie longue = effets et risques d'accumulation prolongés (important pour le redose et les interactions)."],
  ["Onset","durée","Délai avant l'apparition des premiers effets après la prise. Une montée lente pousse parfois à reprendre trop tôt (« redose »), d'où des surdoses."],
  ["Plateau","durée","Phase où les effets sont à leur maximum et stables, avant la descente."],
  ["Biodisponibilité","pharmacologie","Fraction de la dose qui atteint réellement la circulation selon la voie (avaler, sniffer, fumer, injecter). Une même dose n'a pas le même effet selon la voie."],
  ["Tolérance","usage","Besoin d'augmenter la dose pour retrouver le même effet, car le corps s'adapte. La tolérance croisée touche des substances de la même famille."],
  ["Dépendance","usage","État où l'arrêt provoque un manque physique (sevrage) et/ou psychique (craving). Différente de l'addiction, qui inclut la perte de contrôle malgré les conséquences."],
  ["Craving","usage","Envie irrépressible de consommer. Les exercices courts de l'app visent à occuper l'esprit le temps qu'une vague de craving redescende."],
  ["Sevrage","usage","Ensemble des symptômes à l'arrêt d'une substance dont on est dépendant. Pour l'alcool et les benzodiazépines, le sevrage brutal peut être dangereux (convulsions) et doit être encadré."],
  ["Redose","usage","Reprendre une dose pendant que la précédente agit encore. Source fréquente de surdose, surtout quand la montée est lente (on croit que « ça ne marche pas »)."],
  ["Surdose / overdose","risque","Dose qui dépasse ce que le corps tolère. Pour les opioïdes, elle se traduit par une dépression respiratoire (la respiration ralentit puis s'arrête)."],
  ["Dépression respiratoire","risque","Ralentissement dangereux de la respiration, principal mécanisme de décès par opioïdes et par mélanges de dépresseurs (alcool + benzo + opioïde)."],
  ["Naloxone","RDR","Antidote des opioïdes (spray nasal ou injection) qui inverse temporairement une overdose. N'agit pas sur les non-opioïdes (xylazine, benzos). À garder à portée si on est concerné."],
  ["Dépresseur","famille","Substance qui ralentit le système nerveux (alcool, benzodiazépines, GHB, opioïdes). Cumuler deux dépresseurs additionne le risque respiratoire."],
  ["Stimulant","famille","Substance qui accélère le système nerveux (cocaïne, amphétamines, cathinones). Risques cardiovasculaires, hyperthermie, redose compulsif."],
  ["Opioïde","famille","Substance agissant sur les récepteurs opioïdes (héroïne, morphine, fentanyl, nitazènes). Analgésie et euphorie, mais dépression respiratoire mortelle en cas de surdose."],
  ["Psychédélique","famille","Substance modifiant la perception via les récepteurs 5-HT2A (LSD, psilocybine, mescaline, 2C-B). Risque surtout psychologique (bad trip) et d'interactions."],
  ["Dissociatif","famille","Substance qui « déconnecte » le corps et l'esprit (kétamine, MXE, PCP). Risque de chutes, de fausses routes en cas de vomissement, et de cystite à usage répété."],
  ["Empathogène / entactogène","famille","Substance qui amplifie l'empathie et le lien (MDMA et apparentés). Risques : hyperthermie, déshydratation, contre-coup sérotoninergique."],
  ["Cathinone","famille","Stimulants de synthèse dérivés de la cathinone du khat (méphédrone, MDPV, alpha-PVP). Souvent vendus sous le nom « sels de bain ». Redose compulsif, charge cardiaque."],
  ["Cannabinoïde de synthèse","famille","Molécules imitant le THC mais souvent bien plus puissantes et dangereuses (« noids » type ADB-, MDMB-). Réparties inégalement sur l'herbe : dosage imprévisible."],
  ["Delirant / anticholinergique","famille","Substances provoquant un vrai délire confus et dangereux (datura, belladone, forte dose de certains antihistaminiques). Très différentes des psychédéliques, et toxiques."],
  ["IMAO","pharmacologie","Inhibiteur de la monoamine oxydase : bloque une enzyme qui dégrade la sérotonine et d'autres messagers. Présent dans l'ayahuasca. Interactions potentiellement mortelles (MDMA, certains stimulants, antidépresseurs, tyramine)."],
  ["ISRS / IRSNa","médicament","Antidépresseurs courants (fluoxétine, sertraline, venlafaxine…) qui augmentent la sérotonine. Atténuent souvent les effets de la MDMA et exposent au syndrome sérotoninergique avec d'autres sérotoninergiques."],
  ["Syndrome sérotoninergique","risque","Excès dangereux de sérotonine (agitation, tremblements, fièvre, rigidité, parfois mortel). Survient en cumulant des substances sérotoninergiques, surtout avec un IMAO."],
  ["Speedball","risque","Mélange d'un stimulant et d'un opioïde. Le stimulant masque la dépression respiratoire de l'opioïde : la surdose frappe quand le stimulant retombe."],
  ["Cocaéthylène","risque","Substance cardiotoxique formée quand cocaïne et alcool sont pris ensemble. Plus durable et plus dur pour le cœur que la cocaïne seule."],
  ["Tranq","produit","Surnom de la xylazine, sédatif vétérinaire qui contamine le fentanyl. La naloxone ne lève pas sa sédation et elle provoque des plaies nécrotiques."],
  ["Lean / purple drank","produit","Sirop codéine + prométhazine mélangé à du soda. Dépression respiratoire potentialisée, surtout avec alcool ou benzos."],
  ["Nitazène","produit","Famille d'opioïdes de synthèse très puissants (iso-, méto-, protonitazène), parfois plus que le fentanyl. Marge dose/overdose minuscule."],
  ["Fenêtre de détection","test","Durée pendant laquelle une substance reste repérable par un test (salive, urine, sang). Varie selon la substance, la dose, la fréquence et le métabolisme."],
  ["Métabolite","pharmacologie","Produit de transformation d'une substance par le corps. Certains tests détectent les métabolites bien après la disparition des effets."],
  ["Adultérant / produit de coupe","risque","Substance ajoutée pour augmenter le volume ou l'effet d'une drogue. Parfois plus dangereuse que le produit attendu (ex. fentanyl dans l'héroïne, lévamisole dans la cocaïne)."],
  ["Analyse de produit (drug checking)","RDR","Faire tester la composition réelle de son produit (bandelettes, services spécialisés). La seule façon de savoir ce qu'on a vraiment entre les mains."],
  ["Sitter","RDR","Personne sobre et de confiance qui veille sur quelqu'un sous l'effet d'une substance, surtout pour les psychédéliques et dissociatifs."],
  ["Set and setting","RDR","L'état d'esprit (set) et l'environnement (setting) dans lesquels on consomme. Déterminants majeurs de la qualité et de la sécurité d'une expérience psychédélique."],
  ["Bad trip","risque","Expérience psychédélique difficile (angoisse, panique, paranoïa). Atténuée par un bon set and setting, un sitter, et le fait de ne pas lutter contre."],
  ["RC (research chemical)","produit","« Produit de recherche » : nouvelle molécule de synthèse vendue pour contourner la loi, souvent mal connue, aux risques peu documentés."],
  ["NPS","produit","Nouvelles substances psychoactives : terme officiel pour la vague de molécules récentes (cathinones, cannabinoïdes de synthèse, nitazènes…) apparaissant plus vite que les législations."],
  ["Vasoconstriction","risque","Resserrement des vaisseaux sanguins (fréquent avec certains stimulants et psychédéliques type DOx). À forte dose ou usage répété, risque pour les extrémités et le cœur."],
  ["Hyperthermie","risque","Montée dangereuse de la température corporelle, fréquente avec MDMA et stimulants, aggravée par la danse, la chaleur et le manque d'eau. Peut être mortelle."],
  ["Mémoire de travail","cerveau","Capacité à garder et manipuler des informations en tête sur quelques secondes à minutes. La saturer avec une tâche visuospatiale (comme le Tetris) laisse moins de place à l'imagerie mentale d'un craving — d'où l'effet mesuré du « paradigme Tetris » (Oxford, 2015)."],
  ["Urge surfing","cerveau","Technique qui consiste à observer une envie sans y céder ni la combattre, en sachant qu'elle monte, culmine puis redescend toujours — comme une vague. Formalisée par le psychologue Alan Marlatt."],
  ["Effet Stroop","cerveau","Difficulté à ignorer une information automatique (comme lire un mot) pour répondre à une autre (comme sa couleur d'encre). Sert à mesurer et entraîner le contrôle attentionnel — la capacité à filtrer un automatisme."],
  ["Flexibilité cognitive","cerveau","Capacité à changer de règle ou de stratégie quand le contexte change, plutôt que de rester sur un automatisme. À l'inverse, la rigidité mentale nourrit les rituels de consommation."],
  ["Delay discounting","cerveau","Tendance à sous-évaluer une récompense future par rapport à une récompense immédiate plus petite. Plus ce biais est marqué, plus l'impulsivité — et le risque addictif — sont élevés."],
  ["Cohérence cardiaque","cerveau","État où le rythme cardiaque et la respiration se synchronisent, obtenu en respirant à un rythme lent et régulier (environ 6 cycles/minute). Active le système parasympathique et fait retomber le stress."],
  ["Système parasympathique","cerveau","Partie du système nerveux qui ralentit le corps et favorise le calme, à l'inverse du système sympathique qui l'active. Le nerf vague en est un acteur central."],
  ["Circuit de la récompense","cerveau","Réseau cérébral, impliquant la dopamine, qui motive à rechercher une récompense. Les substances le détournent ; des petits plaisirs du quotidien, vécus et savourés, peuvent le réentraîner à répondre à la vie sans elles."],
];

(function(){
  const box=document.getElementById('lexique');
  const search=document.getElementById('lx-search');
  if(!box) return;
  function L(){ return window.LUCIDE ? LUCIDE.lang() : 'fr'; }
  // Liste localisée : EN/ES/DE depuis LUCIDE_LEX_I18N (même ordre), sinon FR
  function localized(){
    const l=L();
    if(l==='fr') return LEXIQUE;
    const dict=(window.LUCIDE_LEX_I18N||{})[l];
    if(!dict) return LEXIQUE;
    return LEXIQUE.map((row,i)=> dict[i] ? dict[i] : row);
  }
  function emptyMsg(){ return window.LUCIDE ? LUCIDE.t('gd.lex_empty') : 'Aucun terme ne correspond.'; }
  function render(q){
    q=(q||'').trim().toLowerCase();
    const items=localized().filter(([t,,d])=> !q || t.toLowerCase().includes(q) || d.toLowerCase().includes(q))
      .sort((a,b)=>a[0].localeCompare(b[0],L()));
    if(!items.length){ box.innerHTML='<div class="lx-empty">'+emptyMsg()+'</div>'; return; }
    box.innerHTML=items.map(([t,tag,d])=>
      '<details class="lx-item"><summary><span>'+t+'<span class="lx-tag">'+tag+'</span></span>'+
      '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></summary>'+
      '<div class="lx-body">'+d+'</div></details>').join('');
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
  document.addEventListener('langchange',()=>render(search?search.value:''));
})();

/* ===== SOURCES & RÉFÉRENCES — un dossier par ligne, FR+EN co-localisés (volume modeste,
   pas besoin d'un fichier i18n séparé comme pour le lexique) ===== */
const SOURCES = [
  { t:"Alcool", href:"alcool.html",
    fr:"Sources : CEN Neurologie (complications neurologiques de l'alcoolisme) · Manuel MSD, édition professionnelle · ScienceDirect (Delirium tremens, mise au point) · Santé sur le Net.",
    en:"Sources: CEN Neurology (neurological complications of alcoholism) · MSD Manual, professional edition · ScienceDirect (Delirium tremens, review) · Santé sur le Net." },
  { t:"Auto-sabotage", href:"autosabotage.html",
    fr:"Sources principales : Berglas & Jones (1978, Journal of Personality and Social Psychology) · Baumeister (1990, Psychological Review) · Baumeister & Scher (1988, Psychological Bulletin) · Marlatt & Gordon (1985) · Khantzian (1997, Harvard Review of Psychiatry) · Kirchner, Shiffman & Wileyto (2011) · Gollwitzer (1999, American Psychologist) · Gollwitzer & Sheeran (2006) · Oettingen (2014). Bibliographie complète dans le mémoire de référence.",
    en:"Main sources: Berglas & Jones (1978, Journal of Personality and Social Psychology) · Baumeister (1990, Psychological Review) · Baumeister & Scher (1988, Psychological Bulletin) · Marlatt & Gordon (1985) · Khantzian (1997, Harvard Review of Psychiatry) · Kirchner, Shiffman & Wileyto (2011) · Gollwitzer (1999, American Psychologist) · Gollwitzer & Sheeran (2006) · Oettingen (2014). Full bibliography in the reference dissertation." },
  { t:"Benzodiazépines", href:"benzodiazepines.html",
    fr:"Sources : ANSM, décision du 10/07/2025 · Conseil National de l'Ordre des Pharmaciens · Addict Aide, RESPADD (juin 2025) · Pharmacovigilance Île-de-France.",
    en:"Sources: ANSM, decision of 10/07/2025 · French National Council of the Order of Pharmacists · Addict Aide, RESPADD (June 2025) · Île-de-France Pharmacovigilance." },
  { t:"Cannabis", href:"cannabis.html",
    fr:"Sources : info.gouv.fr (entretien addictologue, 2025) · Centre d'Addictovigilance (alerte edibles, avril 2025) · ANSES/ANSM (alerte CBD, juin 2025) · Agence régionale de santé Occitanie · Stop-Cannabis.ch (revue de littérature sur le THC).",
    en:"Sources: info.gouv.fr (interview with an addiction specialist, 2025) · Addictovigilance Centre (edibles alert, April 2025) · ANSES/ANSM (CBD alert, June 2025) · Occitanie Regional Health Agency · Stop-Cannabis.ch (literature review on THC)." },
  { t:"Cocaïne", href:"cocaine.html",
    fr:"Sources : OFDT (janvier 2025) · Infirmiers.com, expertise collective · Revues Générales Cœur et addictions (Réalités Cardiologiques) · Manuel MSD grand public (avril 2025) · EUDA, European Drug Report 2025-2026 · PMC/NIH (revues sur le traitement du trouble de l'usage de cocaïne).",
    en:"Sources: OFDT (January 2025) · Infirmiers.com, collective expert review · Revues Générales Cœur et addictions (Réalités Cardiologiques) · MSD Manual consumer version (April 2025) · EUDA, European Drug Report 2025-2026 · PMC/NIH (reviews on the treatment of cocaine use disorder)." },
  { t:"Crack", href:"crack.html",
    fr:"Sources : mécanisme dopaminergique et risques cardiovasculaires — mêmes références que le dossier Cocaïne (OFDT, EUDA, PMC/NIH) · matériel d'inhalation à moindre risque — CATIE (Canada) et National Harm Reduction Coalition · histoire du ratio de peines 100 pour 1 — Anti-Drug Abuse Act (1986), Fair Sentencing Act (2010).",
    en:"Sources: dopaminergic mechanism and cardiovascular risks — same references as the Cocaine file (OFDT, EUDA, PMC/NIH) · lower-risk smoking equipment — CATIE (Canada) and the National Harm Reduction Coalition · history of the 100-to-1 sentencing ratio — Anti-Drug Abuse Act (1986), Fair Sentencing Act (2010)." },
  { t:"Environnement & nature", href:"environnement.html",
    fr:"Sources principales : Alexander, Coambs & Hadaway (1978, Psychopharmacology) · Robins, Davis & Nurco (1974, American Journal of Public Health) · Robins et coll. (2010, American Journal on Addictions) · Wikler · Siegel (1983) · Stewart, de Wit & Eikelboom (1984, Psychological Review) · Bouton (2002, 2004) · Sinha (2001, Psychopharmacology) · Kaplan (1995, Journal of Environmental Psychology) · Ulrich et coll. (1991, Journal of Environmental Psychology) · Solinas et coll. (2008, PNAS ; 2009, Neuropsychopharmacology) · Bardo et coll. (2001). Bibliographie complète (32 références) dans le mémoire de référence.",
    en:"Main sources: Alexander, Coambs & Hadaway (1978, Psychopharmacology) · Robins, Davis & Nurco (1974, American Journal of Public Health) · Robins et al. (2010, American Journal on Addictions) · Wikler · Siegel (1983) · Stewart, de Wit & Eikelboom (1984, Psychological Review) · Bouton (2002, 2004) · Sinha (2001, Psychopharmacology) · Kaplan (1995, Journal of Environmental Psychology) · Ulrich et al. (1991, Journal of Environmental Psychology) · Solinas et al. (2008, PNAS; 2009, Neuropsychopharmacology) · Bardo et al. (2001). Full bibliography (32 references) in the reference dissertation." },
  { t:"MDMA", href:"mdma.html",
    fr:"Sources : Drogues Info Service · Manuel MSD grand public (avril 2025) · PsychoWiki/Psychoactif · GREA (Suisse) · NBC News, The Conversation (couverture de la décision FDA, août 2024) · PMC/NIH (revues sur la thérapie assistée par MDMA, 2025-2026).",
    en:"Sources: Drogues Info Service · MSD Manual consumer version (April 2025) · PsychoWiki/Psychoactif · GREA (Switzerland) · NBC News, The Conversation (coverage of the FDA decision, August 2024) · PMC/NIH (reviews on MDMA-assisted therapy, 2025-2026)." },
  { t:"Protoxyde d'azote", href:"nitreux.html",
    fr:"Sources : OFDT (données d'usage 2022-2025) · ANSM (signalements d'intoxications graves) · Légifrance (loi du 1ᵉʳ juin 2021) · Sénat (proposition de loi, février 2026) · projet de loi RIPOST (mars 2026, en discussion parlementaire au moment de la rédaction).",
    en:"Sources: OFDT (2022-2025 usage data) · ANSM (serious intoxication reports) · Légifrance (law of 1 June 2021) · French Senate (bill, February 2026) · RIPOST draft law (March 2026, under parliamentary debate at the time of writing)." },
  { t:"Opioïdes de synthèse", href:"opioides-synthese.html",
    fr:"Sources : OFDT (Sintes, fiche xylazine) · Agence européenne des drogues — EUDA, European Drug Report 2025-2026 · National Harm Reduction Coalition · Santé publique Ottawa · UC Davis Health.",
    en:"Sources: OFDT (Sintes, xylazine factsheet) · European Union Drugs Agency — EUDA, European Drug Report 2025-2026 · National Harm Reduction Coalition · Ottawa Public Health · UC Davis Health." },
  { t:"Polyconsommation", href:"polyconsommation.html",
    fr:"Sources : OFDT (données 2023, chiffres clés 2025) · ANPAA · F-N-A-S / CESPHARM · Nuit Blanche (Suisse) · Infodrog (fiche médicaments et polyconsommation, 2026) · Revol et coll., JAMA Network Open 2023 (registre DRAMES).",
    en:"Sources: OFDT (2023 data, key figures 2025) · ANPAA · F-N-A-S / CESPHARM · Nuit Blanche (Switzerland) · Infodrog (medicines and polydrug use factsheet, 2026) · Revol et al., JAMA Network Open 2023 (DRAMES register)." },
  { t:"Psychédéliques & micro-dosage", href:"psychedeliques.html",
    fr:"Sources : Szigeti et coll., eLife (2021, essai auto-aveuglé sur le micro-dosage) · Carhart-Harris et coll., New England Journal of Medicine (2021, psilocybine vs escitalopram) · Bogenschutz et coll., JAMA Psychiatry (2022, psilocybine et trouble de l'usage d'alcool) · décision FDA sur la MDMA (2024) · littérature sur les récepteurs 5-HT2B et valvulopathies · OFDT · MILDECA.",
    en:"Sources: Szigeti et al., eLife (2021, self-blinded microdosing trial) · Carhart-Harris et al., New England Journal of Medicine (2021, psilocybin vs escitalopram) · Bogenschutz et al., JAMA Psychiatry (2022, psilocybin and alcohol use disorder) · FDA decision on MDMA (2024) · literature on 5-HT2B receptors and valvulopathy · OFDT · MILDECA." },
  { t:"RDR vs abstinence", href:"rdr-vs-abstinence.html",
    fr:"Sources : MILDECA, « L'essentiel sur la réduction des risques et des dommages » · Évaluation INSERM des salles de Paris et Strasbourg (commande MILDECA) · Santé publique France, revue La Santé en action (juillet 2025) · ReachLink, revue comparative RDR/abstinence.",
    en:"Sources: MILDECA, \"The essentials on harm reduction\" · INSERM evaluation of the Paris and Strasbourg facilities (commissioned by MILDECA) · Santé publique France, La Santé en action review (July 2025) · ReachLink, comparative review of harm reduction and abstinence." },
  { t:"Rechute", href:"rechute.html",
    fr:"Sources : OFDT · Marlatt & Gordon (1985) · Kirchner, Shiffman & Wileyto (2011) · Tabac Info Service (statistiques de rechute tabagique) · Circea-addictions (fiche mémo rechute) · Fréquence Médicale (mécanismes neurologiques) · Option Zero.",
    en:"Sources: OFDT · Marlatt & Gordon (1985) · Kirchner, Shiffman & Wileyto (2011) · Tabac Info Service (smoking relapse statistics) · Circea-addictions (relapse briefing note) · Fréquence Médicale (neurological mechanisms) · Option Zero." },
  { t:"Tabac & vapotage", href:"tabac-vapotage.html",
    fr:"Sources : Institut national du cancer · MILDECA (drogues.gouv.fr) · Haut Conseil de Santé Publique, avis novembre 2021 · Loi n° 2025-175 du 24 février 2025 · Décret n° 2025-898 · Échosciences Grenoble · EditorialWeb (chiffres lycéens 2026).",
    en:"Sources: French National Cancer Institute · MILDECA (drogues.gouv.fr) · High Council for Public Health, opinion of November 2021 · Law no. 2025-175 of 24 February 2025 · Decree no. 2025-898 · Échosciences Grenoble · EditorialWeb (secondary school figures 2026)." },
  { t:"Vérificateur d'interactions", href:"psychochecker.html",
    fr:"S'appuie sur la littérature clinique disponible plutôt que sur des témoignages — chaque fiche n'a pas de bibliographie individuelle publiée. Pour vérifier une interaction de façon indépendante : le combinateur de TripSit (tripsit.me/combo) et PsychonautWiki (psychonautwiki.org) sont des références de référence dans le champ RDR.",
    en:"Draws on available clinical literature rather than anecdotal reports — individual entries do not each carry a published bibliography. To check an interaction independently: the TripSit combination tool (tripsit.me/combo) and PsychonautWiki (psychonautwiki.org) are standard reference points in the harm reduction field." },
  { t:"Fenêtres de détection", href:"detection.html",
    fr:"Sources : SAMHSA Oral Fluid Mandatory Guidelines (2023) · manuel SAMHSA de prélèvement salivaire (2024) · Cone & Huestis (2007) · Verstraete (2004) · NIDA.",
    en:"Sources: SAMHSA Oral Fluid Mandatory Guidelines (2023) · SAMHSA Oral Fluid Specimen Collection Handbook (2024) · Cone & Huestis (2007) · Verstraete (2004) · NIDA." },
];

(function(){
  const box=document.getElementById('sources');
  const search=document.getElementById('src-search');
  if(!box) return;
  function L(){ return window.LUCIDE ? LUCIDE.lang() : 'fr'; }
  function emptyMsg(){ return window.LUCIDE ? LUCIDE.t('gd.lex_empty') : 'Aucun terme ne correspond.'; }
  function render(q){
    q=(q||'').trim().toLowerCase();
    const l=L();
    const items=SOURCES.map(s=>({ t:s.t, href:s.href, d: l==='en' ? s.en : s.fr }))
      .filter(s=> !q || s.t.toLowerCase().includes(q) || s.d.toLowerCase().includes(q))
      .sort((a,b)=>a.t.localeCompare(b.t,l));
    if(!items.length){ box.innerHTML='<div class="lx-empty">'+emptyMsg()+'</div>'; return; }
    box.innerHTML=items.map(s=>
      '<div class="card card-pad" style="margin-bottom:10px">'+
      '<a href="'+s.href+'" style="font-family:var(--font-editorial);font-weight:var(--w-medium);font-size:var(--fs-sm);color:var(--ink);text-decoration:underline">'+s.t+'</a>'+
      '<p class="note-sm m0" style="margin-top:4px">'+s.d+'</p></div>'
    ).join('');
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
  document.addEventListener('langchange',()=>render(search?search.value:''));
})();

/* ===== ANECDOTES — toutes régions ===== */
(function(){
  const box=document.getElementById('anecdotes');
  const search=document.getElementById('an-search');
  if(!box || !window.MDAnecdotes) return;

  function myRegion(){
    try{
      const o=JSON.parse(localStorage.getItem('ctc_v6')||'{}');
      const c=(o.user && o.user.region) || 'BE';
      return (window.MDRegions && window.MDRegions.exists && window.MDRegions.exists(c)) ? c : 'BE';
    }catch(e){ return 'BE'; }
  }
  function regionLabel(code){
    try{ return window.MDRegions ? window.MDRegions.get(code).label : code; }catch(e){ return code; }
  }

  function buildGroups(){
    const groups=[];
    const mine=myRegion();
    const regionCodes=Object.keys(window.MDAnecdotesRegion||{});

    if(window.MDAnecdotesRegion[mine]){
      groups.push({ key:'mine', label:'Ta région — '+regionLabel(mine), items:window.MDAnecdotesRegion[mine].map(a=>a.t) });
    }
    if(window.MDAnecdoteBridges){
      const bridges=Object.values(window.MDAnecdoteBridges).map(b=>b.t);
      if(bridges.length) groups.push({ key:'bridges', label:'Croisements entre régions', items:bridges });
    }
    regionCodes.filter(c=>c!==mine).sort((a,b)=>regionLabel(a).localeCompare(regionLabel(b),'fr')).forEach(code=>{
      groups.push({ key:'r-'+code, label:regionLabel(code), items:window.MDAnecdotesRegion[code].map(a=>a.t) });
    });
    groups.push({ key:'general', label:'Anecdotes générales', items:(window.MDAnecdotes||[]).map(a=>a.t) });
    return groups;
  }

  function emptyMsg(){ return 'Aucune anecdote ne correspond.'; }

  function render(q){
    q=(q||'').trim().toLowerCase();
    const groups=buildGroups();
    let html='';
    groups.forEach(g=>{
      const items=q ? g.items.filter(t=>t.toLowerCase().includes(q)) : g.items;
      if(!items.length) return;
      html += '<details class="lx-item"'+(g.key==='mine'?' open':'')+'><summary><span>'+g.label+'<span class="lx-tag">'+items.length+'</span></span>'+
        '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></summary>'+
        '<div class="lx-body">'+items.map(t=>'<p style="margin:0 0 10px">'+t+'</p>').join('')+'</div></details>';
    });
    box.innerHTML = html || '<div class="lx-empty">'+emptyMsg()+'</div>';
  }
  render('');
  if(search) search.addEventListener('input',()=>render(search.value));
})();

/* ---- bloc suivant ---- */

/* ---- bloc suivant ---- */

/* Onglets */
document.querySelectorAll('.tab-btn').forEach(function(btn){
  btn.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
    document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
    btn.classList.add('active'); btn.setAttribute('aria-selected','true');
    document.getElementById('tab-'+btn.getAttribute('data-tab')).classList.add('active');
  });
});
(function(){ var m=/[?&]tab=([a-z]+)/.exec(location.search); if(m){ var b=document.querySelector('.tab-btn[data-tab="'+m[1]+'"]'); if(b) b.click(); } })();

document.querySelectorAll('[data-tab-goto]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var b = document.querySelector('.tab-btn[data-tab="'+btn.getAttribute('data-tab-goto')+'"]');
    if (b) b.click();
  });
});

try{MDCore.init({page:'guide',section:'equilibre'});}catch(e){}try{MDPageIntro.init('guide');}catch(e){}

/* ---- bloc suivant ---- */

LUCIDE.init({page:''});
