/* data.js — Couche de données MyDope Off (100 % local, hors-ligne).
   - migrate() : normalise ctc_v6 vers le schéma v7 (sessions normalisées + parcours/prefs/reco).
   - logSession(type, champs) : journal normalisé commun à tous les modules.
   Aucune sortie réseau. Idempotent. Chargé avant nav.js sur toutes les pages.
   Expose window.MDData. */
window.MDData = (function () {
  var KEY = 'ctc_v6';
  var CORRUPT_KEY = 'ctc_v6_corrompu';
  var corruptionSeen = false;
  var lastWriteOk = true;

  /* read() : lecture tolérante. Si les données sont illisibles (écriture interrompue, quota
     atteint en plein write, corruption disque), on repart sur une base saine POUR NE PAS
     BLOQUER l'app — mais on met d'abord la donnée brute de côté sous CORRUPT_KEY. Sans ça,
     le premier write() qui suit écrase définitivement un historique dont une grande partie
     est souvent encore lisible (un JSON tronqué garde toutes les séances d'avant la coupure).
     hadCorruption() permet ensuite de prévenir la personne au lieu de la laisser croire
     qu'elle repart de zéro sans raison. */
  function read() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { return {}; }
    if (!raw) return {};
    try {
      var parsed = JSON.parse(raw);
      return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (e) {
      corruptionSeen = true;
      try {
        if (!localStorage.getItem(CORRUPT_KEY)) localStorage.setItem(CORRUPT_KEY, raw);
      } catch (e2) {}
      return {};
    }
  }
  function hadCorruption() {
    if (corruptionSeen) return true;
    try { return !!localStorage.getItem(CORRUPT_KEY); } catch (e) { return false; }
  }
  function write(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); return true; } catch (e) { return false; } }

  /* Migration v6 (implicite) -> v7. Non destructive (champs inconnus -> meta). Idempotente. */
  function migrate() {
    var o = read();
    var v = o.schemaVersion || 6;
    if (v < 7) {
      o.sessions = (Array.isArray(o.sessions) ? o.sessions : []).map(function (s) {
        if (!s || typeof s !== 'object') return s;
        if (s.v === 7) return s;
        var known = { type:1, date:1, envieAvant:1, envieApres:1, axes:1, contexte:1, dureeSec:1, dur:1, id:1, v:1, meta:1 };
        var meta = {}; for (var k in s) { if (Object.prototype.hasOwnProperty.call(s, k) && !known[k]) meta[k] = s[k]; }
        var rec = {
          id: s.id || ('s' + (s.date || Date.now()) + '_' + Math.random().toString(36).slice(2, 5)),
          v: 7,
          type: s.type || 'inconnu',
          date: s.date || Date.now()
        };
        if (s.dur != null || s.dureeSec != null) rec.dureeSec = (s.dur != null ? s.dur : s.dureeSec);
        if (s.envieAvant != null) rec.envieAvant = s.envieAvant;
        if (s.envieApres != null) rec.envieApres = s.envieApres;
        if (s.axes) rec.axes = s.axes;
        if (s.contexte) rec.contexte = s.contexte;
        if (Object.keys(meta).length) rec.meta = meta;
        return rec;
      });
      o.parcours = o.parcours || {
        schemaVersion: 1, chapitre: 1, jalonsFaits: [],
        axes: { inhib: 0, emo: 0, attn: 0, envies: 0, stab: 0 }, axesHist: [],
        rythme: 0.3, dernierJourActif: 0, valeurs: [], identite: []
      };
      o.prefs = o.prefs || {
        lang: (function () { try { return localStorage.getItem('mydopeoff_lang'); } catch (e) { return null; } })() || 'fr',
        capteurs: { motion: true, cam: true, mic: true },
        rappels: { on: false, heure: '20:00' },
        a11y: { grosTexte: false, contrasteEleve: false, reductionMouvement: false }
      };
      o.reco = o.reco || { effAppris: {}, statsHoraires: {}, lastModules: [] };
      o.schemaVersion = 7;
      write(o);
    }
    if (!o.trophies) { o.trophies = { debloquees: [], tiers: {} }; write(o); }
    else if (!o.trophies.tiers) { o.trophies.tiers = {}; (o.trophies.debloquees||[]).forEach(function(id){ o.trophies.tiers[id]=1; }); write(o); }
    return o;
  }

  /* Journal normalisé. type = 'breathe'|'tetris'|'maze'|'surf'|'lettre'|'scan'|'urgence'|... ;
     champs (optionnels) : date, dureeSec, envieAvant, envieApres, axes{}, contexte{}, meta{}.
     Renvoie le nombre total de séances (pour le témoin d'accomplissement). */
  function logSession(type, champs) {
    champs = champs || {};
    var o = read();
    o.sessions = Array.isArray(o.sessions) ? o.sessions : [];
    var rec = {
      id: 's' + Date.now() + '_' + Math.random().toString(36).slice(2, 5),
      v: 7, type: type, date: champs.date || Date.now()
    };
    ['dureeSec', 'envieAvant', 'envieApres', 'axes', 'contexte', 'meta'].forEach(function (k) {
      if (champs[k] !== undefined && champs[k] !== null) rec[k] = champs[k];
    });
    o.sessions.push(rec);
    if (o.parcours) o.parcours.dernierJourActif = Date.now();
    lastWriteOk = write(o);
    return o.sessions.length;
  }
  /* Une écriture peut échouer sans lever d'erreur visible (quota atteint, stockage bloqué).
     Les appelants qui viennent d'enregistrer quelque chose d'important pour la personne
     (une séance terminée) doivent pouvoir le vérifier plutôt que de la laisser croire que
     c'est gardé. */
  function lastSaveOk() { return lastWriteOk; }

  function getCtc() { return read(); }
  /* État résumé des 3 bilans (« faire le point ») : dernier score, ancienneté, tendance
     par rapport au précédent du même type. improving est déjà normalisé (true = mieux)
     selon le sens de chaque échelle (wellbeing: plus haut = mieux ; craving/audit: plus bas = mieux).
     Fondation partagée pour toute personnalisation jeux/mascotte basée sur le vécu récent. */
  function getBilanState() {
    var sessions = getSessions().filter(function (s) { return s.type === 'q' && s.id; });
    var out = {};
    ['wellbeing', 'craving', 'audit'].forEach(function (id) {
      var matches = sessions.filter(function (s) { return s.id === id; }).sort(function (a, b) { return b.date - a.date; });
      if (!matches.length) { out[id] = null; return; }
      var latest = matches[0], prev = matches[1];
      var higherIsBetter = (id === 'wellbeing');
      var improving = null;
      if (prev) {
        var delta = latest.score - prev.score;
        if (Math.abs(delta) >= 1) improving = higherIsBetter ? (delta > 0) : (delta < 0);
      }
      out[id] = { score: latest.score, label: latest.label, date: latest.date,
        daysAgo: Math.floor((Date.now() - latest.date) / 86400000), improving: improving };
    });
    return out;
  }
  /* Valeurs choisies dans « Mes valeurs » (identite.js). Tableau vide si jamais rempli —
     à chaque appelant de décider du repli (liste générique, ou simplement ne rien personnaliser). */
  function getValeurs() {
    try { var o = read(); return (o.parcours && Array.isArray(o.parcours.valeurs)) ? o.parcours.valeurs : []; }
    catch (e) { return []; }
  }
  function getSessions() { var o = read(); return Array.isArray(o.sessions) ? o.sessions : []; }
  function countSessions(type) { return getSessions().filter(function (s) { return !type || s.type === type; }).length; }
  function countThisWeek() { var wk = Date.now() - 604800000; return getSessions().filter(function (s) { return (s.date || 0) >= wk; }).length; }

  /* Trophées (collection de cartes, à paliers) : { debloquees:['slug',...], tiers:{'slug':star} }.
     debloquees reste maintenu pour compat (toute carte avec au moins 1 étoile). Idempotent. */
  function getTrophies() { var o = read(); return (o.trophies && Array.isArray(o.trophies.debloquees)) ? o.trophies.debloquees : []; }
  function getTrophyTiers() { var o = read(); return (o.trophies && o.trophies.tiers) ? o.trophies.tiers : {}; }
  /* setTrophyTier(id, star) : ne fait rien si star <= palier déjà atteint. Renvoie true si progression réelle. */
  function setTrophyTier(id, star) {
    var o = read(); o.trophies = o.trophies || { debloquees: [], tiers: {} };
    var cur = o.trophies.tiers[id] || 0;
    if (star <= cur) return false;
    o.trophies.tiers[id] = star;
    if (o.trophies.debloquees.indexOf(id) < 0) o.trophies.debloquees.push(id);
    write(o);
    return true;
  }

  migrate(); // exécution unique au chargement (idempotente)

  /* — Tendances de suivi (calendrier « Ta progression ») —
     Principe : ne jamais convertir une quantité en dose de principe actif absolue (la pureté et
     le dosage réel varient trop pour être supposés — cf. décision du 27/07). On compare
     seulement la personne à elle-même dans le temps : fréquence des entrées, quantité déclarée
     (uniquement entre unités identiques — jamais g vs ligne), et ressenti auto-évalué (niveau
     Léger/Modéré/Notable déjà saisi à chaque entrée). Nécessite un minimum de données des deux
     côtés de la comparaison ; renvoie overall:null plutôt que de forcer une lecture douteuse. */
  function normSub(s) { return (s || '').toLowerCase().trim(); }
  function getEntries() { var o = read(); return Array.isArray(o.entries) ? o.entries : []; }
  function getDistinctSubstances() {
    var seen = {}, out = [];
    getEntries().forEach(function (e) {
      if (!e || !e.substance || !((Number(e.level) || 0) > 0)) return;
      var k = normSub(e.substance);
      if (k && !seen[k]) { seen[k] = true; out.push(e.substance); }
    });
    return out;
  }
  function mostCommonUnit(arr) {
    var counts = {}, best = null, bc = 0;
    arr.forEach(function (e) { if (e.unit) counts[e.unit] = (counts[e.unit] || 0) + 1; });
    Object.keys(counts).forEach(function (u) { if (counts[u] > bc) { best = u; bc = counts[u]; } });
    return best;
  }
  function avgOf(arr, key) {
    var v = arr.map(function (e) { return Number(e[key]) || 0; }).filter(function (n) { return n > 0; });
    return v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : null;
  }
  function dirOf(recent, prior, eps) {
    if (recent == null || prior == null) return null;
    var d = recent - prior;
    if (Math.abs(d) <= (eps || 0.15) * Math.max(1, Math.abs(prior))) return 'stable';
    return d > 0 ? 'up' : 'down';
  }
  function substanceTrend(substance) {
    var target = normSub(substance);
    if (!target) return null;
    var all = getEntries().filter(function (e) {
      return e && e.date && normSub(e.substance) === target && (Number(e.level) || 0) > 0;
    });
    if (all.length < 4) return null; // pas assez d'historique pour une tendance fiable
    var now = Date.now(), win = 14 * 86400000;
    var recentFrom = now - win, priorFrom = now - 2 * win;
    function ts(e) { return new Date(e.date + 'T00:00:00').getTime(); }
    var recent = all.filter(function (e) { var t = ts(e); return t >= recentFrom && t <= now; });
    var prior = all.filter(function (e) { var t = ts(e); return t >= priorFrom && t < recentFrom; });
    if (recent.length < 2 || prior.length < 2) return null; // pas assez des deux côtés
    var freqDir = dirOf(recent.length, prior.length, 0.2);
    var unitR = mostCommonUnit(recent), unitP = mostCommonUnit(prior);
    var qtyDir = null, qtyUnit = null;
    if (unitR && unitR === unitP) {
      qtyDir = dirOf(
        avgOf(recent.filter(function (e) { return e.unit === unitR; }), 'qty'),
        avgOf(prior.filter(function (e) { return e.unit === unitP; }), 'qty')
      );
      qtyUnit = unitR;
    }
    var levelDir = dirOf(avgOf(recent, 'level'), avgOf(prior, 'level'));
    var signals = [freqDir, qtyDir, levelDir].filter(Boolean);
    var ups = signals.filter(function (s) { return s === 'up'; }).length;
    var downs = signals.filter(function (s) { return s === 'down'; }).length;
    var overall = null;
    if (freqDir === 'up' && ups >= 2) overall = 'up';
    else if (freqDir === 'down' && downs >= 2) overall = 'down';
    else if (freqDir && ups === 0 && downs === 0) overall = 'stable';
    return { freqDir: freqDir, qtyDir: qtyDir, qtyUnit: qtyUnit, levelDir: levelDir, overall: overall,
      recentCount: recent.length, priorCount: prior.length };
  }

  return {
    migrate: migrate, logSession: logSession,
    getCtc: getCtc, getSessions: getSessions, getValeurs: getValeurs, getBilanState: getBilanState,
    countSessions: countSessions, countThisWeek: countThisWeek,
    getTrophies: getTrophies, getTrophyTiers: getTrophyTiers, setTrophyTier: setTrophyTier,
    getEntries: getEntries, getDistinctSubstances: getDistinctSubstances, substanceTrend: substanceTrend,
    read: read, write: write, hadCorruption: hadCorruption, lastSaveOk: lastSaveOk
  };
})();
