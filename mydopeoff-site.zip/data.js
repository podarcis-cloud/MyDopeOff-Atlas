/* data.js — Couche de données MyDope Off (100 % local, hors-ligne).
   - migrate() : normalise ctc_v6 vers le schéma v7 (sessions normalisées + parcours/prefs/reco).
   - logSession(type, champs) : journal normalisé commun à tous les modules.
   Aucune sortie réseau. Idempotent. Chargé avant nav.js sur toutes les pages.
   Expose window.MDData. */
window.MDData = (function () {
  var KEY = 'ctc_v6';

  function read() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function write(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); return true; } catch (e) { return false; } }

  /* Migration v6 (implicite) -> v7. Non destructive (champs inconnus -> meta). Idempotente. */
  function migrate() {
    var o = read();
    var v = o.schemaVersion || 6;
    if (v < 7) {
      o.sessions = (Array.isArray(o.sessions) ? o.sessions : []).map(function (s) {
        if (!s || typeof s !== 'object') return s;
        if (s.v === 7) return s;
        var known = { type:1, date:1, envieAvant:1, envieApres:1, axes:1, contexte:1, dureeSec:1, dur:1, id:1, v:1, meta:1 };
        var meta = {}; for (var k in s) { if (Object.prototype.hasOwnProperty.call(s, k) && !known[k]) meta[k] = s[k]; }
        var rec = {
          id: s.id || ('s' + (s.date || Date.now()) + '_' + Math.random().toString(36).slice(2, 5)),
          v: 7,
          type: s.type || 'inconnu',
          date: s.date || Date.now()
        };
        if (s.dur != null || s.dureeSec != null) rec.dureeSec = (s.dur != null ? s.dur : s.dureeSec);
        if (s.envieAvant != null) rec.envieAvant = s.envieAvant;
        if (s.envieApres != null) rec.envieApres = s.envieApres;
        if (s.axes) rec.axes = s.axes;
        if (s.contexte) rec.contexte = s.contexte;
        if (Object.keys(meta).length) rec.meta = meta;
        return rec;
      });
      o.parcours = o.parcours || {
        schemaVersion: 1, chapitre: 1, jalonsFaits: [],
        axes: { inhib: 0, emo: 0, attn: 0, envies: 0, stab: 0 }, axesHist: [],
        rythme: 0.3, dernierJourActif: 0, valeurs: [], identite: []
      };
      o.prefs = o.prefs || {
        lang: (function () { try { return localStorage.getItem('mydopeoff_lang'); } catch (e) { return null; } })() || 'fr',
        capteurs: { motion: true, cam: true, mic: true },
        rappels: { on: false, heure: '20:00' },
        a11y: { grosTexte: false, contrasteEleve: false, reductionMouvement: false }
      };
      o.reco = o.reco || { effAppris: {}, statsHoraires: {}, lastModules: [] };
      o.schemaVersion = 7;
      write(o);
    }
    return o;
  }

  /* Journal normalisé. type = 'breathe'|'tetris'|'maze'|'surf'|'lettre'|'scan'|'urgence'|... ;
     champs (optionnels) : date, dureeSec, envieAvant, envieApres, axes{}, contexte{}, meta{}.
     Renvoie le nombre total de séances (pour le témoin d'accomplissement). */
  function logSession(type, champs) {
    champs = champs || {};
    var o = read();
    o.sessions = Array.isArray(o.sessions) ? o.sessions : [];
    var rec = {
      id: 's' + Date.now() + '_' + Math.random().toString(36).slice(2, 5),
      v: 7, type: type, date: champs.date || Date.now()
    };
    ['dureeSec', 'envieAvant', 'envieApres', 'axes', 'contexte', 'meta'].forEach(function (k) {
      if (champs[k] !== undefined && champs[k] !== null) rec[k] = champs[k];
    });
    o.sessions.push(rec);
    if (o.parcours) o.parcours.dernierJourActif = Date.now();
    write(o);
    return o.sessions.length;
  }

  function getCtc() { return read(); }
  function getSessions() { var o = read(); return Array.isArray(o.sessions) ? o.sessions : []; }
  function countSessions(type) { return getSessions().filter(function (s) { return !type || s.type === type; }).length; }
  function countThisWeek() { var wk = Date.now() - 604800000; return getSessions().filter(function (s) { return (s.date || 0) >= wk; }).length; }

  migrate(); // exécution unique au chargement (idempotente)

  return {
    migrate: migrate, logSession: logSession,
    getCtc: getCtc, getSessions: getSessions,
    countSessions: countSessions, countThisWeek: countThisWeek,
    read: read, write: write
  };
})();
