/* MyDope Off — page-alertes.js
   Initialisation de alertes.html. Le rendu passe après MDCore.init() pour que la langue
   et la région soient déjà connues : une alerte rendue avant serait filtrée sur une région
   nulle et affichée dans la mauvaise langue. */
(function () {
  function start() {
    try { MDCore.init({ page: 'alertes', section: 'securite' }); } catch (e) {}
    try {
      if (window.MDAlertes) {
        MDAlertes.renderListe(document.getElementById('alertes-liste'));
        /* Le titre ne reste pas seul quand aucune actualité ne concerne la région :
           une section vide donne l'impression que le produit a oublié quelque chose. */
        var nActus = MDAlertes.renderActus(document.getElementById('actus-liste'));
        var bloc = document.getElementById('actus-bloc');
        if (bloc) bloc.hidden = (nActus === 0);
        MDAlertes.renderAnnuaire(document.getElementById('annuaire-liste'));
      }
    } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
