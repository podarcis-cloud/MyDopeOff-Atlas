/* MyDope Off — page-alertes.js
   Initialisation de alertes.html. Le rendu passe après MDCore.init() pour que la langue
   et la région soient déjà connues : une alerte rendue avant serait filtrée sur une région
   nulle et affichée dans la mauvaise langue. */
(function () {
  function start() {
    try { MDCore.init({ page: 'alertes', section: 'securite' }); } catch (e) {}
    try {
      /* Onglets : même mécanique que guide.html, reprise plutôt que réécrite. */
      document.querySelectorAll('.tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.querySelectorAll('.tab-btn').forEach(function (b) {
            b.classList.remove('active'); b.setAttribute('aria-selected', 'false');
          });
          btn.classList.add('active'); btn.setAttribute('aria-selected', 'true');
          document.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('active'); });
          var pane = document.getElementById('tab-' + btn.getAttribute('data-tab'));
          if (pane) pane.classList.add('active');
        });
      });
      /* Ancrage par URL : alertes.html?tab=paysage ouvre directement les actualités. */
      var m = /[?&]tab=([a-z]+)/.exec(location.search);
      if (m) { var b = document.querySelector('.tab-btn[data-tab="' + m[1] + '"]'); if (b) b.click(); }

      if (window.MDAlertes) {
        MDAlertes.renderListe(document.getElementById('alertes-liste'));
        /* Le titre ne reste pas seul quand aucune actualité ne concerne la région :
           une section vide donne l'impression que le produit a oublié quelque chose. */
        /* L'onglet reste accessible même sans actualité : on y affiche alors un message
           plutôt qu'une page blanche, puisque l'onglet est visible dans tous les cas. */
        var nActus = MDAlertes.renderActus(document.getElementById('actus-liste'));
        var vide = document.getElementById('actus-vide');
        if (vide) vide.hidden = (nActus > 0);
        MDAlertes.renderAnnuaire(document.getElementById('annuaire-liste'));
      }
    } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
