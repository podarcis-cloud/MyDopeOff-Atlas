/* MyDope Off — page-index.js · accueil */
(function () {
  'use strict';
  function ready(fn){ if (document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }
  function goalDays(){ var s=store(); return (s.goal && s.goal.days) || 14; }

  // Jours de suivi consécutifs jusqu'à aujourd'hui (présence d'une entrée datée).
  function trackedStreak(es){
    if (!es.length) return 0;
    var set={}; es.forEach(function(e){ if (e && e.date) set[e.date]=1; });
    var d=new Date(), n=0;
    for (var i=0;i<400;i++){
      var key=d.toISOString().slice(0,10);
      if (set[key]) { n++; d.setDate(d.getDate()-1); } else break;
    }
    return n;
  }

  ready(function () {
    if (window.MDCore) MDCore.init({ page:'index', section:'accueil' });

    var es=entries();
    if (es.length){
      var n=trackedStreak(es) || es.length;
      var goal=goalDays();
      var card=document.getElementById('progress-card');
      var line=document.getElementById('streak-line');
      var gl=document.getElementById('goal-line');
      if (card && line){
        line.textContent = (window.MDCore? '' : '') + n + ' ' + (n>1?'jours de suivi':'jour de suivi');
        if (gl) gl.textContent = (window.MDCore? MDCore.t('suivi.goalline',{n:goal}) : ('Objectif : '+goal+' jours.'));
        card.hidden=false;
      }
    }
  });
})();
