/* MyDope Off — page-index.js · accueil */
(function () {
  'use strict';
  function ready(fn){ if (document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }

  // Jours de suivi consécutifs jusqu'à aujourd'hui (présence d'une entrée datée).
  function trackedStreak(es){
    if (!es.length) return 0;
    var set={}; es.forEach(function(e){ if (e && e.date) set[e.date]=1; });
    var d=new Date(), n=0;
    for (var i=0;i<400;i++){
      var key=d.toISOString().slice(0,10);
      if (set[key]) { n++; d.setDate(d.getDate()-1); } else break;
    }
    return n;
  }

  // Détecte un jour de la semaine qui revient nettement plus que les autres dans l'historique.
  function dominantWeekday(es){
    if (es.length < 3) return null;
    var counts=[0,0,0,0,0,0,0];
    es.forEach(function(e){ if(e && e.date){ var d=new Date(e.date+'T00:00:00'); if(!isNaN(d)) counts[d.getDay()]++; } });
    var maxI=0; for (var i=1;i<7;i++) if (counts[i]>counts[maxI]) maxI=i;
    return (counts[maxI]>=3 && counts[maxI]/es.length>=0.4) ? maxI : null;
  }
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var DOW = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
  var DOW_EN = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  function domWeekdayLabel(i){ return lang()==='en' ? DOW_EN[i] : DOW[i]; }

  /* Bannière d'invitation : valeurs d'abord (fondation identitaire), puis bilan (état récent) —
     ces deux sections nourrissent toute la personnalisation du reste de l'app. Repli « plus tard »
     masqué pour la session en cours seulement (sessionStorage) : revient tant que non complété,
     sans être un nag permanent une fois fermé une fois. */
  /* renderNudge() supprimée — l'invitation à remplir les valeurs vit uniquement
     sur le Labo (page-fiches.js, #labo-intro), plus sur l'accueil. */


  ready(function () {
    if (window.MDCore) MDCore.init({ page:'index', section:'accueil' });
  /* Pas de bandeau encadré ici : sur l'accueil, c'est la mascotte qui porte l'alerte
     (voir MDAlertes.mascotte). Deux signaux pour une même information n'en font aucun. */

    var cardBilan = document.getElementById('card-bilan');
    if (cardBilan) {
      cardBilan.addEventListener('click', function (e) {
        if (window.MDBilanHero) { e.preventDefault(); MDBilanHero.openMenu(); }
        // sinon, repli naturel sur la navigation (href) déjà présente sur la balise
      });
    }

    /* Le libellé du bouton principal dépend de l'existence d'un historique : « Reprendre »
       n'a aucun sens pour quelqu'un qui arrive. */
    try {
      var cta = document.querySelector('.cta [data-i18n="home.cta"]');
      if (cta && !entries().length) {
        cta.setAttribute('data-i18n', 'home.cta_new');
        cta.textContent = (window.MDCore && MDCore.t) ? MDCore.t('home.cta_new') : 'Commencer';
      }
    } catch (e) {}

    var es=entries();
    var realStreak = trackedStreak(es);
    /* `streak` sert à CHOISIR le registre d'accueil (première venue ou retour), jamais à
       être affiché : une série consécutive qui casse parce qu'on a sauté un jour punit
       le fait de ne pas avoir noté. Ce qui s'affiche est le nombre de jours notés, qui
       ne peut que monter. */
    var joursNotes = es.reduce(function(acc, e){
      if (e && e.date && acc.indexOf(e.date) === -1) acc.push(e.date);
      return acc;
    }, []).length;
    var streak = es.length ? (realStreak || es.length) : 0;
    var dow = dominantWeekday(es), today = new Date().getDay();
    var habitMatch = (realStreak<=1 && dow!=null && dow===today);

    /* renderNudge() supprimé : l'invitation à remplir les valeurs ne doit exister
       QUE sur le Labo (carte #labo-intro, page-fiches.js) — jamais sur l'accueil. */

    if (window.MDCompagnon){
      if (habitMatch){
        setTimeout(function(){
          MDCompagnon.toast({ mood:'curiosite', key:'home-habit-'+today,
            text:(lang()==='en'
              ? ('Back again on a '+domWeekdayLabel(today)+'. This is starting to look like a habit.')
              : ('Te revoilà un '+DOW[today]+'. Ça commence à ressembler à une habitude.')) });
        }, 700);
        return;
      }
      var BACK_POOL = lang()==='en' ? [
        { mood:'encouragement', text:'Good to see you back. '+joursNotes+' '+(joursNotes>1?'days noted down \u2014 the kind of thing that pays off later.':'day noted down, and that\u2019s a start.') },
        { mood:'celebration', text:'You\u2019re back. '+joursNotes+' '+(joursNotes>1?'days noted down so far \u2014 that counts for more than it seems.':'day, and that\u2019s already something.') },
        { mood:'bienveillance', text:'Welcome back. No need for a clear goal to open the app today.' }
      ] : [
        { mood:'encouragement', text:'Content\u00b7e de te revoir. '+joursNotes+' '+(joursNotes>1?'jours not\u00e9s \u2014 le genre de chose qui sert plus tard.':'jour not\u00e9, c\u2019est un d\u00e9but.') },
        { mood:'celebration', text:'Te revoil\u00e0. '+joursNotes+' '+(joursNotes>1?'jours not\u00e9s jusqu\u2019ici \u2014 \u00e7a compte plus qu\u2019il n\u2019y para\u00eet.':'jour, et c\u2019est d\u00e9j\u00e0 quelque chose.') },
        { mood:'bienveillance', text:'Bienvenue de retour. Pas besoin d\u2019avoir un objectif clair pour ouvrir l\u2019appli aujourd\u2019hui.' }
      ];
      try{
        var homeVals = window.MDData ? MDData.getValeurs() : [];
        if (homeVals.length){
          var homeV = homeVals[Math.floor(Math.random()*homeVals.length)];
          BACK_POOL.push({ mood:'curiosite', text:(lang()==='en'
            ? ('You\u2019re back. \u00ab '+homeV+' \u00bb \u2014 it\u2019s still there, somewhere in what you\u2019re doing here.')
            : ('Te revoil\u00e0. \u00ab '+homeV+' \u00bb \u2014 c\u2019est toujours l\u00e0, quelque part dans ce que tu fais ici.')) });
        }
      }catch(e){}
      try{
        if (window.MDParcours && MDParcours.getChapterMood){
          var chap = MDParcours.getChapterMood();
          if (chap && chap.text) BACK_POOL.push({ mood: chap.mood, text: chap.text });
        }
      }catch(e){}
      try{
        if (window.MDData && MDData.getDistinctSubstances && MDData.substanceTrend){
          var trendSubs = MDData.getDistinctSubstances(), trendUp = null, trendDown = null;
          trendSubs.forEach(function(s){
            var t = MDData.substanceTrend(s);
            if (t && t.overall==='up' && !trendUp) trendUp = s;
            if (t && t.overall==='down' && !trendDown) trendDown = s;
          });
          if (trendDown){
            BACK_POOL.push({ mood:'fierte', text:(lang()==='en'
              ? ('Your recent entries for '+trendDown+' are down compared to last month \u2014 that\u2019s noticeable.')
              : ('Tes derni\u00e8res entr\u00e9es sur '+trendDown+' sont en baisse par rapport au mois dernier \u2014 \u00e7a se remarque.')) });
          }
          if (trendUp){
            BACK_POOL.push({ mood:'vigilance', text:(lang()==='en'
              ? ('Your recent entries for '+trendUp+' are up compared to last month. No judgment \u2014 just an observation, if that\u2019s useful to you.')
              : ('Tes derni\u00e8res entr\u00e9es sur '+trendUp+' sont en hausse par rapport au mois dernier. Pas de jugement \u2014 juste un constat, si \u00e7a t\u2019est utile.')) });
          }
        }
      }catch(e){}
      var WELCOME_POOL = lang()==='en' ? [
        { mood:'bienveillance', text:'Welcome. Here, you move at your own pace \u2014 no judgment, no accounts to settle.' },
        { mood:'ecoute', text:'Welcome. You can just look around, to start. Nothing here is mandatory.' },
        { mood:'curiosite', text:'Welcome. Take your time to see what\u2019s here \u2014 you\u2019ll move at your own pace.' },
        { mood:'curiosite-active', text:'Welcome. Explore freely \u2014 there\u2019s no right way to start.' }
      ] : [
        { mood:'bienveillance', text:'Bienvenue. Ici, tu avances \u00e0 ton rythme \u2014 sans jugement, sans compte \u00e0 rendre.' },
        { mood:'ecoute', text:'Bienvenue. Tu peux juste regarder, pour commencer. Rien n\u2019est obligatoire ici.' },
        { mood:'curiosite', text:'Bienvenue. Prends le temps de voir ce qu\u2019il y a \u2014 tu avanceras \u00e0 ton rythme.' },
        { mood:'curiosite-active', text:'Bienvenue. Explore \u00e0 ton aise \u2014 il n\u2019y a pas de bonne fa\u00e7on de commencer.' }
      ];
      /* CARTE HAUTE (#mascot-intro) : TOUJOURS le mot d'accueil + mini-didacticiel +
         recherche. Ne contient JAMAIS l'alerte — c'est un signal distinct, momentané,
         qui reste en toast BAS comme tous les autres toasts du produit (retour de
         Simon : les deux avaient été fusionnés à tort). */
      var pool = streak > 0 ? BACK_POOL : WELCOME_POOL;
      var moods = pool.map(function(p){ return p.mood; });
      var picked = MDCompagnon.pickMood ? MDCompagnon.pickMood(moods, streak>0?'home-back':'home-welcome') : moods[0];
      var msg = pool.filter(function(p){ return p.mood===picked; })[0] || pool[0];
      var host = document.getElementById('mascot-intro');
      if (host) {
        var av = (window.MDCompagnon && MDCompagnon.avatarHTML) ? MDCompagnon.avatarHTML(msg.mood, {cls:'mint-av'}) : '';
        var l = (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr';
        /* Le mini-didacticiel s'affiche à CHAQUE visite (pas seulement la première) :
           c'est un repère de page, pas une formalité d'accueil qu'on coche une fois. */
        var tuto = '<span class="mint-tuto">' + (l==='en'
            ? 'Journal below, exercises in Lab, alerts on what\u2019s circulating \u2014 or just type what\u2019s going on.'
            : 'Le journal en dessous, des exercices dans Labo, les alertes sur ce qui circule \u2014 ou tape juste ce qui se passe.') + '</span>';
        var ph = (l==='en') ? '\u201cstress\u201d, \u201cxanax\u201d, \u201cgames\u201d\u2026' : '\u00ab stress \u00bb, \u00ab xanax \u00bb, \u00ab jeux \u00bb\u2026';
        var champLabel = (l==='en') ? 'Search' : 'Chercher';
        host.innerHTML =
          '<div class="mint"><div class="mint-row">' + av +
          '<div class="mint-body"><p>' + esc(msg.text) + '</p>' + tuto + '</div></div>' +
          '<div class="mint-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>' +
          '<input type="search" id="mint-champ" autocomplete="off" placeholder="' + esc(ph) + '" aria-label="' + esc(champLabel) + '">' +
          '</div><div id="mint-suggest" class="mint-suggest" hidden></div></div>';

        var champ = document.getElementById('mint-champ');
        var sugg = document.getElementById('mint-suggest');
        function aller(v){ v=(v||champ.value).trim(); if(v) location.href='recherche.html?q='+encodeURIComponent(v); }
        if (champ) {
          champ.addEventListener('keydown', function(e){ if(e.key==='Enter') aller(); });
          /* Suggestions EN DIRECT pendant la frappe (retour de Simon : sans ça, taper
             puis appuyer sur Entrée sans savoir si ça mène quelque part n'est pas
             intuitif). Trois résultats maximum, cliquables, sans quitter l'accueil. */
          champ.addEventListener('input', function(){
            var v = champ.value.trim();
            if (!v || !window.MDRecherche || !sugg) { if(sugg){sugg.hidden=true;sugg.innerHTML='';} return; }
            var res = MDRecherche.chercher(v).slice(0, 4);
            if (!res.length) { sugg.hidden = true; sugg.innerHTML = ''; return; }
            sugg.hidden = false;
            sugg.innerHTML = res.map(function(r){
              var titre = (l==='en' ? r.titre_en : r.titre_fr) || r.titre_fr;
              return '<a href="' + r.url + '">' + esc(titre) + '</a>';
            }).join('');
          });
        }
      }

      /* Alerte critique : toast BAS, momentané, séparé du bloc d'accueil. */
      var al = (window.MDAlertes && MDAlertes.mascotte) ? MDAlertes.mascotte() : null;
      if (al) MDCompagnon.toast(al);
    }

    function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }
  });
})();
