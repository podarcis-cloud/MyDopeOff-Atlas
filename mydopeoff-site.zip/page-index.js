/* MyDope Off — page-index.js · accueil */
(function () {
  'use strict';
  function ready(fn){ if (document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  function store(){ try { return JSON.parse(localStorage.getItem('ctc_v6'))||{}; } catch(e){ return {}; } }
  function entries(){ var s=store(); return Array.isArray(s.entries)? s.entries : []; }

  // Jours de suivi consécutifs jusqu'à aujourd'hui (présence d'une entrée datée).
  function trackedStreak(es){
    if (!es.length) return 0;
    var set={}; es.forEach(function(e){ if (e && e.date) set[e.date]=1; });
    var d=new Date(), n=0;
    for (var i=0;i<400;i++){
      var key=d.toISOString().slice(0,10);
      if (set[key]) { n++; d.setDate(d.getDate()-1); } else break;
    }
    return n;
  }

  // Détecte un jour de la semaine qui revient nettement plus que les autres dans l'historique.
  function dominantWeekday(es){
    if (es.length < 3) return null;
    var counts=[0,0,0,0,0,0,0];
    es.forEach(function(e){ if(e && e.date){ var d=new Date(e.date+'T00:00:00'); if(!isNaN(d)) counts[d.getDay()]++; } });
    var maxI=0; for (var i=1;i<7;i++) if (counts[i]>counts[maxI]) maxI=i;
    return (counts[maxI]>=3 && counts[maxI]/es.length>=0.4) ? maxI : null;
  }
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var DOW = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
  var DOW_EN = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  function domWeekdayLabel(i){ return lang()==='en' ? DOW_EN[i] : DOW[i]; }

  /* Bannière d'invitation : valeurs d'abord (fondation identitaire), puis bilan (état récent) —
     ces deux sections nourrissent toute la personnalisation du reste de l'app. Repli « plus tard »
     masqué pour la session en cours seulement (sessionStorage) : revient tant que non complété,
     sans être un nag permanent une fois fermé une fois. */
  function renderNudge(){
    var host = document.getElementById('personalize-nudge');
    if (!host || !window.MDData) return;
    var dismissed = false;
    try { dismissed = sessionStorage.getItem('mdNudgeDismissed') === '1'; } catch(e){}
    if (dismissed) return;

    var valeurs = MDData.getValeurs();
    var bilanState = MDData.getBilanState() || {};
    var hasBilan = !!(bilanState.wellbeing || bilanState.craving || bilanState.audit);

    var kind = null;
    if (!valeurs.length) kind = 'valeurs';
    else if (!hasBilan) kind = 'bilan';
    if (!kind) return; // les deux sont déjà complétés, rien à afficher

    var av = window.MDCompagnon && window.MDCompagnon.avatarHTML ? (window.MDMascotte ? MDMascotte.avatar('ambiance', { humeur:'curiosite' }) : MDCompagnon.avatarHTML('curiosite', {size:44})) : '';
    var copy = kind==='valeurs'
      ? (lang()==='en'
          ? { text:'Two minutes to say what matters to you? It\u2019s then used to personalise the games and messages, not just to fill in a box.', label:'Choose my values', go:function(){ if (window.MDIdentite) MDIdentite.open(renderNudge); else location.href='fiches.html'; } }
          : { text:'Deux minutes pour dire ce qui compte pour toi ? Ça sert ensuite \u00e0 personnaliser les jeux et les messages, pas juste \u00e0 remplir une case.', label:'Choisir mes valeurs', go:function(){ if (window.MDIdentite) MDIdentite.open(renderNudge); else location.href='fiches.html'; } })
      : (lang()==='en'
          ? { text:'A first "check-in" helps tailor what the app offers you to your real rhythm, not to a general average.', label:'Check in', go:function(){ if (window.MDBilanHero) MDBilanHero.openMenu(); else location.href='fiches.html'; } }
          : { text:'Un premier \u00ab\u00a0faire le point\u00a0\u00bb aide \u00e0 adapter ce que l\u2019app te propose \u00e0 ton rythme r\u00e9el, pas \u00e0 une moyenne g\u00e9n\u00e9rale.', label:'Faire le point', go:function(){ if (window.MDBilanHero) MDBilanHero.openMenu(); else location.href='fiches.html'; } });

    host.innerHTML = '<div class="nudge-card">'+av+
      '<div class="nudge-body"><p>'+copy.text+'</p>'+
      '<div class="nudge-actions"><a href="#" class="nudge-go" id="nudge-go">'+copy.label+'</a>'+
      '<button type="button" class="nudge-later" id="nudge-later">'+(lang()==='en'?'later':'plus tard')+'</button></div></div></div>';
    var goBtn = document.getElementById('nudge-go');
    if (goBtn) goBtn.addEventListener('click', function(e){ e.preventDefault(); copy.go(); });
    var laterBtn = document.getElementById('nudge-later');
    if (laterBtn) laterBtn.addEventListener('click', function(){
      try { sessionStorage.setItem('mdNudgeDismissed','1'); } catch(e){}
      host.innerHTML = '';
    });
  }

  ready(function () {
    if (window.MDCore) MDCore.init({ page:'index', section:'accueil' });

    var cardBilan = document.getElementById('card-bilan');
    if (cardBilan) {
      cardBilan.addEventListener('click', function (e) {
        if (window.MDBilanHero) { e.preventDefault(); MDBilanHero.openMenu(); }
        // sinon, repli naturel sur la navigation (href) déjà présente sur la balise
      });
    }

    var es=entries();
    var realStreak = trackedStreak(es);
    var streak = es.length ? (realStreak || es.length) : 0;
    var dow = dominantWeekday(es), today = new Date().getDay();
    var habitMatch = (realStreak<=1 && dow!=null && dow===today);

    renderNudge();

    if (window.MDCompagnon){
      if (habitMatch){
        setTimeout(function(){
          MDCompagnon.toast({ mood:'curiosite', key:'home-habit-'+today,
            text:(lang()==='en'
              ? ('Back again on a '+domWeekdayLabel(today)+'. This is starting to look like a habit.')
              : ('Te revoilà un '+DOW[today]+'. Ça commence à ressembler à une habitude.')) });
        }, 700);
        return;
      }
      var BACK_POOL = lang()==='en' ? [
        { mood:'encouragement', text:'Good to see you back. '+streak+' '+(streak>1?'days tracked, that\u2019s real progress.':'day tracked, that\u2019s a good start.') },
        { mood:'celebration', text:'You\u2019re back. '+streak+' '+(streak>1?'days in a row \u2014 that counts for more than it seems.':'day, and that\u2019s already something.') },
        { mood:'bienveillance', text:'Welcome back. No need for a clear goal to open the app today.' }
      ] : [
        { mood:'encouragement', text:'Content\u00b7e de te revoir. '+streak+' '+(streak>1?'jours de suivi, c\u2019est du concret.':'jour de suivi, c\u2019est un bon d\u00e9but.') },
        { mood:'celebration', text:'Te revoil\u00e0. '+streak+' '+(streak>1?'jours d\u2019affil\u00e9e \u2014 \u00e7a compte plus qu\u2019il n\u2019y para\u00eet.':'jour, et c\u2019est d\u00e9j\u00e0 quelque chose.') },
        { mood:'bienveillance', text:'Bienvenue de retour. Pas besoin d\u2019avoir un objectif clair pour ouvrir l\u2019appli aujourd\u2019hui.' }
      ];
      try{
        var homeVals = window.MDData ? MDData.getValeurs() : [];
        if (homeVals.length){
          var homeV = homeVals[Math.floor(Math.random()*homeVals.length)];
          BACK_POOL.push({ mood:'curiosite', text:(lang()==='en'
            ? ('You\u2019re back. \u00ab '+homeV+' \u00bb \u2014 it\u2019s still there, somewhere in what you\u2019re doing here.')
            : ('Te revoil\u00e0. \u00ab '+homeV+' \u00bb \u2014 c\u2019est toujours l\u00e0, quelque part dans ce que tu fais ici.')) });
        }
      }catch(e){}
      try{
        if (window.MDParcours && MDParcours.getChapterMood){
          var chap = MDParcours.getChapterMood();
          if (chap && chap.text) BACK_POOL.push({ mood: chap.mood, text: chap.text });
        }
      }catch(e){}
      try{
        if (window.MDData && MDData.getDistinctSubstances && MDData.substanceTrend){
          var trendSubs = MDData.getDistinctSubstances(), trendUp = null, trendDown = null;
          trendSubs.forEach(function(s){
            var t = MDData.substanceTrend(s);
            if (t && t.overall==='up' && !trendUp) trendUp = s;
            if (t && t.overall==='down' && !trendDown) trendDown = s;
          });
          if (trendDown){
            BACK_POOL.push({ mood:'fierte', text:(lang()==='en'
              ? ('Your recent entries for '+trendDown+' are down compared to last month \u2014 that\u2019s noticeable.')
              : ('Tes derni\u00e8res entr\u00e9es sur '+trendDown+' sont en baisse par rapport au mois dernier \u2014 \u00e7a se remarque.')) });
          }
          if (trendUp){
            BACK_POOL.push({ mood:'vigilance', text:(lang()==='en'
              ? ('Your recent entries for '+trendUp+' are up compared to last month. No judgment \u2014 just an observation, if that\u2019s useful to you.')
              : ('Tes derni\u00e8res entr\u00e9es sur '+trendUp+' sont en hausse par rapport au mois dernier. Pas de jugement \u2014 juste un constat, si \u00e7a t\u2019est utile.')) });
          }
        }
      }catch(e){}
      var WELCOME_POOL = lang()==='en' ? [
        { mood:'bienveillance', text:'Welcome. Here, you move at your own pace \u2014 no judgment, no accounts to settle.' },
        { mood:'ecoute', text:'Welcome. You can just look around, to start. Nothing here is mandatory.' },
        { mood:'curiosite', text:'Welcome. Take your time to see what\u2019s here \u2014 you\u2019ll move at your own pace.' },
        { mood:'curiosite-active', text:'Welcome. Explore freely \u2014 there\u2019s no right way to start.' }
      ] : [
        { mood:'bienveillance', text:'Bienvenue. Ici, tu avances \u00e0 ton rythme \u2014 sans jugement, sans compte \u00e0 rendre.' },
        { mood:'ecoute', text:'Bienvenue. Tu peux juste regarder, pour commencer. Rien n\u2019est obligatoire ici.' },
        { mood:'curiosite', text:'Bienvenue. Prends le temps de voir ce qu\u2019il y a \u2014 tu avanceras \u00e0 ton rythme.' },
        { mood:'curiosite-active', text:'Bienvenue. Explore \u00e0 ton aise \u2014 il n\u2019y a pas de bonne fa\u00e7on de commencer.' }
      ];
      setTimeout(function(){
        var pool = streak > 0 ? BACK_POOL : WELCOME_POOL;
        var moods = pool.map(function(p){ return p.mood; });
        var picked = MDCompagnon.pickMood ? MDCompagnon.pickMood(moods, streak>0?'home-back':'home-welcome') : moods[0];
        var msg = pool.filter(function(p){ return p.mood===picked; })[0] || pool[0];
        MDCompagnon.toast({ mood: msg.mood, key: streak>0?'home-back':'home-welcome', text: msg.text });
      }, 700);
    }
  });
})();
