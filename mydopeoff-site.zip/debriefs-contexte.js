/* MyDope Off — debriefs-contexte.js
   ============================================================================
   Phrases d'accompagnement contextuelles, ajoutées au débrief de fin d'exercice.

   Elles ne remplacent jamais le débrief : elles s'ajoutent après, en une phrase.
   Le débrief dit ce qui vient de se passer dans le corps ; celle-ci reconnaît la
   situation d'où la personne arrive.

   CE QU'AUCUNE DE CES PHRASES NE FAIT (chapitre 40) :
     · citer un chiffre, une fréquence, une durée, une évolution ;
     · comparer à une période précédente, à une moyenne, à quelqu'un d'autre ;
     · qualifier une période de bonne ou de mauvaise (zieloffen) ;
     · féliciter une baisse, déplorer une hausse.

   Chaque phrase doit rester juste dans TOUS les cas où elle peut sortir. C'est cette
   contrainte, et non le manque d'idées, qui limite le nombre de variantes : une phrase
   qui ne serait vraie que la moitié du temps est pire que pas de phrase.

   Clés : usage (frequent | regulier | espace) × intensite (calme | habituel | charge),
   plus un pool `sensible` qui prend le pas sur tout le reste quand un bilan récent
   indique un moment difficile.
   ============================================================================ */
window.MDDebriefsContexte = {

  /* Prend le pas sur tout : un jour où un bilan récent a signalé un moment difficile,
     on ne fait ni humour ni observation sur les habitudes. On reconnaît la venue. */
  sensible: [
    { fr: 'Venir faire ça un jour comme aujourd’hui demande plus que les autres jours.',
      en: 'Doing this on a day like today takes more than on other days.' },
    { fr: 'Tu es venu·e alors que ce n’était pas le moment le plus simple pour le faire.',
      en: 'You came and did this when it wasn’t the easiest moment to.' },
    { fr: 'Ça compte, surtout en ce moment.',
      en: 'That counts, especially right now.' }
  ],

  frequent: {
    calme: [
      { fr: 'Tu passes ici souvent en ce moment — c’est une habitude que tu as construite toi-même.',
        en: 'You’ve been coming here often lately — that’s a habit you built yourself.' },
      { fr: 'Revenir régulièrement, c’est ce qui rend un outil disponible le jour où il faut.',
        en: 'Coming back regularly is what makes a tool available on the day it’s needed.' }
    ],
    habituel: [
      { fr: 'Tu connais déjà cet exercice — le refaire n’a rien d’une répétition inutile.',
        en: 'You already know this exercise — doing it again isn’t pointless repetition.' },
      { fr: 'Ça devient un réflexe, et un réflexe se construit exactement comme ça.',
        en: 'It’s becoming a reflex, and reflexes get built exactly like this.' }
    ],
    charge: [
      { fr: 'Semaine dense, et tu prends quand même deux minutes pour ça.',
        en: 'A dense week, and you still take two minutes for this.' },
      { fr: 'C’est souvent dans les périodes chargées qu’on lâche ce genre de chose en premier — pas cette fois.',
        en: 'Busy stretches are usually when this kind of thing goes first — not this time.' }
    ]
  },

  regulier: {
    calme: [
      { fr: 'Tu es passé·e sans que rien ne t’y pousse en particulier. Ça aussi, ça sert.',
        en: 'You stopped by with nothing in particular pushing you to. That serves a purpose too.' },
      { fr: 'S’entraîner à froid, c’est ce qui rend l’exercice utilisable à chaud.',
        en: 'Practising when things are calm is what makes an exercise usable when they aren’t.' }
    ],
    habituel: [
      { fr: 'Tu reviens de temps en temps, à ton rythme — c’est un rythme qui vaut les autres.',
        en: 'You come back now and then, at your own pace — a pace as good as any.' },
      { fr: 'Rien ne t’obligeait à ouvrir ça aujourd’hui.',
        en: 'Nothing obliged you to open this today.' }
    ],
    charge: [
      { fr: 'La semaine a été chargée, et tu es quand même là.',
        en: 'It’s been a heavy week, and you’re here anyway.' },
      { fr: 'Ouvrir ça dans une semaine comme celle-là, c’est déjà une décision.',
        en: 'Opening this in a week like this one is already a decision.' }
    ]
  },

  espace: {
    calme: [
      { fr: 'Tu ne passes pas souvent, et il n’y a aucune raison que ça change si ça te va comme ça.',
        en: 'You don’t come by often, and there’s no reason that should change if it suits you.' },
      { fr: 'Un exercice fait une fois reste disponible la fois d’après.',
        en: 'An exercise done once stays available the next time.' }
    ],
    habituel: [
      { fr: 'Tu passes rarement ici — ce que tu viens de faire compte autant que si tu venais tous les jours.',
        en: 'You rarely come here — what you just did counts as much as if you came daily.' },
      { fr: 'Pas besoin d’en faire une habitude pour que ça serve.',
        en: 'It doesn’t have to become a habit to be worth something.' }
    ],
    charge: [
      { fr: 'Tu passes rarement, et tu es passé·e aujourd’hui.',
        en: 'You rarely come by, and you came by today.' },
      { fr: 'Chercher un outil au moment où on en a besoin, c’est exactement à ça qu’il sert.',
        en: 'Reaching for a tool at the moment you need it is exactly what it’s for.' }
    ]
  }
};
