/* urgence.js — Mode urgence (M2) + Urge surfing (M3) + FAB flottant.
   Auto-contenu : injecte DOM + styles (charte Atlas, couleurs en fallback), boutons <button>
   (tap iOS fiable). Co-régule AVANT de mesurer. Branche réduction des risques sans jugement.
   Journalise via MDData.logSession. 100 % local. Expose window.MDUrgence. Auto-monte le FAB. */
window.MDUrgence = (function () {
  var INJ = false, ov = null, avant = null;

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      /* FAB */
      '.mdu-fab{position:fixed;right:16px;bottom:82px;bottom:calc(82px + env(safe-area-inset-bottom));z-index:50;display:flex;align-items:center;gap:7px;' +
      'padding:11px 15px;border:none;border-radius:30px;background:var(--terra,#C7765C);color:#fff;' +
      'font-family:var(--ui,Inter,system-ui,sans-serif);font-weight:700;font-size:13.5px;cursor:pointer;' +
      'box-shadow:0 8px 22px rgba(199,118,92,.45);-webkit-tap-highlight-color:transparent}' +
      '.mdu-fab:active{transform:scale(.96)}.mdu-fab .mdu-bolt{font-size:15px;line-height:1}' +
      /* modal */
      '.mdu-ov{position:fixed;inset:0;z-index:4500;display:flex;align-items:center;justify-content:center;' +
      'padding:20px;background:var(--bg,#F5F2EA);font-family:var(--ui,Inter,sans-serif);overflow-y:auto}' +
      '.mdu-card{position:relative;z-index:1;max-width:380px;width:100%;text-align:center;color:var(--ink,#1F2B25)}' +
      '.mdu-q{font-family:var(--title,Newsreader,Georgia,serif);font-size:22px;line-height:1.25;margin:0 0 6px}' +
      '.mdu-sub{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14px;color:var(--ink-2,#58635E);margin:0 0 18px}' +
      /* échelle 0-10 */
      '.mdu-scale{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin:6px 0 16px}' +
      '.mdu-n{min-width:38px;height:42px;border:1px solid var(--line,#E2DCD0);background:var(--surface,#fff);' +
      'color:var(--ink,#1F2B25);border-radius:11px;font-family:var(--content,"Atkinson Hyperlegible",sans-serif);' +
      'font-size:16px;font-weight:700;cursor:pointer;-webkit-tap-highlight-color:transparent}.mdu-n:active{transform:scale(.94)}' +
      /* boutons */
      '.mdu-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-family:var(--ui,Inter,sans-serif);' +
      'font-weight:700;font-size:15px;padding:14px;cursor:pointer;margin-top:6px}' +
      '.mdu-go.terra{background:var(--terra,#C7765C)}' +
      '.mdu-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);' +
      'font-family:var(--ui,Inter,sans-serif);font-weight:600;font-size:14px;padding:12px;cursor:pointer;margin-top:9px}' +
      '.mdu-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:13px;text-decoration:underline;cursor:pointer;margin-top:14px}' +
      '.mdu-safe{text-align:left;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:14px;margin:4px 0 12px;' +
      'font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13.5px;line-height:1.5;color:var(--ink,#1F2B25)}' +
      '.mdu-safe b{font-family:var(--ui,Inter,sans-serif)}.mdu-safe a{color:var(--terra,#C7765C);font-weight:700}';
    var st = document.createElement('style'); st.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(st);
  }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function shell() {
    closeOv();
    inject();
    ov = E('div', 'mdu-ov'); var c = E('div', 'mdu-card'); ov.appendChild(c);
    document.body.appendChild(ov); if (window.MDDecor) window.MDDecor.into(ov, { dots: true });
    return c;
  }
  function closeOv() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function exitBtn(c, label) { var b = E('button', 'mdu-exit', label || 'Je vais mieux'); b.type = 'button'; b.onclick = function () { closeOv(); }; c.appendChild(b); }
  function scaleInto(c, onPick) {
    var row = E('div', 'mdu-scale');
    for (var i = 0; i <= 10; i++) (function (n) {
      var b = E('button', 'mdu-n', String(n)); b.type = 'button'; b.setAttribute('aria-label', 'Envie ' + n + ' sur 10');
      b.onclick = function () { onPick(n); }; row.appendChild(b);
    })(i);
    c.appendChild(row);
  }
  function log(type, fields) { try { if (window.MDData) window.MDData.logSession(type, fields || {}); } catch (e) { } }

  /* ---- M2 : ouverture, co-régulation d'abord ---- */
  function open() {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Une envie est là.'));
    c.appendChild(E('p', 'mdu-sub', 'Elle monte, culmine, puis redescend \u2014 toujours. Voyons où tu en es, là, maintenant.'));
    scaleInto(c, route);
    exitBtn(c, 'Je vais mieux');
  }
  // Lance un VRAI exercice (pas de copie) ; il mesurera l'envie avant/après.
  function launch(moduleKey, v) {
    try { sessionStorage.setItem('mdScan', JSON.stringify({ envie: v, ts: Date.now() })); } catch (e) { }
    var page = { breathe: 'breathe.html', tetris: 'tetris.html', maze: 'maze.html' }[moduleKey];
    if (page) location.href = page;
  }
  function exoBtns(c, v, primaryFirst) {
    var defs = [
      { k: 'breathe', t: 'M\u2019apaiser \u2014 Souffle' },
      { k: 'tetris', t: 'Occuper mon esprit \u2014 Tetris' },
      { k: 'maze', t: 'Me recentrer \u2014 Labyrinthe' }
    ];
    defs.forEach(function (d, i) {
      var b = E('button', (i === 0 && primaryFirst) ? 'mdu-go' : 'mdu-2nd', d.t); b.type = 'button';
      b.onclick = function () { launch(d.k, v); }; c.appendChild(b);
    });
  }
  function route(v) {
    if (window.MDReco && window.MDReco.recordHoraire) { try { window.MDReco.recordHoraire(v); } catch (e) { } }
    if (v >= 8) { stageRouge(v); return; }
    var c = shell();
    c.appendChild(E('p', 'mdu-q', v <= 3 ? 'Tu gères.' : 'On laisse passer la vague.'));
    c.appendChild(E('p', 'mdu-sub', v <= 3
      ? 'L\u2019envie est basse. Si tu veux, occupe-toi un court instant.'
      : 'Le temps que ça redescende, détourne ton esprit avec un exercice court.'));
    exoBtns(c, v, true);
    var rdr = E('button', 'mdu-2nd', 'Réduire les risques'); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    exitBtn(c, 'Je vais mieux');
  }
  function stageRouge(v) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'On traverse ça ensemble.'));
    var safe = E('div', 'mdu-safe');
    var vlist = '';
    try { var pv = ((window.MDData ? window.MDData.getCtc() : {}).parcours || {}).valeurs || []; if (pv.length) vlist = '<br><b>Ce qui compte pour toi :</b> ' + pv.slice(0, 4).join(', ') + '.'; } catch (e) { }
    safe.innerHTML = '<b>Tu peux attendre 10 minutes.</b> L\u2019intensité <b>va</b> redescendre.<br>' +
      'Repense à ce qui compte \u2014 ou relis ta lettre au futur toi.' + vlist;
    c.appendChild(safe);
    var s = E('button', 'mdu-go', 'M\u2019apaiser \u2014 Souffle'); s.type = 'button'; s.onclick = function () { launch('breathe', v); }; c.appendChild(s);
    var rdr = E('button', 'mdu-2nd', 'Si je vais consommer quand même'); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'filet' } });
    exitBtn(c, 'Je vais mieux');
  }
  function stageRDR(v) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Alors, réduisons les risques.'));
    c.appendChild(E('p', 'mdu-sub', 'Sans jugement. Te garder en sécurité passe d\u2019abord.'));
    var safe = E('div', 'mdu-safe');
    safe.innerHTML = '\u2022 Ne consomme pas seul\u00B7e.<br>\u2022 Teste ton produit si tu peux, commence <b>bas</b>, espace les prises.<br>' +
      '\u2022 Si opioïdes : aie de la <b>naloxone</b> à portée.<br>\u2022 Ne mélange pas \u2014 vérifie les interactions.';
    c.appendChild(safe);
    var a = E('a', null, 'Ouvrir les infos réduction des risques \u2192'); a.href = 'rdr.html';
    a.style.cssText = 'display:block;color:var(--terra,#C7765C);font-weight:700;font-family:var(--ui,Inter,sans-serif);font-size:14px;margin-bottom:14px';
    c.appendChild(a);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'rdr' } });
    exitBtn(c, 'Fermer');
  }

  /* ---- FAB ---- */
  function mountFAB() {
    if (document.querySelector('.mdu-fab')) return;
    inject();
    var b = E('button', 'mdu-fab'); b.type = 'button'; b.setAttribute('aria-label', 'Je suis en craving');
    var bolt = E('span', 'mdu-bolt', '\u26A1'); b.appendChild(bolt); b.appendChild(document.createTextNode('En craving'));
    b.onclick = open; document.body.appendChild(b);
  }
  function auto() {
    if (window.MD_NO_FAB) return;                 // pages d'exercice : pas de FAB
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountFAB);
    else mountFAB();
  }
  auto();

  return { open: open, mountFAB: mountFAB };
})();
