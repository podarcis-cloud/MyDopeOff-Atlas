/* urgence.js — Mode urgence (M2) + Urge surfing (M3) + FAB flottant.
   Auto-contenu : injecte DOM + styles (charte Atlas, couleurs en fallback), boutons <button>
   (tap iOS fiable). Co-régule AVANT de mesurer. Branche réduction des risques sans jugement.
   Journalise via MDData.logSession. 100 % local. Expose window.MDUrgence. Auto-monte le FAB. */
window.MDUrgence = (function () {
  var INJ = false, ov = null, avant = null;

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      /* FAB — héros craving (personnage rouge, 2 poses) */
      '.mdu-fab{position:fixed;right:14px;bottom:80px;bottom:calc(80px + env(safe-area-inset-bottom));z-index:var(--z-nav,50);' +
      'display:flex;flex-direction:column;align-items:center;gap:2px;border:none;background:none !important;padding:0;cursor:pointer;' +
      '-webkit-tap-highlight-color:transparent;font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mdu-av{position:relative;width:70px;height:70px;border-radius:50%;overflow:visible;background:transparent;' +
      'transition:transform .25s var(--ease,ease),filter .25s}' +
      '.mdu-av img{position:absolute;inset:0;margin:auto;width:100%;height:100%;object-fit:contain;transition:opacity .28s ease,transform .28s ease}' +
      '.mdu-av .open{opacity:0;transform:scale(.86)}' +
      '.mdu-av .rest{opacity:1}' +
      '.mdu-lbl{font-weight:var(--w-bold,700);font-size:var(--fs-caps,11px);color:var(--terra-d,#A85A42);background:color-mix(in srgb,var(--bg,#F5F2EA) 86%,transparent);' +
      'padding:1px 8px;border-radius:20px;white-space:nowrap;transition:opacity .2s}' +
      /* état actif : .armed (tactile) ou hover (desktop uniquement) -> bras ouverts */
      '.mdu-fab.armed .mdu-av{transform:scale(1.08);filter:drop-shadow(0 6px 14px rgba(199,118,92,.5))}' +
      '.mdu-fab.armed .open{opacity:1;transform:scale(1)}' +
      '.mdu-fab.armed .rest{opacity:0;transform:scale(1.06)}' +
      '.mdu-fab.armed .mdu-lbl{color:#fff;background:var(--terra,#C7765C)}' +
      '@media (hover:hover) and (pointer:fine){' +
      '.mdu-fab:hover .mdu-av{transform:scale(1.08);filter:drop-shadow(0 6px 14px rgba(199,118,92,.5))}' +
      '.mdu-fab:hover .open{opacity:1;transform:scale(1)}' +
      '.mdu-fab:hover .rest{opacity:0;transform:scale(1.06)}}' +
      '.mdu-fab:active{transform:scale(.97)}' +
      '@media (prefers-reduced-motion:reduce){.mdu-av,.mdu-av img{transition:none}}' +
      /* modal */
      '.mdu-ov{z-index:var(--z-modal-5,4500);align-items:flex-start;justify-content:center;' +
      'padding:20px;background:var(--bg,#F5F2EA);font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mdu-card{position:relative;z-index:var(--z-base,1);max-width:380px;width:100%;text-align:center;color:var(--ink,#1F2B25)}' +
      '.mdu-ava{display:block;width:var(--avatar-lg,88px);height:var(--avatar-lg,88px);border-radius:50%;overflow:hidden;margin:0 auto 8px;background:var(--sauge-50,#EEF1E9);border:1px solid var(--line,#E2DCD0)}' +
      '.mdu-ava img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdu-q{font-family:var(--font-editorial,Newsreader,Georgia,serif);font-size:var(--fs-h3,22px);line-height:var(--lh-tight,1.25);margin:0 0 6px}' +
      '.mdu-sub{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,14px);color:var(--ink-2,#58635E);margin:0 0 18px}' +
      /* paliers chaleureux (remplacent l\'échelle 0-10) */
      '.mdu-steps{display:flex;flex-direction:column;gap:9px;margin:6px 0 16px}' +
      '.mdu-step{display:flex;align-items:center;gap:12px;width:100%;text-align:left;border:1.5px solid var(--line,#E2DCD0);' +
      'background:var(--surface,#fff);color:var(--ink,#1F2B25);border-radius:14px;padding:13px 15px;cursor:pointer;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-ui,15.5px);font-weight:var(--w-bold,700);-webkit-tap-highlight-color:transparent}' +
      '.mdu-step:active{transform:scale(.98)}.mdu-step .mdu-dot{flex:0 0 auto;width:16px;height:16px;border-radius:50%;background:var(--sc)}' +
      /* boutons */
      '.mdu-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-family:var(--font-technical,Inter,sans-serif);' +
      'font-weight:var(--w-bold,700);font-size:var(--fs-ui,15px);padding:14px;cursor:pointer;margin-top:6px}' +
      '.mdu-go.terra{background:var(--terra,#C7765C)}' +
      '.mdu-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);' +
      'font-family:var(--font-technical,Inter,sans-serif);font-weight:var(--w-medium,600);font-size:var(--fs-sm,14px);padding:12px;cursor:pointer;margin-top:9px}' +
      '.mdu-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer;margin-top:14px}' +
      '.mdu-safe{text-align:left;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:14px;margin:4px 0 12px;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,13.5px);line-height:var(--lh-normal,1.5);color:var(--ink,#1F2B25)}' +
      '.mdu-safe b{font-family:var(--font-technical,Inter,sans-serif)}.mdu-safe a{color:var(--terra,#C7765C);font-weight:var(--w-bold,700)}';
    var st = document.createElement('style'); st.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(st);
  }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function shell() {
    closeOv();
    inject();
    ov = E('div', 'mdu-ov md-ov'); var c = E('div', 'mdu-card'); ov.appendChild(c);
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: 'Envie en cours' });
    return c;
  }
  function closeOv() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function exitBtn(c, label) { var b = E('button', 'mdu-exit', label || 'Je vais mieux'); b.type = 'button'; b.onclick = function () { closeOv(); }; c.appendChild(b); }
  // Le héros ouvre chaque écran (chaleureux, pas austère)
  function heroHead(c, mood) {
    if (!window.MDCompagnon) return;
    var av = E('div', 'mdu-ava'); av.innerHTML = '<img src="avatars/' + mood + '.png" alt="" width="88" height="88">'; c.appendChild(av);
  }
  var URG_STEPS = [
    { t: 'Presque rien', v: 1, c: 'var(--sauge,#7A8F72)' },
    { t: 'Un peu', v: 3, c: 'var(--sauge,#7A8F72)' },
    { t: 'Bien présente', v: 5, c: 'var(--ocre,#D5A84A)' },
    { t: 'Forte', v: 7, c: 'var(--terra,#C7765C)' },
    { t: 'Au taquet', v: 9, c: 'var(--terra,#C7765C)' }
  ];
  function scaleInto(c, onPick) {
    var wrap = E('div', 'mdu-steps');
    URG_STEPS.forEach(function (st) {
      var b = E('button', 'mdu-step'); b.type = 'button'; b.style.setProperty('--sc', st.c);
      b.setAttribute('aria-label', 'Envie : ' + st.t);
      b.innerHTML = '<span class="mdu-dot"></span><span>' + st.t + '</span>';
      b.onclick = function () { onPick(st.v); }; wrap.appendChild(b);
    });
    c.appendChild(wrap);
  }
  function log(type, fields) { try { if (window.MDData) window.MDData.logSession(type, fields || {}); } catch (e) { } }

  /* ---- M2 : ouverture, co-régulation d'abord ---- */
  function open() {
    var c = shell();
    heroHead(c, 'ecoute');
    c.appendChild(E('p', 'mdu-q', 'Une envie est là.'));
    c.appendChild(E('p', 'mdu-sub', 'Elle monte, culmine, puis redescend \u2014 toujours. Voyons où tu en es, là, maintenant.'));
    scaleInto(c, route);
    exitBtn(c, 'Je vais mieux');
  }
  // Lance un VRAI exercice (pas de copie) ; il mesurera l'envie avant/après.
  function launch(moduleKey, v) {
    try { sessionStorage.setItem('mdScan', JSON.stringify({ envie: v, ts: Date.now() })); } catch (e) { }
    var page = { breathe: 'breathe.html', tetris: 'tetris.html', maze: 'maze.html' }[moduleKey];
    if (page) location.href = page;
  }
  function exoBtns(c, v, primaryFirst) {
    var defs = [
      { k: 'breathe', t: 'M\u2019apaiser \u2014 Souffle' },
      { k: 'tetris', t: 'Occuper mon esprit \u2014 Tetris' },
      { k: 'maze', t: 'Me recentrer \u2014 Labyrinthe' }
    ];
    defs.forEach(function (d, i) {
      var b = E('button', (i === 0 && primaryFirst) ? 'mdu-go' : 'mdu-2nd', d.t); b.type = 'button';
      b.onclick = function () { launch(d.k, v); }; c.appendChild(b);
    });
  }
  function route(v) {
    if (window.MDReco && window.MDReco.recordHoraire) { try { window.MDReco.recordHoraire(v); } catch (e) { } }
    if (v >= 8) { stageRouge(v); return; }
    var c = shell();
    var waveMood = Math.random() < 0.5 ? 'respiration' : 'lacher-prise';
    heroHead(c, v <= 3 ? 'encouragement' : waveMood);
    c.appendChild(E('p', 'mdu-q', v <= 3 ? 'Tu gères.' : 'On laisse passer la vague.'));
    c.appendChild(E('p', 'mdu-sub', v <= 3
      ? 'L\u2019envie est basse. Si tu veux, occupe-toi un court instant.'
      : 'Le temps que ça redescende, détourne ton esprit avec un exercice court.'));
    exoBtns(c, v, true);
    var rdr = E('button', 'mdu-2nd', 'Réduire les risques'); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    exitBtn(c, 'Je vais mieux');
  }
  function stageRouge(v) {
    var c = shell();
    heroHead(c, 'bienveillance');
    c.appendChild(E('p', 'mdu-q', 'On traverse ça ensemble.'));
    var safe = E('div', 'mdu-safe');
    var vlist = '';
    try { var pv = ((window.MDData ? window.MDData.getCtc() : {}).parcours || {}).valeurs || []; if (pv.length) vlist = '<br><b>Ce qui compte pour toi :</b> ' + pv.slice(0, 4).join(', ') + '.'; } catch (e) { }
    safe.innerHTML = '<b>Tu peux attendre 10 minutes.</b> L\u2019intensité <b>va</b> redescendre.<br>' +
      'Repense à ce qui compte \u2014 ou relis ta lettre au futur toi.' + vlist;
    c.appendChild(safe);
    var s = E('button', 'mdu-go', 'M\u2019apaiser \u2014 Souffle'); s.type = 'button'; s.onclick = function () { launch('breathe', v); }; c.appendChild(s);
    var rdr = E('button', 'mdu-2nd', 'Si je vais consommer quand même'); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'filet' } });
    exitBtn(c, 'Je vais mieux');
  }
  function stageRDR(v) {
    var c = shell();
    heroHead(c, 'bienveillance');
    c.appendChild(E('p', 'mdu-q', 'Alors, réduisons les risques.'));
    c.appendChild(E('p', 'mdu-sub', 'Sans jugement. Te garder en sécurité passe d\u2019abord.'));
    var safe = E('div', 'mdu-safe');
    safe.innerHTML = '\u2022 Ne consomme pas seul\u00B7e.<br>\u2022 Teste ton produit si tu peux, commence <b>bas</b>, espace les prises.<br>' +
      '\u2022 Si opioïdes : aie de la <b>naloxone</b> à portée.<br>\u2022 Ne mélange pas \u2014 vérifie les interactions.';
    c.appendChild(safe);
    var a = E('a', null, 'Ouvrir les infos réduction des risques \u2192'); a.href = 'rdr.html';
    a.style.cssText = 'display:block;color:var(--terra,#C7765C);font-weight:var(--w-bold,700);font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-sm,14px);margin-bottom:14px';
    c.appendChild(a);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'rdr' } });
    exitBtn(c, 'Fermer');
  }

  /* ---- FAB héros craving ---- */
  function mountFAB() {
    if (document.querySelector('.mdu-fab')) return;
    inject();
    var b = E('button', 'mdu-fab'); b.type = 'button'; b.setAttribute('aria-label', 'Je suis en craving — besoin d\u2019aide');
    var av = E('span', 'mdu-av');
    var rest = document.createElement('img'); rest.className = 'rest'; rest.src = 'craving-rest-v2.png'; rest.alt = ''; rest.width = 70; rest.height = 70; rest.setAttribute('aria-hidden', 'true');
    var openi = document.createElement('img'); openi.className = 'open'; openi.src = 'craving-open-v2.png'; openi.alt = ''; openi.width = 70; openi.height = 70; openi.setAttribute('aria-hidden', 'true');
    av.appendChild(rest); av.appendChild(openi);
    var lbl = E('span', 'mdu-lbl', 'En craving');
    b.appendChild(av); b.appendChild(lbl);

    var canHover = false;
    try { canHover = window.matchMedia && window.matchMedia('(hover:hover) and (pointer:fine)').matches; } catch (e) { }

    if (canHover) {
      // PC : le survol ouvre les bras, un clic suffit pour accéder à l'aide
      b.addEventListener('click', open);
    } else {
      // Tactile : 1er appui = ouvre les bras (signale le craving) ; 2e appui = aide
      var armed = false, timer = null;
      function disarm() { armed = false; b.classList.remove('armed'); lbl.textContent = 'En craving'; if (timer) { clearTimeout(timer); timer = null; } }
      b.addEventListener('click', function () {
        if (!armed) {
          armed = true; b.classList.add('armed'); lbl.textContent = 'Clique';
          if (timer) clearTimeout(timer);
          timer = setTimeout(disarm, 4500);
        } else {
          disarm(); open();
        }
      });
    }
    document.body.appendChild(b);
  }
  function auto() {
    if (window.MD_NO_FAB || (document.body && document.body.getAttribute('data-no-fab')==='true')) return;   // pages d'exercice : pas de FAB
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountFAB);
    else mountFAB();
  }
  auto();

  return { open: open, mountFAB: mountFAB };
})();
