/* urgence.js — Mode urgence (M2) + Urge surfing (M3) + FAB flottant.
   Auto-contenu : injecte DOM + styles (charte Atlas, couleurs en fallback), boutons <button>
   (tap iOS fiable). Co-régule AVANT de mesurer. Branche réduction des risques sans jugement.
   Journalise via MDData.logSession. 100 % local. Expose window.MDUrgence. Auto-monte le FAB. */
window.MDUrgence = (function () {
  var INJ = false, ov = null, avant = null;

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      /* FAB */
      '.mdu-fab{position:fixed;right:16px;bottom:78px;z-index:3500;display:flex;align-items:center;gap:7px;' +
      'padding:11px 15px;border:none;border-radius:30px;background:var(--terra,#C7765C);color:#fff;' +
      'font-family:var(--ui,Inter,system-ui,sans-serif);font-weight:700;font-size:13.5px;cursor:pointer;' +
      'box-shadow:0 8px 22px rgba(199,118,92,.45);-webkit-tap-highlight-color:transparent}' +
      '.mdu-fab:active{transform:scale(.96)}.mdu-fab .mdu-bolt{font-size:15px;line-height:1}' +
      /* modal */
      '.mdu-ov{position:fixed;inset:0;z-index:4500;display:flex;align-items:center;justify-content:center;' +
      'padding:20px;background:var(--bg,#F5F2EA);font-family:var(--ui,Inter,sans-serif);overflow-y:auto}' +
      '.mdu-card{max-width:380px;width:100%;text-align:center;color:var(--ink,#1F2B25)}' +
      '.mdu-q{font-family:var(--title,Newsreader,Georgia,serif);font-size:22px;line-height:1.25;margin:0 0 6px}' +
      '.mdu-sub{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:14px;color:var(--ink-2,#58635E);margin:0 0 18px}' +
      /* orbe respiration */
      '.mdu-orb{width:150px;height:150px;border-radius:50%;margin:8px auto 18px;' +
      'background:radial-gradient(circle at 38% 34%, #9db4a6, var(--sauge,#7A8F72) 62%, var(--foret,#33463E));' +
      'box-shadow:0 10px 40px rgba(51,70,62,.3)}' +
      '@media (prefers-reduced-motion:no-preference){.mdu-orb{animation:mdu-breathe 8s ease-in-out infinite}}' +
      '@keyframes mdu-breathe{0%,100%{transform:scale(.72);opacity:.82}50%{transform:scale(1);opacity:1}}' +
      '.mdu-orbcap{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13px;color:var(--ink-2,#58635E);margin:-6px 0 18px}' +
      /* vague (urge surfing) */
      '.mdu-wavewrap{position:relative;height:170px;border-radius:18px;overflow:hidden;margin:8px 0 16px;' +
      'background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0)}' +
      '.mdu-wave{position:absolute;left:0;right:0;bottom:0;height:18%;transition:height 1.6s ease-in-out;' +
      'background:linear-gradient(180deg, var(--fjord,#69889A), var(--sauge,#7A8F72));border-radius:50% 50% 0 0/22px 22px 0 0;opacity:.92}' +
      '.mdu-wave.rise{height:88%}.mdu-wave.fall{height:10%;transition:height 3.2s ease-in-out}' +
      /* échelle 0-10 */
      '.mdu-scale{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin:6px 0 16px}' +
      '.mdu-n{min-width:38px;height:42px;border:1px solid var(--line,#E2DCD0);background:var(--surface,#fff);' +
      'color:var(--ink,#1F2B25);border-radius:11px;font-family:var(--content,"Atkinson Hyperlegible",sans-serif);' +
      'font-size:16px;font-weight:700;cursor:pointer;-webkit-tap-highlight-color:transparent}.mdu-n:active{transform:scale(.94)}' +
      /* boutons */
      '.mdu-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-family:var(--ui,Inter,sans-serif);' +
      'font-weight:700;font-size:15px;padding:14px;cursor:pointer;margin-top:6px}' +
      '.mdu-go.terra{background:var(--terra,#C7765C)}' +
      '.mdu-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);' +
      'font-family:var(--ui,Inter,sans-serif);font-weight:600;font-size:14px;padding:12px;cursor:pointer;margin-top:9px}' +
      '.mdu-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:13px;text-decoration:underline;cursor:pointer;margin-top:14px}' +
      '.mdu-safe{text-align:left;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:14px;margin:4px 0 12px;' +
      'font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:13.5px;line-height:1.5;color:var(--ink,#1F2B25)}' +
      '.mdu-safe b{font-family:var(--ui,Inter,sans-serif)}.mdu-safe a{color:var(--terra,#C7765C);font-weight:700}' +
      '.mdu-delta{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:17px;margin:8px 0 12px}' +
      '.mdu-big{font-family:var(--title,Newsreader,serif);font-size:30px;font-weight:700}' +
      '.mdu-down{color:var(--sauge,#7A8F72)}.mdu-up{color:var(--terra,#C7765C)}.mdu-flat{color:var(--ink-2,#58635E)}';
    var st = document.createElement('style'); st.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(st);
  }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function shell() {
    closeOv();
    inject();
    ov = E('div', 'mdu-ov'); var c = E('div', 'mdu-card'); ov.appendChild(c);
    document.body.appendChild(ov); return c;
  }
  function closeOv() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function exitBtn(c, label) { var b = E('button', 'mdu-exit', label || 'Je vais mieux'); b.type = 'button'; b.onclick = function () { closeOv(); }; c.appendChild(b); }
  function scaleInto(c, onPick) {
    var row = E('div', 'mdu-scale');
    for (var i = 0; i <= 10; i++) (function (n) {
      var b = E('button', 'mdu-n', String(n)); b.type = 'button'; b.setAttribute('aria-label', 'Envie ' + n + ' sur 10');
      b.onclick = function () { onPick(n); }; row.appendChild(b);
    })(i);
    c.appendChild(row);
  }
  function log(type, fields) { try { if (window.MDData) window.MDData.logSession(type, fields || {}); } catch (e) { } }

  /* ---- M2 : ouverture, co-régulation d'abord ---- */
  function open() {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Tu es là. On respire ensemble.'));
    c.appendChild(E('div', 'mdu-orb'));
    c.appendChild(E('p', 'mdu-orbcap', 'Inspire en gonflant\u2026 souffle en dégonflant.'));
    var go = E('button', 'mdu-go', 'Continuer'); go.type = 'button'; go.onclick = stageEnvie; c.appendChild(go);
    exitBtn(c, 'Je vais mieux');
  }
  function stageEnvie() {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'L\u2019envie est à\u2026'));
    c.appendChild(E('p', 'mdu-sub', '0 = aucune  ·  10 = irrésistible'));
    scaleInto(c, route);
    exitBtn(c, 'Je vais mieux');
  }
  function route(v) {
    avant = v;
    if (v <= 3) {
      var c = shell();
      c.appendChild(E('p', 'mdu-q', 'Tu gères.'));
      c.appendChild(E('p', 'mdu-sub', 'L\u2019envie est basse. Un instant pour toi suffit souvent.'));
      var s = E('button', 'mdu-go', 'Respirer 30 s'); s.type = 'button'; s.onclick = function () { open(); }; c.appendChild(s);
      log('urgence', { envieAvant: v, contexte: { niveau: 'vert' }, meta: { issue: 'sortie' } });
      exitBtn(c, 'Fermer');
    } else if (v <= 7) {
      openSurf(v, 'orange');
    } else {
      stageRouge(v);
    }
  }
  function stageRouge(v) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'On traverse ça ensemble.'));
    var safe = E('div', 'mdu-safe');
    var vlist = '';
    try { var pv = ((window.MDData ? window.MDData.getCtc() : {}).parcours || {}).valeurs || []; if (pv.length) vlist = '<br><b>Ce qui compte pour toi :</b> ' + pv.slice(0, 4).join(', ') + '.'; } catch (e) { }
    safe.innerHTML = '<b>Tu peux attendre 10 minutes.</b> L\u2019intensité va redescendre.<br>' +
      'Repense à ce qui compte pour toi \u2014 ou relis ta lettre au futur toi.' + vlist;
    c.appendChild(safe);
    var surf = E('button', 'mdu-go', 'Traverser l\u2019envie avec moi'); surf.type = 'button';
    surf.onclick = function () { openSurf(v, 'rouge'); }; c.appendChild(surf);
    var rdr = E('button', 'mdu-2nd', 'Si je vais consommer quand même'); rdr.type = 'button';
    rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    exitBtn(c, 'Je vais mieux');
  }
  function stageRDR(v) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Alors, réduisons les risques.'));
    c.appendChild(E('p', 'mdu-sub', 'Sans jugement. Te garder en sécurité passe d\u2019abord.'));
    var safe = E('div', 'mdu-safe');
    safe.innerHTML = '\u2022 Ne consomme pas seul\u00B7e.<br>\u2022 Teste ton produit si tu peux, commence <b>bas</b>, espace les prises.<br>' +
      '\u2022 Si opioïdes : aie de la <b>naloxone</b> à portée.<br>\u2022 Ne mélange pas \u2014 vérifie les interactions.';
    c.appendChild(safe);
    var a = E('a', null, 'Ouvrir les infos réduction des risques \u2192'); a.href = 'rdr.html';
    a.style.cssText = 'display:block;color:var(--terra,#C7765C);font-weight:700;font-family:var(--ui,Inter,sans-serif);font-size:14px;margin-bottom:14px';
    c.appendChild(a);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'rdr' } });
    exitBtn(c, 'Fermer');
  }

  /* ---- M3 : Urge surfing ---- */
  function openSurf(av, niveau) {
    if (av != null) avant = av;
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'On surfe l\u2019envie.'));
    c.appendChild(E('p', 'mdu-sub', 'On ne la combat pas. On la regarde monter, culminer, puis redescendre.'));
    var wrap = E('div', 'mdu-wavewrap'); var wave = E('span', 'mdu-wave'); wrap.appendChild(wave); c.appendChild(wrap);
    var go = E('button', 'mdu-go', 'Commencer'); go.type = 'button';
    go.onclick = function () { surfRise(c, wave, niveau); }; c.appendChild(go);
    exitBtn(c, 'Plus tard');
  }
  function surfRise(c, wave, niveau) {
    wave.className = 'mdu-wave rise';
    c.querySelector('.mdu-q').textContent = 'Elle monte\u2026';
    c.querySelector('.mdu-sub').textContent = 'C\u2019est normal. Reste à l\u2019observer, sans rien faire.';
    var btn = c.querySelector('.mdu-go'); btn.textContent = 'Le pic est là';
    btn.onclick = function () { surfPeak(c, wave, niveau); };
  }
  function surfPeak(c, wave, niveau) {
    c.querySelector('.mdu-q').textContent = 'Tu es au sommet.';
    c.querySelector('.mdu-sub').textContent = 'Tu n\u2019as rien fait. La vague va redescendre.';
    var btn = c.querySelector('.mdu-go');
    setTimeout(function () { wave.className = 'mdu-wave fall'; }, 60);
    btn.textContent = 'Je la sens redescendre';
    btn.onclick = function () { surfAfter(niveau); };
  }
  function surfAfter(niveau) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Et maintenant, l\u2019envie est à\u2026'));
    scaleInto(c, function (apres) {
      var delta = (avant != null && apres != null) ? (avant - apres) : null;
      log('surf', { envieAvant: avant, envieApres: apres, contexte: { niveau: niveau || 'orange' }, meta: { picTraverse: true } });
      surfRecap(avant, apres, delta);
    });
    exitBtn(c, 'Passer');
  }
  function surfRecap(av, ap, delta) {
    var c = shell();
    c.appendChild(E('p', 'mdu-q', 'Tu l\u2019as traversée.'));
    if (av != null && ap != null) {
      var d = E('p', 'mdu-delta');
      var cls = delta > 0 ? 'mdu-down' : (delta < 0 ? 'mdu-up' : 'mdu-flat');
      var arrow = delta > 0 ? '\u25BC' : (delta < 0 ? '\u25B2' : '\u2192');
      d.innerHTML = 'Ton envie : <span class="mdu-big">' + av + '</span> \u2192 <span class="mdu-big">' + ap +
        '</span><br><span class="' + cls + '">' + arrow + ' ' + (delta > 0 ? '\u2212' + delta : (delta < 0 ? '+' + (-delta) : 'stable')) + '</span>';
      c.appendChild(d);
    }
    c.appendChild(E('p', 'mdu-sub', 'L\u2019envie est un pic qui passe. Tu viens de le prouver.'));
    var go = E('button', 'mdu-go', 'Terminer'); go.type = 'button'; go.onclick = function () { closeOv(); avant = null; }; c.appendChild(go);
  }

  /* ---- FAB ---- */
  function mountFAB() {
    if (document.querySelector('.mdu-fab')) return;
    inject();
    var b = E('button', 'mdu-fab'); b.type = 'button'; b.setAttribute('aria-label', 'Je suis en craving');
    var bolt = E('span', 'mdu-bolt', '\u26A1'); b.appendChild(bolt); b.appendChild(document.createTextNode('En craving'));
    b.onclick = open; document.body.appendChild(b);
  }
  function auto() {
    if (window.MD_NO_FAB) return;                 // pages d'exercice : pas de FAB
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountFAB);
    else mountFAB();
  }
  auto();

  return { open: open, openSurf: openSurf, mountFAB: mountFAB };
})();
