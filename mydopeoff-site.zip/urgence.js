/* urgence.js — Mode urgence (M2) + Urge surfing (M3) + FAB flottant.
   Auto-contenu : injecte DOM + styles (charte Atlas, couleurs en fallback), boutons <button>
   (tap iOS fiable). Co-régule AVANT de mesurer. Branche réduction des risques sans jugement.
   Journalise via MDData.logSession. 100 % local. Expose window.MDUrgence. Auto-monte le FAB. */
window.MDUrgence = (function () {
  var INJ = false, ov = null, avant = null;
  function lang() { try { return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; } catch (e) { return 'fr'; } }
  var T = {
    craving_in_progress:{fr:'Envie en cours',en:'Craving in progress'},
    feel_better:{fr:'Je vais mieux',en:'I feel better'},
    almost_none:{fr:'Presque rien',en:'Almost none'}, a_little:{fr:'Un peu',en:'A little'},
    well_present:{fr:'Bien présente',en:'Well present'}, strong:{fr:'Forte',en:'Strong'}, maxed_out:{fr:'Au taquet',en:'Maxed out'},
    urge_lbl:{fr:function(t){return 'Envie : '+t;}, en:function(t){return 'Urge: '+t;}},
    urge_here:{fr:'Une envie est là.',en:'An urge is here.'},
    urge_sub:{fr:'Elle monte, culmine, puis redescend \u2014 toujours. Voyons où tu en es, là, maintenant.',
              en:'It rises, peaks, then falls again \u2014 always. Let\u2019s see where you\u2019re at, right now.'},
    calm_breath:{fr:'M\u2019apaiser \u2014 Souffle',en:'Calm down \u2014 Breathe'},
    occupy_tetris:{fr:'Occuper mon esprit \u2014 Tetris',en:'Occupy my mind \u2014 Tetris'},
    recenter_maze:{fr:'Me recentrer \u2014 Labyrinthe',en:'Recentre myself \u2014 Maze'},
    you_manage:{fr:'Tu gères.',en:'You\u2019ve got this.'}, let_wave_pass:{fr:'On laisse passer la vague.',en:'Let\u2019s let the wave pass.'},
    low_urge_sub:{fr:'L\u2019envie est basse. Si tu veux, occupe-toi un court instant.',en:'The urge is low. If you want, occupy yourself for a short moment.'},
    high_urge_sub:{fr:'Le temps que ça redescende, détourne ton esprit avec un exercice court.',en:'While it settles down, redirect your mind with a short exercise.'},
    reduce_risks:{fr:'Réduire les risques',en:'Reduce risks'},
    through_together:{fr:'On traverse ça ensemble.',en:'We\u2019ll get through this together.'},
    what_matters:{fr:'Ce qui compte pour toi :',en:'What matters to you:'},
    can_wait_10:{fr:'<b>Tu peux attendre 10 minutes.</b> L\u2019intensité <b>va</b> redescendre.<br>Repense à ce qui compte \u2014 ou relis la lettre que tu t\u2019es écrite.',
                 en:'<b>You can wait 10 minutes.</b> The intensity <b>will</b> come back down.<br>Think back to what matters \u2014 or reread the letter you wrote yourself.'},
    if_use_anyway:{fr:'Si je vais consommer quand même',en:'If I\u2019m going to use anyway'},
    lets_reduce_risks:{fr:'Alors, réduisons les risques.',en:'Alright, let\u2019s reduce the risks.'},
    without_judgment:{fr:'Sans jugement. Te garder en sécurité passe d\u2019abord.',en:'No judgment. Keeping you safe comes first.'},
    rdr_list:{fr:'\u2022 Ne consomme pas seul\u00B7e.<br>\u2022 Teste ton produit si tu peux, commence <b>bas</b>, espace les prises.<br>\u2022 Si opioïdes : aie de la <b>naloxone</b> à portée.<br>\u2022 Ne mélange pas \u2014 vérifie les interactions.',
              en:'\u2022 Don\u2019t use alone.<br>\u2022 Test your product if you can, start <b>low</b>, space out your doses.<br>\u2022 If opioids: keep <b>naloxone</b> within reach.<br>\u2022 Don\u2019t mix \u2014 check interactions.'},
    open_rdr_info:{fr:'Ouvrir les infos réduction des risques \u2192',en:'Open harm reduction info \u2192'},
    close_btn:{fr:'Fermer',en:'Close'},
    craving_aria:{fr:'Je suis en craving — besoin d\u2019aide',en:'I\u2019m craving — need help'},
    craving_lbl:{fr:'En craving',en:'Craving'},
    gauge_confirm:{fr:'C\u2019est \u00e0 peu pr\u00e8s \u00e7a',en:'That\u2019s about right'},
    gauge_end_low:{fr:'presque rien',en:'almost none'},
    gauge_end_high:{fr:'au taquet',en:'maxed out'}
  };
  function t(k, arg) { var e = T[k]; if (!e) return k; var v = lang() === 'en' ? e.en : e.fr; return (typeof v === 'function') ? v(arg) : v; }

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      /* FAB — héros craving (visuel SOS unique, simple tap) */
      '.mdu-fab{position:fixed;right:14px;bottom:80px;bottom:calc(80px + env(safe-area-inset-bottom));z-index:var(--z-nav,50);' +
      'display:flex;flex-direction:column;align-items:center;gap:2px;border:none;background:none !important;padding:0;cursor:pointer;' +
      '-webkit-tap-highlight-color:transparent;font-family:var(--font-technical,Inter,system-ui,sans-serif)}' +
      '.mdu-av{position:relative;width:70px;height:70px;border-radius:50%;overflow:visible;background:transparent;' +
      'transition:transform .2s var(--ease,ease),filter .2s}' +
      '.mdu-av img{position:absolute;inset:0;margin:auto;width:100%;height:100%;object-fit:contain}' +
      '.mdu-lbl{font-weight:var(--w-bold,700);font-size:var(--fs-caps,11px);color:var(--terra-d,#A85A42);background:color-mix(in srgb,var(--bg,#F5F2EA) 86%,transparent);' +
      'padding:1px 8px;border-radius:20px;white-space:nowrap}' +
      '.mdu-fab:active .mdu-av{transform:scale(.94)}' +
      '@media (hover:hover) and (pointer:fine){' +
      '.mdu-fab:hover .mdu-av{transform:scale(1.08);filter:drop-shadow(0 6px 14px rgba(199,118,92,.5))}}' +
      '@media (prefers-reduced-motion:reduce){.mdu-av,.mdu-av img{transition:none}}' +
      /* modal */
      '.mdu-ov{z-index:var(--z-modal-5,4500);align-items:flex-start;justify-content:center;' +
      'padding:20px;background:var(--bg,#F5F2EA);font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mdu-card{position:relative;z-index:var(--z-base,1);max-width:380px;width:100%;text-align:center;color:var(--ink,#1F2B25)}' +
      '.mdu-ava{display:block;width:var(--avatar-md,52px);height:var(--avatar-md,52px);border-radius:50%;overflow:hidden;margin:0 auto 8px;background:var(--sauge-50,#EEF1E9);border:1px solid var(--line,#E2DCD0)}' +
      '.mdu-ava img{width:100%;height:100%;object-fit:cover;display:block}' +
      '.mdu-q{font-family:var(--font-editorial,Newsreader,Georgia,serif);font-size:var(--fs-h3,22px);line-height:var(--lh-tight,1.25);margin:0 0 6px}' +
      '.mdu-sub{font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,14px);color:var(--ink-2,#58635E);margin:0 0 18px}' +
      /* jauge d'intensité — remplace les 5 boutons empilés (v2), garde le ton chaud :
         pas de chiffre affiché, juste un mot qui change en direct + une couleur qui glisse. */
      '.mdu-gauge{margin:10px 0 18px}' +
      '.mdu-gauge-label{font-family:var(--font-editorial,Newsreader,Georgia,serif);font-size:var(--fs-h4,19px);' +
      'color:var(--gc,var(--sauge,#7A8F72));min-height:1.3em;margin-bottom:14px;transition:color .15s}' +
      '.mdu-gauge-track{position:relative;height:44px;display:flex;align-items:center;touch-action:pan-y}' +
      '.mdu-gauge-rail{position:absolute;top:50%;left:0;right:0;height:10px;transform:translateY(-50%);border-radius:999px;' +
      'background:linear-gradient(90deg,var(--sauge,#7A8F72) 0%,var(--ocre,#D5A84A) 50%,var(--terra,#C7765C) 100%);opacity:.28}' +
      '.mdu-gauge-fill{position:absolute;top:50%;left:0;height:10px;transform:translateY(-50%);border-radius:999px;background:var(--gc,var(--sauge,#7A8F72));' +
      'transition:background .15s;pointer-events:none}' +
      '.mdu-gauge-input{position:relative;width:100%;height:30px;margin:0;-webkit-appearance:none;appearance:none;' +
      'background:transparent!important;border:none!important;border-radius:0!important;padding:0!important;cursor:pointer}' +
      '.mdu-gauge-input:focus{outline:none;box-shadow:none!important;border:none!important}' +
      '.mdu-gauge-input::-webkit-slider-runnable-track{-webkit-appearance:none;height:30px;background:transparent}' +
      '.mdu-gauge-input::-webkit-slider-thumb{-webkit-appearance:none;width:30px;height:30px;border-radius:50%;' +
      'background:var(--gc,var(--sauge,#7A8F72));border:3px solid #fff;box-shadow:0 2px 8px rgba(31,43,37,.28);margin-top:0;' +
      'transition:background .15s}' +
      '.mdu-gauge-input::-moz-range-track{height:30px;background:transparent}' +
      '.mdu-gauge-input::-moz-range-thumb{width:30px;height:30px;border:3px solid #fff;border-radius:50%;' +
      'background:var(--gc,var(--sauge,#7A8F72));box-shadow:0 2px 8px rgba(31,43,37,.28)}' +
      '.mdu-gauge-ends{display:flex;justify-content:space-between;margin-top:6px;' +
      'font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-caps,11px);color:var(--ink-2,#58635E);' +
      'text-transform:uppercase;letter-spacing:var(--ls-caps,.06em)}' +
      '.mdu-gauge-go{width:100%;border:none;border-radius:13px;background:var(--gc,var(--foret,#33463E));color:#fff;' +
      'font-family:var(--font-technical,Inter,sans-serif);font-weight:var(--w-bold,700);font-size:var(--fs-ui,15px);' +
      'padding:14px;cursor:pointer;margin-top:16px;transition:background .15s}' +
      /* boutons */
      '.mdu-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-family:var(--font-technical,Inter,sans-serif);' +
      'font-weight:var(--w-bold,700);font-size:var(--fs-ui,15px);padding:14px;cursor:pointer;margin-top:6px}' +
      '.mdu-go.terra{background:var(--terra,#C7765C)}' +
      '.mdu-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);' +
      'font-family:var(--font-technical,Inter,sans-serif);font-weight:var(--w-medium,600);font-size:var(--fs-sm,14px);padding:12px;cursor:pointer;margin-top:9px}' +
      '.mdu-exit{background:none;border:none;color:var(--ink-2,#58635E);font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer;margin-top:14px}' +
      '.mdu-safe{text-align:left;background:var(--surface,#fff);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:14px;margin:4px 0 12px;' +
      'font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,13.5px);line-height:var(--lh-normal,1.5);color:var(--ink,#1F2B25)}' +
      '.mdu-safe b{font-family:var(--font-technical,Inter,sans-serif)}.mdu-safe a{color:var(--terra,#C7765C);font-weight:var(--w-bold,700)}';
    var st = document.createElement('style'); st.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(st);
  }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function shell() {
    closeOv();
    inject();
    ov = E('div', 'mdu-ov md-ov'); var c = E('div', 'mdu-card'); ov.appendChild(c);
    document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: t('craving_in_progress'), onClose: closeOv });
    return c;
  }
  function closeOv() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function exitBtn(c, label) { var b = E('button', 'mdu-exit', label || t('feel_better')); b.type = 'button'; b.onclick = function () { closeOv(); }; c.appendChild(b); }
  // Le héros ouvre chaque écran (chaleureux, pas austère)
  function heroHead(c, mood) {
    if (!window.MDCompagnon) return;
    var av = E('div', 'mdu-ava');
    av.innerHTML = window.MDMascotte
      ? window.MDMascotte.avatar('craving', { humeur: mood })
      : window.MDCompagnon.avatarHTML(mood, { size: 'md' });
    c.appendChild(av);
  }
  var GAUGE_ZONES = [
    { max:1, l:'almost_none', c:[122,143,114] },
    { max:3, l:'a_little', c:[151,163,110] },
    { max:6, l:'well_present', c:[213,168,74] },
    { max:8, l:'strong', c:[205,131,90] },
    { max:10, l:'maxed_out', c:[199,118,92] }
  ];
  function gaugeColor(v){
    var z = GAUGE_ZONES.filter(function(g){ return v<=g.max; })[0] || GAUGE_ZONES[GAUGE_ZONES.length-1];
    return 'rgb('+z.c[0]+','+z.c[1]+','+z.c[2]+')';
  }
  function gaugeLabel(v){
    var z = GAUGE_ZONES.filter(function(g){ return v<=g.max; })[0] || GAUGE_ZONES[GAUGE_ZONES.length-1];
    return t(z.l);
  }
  function scaleInto(c, onPick) {
    var wrap = E('div', 'mdu-gauge');
    var val = 5;
    var label = E('div', 'mdu-gauge-label'); label.setAttribute('aria-live','polite'); label.textContent = gaugeLabel(val);
    var track = E('div', 'mdu-gauge-track');
    var rail = E('div', 'mdu-gauge-rail');
    var fill = E('div', 'mdu-gauge-fill'); fill.style.width = (val*10)+'%';
    var input = document.createElement('input'); input.type='range'; input.min='0'; input.max='10'; input.step='1'; input.value=String(val);
    input.className='mdu-gauge-input'; input.setAttribute('aria-label', t('urge_lbl', gaugeLabel(val)));
    track.appendChild(rail); track.appendChild(fill); track.appendChild(input);
    var ends = E('div', 'mdu-gauge-ends');
    ends.innerHTML = '<span>'+t('gauge_end_low')+'</span><span>'+t('gauge_end_high')+'</span>';
    function update(){
      val = parseInt(input.value,10);
      var col = gaugeColor(val);
      wrap.style.setProperty('--gc', col);
      label.textContent = gaugeLabel(val);
      fill.style.width = (val*10)+'%';
      input.setAttribute('aria-label', t('urge_lbl', gaugeLabel(val)));
    }
    input.addEventListener('input', update);
    update();
    var go = E('button', 'mdu-gauge-go', t('gauge_confirm')); go.type='button';
    go.onclick = function(){ onPick(val); };
    wrap.appendChild(label); wrap.appendChild(track); wrap.appendChild(ends); wrap.appendChild(go);
    c.appendChild(wrap);
  }
  function log(type, fields) { try { if (window.MDData) window.MDData.logSession(type, fields || {}); } catch (e) { } }

  /* ---- M2 : ouverture, co-régulation d'abord ---- */
  function open() {
    var c = shell();
    heroHead(c, 'ecoute');
    c.appendChild(E('p', 'mdu-q', t('urge_here')));
    c.appendChild(E('p', 'mdu-sub', t('urge_sub')));
    scaleInto(c, route);
    exitBtn(c, t('feel_better'));
  }
  // Lance un VRAI exercice (pas de copie) ; il mesurera l'envie avant/après.
  function launch(moduleKey, v) {
    try { sessionStorage.setItem('mdScan', JSON.stringify({ envie: v, ts: Date.now() })); } catch (e) { }
    var page = { breathe: 'breathe.html', tetris: 'tetris.html', maze: 'maze.html' }[moduleKey];
    if (page) location.href = page;
  }
  function exoBtns(c, v, primaryFirst) {
    var defs = [
      { k: 'breathe', t: t('calm_breath') },
      { k: 'tetris', t: t('occupy_tetris') },
      { k: 'maze', t: t('recenter_maze') }
    ];
    defs.forEach(function (d, i) {
      var b = E('button', (i === 0 && primaryFirst) ? 'mdu-go' : 'mdu-2nd', d.t); b.type = 'button';
      b.onclick = function () { launch(d.k, v); }; c.appendChild(b);
    });
  }
  function route(v) {
    if (window.MDReco && window.MDReco.recordHoraire) { try { window.MDReco.recordHoraire(v); } catch (e) { } }
    if (v >= 8) { stageRouge(v); return; }
    var c = shell();
    var waveMood = Math.random() < 0.5 ? 'respiration' : 'lacher-prise';
    heroHead(c, v <= 3 ? 'encouragement' : waveMood);
    c.appendChild(E('p', 'mdu-q', v <= 3 ? t('you_manage') : t('let_wave_pass')));
    c.appendChild(E('p', 'mdu-sub', v <= 3 ? t('low_urge_sub') : t('high_urge_sub')));
    exoBtns(c, v, true);
    var rdr = E('button', 'mdu-2nd', t('reduce_risks')); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    exitBtn(c, t('feel_better'));
  }
  function stageRouge(v) {
    var c = shell();
    heroHead(c, 'bienveillance');
    c.appendChild(E('p', 'mdu-q', t('through_together')));
    var safe = E('div', 'mdu-safe');
    var vlist = '';
    try { var pv = ((window.MDData ? window.MDData.getCtc() : {}).parcours || {}).valeurs || []; if (pv.length) vlist = '<br><b>' + t('what_matters') + '</b> ' + pv.slice(0, 4).join(', ') + '.'; } catch (e) { }
    safe.innerHTML = t('can_wait_10') + vlist;
    c.appendChild(safe);
    var s = E('button', 'mdu-go', t('calm_breath')); s.type = 'button'; s.onclick = function () { launch('breathe', v); }; c.appendChild(s);
    var rdr = E('button', 'mdu-2nd', t('if_use_anyway')); rdr.type = 'button'; rdr.onclick = function () { stageRDR(v); }; c.appendChild(rdr);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'filet' } });
    exitBtn(c, t('feel_better'));
  }
  function stageRDR(v) {
    var c = shell();
    heroHead(c, 'bienveillance');
    c.appendChild(E('p', 'mdu-q', t('lets_reduce_risks')));
    c.appendChild(E('p', 'mdu-sub', t('without_judgment')));
    var safe = E('div', 'mdu-safe');
    safe.innerHTML = t('rdr_list');
    c.appendChild(safe);
    var a = E('a', null, t('open_rdr_info')); a.href = 'rdr.html';
    a.style.cssText = 'display:block;color:var(--terra,#C7765C);font-weight:var(--w-bold,700);font-family:var(--font-technical,Inter,sans-serif);font-size:var(--fs-sm,14px);margin-bottom:14px';
    c.appendChild(a);
    log('urgence', { envieAvant: v, contexte: { niveau: 'rouge' }, meta: { issue: 'rdr' } });
    exitBtn(c, t('close_btn'));
  }

  /* ---- FAB héros craving ---- */
  function mountFAB() {
    if (document.querySelector('.mdu-fab')) return;
    inject();
    var b = E('button', 'mdu-fab'); b.type = 'button'; b.setAttribute('aria-label', t('craving_aria'));
    var av = E('span', 'mdu-av');
    var img = document.createElement('img'); img.src = 'craving-sos.png'; img.alt = ''; img.width = 70; img.height = 70; img.setAttribute('aria-hidden', 'true');
    av.appendChild(img);
    var lbl = E('span', 'mdu-lbl', t('craving_lbl'));
    b.appendChild(av); b.appendChild(lbl);
    b.addEventListener('click', open);
    document.body.appendChild(b);
  }
  function auto() {
    if (window.MD_NO_FAB || (document.body && document.body.getAttribute('data-no-fab')==='true')) return;   // pages d'exercice : pas de FAB
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountFAB);
    else mountFAB();
  }
  auto();

  return { open: open, mountFAB: mountFAB };
})();
