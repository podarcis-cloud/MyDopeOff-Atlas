/* decor.js — Couche décor « Atlas » réutilisable pour TOUS les écrans du Parcours.
   Fond ivoire chaud + blobs organiques SVG (palette signature) + points épars + vague/arc.
   Enfants SVG créés via createElementNS (rendu fiable partout, iOS inclus). pointer-events off.
   Usage : MDDecor.into(overlayEl, {dots,wave,arc}); mettre la carte de contenu en .atlas-up
   (ou position:relative;z-index:1). Expose window.MDDecor. */
window.MDDecor = (function () {
  var NS = 'http://www.w3.org/2000/svg', INJ = false;
  var BLOB = 'M54 7c19-3 37 7 44 25 6 17 3 38-11 50-13 12-34 16-51 9C18 84 6 66 7 47 8 28 22 12 41 8c5-1 9-1 13-1Z';
  function css() {
    if (INJ) return; INJ = true;
    var s = document.createElement('style');
    s.textContent =
      '.atlas-decor{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;z-index:0;border-radius:inherit;background:var(--bg,#F5F2EA)}' +
      '.atlas-decor>*{position:absolute}' +
      '.atlas-up{position:relative;z-index:1}';
    document.head.appendChild(s);
  }
  function mk(tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  function svg(w, h, pos, op) {
    var e = mk('svg', { width: w, height: h, viewBox: '0 0 ' + w + ' ' + h, 'aria-hidden': 'true' });
    e.style.cssText = pos + (op != null ? 'opacity:' + op + ';' : '');
    return e;
  }
  function blob(color, size, pos, op) {
    var e = mk('svg', { width: size, height: size, viewBox: '0 0 108 108', 'aria-hidden': 'true' });
    e.style.cssText = pos + 'opacity:' + op + ';';
    e.appendChild(mk('path', { d: BLOB, fill: color }));
    return e;
  }
  function dots(pos) {
    var P = [[4, 22], [14, 10], [10, 32], [24, 18], [22, 38], [34, 8], [33, 28], [44, 22], [42, 40], [54, 14], [52, 34], [62, 26]];
    var e = svg(70, 48, pos, .5);
    P.forEach(function (p) { e.appendChild(mk('circle', { cx: p[0], cy: p[1], r: 1.7, fill: '#58635E' })); });
    return e;
  }
  function wave(pos) {
    var e = svg(64, 26, pos, .5);
    e.appendChild(mk('path', { d: 'M2 8 q8 -7 16 0 t16 0 t16 0', fill: 'none', stroke: '#C7765C', 'stroke-width': 2, 'stroke-linecap': 'round' }));
    e.appendChild(mk('path', { d: 'M2 18 q8 -7 16 0 t16 0 t16 0', fill: 'none', stroke: '#69889A', 'stroke-width': 2, 'stroke-linecap': 'round' }));
    return e;
  }
  function arc(pos) {
    var e = svg(46, 28, pos, .5);
    e.appendChild(mk('path', { d: 'M4 24 a19 19 0 0 1 38 0', fill: 'none', stroke: '#7A8F72', 'stroke-width': 2 }));
    e.appendChild(mk('path', { d: 'M11 24 a12 12 0 0 1 24 0', fill: 'none', stroke: '#D5A84A', 'stroke-width': 2 }));
    return e;
  }
  function into(host, opts) {
    if (!host) return; css(); opts = opts || {};
    if (host.querySelector('.atlas-decor')) return;
    var d = document.createElement('div'); d.className = 'atlas-decor';
    d.appendChild(blob('#7A8F72', 240, 'top:-78px;left:-66px;', .17));
    d.appendChild(blob('#CBA8A0', 210, 'top:-58px;right:-58px;', .22));
    d.appendChild(blob('#69889A', 260, 'bottom:-92px;right:-64px;', .16));
    d.appendChild(blob('#D5A84A', 200, 'bottom:-66px;left:-58px;', .17));
    d.appendChild(blob('#33463E', 150, 'top:40%;left:56%;', .06));
    if (opts.dots !== false) d.appendChild(dots('top:14px;left:12px;'));
    if (opts.wave) d.appendChild(wave('bottom:16px;right:12px;'));
    if (opts.arc) d.appendChild(arc('top:12px;right:14px;'));
    host.insertBefore(d, host.firstChild);
    return d;
  }
  return { into: into, css: css };
})();
