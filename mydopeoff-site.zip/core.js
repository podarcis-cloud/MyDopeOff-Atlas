/* ============================================================================
   MyDope Off — core.js · socle partagé (direction « Atlas du changement »)
   • Profil lu/écrit UNIQUEMENT dans localStorage (jamais l'URL → pas de fuite).
   • Source unique : logo / wordmark / nav / i18n / région / thème de section.
   Dépendances optionnelles chargées avant : i18n.js (MD_DICT), regions.js (MDRegions).
   Chemins À PLAT (déploiement GitHub Pages sans sous-dossier).
   ============================================================================ */
window.MDCore = (function () {
  'use strict';

  var KEY = 'ctc_v6', LANG_KEY = 'mydopeoff_lang';
  var LANGS = ['fr','en','es','de'];
  var LANG_NAMES = { fr:'Français', en:'English', es:'Español', de:'Deutsch' };

  /* ---------- Profil (localStorage only) ---------- */
  function store(){ try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ return {}; } }
  function user(){ return store().user || null; }
  function saveUser(u){ try { var s=store(); s.user=u; localStorage.setItem(KEY, JSON.stringify(s)); } catch(e){} }
  function regionCode(){ var u=user(), c=(u&&u.region)||'BE'; if (window.MDRegions && !window.MDRegions.exists(c)) c='BE'; return c; }
  function region(){ return window.MDRegions ? window.MDRegions.get(regionCode()) : null; }
  function link(href){ return href; }

  /* ---------- i18n ---------- */
  function dict(){ return window.MD_DICT || {}; }
  function lang(){ try { var l=localStorage.getItem(LANG_KEY); if (l && LANGS.indexOf(l)>-1) return l; } catch(e){} return 'fr'; }
  function setLang(l){
    if (LANGS.indexOf(l)===-1) return;
    try { localStorage.setItem(LANG_KEY,l); } catch(e){}
    document.documentElement.setAttribute('lang', l);
    applyI18n(); renderLangSelect();
    document.dispatchEvent(new CustomEvent('langchange',{ detail:{ lang:l } }));
  }
  function t(keyOrObj, vars){
    var l=lang(), s, D=dict();
    if (keyOrObj && typeof keyOrObj==='object') s = keyOrObj[l]||keyOrObj.fr||'';
    else { var e=D[keyOrObj]; s = e ? (e[l]||e.fr) : keyOrObj; }
    if (vars) Object.keys(vars).forEach(function(k){ s=s.replace('{'+k+'}', vars[k]); });
    return s;
  }
  function applyI18n(){
    var D=dict();
    document.querySelectorAll('[data-i18n]').forEach(function(el){ var k=el.getAttribute('data-i18n'); if (D[k]) el.textContent=t(k); });
    document.querySelectorAll('[data-i18n-ph]').forEach(function(el){ var k=el.getAttribute('data-i18n-ph'); if (D[k]) el.setAttribute('placeholder', t(k)); });
    document.querySelectorAll('[data-i18n-aria]').forEach(function(el){ var k=el.getAttribute('data-i18n-aria'); if (D[k]) el.setAttribute('aria-label', t(k)); });
  }
  function renderLangSelect(){
    document.querySelectorAll('[data-langselect]').forEach(function(host){
      var cur=lang();
      host.innerHTML = '<div class="lang" role="group" aria-label="'+t('common.language')+'">'+
        LANGS.map(function(l){ return '<button type="button" class="'+(l===cur?'on':'')+'" data-setlang="'+l+'" aria-pressed="'+(l===cur)+'">'+l.toUpperCase()+'</button>'; }).join('')+'</div>';
      host.querySelectorAll('[data-setlang]').forEach(function(b){ b.addEventListener('click', function(){ setLang(b.getAttribute('data-setlang')); }); });
    });
  }

  /* ---------- Marque : sommet & soleil (Atlas) ---------- */
  function logoSVG(size, mono){
    size = size || 30;
    var c1 = mono ? '#fff' : '#33463E';   // forêt
    var c2 = mono ? '#fff' : '#69889A';   // fjord
    var sun = mono ? '#fff' : '#C7765C';  // terracotta
    return '<svg viewBox="0 0 32 32" width="'+size+'" height="'+size+'" role="img" aria-label="MyDope Off">'+
      '<circle cx="23.5" cy="9" r="3.4" fill="'+sun+'"'+(mono?' opacity="0.9"':'')+'/>'+
      '<path d="M1 26 L9 14 L14 21 L20 11 L31 26 Z" fill="'+c2+'"'+(mono?' opacity="0.55"':'')+'/>'+
      '<path d="M1 26 L11 17 L17 23 L23 16 L31 26 Z" fill="'+c1+'"/></svg>';
  }
  function appIcon(size){
    size = size || 56;
    return '<span class="app-icon" style="display:inline-flex;align-items:center;justify-content:center;width:'+size+'px;height:'+size+'px;border-radius:'+Math.round(size*0.28)+'px;background:#F5F2EA;border:1px solid #E2DCD0;">'+logoSVG(Math.round(size*0.62))+'</span>';
  }
  function wordmark(){ return '<span class="wm"><span class="mark">'+logoSVG(26)+'</span>MyDope <b>Off</b></span>'; }

  /* ---------- Navigation (renommée, color-codée, apparition au scroll) ---------- */
  var NAV = [
    { k:'index', href:'index.html', tkey:'nav.home',        icon:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>' },
    { k:'suivi', href:'suivi.html', tkey:'nav.progression', icon:'<path d="M3 18 L9 11 l4 4 L21 6"/>' },
    { k:'psychochecker', href:'psychochecker.html', tkey:'nav.substances', icon:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>' },
    { k:'fiches', href:'fiches.html', tkey:'nav.equilibre', icon:'<path d="M3 12h4l2 5 4-12 2 7h6"/>' },
    { k:'rdr', href:'rdr.html', tkey:'nav.securite',        icon:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>' }
  ];
  function renderNav(active){
    return '<nav class="bn" id="bn" aria-label="Navigation principale">'+
      NAV.map(function(n){
        return '<a class="'+(n.k===active?'on':'')+'" href="'+n.href+'"'+(n.k===active?' aria-current="page"':'')+'>'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+n.icon+'</svg>'+
          '<span>'+t(n.tkey)+'</span></a>';
      }).join('')+'</nav>';
  }
  function mountScrollNav(){
    var bn=document.getElementById('bn'); if(!bn) return;
    function upd(){ var y=window.scrollY||document.documentElement.scrollTop; bn.classList.toggle('show', y>150); }
    window.addEventListener('scroll',upd,{passive:true}); upd();
  }

  /* ---------- Init ---------- */
  function init(opts){
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());
    if (opts.section) document.body.setAttribute('data-section', opts.section);

    document.querySelectorAll('[data-logo]').forEach(function(el){ el.innerHTML=logoSVG(parseInt(el.getAttribute('data-logo'),10)||30, el.hasAttribute('data-mono')); });
    document.querySelectorAll('[data-appicon]').forEach(function(el){ el.innerHTML=appIcon(parseInt(el.getAttribute('data-appicon'),10)||56); });
    document.querySelectorAll('[data-wordmark]').forEach(function(el){ el.innerHTML=wordmark(); });

    var navHost=document.querySelector('[data-nav]');
    if (navHost) navHost.outerHTML=renderNav(opts.page||'');
    mountScrollNav();

    document.querySelectorAll('[data-back]').forEach(function(b){
      b.addEventListener('click', function(){
        if (window.history.length>1 && document.referrer && document.referrer.indexOf(location.origin)===0) window.history.back();
        else location.href='index.html';
      });
    });

    applyI18n(); renderLangSelect();
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(function(){});
  }

  return {
    user:user, saveUser:saveUser, region:region, regionCode:regionCode, link:link,
    t:t, lang:lang, setLang:setLang, applyI18n:applyI18n, renderLangSelect:renderLangSelect,
    logoSVG:logoSVG, appIcon:appIcon, wordmark:wordmark, renderNav:renderNav, init:init,
    LANGS:LANGS, LANG_NAMES:LANG_NAMES
  };
})();
if (!window.LUCIDE) window.LUCIDE = window.MDCore;
