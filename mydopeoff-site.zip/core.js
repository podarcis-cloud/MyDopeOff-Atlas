/* ============================================================================
   MyDope Off — core.js · socle partagé (direction « Atlas du changement »)
   • Profil lu/écrit UNIQUEMENT dans localStorage (jamais l'URL → pas de fuite).
   • Source unique : logo / wordmark / nav / i18n / région / thème de section.
   Dépendances optionnelles chargées avant : i18n.js (MD_DICT), regions.js (MDRegions).
   Chemins À PLAT (déploiement GitHub Pages sans sous-dossier).
   ============================================================================ */
window.MDCore = (function () {
  'use strict';

  var KEY = 'ctc_v6', LANG_KEY = 'mydopeoff_lang';
  var LANGS = ['fr','en'];
  var LANG_NAMES = { fr:'Français', en:'English' };

  /* ---------- Profil (localStorage only) ---------- */
  function store(){ try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ return {}; } }
  function user(){ return store().user || null; }
  function saveUser(u){ try { var s=store(); s.user=u; localStorage.setItem(KEY, JSON.stringify(s)); } catch(e){} }
  function regionCode(){ var u=user(), c=(u&&u.region)||'BE'; if (window.MDRegions && !window.MDRegions.exists(c)) c='BE'; return c; }
  function region(){ return window.MDRegions ? window.MDRegions.get(regionCode()) : null; }
  function link(href){ return href; }

  /* ---------- i18n ---------- */
  function dict(){ return window.MD_DICT || {}; }
  function lang(){ try { var l=localStorage.getItem(LANG_KEY); if (l && LANGS.indexOf(l)>-1) return l; } catch(e){} return 'fr'; }
  /* ---------- Titres d'onglet (indexés par nom de fichier réel, pas par la clé `page` passée
     à init() — certaines pages partagent la même section logique (ex. detection.html et
     suivi.html utilisent toutes deux page:'suivi') sans partager le même titre. ---------- */
  var TITLES = {
    'admin': { fr:'MyDope Off — Administration', en:'MyDope Off — Admin' },
    'alcool': { fr:'MyDope Off — Dossier alcool', en:'MyDope Off — Alcohol file' },
    'antisabotage': { fr:'MyDope Off — Plan anti-sabotage', en:'MyDope Off — Anti-sabotage plan' },
    'autosabotage': { fr:'MyDope Off — Dossier auto-sabotage', en:'MyDope Off — Self-sabotage file' },
    'benzodiazepines': { fr:'MyDope Off — Dossier benzodiazépines', en:'MyDope Off — Benzodiazepines file' },
    'braise': { fr:'MyDope Off — Braise', en:'MyDope Off — Ember' },
    'breathe': { fr:'MyDope Off — Souffle', en:'MyDope Off — Breath' },
    'cannabis': { fr:'MyDope Off — Dossier cannabis', en:'MyDope Off — Cannabis file' },
    'cocaine': { fr:'MyDope Off — Dossier cocaïne', en:'MyDope Off — Cocaine file' },
    'controles': { fr:'Alcool, stupéfiants & conduite — MyDope Off', en:'Alcohol, drugs & driving — MyDope Off' },
    'crack': { fr:'MyDope Off — Dossier crack', en:'MyDope Off — Crack file' },
    'detection': { fr:'MyDope Off — Fenêtres de détection', en:'MyDope Off — Detection windows' },
    'dualtask': { fr:'MyDope Off — Double tâche', en:'MyDope Off — Dual task' },
    'echo': { fr:'MyDope Off — Écho', en:'MyDope Off — Echo' },
    'elan': { fr:'MyDope Off — Élan', en:'MyDope Off — Impulse' },
    'environnement': { fr:'MyDope Off — Dossier environnement & nature', en:'MyDope Off — Environment & nature file' },
    'fiches': { fr:'MyDope Off — Labo', en:'MyDope Off — Lab' },
    'filtre': { fr:'MyDope Off — Filtre', en:'MyDope Off — Filter' },
    'guide': { fr:'MyDope Off — Guide', en:'MyDope Off — Guide' },
    'index': { fr:'MyDope Off — Accueil', en:'MyDope Off — Home' },
    'inscription': { fr:'Bienvenue — MyDope Off', en:'Welcome — MyDope Off' },
    'ketamine': { fr:'MyDope Off — Dossier kétamine', en:'MyDope Off — Ketamine file' },
    'lettre': { fr:'MyDope Off — Lettre à ton futur toi', en:'MyDope Off — Letter to your future self' },
    'maze': { fr:'MyDope Off — Gyro Labyrinthe', en:'MyDope Off — Gyro Maze' },
    'mdma': { fr:'MyDope Off — Dossier MDMA', en:'MyDope Off — MDMA file' },
    'nitreux': { fr:'MyDope Off — Dossier protoxyde d\u2019azote', en:'MyDope Off — Nitrous oxide file' },
    'opioides-synthese': { fr:'MyDope Off — Dossier opioïdes de synthèse', en:'MyDope Off — Synthetic opioids file' },
    'patience': { fr:'MyDope Off — Patience', en:'MyDope Off — Patience' },
    'polyconsommation': { fr:'MyDope Off — Dossier polyconsommation', en:'MyDope Off — Polydrug use file' },
    'profil': { fr:'MyDope Off — Profil', en:'MyDope Off — Profile' },
    'psychedeliques': { fr:'MyDope Off — Dossier psychédéliques et micro-dosage', en:'MyDope Off — Psychedelics and microdosing file' },
    'psychochecker': { fr:'MyDope Off — Substances', en:'MyDope Off — Substances' },
    'rdr-vs-abstinence': { fr:'MyDope Off — Dossier RDR vs abstinence', en:'MyDope Off — Harm reduction vs abstinence file' },
    'rdr': { fr:'MyDope Off — Réflexes', en:'MyDope Off — Reflexes' },
    'rechute': { fr:'MyDope Off — Dossier rechute', en:'MyDope Off — Relapse file' },
    'soutenir': { fr:'MyDope Off — Soutenir le projet', en:'MyDope Off — Support the project' },
    'suivi': { fr:'MyDope Off — Journal', en:'MyDope Off — Journal' },
    'surf': { fr:'MyDope Off — Surf de l\u2019envie', en:'MyDope Off — Surfing the urge' },
    'tabac-vapotage': { fr:'MyDope Off — Dossier tabac et vapotage', en:'MyDope Off — Tobacco and vaping file' },
    'tetris': { fr:'MyDope Off — Tetris anti-craving', en:'MyDope Off — Anti-craving Tetris' },
    'virage': { fr:'MyDope Off — Virage', en:'MyDope Off — Switch' }
  };
  function pageFileId(){ try { return (location.pathname.split('/').pop() || '').replace(/\.html$/, ''); } catch(e){ return ''; } }
  function applyTitle(){
    var id = pageFileId(), e = TITLES[id];
    if (e) document.title = lang()==='en' ? e.en : e.fr;
  }

  function setLang(l){
    if (LANGS.indexOf(l)===-1) return;
    try { localStorage.setItem(LANG_KEY,l); } catch(e){}
    document.documentElement.setAttribute('lang', l);
    applyI18n(); renderLangSelect(); applyTitle();
    if(window.MDTranslateDOM) window.MDTranslateDOM(l==='en');
    document.dispatchEvent(new CustomEvent('langchange',{ detail:{ lang:l } }));
  }

  /* ---------- Thème clair/sombre (localStorage ; 'auto' = suit l'OS) ---------- */
  var THEME_KEY='mydopeoff_theme';
  function theme(){ try{ var v=localStorage.getItem(THEME_KEY); if(v==='dark'||v==='light') return v; }catch(e){} return 'auto'; }
  function applyTheme(v){
    var root=document.documentElement;
    if(v==='dark') root.setAttribute('data-theme','dark');
    else if(v==='light') root.setAttribute('data-theme','light');
    else root.removeAttribute('data-theme'); /* auto : @media prend le relais */
  }
  function setTheme(v){
    if(['dark','light','auto'].indexOf(v)===-1) return;
    try{ if(v==='auto') localStorage.removeItem(THEME_KEY); else localStorage.setItem(THEME_KEY,v); }catch(e){}
    applyTheme(v);
    document.dispatchEvent(new CustomEvent('themechange',{ detail:{ theme:v } }));
  }
  function toggleTheme(){
    /* Clair par défaut. La bascule alterne clair <-> sombre selon l'état courant. */
    var eff = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    setTheme(eff==='dark' ? 'light' : 'dark');
  }

  function t(keyOrObj, vars){
    var l=lang(), s, D=dict();
    if (keyOrObj && typeof keyOrObj==='object') s = keyOrObj[l]||keyOrObj.fr||'';
    else { var e=D[keyOrObj]; s = e ? (e[l]||e.fr) : keyOrObj; }
    if (vars) Object.keys(vars).forEach(function(k){ s=s.replace('{'+k+'}', vars[k]); });
    return s;
  }
  function applyI18n(){
    var D=dict();
    /* Une entrée peut ne couvrir qu'une langue (les traductions de contenu ne stockent que
       l'anglais : le HTML de la page EST déjà la version française). On ne remplace donc que
       si t() renvoie une chaîne réelle — sinon on laisserait « undefined » à la place du texte. */
    function tr(k){ var s = t(k); return (typeof s === 'string' && s.length) ? s : null; }
    document.querySelectorAll('[data-i18n]').forEach(function(el){ var k=el.getAttribute('data-i18n'), s=D[k]&&tr(k); if (s) el.textContent=s; });
    document.querySelectorAll('[data-i18n-html]').forEach(function(el){ var k=el.getAttribute('data-i18n-html'), s=D[k]&&tr(k); if (s) el.innerHTML=s; });
    document.querySelectorAll('[data-i18n-ph]').forEach(function(el){ var k=el.getAttribute('data-i18n-ph'), s=D[k]&&tr(k); if (s) el.setAttribute('placeholder', s); });
    document.querySelectorAll('[data-i18n-aria]').forEach(function(el){ var k=el.getAttribute('data-i18n-aria'), s=D[k]&&tr(k); if (s) el.setAttribute('aria-label', s); });
  }
  function renderLangSelect(){
    document.querySelectorAll('[data-langselect]').forEach(function(host){
      var cur=lang();
      host.innerHTML = '<div class="lang" role="group" aria-label="'+t('common.language')+'">'+
        LANGS.map(function(l){ return '<button type="button" class="'+(l===cur?'on':'')+'" data-setlang="'+l+'" aria-pressed="'+(l===cur)+'">'+l.toUpperCase()+'</button>'; }).join('')+'</div>';
      host.querySelectorAll('[data-setlang]').forEach(function(b){ b.addEventListener('click', function(){ setLang(b.getAttribute('data-setlang')); }); });
    });
  }

  /* ---------- Marque : sommet & soleil (Atlas) ---------- */
  function logoSVG(size, mono){
    size = size || 30;
    // Logo Atlas (mandala). PNG léger sous 40px (topbar) ; SVG net au-delà (grand format).
    var src = size <= 40 ? 'logo-mark.png' : 'logo-atlas.svg';
    return '<img src="'+src+'" width="'+size+'" height="'+size+'" alt="MyDope Off" ' +
      'style="display:block;object-fit:contain' + (mono ? ';filter:brightness(0) invert(1)' : '') + '">';
  }
  function appIcon(size){
    size = size || 56;
    return '<span class="app-icon" style="display:inline-flex;align-items:center;justify-content:center;width:'+size+'px;height:'+size+'px;border-radius:'+Math.round(size*0.28)+'px;background:var(--bg);border:1px solid var(--line);">'+logoSVG(Math.round(size*0.62))+'</span>';
  }
  function wordmark(){ return '<span class="wm"><span class="mark">'+logoSVG(26)+'</span>MyDope <b>Off</b></span>'; }

  /* ---------- Navigation : source unique = nav.js ---------- */
  function renderNav(active){ return (window.MDNav ? MDNav.render(active||'') : ''); }
  function mountScrollNav(){ /* nav.js gère l'affichage */ }

  /* ---- Mise en garde à valider (premier lancement) ---- */
  function ensureConsent(){
    var s; try { s = JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ s = {}; }
    if (s.consent) return;
    var regOpts = '';
    try {
      if (window.MDRegions && window.MDRegions.list) {
        regOpts = window.MDRegions.list().map(function(r){
          return '<option value="'+r.code+'"'+(r.code==='BE'?' selected':'')+'>'+r.label+'</option>';
        }).join('');
      }
    } catch(e){}
    var ov = document.createElement('div');
    ov.className = 'sheet-backdrop open'; ov.setAttribute('aria-hidden','false');
    ov.style.zIndex = '9000';
    ov.innerHTML =
      '<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="cons-h">'+
        '<div style="display:flex;justify-content:center;margin-bottom:6px">'+appIcon(56)+'</div>'+
        '<h3 id="cons-h" style="text-align:center">Avant de commencer</h3>'+
        '<p class="sub" style="text-align:center">MyDope Off est un outil d\u2019information et de r\u00e9duction des risques.</p>'+
        '<div class="notice" style="margin:4px 0 6px"><span>Il <b>n\u2019encourage aucune consommation</b> et ne remplace pas un avis m\u00e9dical, psychologique ou juridique. Tes donn\u00e9es restent <b>sur ton appareil</b>. En cas d\u2019urgence vitale : <b>112</b> (UE) ou <b>15</b> (FR).</span></div>'+
        (regOpts ? ('<label for="cons-region" style="display:block;font-size:var(--fs-xs,12.5px);color:var(--ink-2,#58635E);margin:10px 2px 5px">Ta r\u00e9gion \u2014 pour des infos et des ressources qui te concernent vraiment</label>'+
        '<select class="select" id="cons-region" style="width:100%;margin-bottom:6px">'+regOpts+'</select>') : '')+
        '<label style="display:flex;gap:10px;align-items:flex-start;font-size:var(--fs-sm,14.5px);margin:10px 2px 14px;cursor:pointer">'+
          '<input type="checkbox" id="cons-ck" style="width:20px;height:20px;flex:0 0 auto;margin-top:1px"><span>J\u2019ai compris et j\u2019accepte ces conditions.</span></label>'+
        '<button type="button" class="btn btn-primary btn-block" id="cons-go" disabled>Entrer</button>'+
      '</div>';
    document.body.appendChild(ov);
    var ck = ov.querySelector('#cons-ck'), go = ov.querySelector('#cons-go');
    ck.addEventListener('change', function(){ go.disabled = !ck.checked; });
    go.addEventListener('click', function(){
      var saved = false;
      try {
        var st = JSON.parse(localStorage.getItem(KEY)) || {};
        st.consent = { at:new Date().toISOString() };
        st.user = st.user || {};
        var regSel = ov.querySelector('#cons-region');
        if (regSel && regSel.value) st.user.region = regSel.value;
        localStorage.setItem(KEY, JSON.stringify(st));
        // relecture : en navigation privée, setItem peut ne pas lever d'erreur mais ne rien écrire
        saved = !!(JSON.parse(localStorage.getItem(KEY) || '{}').consent);
      } catch(e){ saved = false; }

      if (saved) { ov.remove(); return; }

      /* Le stockage local n'est pas disponible (navigation privée, quota plein, cookies
         bloqués). On ne peut rien enregistrer — mais consulter les fiches, le vérificateur
         d'interactions et les exercices reste parfaitement utilisable. On le dit clairement
         plutôt que de laisser la personne perdre sa progression sans comprendre pourquoi
         (et sans faire reboucler cet écran à chaque visite en silence). */
      var sheet = ov.querySelector('.sheet');
      if (!sheet) { ov.remove(); return; }
      sheet.innerHTML =
        '<h3 style="text-align:center">Rien ne pourra être enregistré</h3>'+
        '<div class="notice warn" style="margin:10px 0 14px"><span>Ton navigateur n\u2019autorise pas cette page \u00e0 garder des donn\u00e9es \u2014 souvent le cas en <b>navigation priv\u00e9e</b>, ou si le stockage du site est bloqu\u00e9. Tu peux tout consulter normalement (fiches, m\u00e9langes, exercices), mais <b>ton suivi et tes r\u00e9ponses dispara\u00eetront en fermant l\u2019onglet</b>.</span></div>'+
        '<p class="sub" style="text-align:center;margin-bottom:14px">Pour conserver ta progression : ouvre l\u2019app dans une fen\u00eatre normale, ou autorise le stockage pour ce site.</p>'+
        '<button type="button" class="btn btn-primary btn-block" id="cons-anyway">Continuer sans enregistrer</button>';
      sheet.querySelector('#cons-anyway').addEventListener('click', function(){ ov.remove(); });
    });
  }

  /* ---------- Init ---------- */
  /* Si data.js a trouvé des données illisibles au démarrage, la personne doit le savoir :
     sans ça, elle constate juste que son suivi a disparu, sans comprendre pourquoi ni savoir
     que la sauvegarde brute est toujours là. Signalé une seule fois, fermable, sans alarmisme. */
  /* Avertissement « ça n'a pas pu être enregistré ». Appelé quand une écriture importante
     échoue (quota atteint, stockage bloqué). Volontairement flottant et non bloquant : la
     personne vient de terminer une séance, on ne casse pas ce moment — mais elle doit savoir
     que ça n'a pas été gardé, plutôt que de le découvrir des semaines plus tard. */
  /* makeDialog(overlay, opts) — rend une modale utilisable au clavier et annonçable par un
     lecteur d'écran. Sans ça, la tabulation reste sur la page DERRIÈRE l'overlay : les boutons
     de la modale sont alors inatteignables autrement qu'à la souris (vérifié : 6 tabulations
     consécutives ne rentraient jamais dans la carte de règles d'un jeu).
     opts.label  : nom annoncé du dialogue.
     opts.onClose: appelé sur Échap (si absent, Échap ne ferme pas — cas des modales qui
                   exigent un choix explicite).
     Les écouteurs se retirent d'eux-mêmes dès que l'overlay quitte le DOM : les 9 modales du
     site ont des cycles de vie différents, aucune n'a à penser au nettoyage. */
  function makeDialog(ov, opts){
    if (!ov || ov.__mdDialog) return;
    ov.__mdDialog = true;
    opts = opts || {};
    ov.setAttribute('role', 'dialog');
    ov.setAttribute('aria-modal', 'true');
    if (opts.label) ov.setAttribute('aria-label', opts.label);

    var SEL = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
    function focusables(){
      return Array.prototype.filter.call(ov.querySelectorAll(SEL), function(el){
        return el.offsetParent !== null || el.getClientRects().length;
      });
    }
    var previous = document.activeElement;
    var f = focusables();
    if (f.length) { try { f[0].focus(); } catch(e){} }
    else { ov.setAttribute('tabindex','-1'); try { ov.focus(); } catch(e){} }

    function onKey(e){
      if (!document.body.contains(ov)) { cleanup(); return; }
      if (e.key === 'Escape' && typeof opts.onClose === 'function') { e.preventDefault(); opts.onClose(); return; }
      if (e.key !== 'Tab') return;
      var list = focusables();
      if (!list.length) { e.preventDefault(); return; }
      var first = list[0], last = list[list.length - 1];
      // Le focus est-il encore dans la modale ? Sinon (ex. il était resté derrière), on le ramène.
      if (!ov.contains(document.activeElement)) { e.preventDefault(); first.focus(); return; }
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    function cleanup(){
      document.removeEventListener('keydown', onKey, true);
      if (previous && document.body.contains(previous)) { try { previous.focus(); } catch(e){} }
    }
    document.addEventListener('keydown', onKey, true);
  }

  function warnNoSave(onDone){
    function done(){ if (typeof onDone === 'function') { var f = onDone; onDone = null; f(); } }
    if (document.getElementById('md-nosave')) { done(); return; }
    var box = document.createElement('div');
    box.id = 'md-nosave';
    box.className = 'notice warn';
    box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:84px;z-index:var(--z-alert,8000);box-shadow:0 10px 30px rgba(31,43,37,.25)';
    box.innerHTML = '<span>Cette s\u00e9ance n\u2019a pas pu \u00eatre enregistr\u00e9e \u2014 l\u2019espace de stockage de ton navigateur est plein ou bloqu\u00e9. Ton suivi ne la comptera pas. '+
      '<button type="button" id="md-nosave-ok" style="background:none;border:none;padding:0;font:inherit;color:inherit;text-decoration:underline;cursor:pointer">J\u2019ai compris</button></span>';
    document.body.appendChild(box);
    var b = box.querySelector('#md-nosave-ok');
    if (b) b.addEventListener('click', function(){ box.remove(); done(); });
    setTimeout(function(){ if (box.parentNode) { box.remove(); done(); } }, 12000);
  }

  function noticeCorruption(){
    try {
      if (!window.MDData || !MDData.hadCorruption || !MDData.hadCorruption()) return;
      if (localStorage.getItem('ctc_v6_corrompu_vu')) return;
    } catch(e){ return; }
    var host = document.querySelector('.page') || document.body;
    if (!host) return;
    var box = document.createElement('div');
    box.className = 'notice warn';
    box.style.margin = '12px 0';
    box.innerHTML = '<span>Une partie de tes donn\u00e9es enregistr\u00e9es \u00e9tait illisible au d\u00e9marrage \u2014 ton suivi repart donc \u00e0 z\u00e9ro ici. <b>Rien n\u2019a \u00e9t\u00e9 supprim\u00e9\u00a0:</b> la sauvegarde d\u2019origine est conserv\u00e9e sur ton appareil au cas o\u00f9 elle serait r\u00e9cup\u00e9rable. '+
      '<button type="button" class="btn-linklike" id="corrupt-ok" style="background:none;border:none;padding:0;font:inherit;color:inherit;text-decoration:underline;cursor:pointer">J\u2019ai compris</button></span>';
    host.insertBefore(box, host.firstChild);
    var b = box.querySelector('#corrupt-ok');
    if (b) b.addEventListener('click', function(){
      try { localStorage.setItem('ctc_v6_corrompu_vu', '1'); } catch(e){}
      box.remove();
    });
  }

  function init(opts){
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());
    applyTheme(theme());
    if (opts.section) document.body.setAttribute('data-section', opts.section);

    document.querySelectorAll('[data-logo]').forEach(function(el){ el.innerHTML=logoSVG(parseInt(el.getAttribute('data-logo'),10)||30, el.hasAttribute('data-mono')); });
    document.querySelectorAll('[data-appicon]').forEach(function(el){ el.innerHTML=appIcon(parseInt(el.getAttribute('data-appicon'),10)||56); });
    document.querySelectorAll('[data-wordmark]').forEach(function(el){ el.innerHTML=wordmark(); });

    document.body.setAttribute('data-page', opts.page||'');
    if (window.MDNav) MDNav.mount();
    mountScrollNav();

    document.querySelectorAll('[data-back]').forEach(function(b){
      b.addEventListener('click', function(e){
        if (window.history.length>1){ if(e&&e.preventDefault) e.preventDefault(); window.history.back(); }
        else location.href='index.html';
      });
    });

    applyI18n();
    applyTitle();
    if(window.MDTranslateDOM) window.MDTranslateDOM(lang()==='en');
    ensureConsent();
    noticeCorruption();
    if (window.MDTrophies) try { MDTrophies.check(); } catch (e) {}
    if ((opts.page||'')==='index') renderLangSelect();
    else document.querySelectorAll('[data-langselect]').forEach(function(h){ h.remove(); });
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(function(){});
  }

  return {
    user:user, saveUser:saveUser, region:region, regionCode:regionCode, link:link,
    t:t, lang:lang, setLang:setLang, applyI18n:applyI18n, renderLangSelect:renderLangSelect,
    theme:theme, setTheme:setTheme, toggleTheme:toggleTheme,
    logoSVG:logoSVG, appIcon:appIcon, wordmark:wordmark, renderNav:renderNav, init:init,
    warnNoSave:warnNoSave, makeDialog:makeDialog,
    LANGS:LANGS, LANG_NAMES:LANG_NAMES
  };
})();
if (!window.LUCIDE) window.LUCIDE = window.MDCore;
