/* ============================================================================
   MyDope Off — core.js · socle partagé (direction « Atlas du changement »)
   • Profil lu/écrit UNIQUEMENT dans localStorage (jamais l'URL → pas de fuite).
   • Source unique : logo / wordmark / nav / i18n / région / thème de section.
   Dépendances optionnelles chargées avant : i18n.js (MD_DICT), regions.js (MDRegions).
   Chemins À PLAT (déploiement GitHub Pages sans sous-dossier).
   ============================================================================ */
window.MDCore = (function () {
  'use strict';

  var KEY = 'ctc_v6', LANG_KEY = 'mydopeoff_lang';
  var LANGS = ['fr','en'];
  var LANG_NAMES = { fr:'Français', en:'English' };

  /* ---------- Profil (localStorage only) ---------- */
  function store(){ try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ return {}; } }
  function user(){ return store().user || null; }
  function saveUser(u){ try { var s=store(); s.user=u; localStorage.setItem(KEY, JSON.stringify(s)); } catch(e){} }
  function regionCode(){ var u=user(), c=(u&&u.region)||'BE'; if (window.MDRegions && !window.MDRegions.exists(c)) c='BE'; return c; }
  function region(){ return window.MDRegions ? window.MDRegions.get(regionCode()) : null; }
  function link(href){ return href; }

  /* ---------- i18n ---------- */
  function dict(){ return window.MD_DICT || {}; }
  function lang(){ try { var l=localStorage.getItem(LANG_KEY); if (l && LANGS.indexOf(l)>-1) return l; } catch(e){} return 'fr'; }
  function setLang(l){
    if (LANGS.indexOf(l)===-1) return;
    try { localStorage.setItem(LANG_KEY,l); } catch(e){}
    document.documentElement.setAttribute('lang', l);
    applyI18n(); renderLangSelect();
    if(window.MDTranslateDOM) window.MDTranslateDOM(l==='en');
    document.dispatchEvent(new CustomEvent('langchange',{ detail:{ lang:l } }));
  }
  function t(keyOrObj, vars){
    var l=lang(), s, D=dict();
    if (keyOrObj && typeof keyOrObj==='object') s = keyOrObj[l]||keyOrObj.fr||'';
    else { var e=D[keyOrObj]; s = e ? (e[l]||e.fr) : keyOrObj; }
    if (vars) Object.keys(vars).forEach(function(k){ s=s.replace('{'+k+'}', vars[k]); });
    return s;
  }
  function applyI18n(){
    var D=dict();
    document.querySelectorAll('[data-i18n]').forEach(function(el){ var k=el.getAttribute('data-i18n'); if (D[k]) el.textContent=t(k); });
    document.querySelectorAll('[data-i18n-ph]').forEach(function(el){ var k=el.getAttribute('data-i18n-ph'); if (D[k]) el.setAttribute('placeholder', t(k)); });
    document.querySelectorAll('[data-i18n-aria]').forEach(function(el){ var k=el.getAttribute('data-i18n-aria'); if (D[k]) el.setAttribute('aria-label', t(k)); });
  }
  function renderLangSelect(){
    document.querySelectorAll('[data-langselect]').forEach(function(host){
      var cur=lang();
      host.innerHTML = '<div class="lang" role="group" aria-label="'+t('common.language')+'">'+
        LANGS.map(function(l){ return '<button type="button" class="'+(l===cur?'on':'')+'" data-setlang="'+l+'" aria-pressed="'+(l===cur)+'">'+l.toUpperCase()+'</button>'; }).join('')+'</div>';
      host.querySelectorAll('[data-setlang]').forEach(function(b){ b.addEventListener('click', function(){ setLang(b.getAttribute('data-setlang')); }); });
    });
  }

  /* ---------- Marque (Atlas) ----------
     Deux marques disponibles :
       • logoSVG()      — repère « sommet & soleil » (carte/atlas), recoloré sur
                          la palette des planches (forêt #23443D, brume #7FA7A1,
                          terracotta #E07A5F).
       • logoAtlasSVG() — marque « enveloppe + chemin + feuille » des planches
                          (« Lettre à ton futur toi »). Prête à remplacer logoSVG
                          partout : il suffit de faire `logoSVG = logoAtlasSVG`.
     Le choix d'identité (sommet vs enveloppe) est documenté dans l'audit. */
  function logoSVG(size, mono){
    size = size || 30;
    var c1 = mono ? '#fff' : '#23443D';   // vert profond (planche)
    var c2 = mono ? '#fff' : '#7FA7A1';   // bleu brume (planche)
    var sun = mono ? '#fff' : '#E07A5F';  // terracotta (planche)
    return '<svg viewBox="0 0 32 32" width="'+size+'" height="'+size+'" role="img" aria-label="Atlas">'+
      '<circle cx="23.5" cy="9" r="3.4" fill="'+sun+'"'+(mono?' opacity="0.9"':'')+'/>'+
      '<path d="M1 26 L9 14 L14 21 L20 11 L31 26 Z" fill="'+c2+'"'+(mono?' opacity="0.55"':'')+'/>'+
      '<path d="M1 26 L11 17 L17 23 L23 16 L31 26 Z" fill="'+c1+'"/></svg>';
  }
  /* Marque enveloppe + chemin sinueux + feuille (fidèle aux planches) */
  function logoAtlasSVG(size, mono){
    size = size || 30;
    var ink = mono ? '#fff' : '#23443D';
    var leaf = mono ? '#fff' : '#7A8F72';
    return '<svg viewBox="0 0 32 32" width="'+size+'" height="'+size+'" fill="none" '+
      'stroke="'+ink+'" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" '+
      'role="img" aria-label="Atlas — Lettre à ton futur toi">'+
      '<path d="M5 8h16a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H8"/>'+        /* enveloppe */
      '<path d="M5 9l8 5 8-5"/>'+                                    /* rabat */
      '<path d="M9 19c-2 2-3 4-3 6 4 0 6-2 7-4" stroke="'+ink+'"/>'+ /* chemin sinueux */
      '<path d="M24 6c2 .3 3 1.6 3 3-1.6.2-2.8-.6-3-3z" fill="'+leaf+'" stroke="'+leaf+'"/>'+ /* feuille */
      '</svg>';
  }
  function appIcon(size){
    size = size || 56;
    return '<span class="app-icon" style="display:inline-flex;align-items:center;justify-content:center;width:'+size+'px;height:'+size+'px;border-radius:'+Math.round(size*0.28)+'px;background:#F6EFE6;border:1px solid #E6DECF;">'+logoSVG(Math.round(size*0.62))+'</span>';
  }
  /* MARQUE ACTIVE — bascule unique entre les deux identités.
     'atlas'  → enveloppe + chemin + feuille (planches)  [défaut]
     'sommet' → sommet & soleil (recoloré)               */
  var BRAND = 'sommet';
  function mark(size, mono){ return BRAND==='atlas' ? logoAtlasSVG(size,mono) : logoSVG(size,mono); }
  function wordmark(){ return '<span class="wm"><span class="mark">'+mark(26)+'</span>MyDope <b>Off</b></span>'; }

  /* ---------- Navigation : source unique = nav.js ---------- */
  function renderNav(active){ return (window.MDNav ? MDNav.render(active||'') : ''); }
  function mountScrollNav(){ /* nav.js gère l'affichage */ }

  /* ---- Mise en garde à valider (premier lancement) ---- */
  function ensureConsent(){
    var s; try { s = JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ s = {}; }
    if (s.consent) return;
    var ov = document.createElement('div');
    ov.className = 'sheet-backdrop open'; ov.setAttribute('aria-hidden','false');
    ov.style.zIndex = '3000';
    ov.innerHTML =
      '<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="cons-h">'+
        '<div style="display:flex;justify-content:center;margin-bottom:6px">'+appIcon(56)+'</div>'+
        '<h3 id="cons-h" style="text-align:center">Avant de commencer</h3>'+
        '<p class="sub" style="text-align:center">MyDope Off est un outil d\u2019information et de r\u00e9duction des risques.</p>'+
        '<div class="notice" style="margin:4px 0 6px"><span>Il <b>n\u2019encourage aucune consommation</b> et ne remplace pas un avis m\u00e9dical, psychologique ou juridique. Tes donn\u00e9es restent <b>sur ton appareil</b>. En cas d\u2019urgence vitale : <b>112</b> (UE) ou <b>15</b> (FR).</span></div>'+
        '<label style="display:flex;gap:10px;align-items:flex-start;font-size:14.5px;margin:10px 2px 14px;cursor:pointer">'+
          '<input type="checkbox" id="cons-ck" style="width:20px;height:20px;flex:0 0 auto;margin-top:1px"><span>J\u2019ai compris et j\u2019accepte ces conditions.</span></label>'+
        '<button type="button" class="btn btn-primary btn-block" id="cons-go" disabled>Entrer</button>'+
      '</div>';
    document.body.appendChild(ov);
    var ck = ov.querySelector('#cons-ck'), go = ov.querySelector('#cons-go');
    ck.addEventListener('change', function(){ go.disabled = !ck.checked; });
    go.addEventListener('click', function(){
      try { var st = JSON.parse(localStorage.getItem(KEY)) || {}; st.consent = { at:new Date().toISOString() }; localStorage.setItem(KEY, JSON.stringify(st)); } catch(e){}
      ov.remove();
    });
  }

  /* ---------- Toast Atlas (remplace alert()) ---------- */
  function toast(msg, kind){
    var t = document.createElement('div');
    t.className = 'atlas-toast' + (kind ? ' '+kind : '') + ' atlas-rise';
    t.setAttribute('role','status'); t.setAttribute('aria-live','polite');
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function(){ t.classList.add('show'); });
    setTimeout(function(){ t.classList.remove('show'); setTimeout(function(){ t.remove(); }, 300); }, 2600);
  }

  /* ---------- Confirmation Atlas (remplace confirm()) ----------
     atlasConfirm({title, body, confirmLabel, cancelLabel, danger}) -> Promise<bool> */
  function atlasConfirm(o){
    o = o || {};
    return new Promise(function(resolve){
      var ov = document.createElement('div');
      ov.className = 'sheet-backdrop open'; ov.style.zIndex = '3200';
      ov.innerHTML =
        '<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="ac-h">'+
          '<h3 id="ac-h">'+(o.title||'Confirmer ?')+'</h3>'+
          (o.body ? '<p class="sub">'+o.body+'</p>' : '')+
          '<div class="actions">'+
            '<button type="button" class="btn btn-outline" data-no>'+(o.cancelLabel||'Annuler')+'</button>'+
            '<button type="button" class="btn '+(o.danger?'btn-danger':'btn-primary')+'" data-yes>'+(o.confirmLabel||'Confirmer')+'</button>'+
          '</div>'+
        '</div>';
      document.body.appendChild(ov);
      function close(v){ ov.classList.remove('open'); setTimeout(function(){ ov.remove(); }, 220); resolve(v); }
      ov.querySelector('[data-yes]').addEventListener('click', function(){ close(true); });
      ov.querySelector('[data-no]').addEventListener('click', function(){ close(false); });
      ov.addEventListener('click', function(e){ if(e.target===ov) close(false); });
    });
  }

  /* ---------- Init ---------- */
  function init(opts){
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());
    if (opts.section) document.body.setAttribute('data-section', opts.section);

    document.querySelectorAll('[data-logo]').forEach(function(el){ el.innerHTML=mark(parseInt(el.getAttribute("data-logo"),10)||30, el.hasAttribute("data-mono")); });
    document.querySelectorAll('[data-appicon]').forEach(function(el){ el.innerHTML=appIcon(parseInt(el.getAttribute('data-appicon'),10)||56); });
    document.querySelectorAll('[data-wordmark]').forEach(function(el){ el.innerHTML=wordmark(); });

    document.body.setAttribute('data-page', opts.page||'');
    if (window.MDNav) MDNav.mount();
    mountScrollNav();

    document.querySelectorAll('[data-back]').forEach(function(b){
      b.addEventListener('click', function(e){
        if (window.history.length>1){ if(e&&e.preventDefault) e.preventDefault(); window.history.back(); }
        else location.href='index.html';
      });
    });

    applyI18n();
    if(window.MDTranslateDOM) window.MDTranslateDOM(lang()==='en');
    ensureConsent();
    if ((opts.page||'')==='index') renderLangSelect();
    else document.querySelectorAll('[data-langselect]').forEach(function(h){ h.remove(); });
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(function(){});
  }

  return {
    user:user, saveUser:saveUser, region:region, regionCode:regionCode, link:link,
    t:t, lang:lang, setLang:setLang, applyI18n:applyI18n, renderLangSelect:renderLangSelect,
    logoSVG:logoSVG, logoAtlasSVG:logoAtlasSVG, appIcon:appIcon, wordmark:wordmark, renderNav:renderNav, init:init,
    toast:toast, atlasConfirm:atlasConfirm,
    LANGS:LANGS, LANG_NAMES:LANG_NAMES
  };
})();
if (!window.LUCIDE) window.LUCIDE = window.MDCore;
