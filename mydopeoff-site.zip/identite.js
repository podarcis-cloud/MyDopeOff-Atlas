/* identite.js — Identité & valeurs (M6), 100 % local.
   L'utilisateur·rice choisit ses valeurs (ACT) et écrit « je suis quelqu'un qui… ».
   Ancre le « pourquoi » derrière les exercices, se relit en plein craving, et se prolonge
   dans la Lettre au futur toi. Stocke dans ctc_v6.parcours.valeurs / .identite ; journalise
   une séance 'identite' (nourrit la Stabilité comportementale). Expose window.MDIdentite. */
window.MDIdentite = (function () {
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }
  /* VALEUR_CATS / VALEURS / SUGG restent en français dans les deux langues : ce sont des
     données choisies par la personne, stockées et relues telles quelles par braise.js,
     elan.js et patience.js (MDData.getValeurs()). Les traduire changerait la valeur
     stockée elle-même, pas seulement son affichage — même contrainte que les unités du
     journal (page-suivi.js), documentée là-bas. */
  var VALEUR_CATS = [
    { cat: 'Relations', items: ['Famille', 'Amitié', 'Lien aux autres', 'Amour', 'Communauté'] },
    { cat: 'Corps & santé', items: ['Santé', 'Sommeil', 'Mouvement', 'Alimentation', 'Énergie'] },
    { cat: 'Sens & croissance', items: ['Apprendre', 'Créativité', 'Travail qui a du sens', 'Curiosité', 'Spiritualité', 'Ambition'] },
    { cat: 'Liberté & nature', items: ['Liberté', 'Aventure', 'Nature', 'Simplicité', 'Voyage'] },
    { cat: 'Intérieur', items: ['Honnêteté', 'Sérénité', 'Courage', 'Humour', 'Gratitude', 'Authenticité'] },
    { cat: 'Contribution', items: ['Aider les autres', 'Justice', 'Environnement', 'Générosité', 'Engagement'] },
    { cat: 'Plaisir & détente', items: ['Repos', 'Jeu', 'Musique & art', 'Beauté', 'Douceur'] }
  ];
  var VALEURS = VALEUR_CATS.reduce(function (acc, c) { return acc.concat(c.items); }, []);
  var CAT_LABELS_EN = { 'Relations':'Relationships', 'Corps & santé':'Body & health', 'Sens & croissance':'Meaning & growth',
    'Liberté & nature':'Freedom & nature', 'Intérieur':'Inner life', 'Contribution':'Contribution', 'Plaisir & détente':'Pleasure & rest' };
  function catLabel(cat){ return lang()==='en' ? (CAT_LABELS_EN[cat]||cat) : cat; }
  var SUGG = ['prend soin de sa santé', 'tient ses engagements', 'est présent\u00b7e pour ses proches',
    'avance à son rythme', 'se relève après une chute', 'apprend de ses erreurs',
    'garde son sens de l\u2019humour', 'ose demander de l\u2019aide', 'reste curieux\u00b7se',
    'fait de son mieux, pas plus'];

  var T = {
    who_be:{fr:'Qui veux-tu être ?',en:'Who do you want to be?'},
    who_be_sub:{fr:'Pas « sans produit » \u2014 mais la personne derrière. Prends ce qui te parle, 8 maximum \u2014 rien d\u2019obligatoire, ce n\u2019est pas un examen.',
                en:'Not "without the substance" \u2014 but the person underneath. Pick whatever speaks to you, 8 maximum \u2014 nothing\u2019s mandatory, this isn\u2019t a test.'},
    hero_line:{fr:'Pas besoin de tout cocher, ni de trouver LA bonne réponse. Prends ce qui te parle, laisse le reste \u2014 ça peut changer avec le temps, ce n\u2019est pas gravé dans le marbre.',
               en:'No need to tick everything, or find THE right answer. Take what speaks to you, leave the rest \u2014 it can change over time, none of it is set in stone.'},
    my_values:{fr:'Mes valeurs',en:'My values'},
    count_chosen:{fr:function(n){return n+' / 8 choisies';}, en:function(n){return n+' / 8 chosen';}},
    surprise_btn:{fr:'\u2728 Pas d\u2019inspiration ? Propose-moi 3 valeurs au hasard',en:'\u2728 Out of ideas? Suggest 3 random values'},
    i_am_someone:{fr:'Je suis quelqu\u2019un qui\u2026',en:'I am someone who\u2026'},
    identity_ph:{fr:'ex : prend soin de sa santé, tient ses engagements\u2026',en:'e.g.: takes care of their health, keeps their commitments\u2026'},
    save_btn:{fr:'Enregistrer',en:'Save'},
    later:{fr:'plus tard',en:'later'},
    what_you_are:{fr:'Ce qui te porte',en:'What carries you'},
    close:{fr:'fermer',en:'close'},
    decl_line:{fr:function(s){return 'Voilà comment tu te définis, en ce moment : \u00ab\u00a0Je suis quelqu\u2019un qui '+s+'\u00a0\u00bb.';},
               en:function(s){return 'This is how you define yourself, right now: "I am someone who '+s+'".';}},
    no_decl_line:{fr:'Tu n\u2019as pas encore posé de déclaration \u2014 rien d\u2019obligatoire, ça peut attendre le moment où ça te parlera.',
                  en:'You haven\u2019t written a declaration yet \u2014 nothing\u2019s mandatory, it can wait until it speaks to you.'},
    values_line:{fr:function(v){return 'Ce qui te porte, là maintenant : '+v+'.';}, en:function(v){return 'What carries you, right now: '+v+'.';}},
    write_letter:{fr:'Écrire ma lettre',en:'Write my letter'},
    modify:{fr:'Modifier',en:'Edit'},
    define_values:{fr:'Définir mes valeurs',en:'Define my values'},
    later_cap:{fr:'Plus tard',en:'Later'},
    mdid_label:{fr:'Mes valeurs',en:'My values'}
  };
  function t(k, arg){ var e=T[k]; if(!e) return k; var v=lang()==='en'?e.en:e.fr; return (typeof v==='function') ? v(arg) : v; }

  var INJ = false, ov = null;

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdid-ov{z-index:var(--z-modal-3,4200);align-items:flex-start;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.5);font-family:var(--font-technical,Inter,sans-serif)}' +
      '.mdid-card{position:relative;z-index:var(--z-base,1);border:1px solid var(--line,#E2DCD0);border-radius:18px;' +
      'max-width:380px;width:100%;padding:20px;box-shadow:0 18px 50px rgba(31,43,37,.25)}' +
      '.mdid-q{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-h3,20px);margin:0 0 3px;text-align:center}' +
      '.mdid-sub{font-size:var(--fs-xs,12.5px);color:var(--ink-2,#58635E);text-align:center;margin:0 0 14px}' +
      '.mdid-lbl{font-size:var(--fs-caps,11.5px);color:var(--ink-2,#58635E);font-weight:var(--w-bold,700);margin:14px 0 7px;text-transform:uppercase;letter-spacing:var(--ls-caps,.04em)}' +
      '.mdid-chips{display:flex;flex-wrap:wrap;gap:7px}' +
      '.mdid-chip{padding:8px 12px;border:1px solid var(--line,#E2DCD0);background:var(--surface,#fff);color:var(--ink,#1F2B25);' +
      'border-radius:20px;font-size:var(--fs-xs,13px);cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '.mdid-chip.sel{background:var(--sauge,#7A8F72);border-color:var(--sauge,#7A8F72);color:#fff}' +
      '.mdid-chip.sg{font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);background:var(--bg-2,#FBF8F1)}' +
      '.mdid-ta{width:100%;box-sizing:border-box;border:1px solid var(--line,#E2DCD0);border-radius:12px;padding:11px;font-size:var(--fs-ui,15px);' +
      'font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);color:var(--ink,#1F2B25);background:var(--bg-2,#FBF8F1);resize:vertical;min-height:64px}' +
      '.mdid-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:var(--w-bold,700);font-size:var(--fs-ui,15px);padding:14px;cursor:pointer;margin-top:16px}' +
      '.mdid-skip{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);font-size:var(--fs-xs,13px);text-decoration:underline;cursor:pointer;margin-top:10px}' +
      '.mdid-cat{font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);font-weight:var(--w-medium,600);margin:12px 0 6px}' +
      '.mdid-cat:first-of-type{margin-top:2px}' +
      '.mdid-hero{display:flex;align-items:flex-start;gap:10px;margin-bottom:12px}' +
      '.mdid-bub{flex:1;min-width:0;background:var(--sauge-50,#EEF1E9);border-radius:14px 14px 14px 4px;padding:10px 12px}' +
      '.mdid-bub p{margin:0;font-family:var(--font-human,"Atkinson Hyperlegible",sans-serif);font-size:var(--fs-sm,14px);color:var(--ink,#1F2B25);line-height:var(--lh-normal,1.5)}' +
      '.mdid-count{font-size:var(--fs-xs,12px);color:var(--ink-2,#58635E);text-align:right;margin:6px 2px 0}' +
      '.mdid-cathead{display:flex;align-items:center;justify-content:space-between;width:100%;background:none;border:none;' +
      'padding:10px 2px;cursor:pointer;-webkit-tap-highlight-color:transparent;text-align:left}' +
      '.mdid-cathead .nm{font-family:var(--font-editorial,Newsreader,serif);font-size:var(--fs-ui,15px);color:var(--ink,#1F2B25)}' +
      '.mdid-cathead .ct{font-size:var(--fs-xs,12px);color:var(--sauge-d,#4C5E45);font-weight:var(--w-bold,700);margin-left:6px}' +
      '.mdid-cathead .chev{color:var(--ink-2,#58635E);transition:transform .15s;flex:0 0 auto}' +
      '.mdid-cathead.open .chev{transform:rotate(180deg)}' +
      '.mdid-catbody{overflow:hidden;max-height:0;transition:max-height .2s ease}' +
      '.mdid-catbody.open{max-height:400px}' +
      '.mdid-catbody .mdid-chips{padding:2px 2px 8px}' +
      '.mdid-surprise{width:100%;background:var(--bg-2,#FBF8F1);border:1px dashed var(--line-2,#D8D3CA);border-radius:12px;' +
      'color:var(--ink,#1F2B25);font-weight:var(--w-medium,600);font-size:var(--fs-sm,14px);padding:11px;cursor:pointer;margin:10px 0 4px}';
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(s);
  }
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function shell() { close(); inject(); ov = E('div', 'mdid-ov md-ov'); var c = E('div', 'mdid-card md-card'); ov.appendChild(c); document.body.appendChild(ov); if (window.MDCore && MDCore.makeDialog) MDCore.makeDialog(ov, { label: t('mdid_label') }); return c; }
  function close() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  var onCloseCb = null;
  function finalClose() { close(); if (typeof onCloseCb === 'function') { var cb = onCloseCb; onCloseCb = null; cb(); } }
  function ctc() { try { return window.MDData ? window.MDData.getCtc() : JSON.parse(localStorage.getItem('ctc_v6') || '{}'); } catch (e) { return {}; } }

  function open(onClose) {
    onCloseCb = onClose || null;
    var o = ctc(); var p = o.parcours || {};
    if ((p.valeurs && p.valeurs.length) || (p.identite && p.identite.length)) showCard(p);
    else edit(p);
  }

  function edit(p) {
    var c = shell();
    var selected = (p.valeurs || []).slice();
    c.appendChild(E('p', 'mdid-q', t('who_be')));
    c.appendChild(E('p', 'mdid-sub', t('who_be_sub')));

    var hero = E('div', 'mdid-hero');
    if (window.MDCompagnon && window.MDCompagnon.avatarHTML) {
      var av = document.createElement('div'); av.innerHTML = window.MDCompagnon.avatarHTML('bienveillance', { size: 'sm' }); hero.appendChild(av.firstChild || av);
    }
    var bub = E('div', 'mdid-bub');
    bub.appendChild(E('p', null, t('hero_line')));
    hero.appendChild(bub);
    c.appendChild(hero);

    c.appendChild(E('div', 'mdid-lbl', t('my_values')));
    var countEl = E('div', 'mdid-count', t('count_chosen', selected.length));
    var chipRefs = {}, bodyRefs = {};
    function refreshCount() { countEl.textContent = t('count_chosen', selected.length); }
    VALEUR_CATS.forEach(function (group) {
      var nSel = group.items.filter(function (v) { return selected.indexOf(v) >= 0; }).length;
      var head = E('button', 'mdid-cathead' + (nSel ? ' open' : '')); head.type = 'button';
      head.innerHTML = '<span class="nm">' + catLabel(group.cat) + (nSel ? '<span class="ct">' + nSel + '</span>' : '') + '</span>' +
        '<svg class="chev" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';
      var bodyWrap = E('div', 'mdid-catbody' + (nSel ? ' open' : ''));
      bodyRefs[group.cat] = bodyWrap;
      head.onclick = function () { head.classList.toggle('open'); bodyWrap.classList.toggle('open'); };
      var chips = E('div', 'mdid-chips');
      group.items.forEach(function (v) {
        var b = E('button', 'mdid-chip' + (selected.indexOf(v) >= 0 ? ' sel' : ''), v); b.type = 'button';
        chipRefs[v] = { btn: b, cat: group.cat, head: head };
        b.onclick = function () {
          var i = selected.indexOf(v);
          if (i >= 0) { selected.splice(i, 1); b.classList.remove('sel'); }
          else if (selected.length < 8) { selected.push(v); b.classList.add('sel'); }
          refreshCount();
        };
        chips.appendChild(b);
      });
      bodyWrap.appendChild(chips);
      c.appendChild(head); c.appendChild(bodyWrap);
    });

    var surprise = E('button', 'mdid-surprise', t('surprise_btn')); surprise.type = 'button';
    surprise.onclick = function () {
      var free = VALEURS.filter(function (v) { return selected.indexOf(v) < 0; });
      for (var s2 = free.length - 1; s2 > 0; s2--) { var j2 = Math.floor(Math.random() * (s2 + 1)); var tmp2 = free[s2]; free[s2] = free[j2]; free[j2] = tmp2; }
      var room = Math.max(0, 8 - selected.length);
      free.slice(0, Math.min(3, room)).forEach(function (v) {
        selected.push(v);
        var ref = chipRefs[v];
        if (ref) { ref.btn.classList.add('sel'); ref.head.classList.add('open'); bodyRefs[ref.cat].classList.add('open'); }
      });
      refreshCount();
    };
    c.appendChild(surprise);
    c.appendChild(countEl);

    c.appendChild(E('div', 'mdid-lbl', t('i_am_someone')));
    var ta = E('textarea', 'mdid-ta'); ta.placeholder = t('identity_ph');
    ta.value = (p.identite && p.identite[0]) || ''; c.appendChild(ta);
    var sg = E('div', 'mdid-chips'); sg.style.marginTop = '8px';
    SUGG.forEach(function (s) {
      var b = E('button', 'mdid-chip sg', '+ ' + s); b.type = 'button';
      b.onclick = function () { ta.value = (ta.value.trim() ? ta.value.replace(/[\s,]*$/, '') + ', ' : '') + s; };
      sg.appendChild(b);
    });
    c.appendChild(sg);
    var go = E('button', 'mdid-go', t('save_btn')); go.type = 'button';
    go.onclick = function () { save(selected, ta.value.trim()); };
    c.appendChild(go);
    var skip = E('button', 'mdid-skip', t('later')); skip.type = 'button'; skip.onclick = finalClose; c.appendChild(skip);
  }

  function save(valeurs, declaration) {
    try {
      var o = ctc(); o.parcours = o.parcours || {};
      o.parcours.valeurs = valeurs || [];
      o.parcours.identite = declaration ? [declaration] : [];
      if (window.MDData) window.MDData.write(o); else localStorage.setItem('ctc_v6', JSON.stringify(o));
      if (window.MDData) window.MDData.logSession('identite', { meta: { valeurs: (valeurs || []).length, declaration: !!declaration } });
      if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    } catch (e) { }
    showCard(ctc().parcours || {});
  }

  function showCard(p) {
    var hasValeurs = p.valeurs && p.valeurs.length;
    var hasDecl = p.identite && p.identite[0];

    if (!window.MDJeuHero || !MDJeuHero.debrief) {
      // Filet minimal si jeu-hero.js n'est pas chargé sur la page (ne devrait plus arriver).
      var c = shell();
      c.appendChild(E('p', 'mdid-q', t('what_you_are')));
      var x = E('button', 'mdid-skip', t('close')); x.type = 'button'; x.onclick = finalClose; c.appendChild(x);
      return;
    }

    var lines = [];
    if (hasDecl) lines.push(t('decl_line', p.identite[0]));
    else lines.push(t('no_decl_line'));
    if (hasValeurs) lines.push(t('values_line', p.valeurs.join(', ')));

    var stats = hasValeurs ? p.valeurs.slice(0, 8).map(function (v) { return { label: '', value: v }; }) : null;

    MDJeuHero.debrief({
      mood: 'bienveillance',
      title: t('what_you_are'),
      lines: lines,
      stats: stats,
      nav: hasDecl || hasValeurs
        ? { primary: { label: t('write_letter'), onClick: function () { location.href = 'lettre.html'; } },
            secondary: { label: t('modify'), onClick: function () { edit(p); } } }
        : { primary: { label: t('define_values'), onClick: function () { edit(p); } },
            secondary: { label: t('later_cap'), onClick: finalClose } },
      onPick: function () {}
    });
  }

  return { open: open };
})();
