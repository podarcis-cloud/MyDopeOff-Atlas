/* identite.js — Identité & valeurs (M6), 100 % local.
   L'utilisateur·rice choisit ses valeurs (ACT) et écrit « je suis quelqu'un qui… ».
   Ancre le « pourquoi » derrière les exercices, se relit en plein craving, et se prolonge
   dans la Lettre au futur toi. Stocke dans ctc_v6.parcours.valeurs / .identite ; journalise
   une séance 'identite' (nourrit la Stabilité comportementale). Expose window.MDIdentite. */
window.MDIdentite = (function () {
  var VALEURS = ['Famille', 'Santé', 'Honnêteté', 'Liberté', 'Créativité', 'Lien aux autres',
    'Apprendre', 'Nature', 'Aider les autres', 'Travail qui a du sens', 'Aventure', 'Sérénité'];
  var SUGG = ['prend soin de sa santé', 'tient ses engagements', 'est présent\u00b7e pour ses proches',
    'avance à son rythme', 'se relève après une chute'];
  var INJ = false, ov = null;

  function inject() {
    if (INJ) return; INJ = true;
    var css =
      '.mdid-ov{position:fixed;inset:0;z-index:4200;display:flex;align-items:center;justify-content:center;padding:20px;' +
      'background:rgba(31,43,37,.5);font-family:var(--ui,Inter,sans-serif);overflow-y:auto}' +
      '.mdid-card{position:relative;z-index:1;background:var(--surface,#fff);color:var(--ink,#1F2B25);border:1px solid var(--line,#E2DCD0);border-radius:18px;' +
      'max-width:380px;width:100%;padding:20px;box-shadow:0 18px 50px rgba(31,43,37,.25)}' +
      '.mdid-q{font-family:var(--title,Newsreader,serif);font-size:20px;margin:0 0 3px;text-align:center}' +
      '.mdid-sub{font-size:12.5px;color:var(--ink-2,#58635E);text-align:center;margin:0 0 14px}' +
      '.mdid-lbl{font-size:11.5px;color:var(--ink-2,#58635E);font-weight:700;margin:14px 0 7px;text-transform:uppercase;letter-spacing:.04em}' +
      '.mdid-chips{display:flex;flex-wrap:wrap;gap:7px}' +
      '.mdid-chip{padding:8px 12px;border:1px solid var(--line,#E2DCD0);background:var(--surface,#fff);color:var(--ink,#1F2B25);' +
      'border-radius:20px;font-size:13px;cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '.mdid-chip.sel{background:var(--sauge,#7A8F72);border-color:var(--sauge,#7A8F72);color:#fff}' +
      '.mdid-chip.sg{font-size:12px;color:var(--ink-2,#58635E);background:var(--bg-2,#FBF8F1)}' +
      '.mdid-decl{font-family:var(--content,"Atkinson Hyperlegible",sans-serif);font-size:15px;margin:2px 0 4px}' +
      '.mdid-ta{width:100%;box-sizing:border-box;border:1px solid var(--line,#E2DCD0);border-radius:12px;padding:11px;font-size:15px;' +
      'font-family:var(--content,"Atkinson Hyperlegible",sans-serif);color:var(--ink,#1F2B25);background:var(--bg-2,#FBF8F1);resize:vertical;min-height:64px}' +
      '.mdid-go{width:100%;border:none;border-radius:13px;background:var(--foret,#33463E);color:#fff;font-weight:700;font-size:15px;padding:14px;cursor:pointer;margin-top:16px}' +
      '.mdid-2nd{width:100%;background:none;border:1px solid var(--line,#E2DCD0);border-radius:13px;color:var(--ink,#1F2B25);font-weight:600;font-size:14px;padding:11px;cursor:pointer;margin-top:9px}' +
      '.mdid-link{display:block;text-align:center;color:var(--terra,#C7765C);font-weight:700;font-size:14px;margin-top:12px;text-decoration:none}' +
      '.mdid-skip{display:block;width:100%;background:none;border:none;color:var(--ink-2,#58635E);font-size:13px;text-decoration:underline;cursor:pointer;margin-top:10px}' +
      '.mdid-vrow{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin:4px 0 12px}' +
      '.mdid-vtag{padding:6px 11px;border-radius:16px;background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);font-size:13px}' +
      '.mdid-mecard{background:var(--bg-2,#FBF8F1);border:1px solid var(--line,#E2DCD0);border-radius:14px;padding:14px;margin:6px 0 4px;text-align:center}';
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.getElementsByTagName('head')[0] || document.body).appendChild(s);
  }
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function shell() { close(); inject(); ov = E('div', 'mdid-ov'); var c = E('div', 'mdid-card'); ov.appendChild(c); document.body.appendChild(ov); if (window.MDDecor) window.MDDecor.into(ov, { dots: true, wave: true }); return c; }
  function close() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
  function ctc() { try { return window.MDData ? window.MDData.getCtc() : JSON.parse(localStorage.getItem('ctc_v6') || '{}'); } catch (e) { return {}; } }

  function open() {
    var o = ctc(); var p = o.parcours || {};
    if ((p.valeurs && p.valeurs.length) || (p.identite && p.identite.length)) showCard(p);
    else edit(p);
  }

  function edit(p) {
    var c = shell();
    var selected = (p.valeurs || []).slice();
    c.appendChild(E('p', 'mdid-q', 'Qui veux-tu être ?'));
    c.appendChild(E('p', 'mdid-sub', 'Pas « sans produit » \u2014 mais la personne derrière. Choisis ce qui compte (jusqu\u2019à 5).'));
    c.appendChild(E('div', 'mdid-lbl', 'Mes valeurs'));
    var chips = E('div', 'mdid-chips');
    VALEURS.forEach(function (v) {
      var b = E('button', 'mdid-chip' + (selected.indexOf(v) >= 0 ? ' sel' : ''), v); b.type = 'button';
      b.onclick = function () {
        var i = selected.indexOf(v);
        if (i >= 0) { selected.splice(i, 1); b.classList.remove('sel'); }
        else if (selected.length < 5) { selected.push(v); b.classList.add('sel'); }
      };
      chips.appendChild(b);
    });
    c.appendChild(chips);
    c.appendChild(E('div', 'mdid-lbl', 'Je suis quelqu\u2019un qui\u2026'));
    var ta = E('textarea', 'mdid-ta'); ta.placeholder = 'ex : prend soin de sa santé, tient ses engagements\u2026';
    ta.value = (p.identite && p.identite[0]) || ''; c.appendChild(ta);
    var sg = E('div', 'mdid-chips'); sg.style.marginTop = '8px';
    SUGG.forEach(function (s) {
      var b = E('button', 'mdid-chip sg', '+ ' + s); b.type = 'button';
      b.onclick = function () { ta.value = (ta.value.trim() ? ta.value.replace(/[\s,]*$/, '') + ', ' : '') + s; };
      sg.appendChild(b);
    });
    c.appendChild(sg);
    var go = E('button', 'mdid-go', 'Enregistrer'); go.type = 'button';
    go.onclick = function () { save(selected, ta.value.trim()); };
    c.appendChild(go);
    var skip = E('button', 'mdid-skip', 'plus tard'); skip.type = 'button'; skip.onclick = close; c.appendChild(skip);
  }

  function save(valeurs, declaration) {
    try {
      var o = ctc(); o.parcours = o.parcours || {};
      o.parcours.valeurs = valeurs || [];
      o.parcours.identite = declaration ? [declaration] : [];
      if (window.MDData) window.MDData.write(o); else localStorage.setItem('ctc_v6', JSON.stringify(o));
      if (window.MDData) window.MDData.logSession('identite', { meta: { valeurs: (valeurs || []).length, declaration: !!declaration } });
      if (window.MDParcours) { try { window.MDParcours.recompute(); } catch (e) { } }
    } catch (e) { }
    showCard(ctc().parcours || {});
  }

  function showCard(p) {
    var c = shell();
    c.appendChild(E('p', 'mdid-q', 'Ce qui te porte'));
    var card = E('div', 'mdid-mecard');
    if (p.valeurs && p.valeurs.length) {
      var row = E('div', 'mdid-vrow');
      p.valeurs.forEach(function (v) { row.appendChild(E('span', 'mdid-vtag', v)); });
      card.appendChild(row);
    }
    if (p.identite && p.identite[0]) {
      card.appendChild(E('p', 'mdid-decl', '« Je suis quelqu\u2019un qui ' + p.identite[0] + ' »'));
    }
    if (!(p.valeurs && p.valeurs.length) && !(p.identite && p.identite[0])) {
      card.appendChild(E('p', 'mdid-decl', 'Rien encore \u2014 prends un instant pour le définir.'));
    }
    c.appendChild(card);
    var lettre = E('a', 'mdid-link', 'Prolonge-le dans une lettre à ton futur toi \u2192'); lettre.href = 'lettre.html'; c.appendChild(lettre);
    var mod = E('button', 'mdid-2nd', 'Modifier'); mod.type = 'button'; mod.onclick = function () { edit(p); }; c.appendChild(mod);
    var x = E('button', 'mdid-skip', 'fermer'); x.type = 'button'; x.onclick = close; c.appendChild(x);
  }

  return { open: open };
})();
