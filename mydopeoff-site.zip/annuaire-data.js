/* MyDope Off — annuaire-data.js
   ============================================================================
   Répertoire international des structures de réduction des risques.
   Issu de `00_AUDIT_REPERTOIRE_INTERNATIONAL.md` (243 structures, 37 pays).

   POURQUOI LE CHAMP `type` EST LE CŒUR DE CE FICHIER
   L'audit a mis au jour une erreur d'orientation possible : envoyer vers un observatoire de
   plaidoyer quelqu'un qui cherche un accueil. Ces familles ne reçoivent pas le même public
   et n'ont pas le même rapport à l'usage. Sans le type, le produit oriente à l'aveugle.

     analyse     Drug checking — neutre, analyse sans condition
     festif      L'usage est acquis, on sécurise le contexte
     bas_seuil   Accueil inconditionnel, rue, précarité
     pairs       Auto-support, porté par les personnes concernées
     soin        Orientation vers un parcours de soin
     plaidoyer   Observation, plaidoyer — NE REÇOIT PAS DE PUBLIC
     info        Ressource d'information et de documentation

   `plaidoyer` n'est jamais proposé comme lieu où aller. Il figure pour la documentation.

   Les URL ont été relevées le 11/08/2026. Elles vieillissent : la moulinette de captation
   peut les revérifier (`node tools/verif-annuaire.js`), mais aucune correction n'entre sans
   revue humaine, comme pour les alertes.
   ============================================================================ */
window.MD_ANNUAIRE = [

  /* ---------- Drug checking / analyse ---------- */
  { nom: 'Energy Control', pays: 'ES', type: 'analyse', url: 'https://energycontrol.org',
    note_fr: 'Analyse de substances, y compris par envoi postal international.',
    note_en: 'Substance analysis, including by international mail-in service.' },
  { nom: 'checkit!', pays: 'AT', type: 'analyse', url: 'https://checkit.wien',
    note_fr: 'Drug checking en salle et mobile, alertes publiées chaque semaine.',
    note_en: 'Fixed-site and mobile drug checking, warnings published weekly.' },
  { nom: 'Saferparty / DIZ', pays: 'CH', type: 'analyse', url: 'https://www.saferparty.ch',
    note_fr: 'Drug checking zurichois, alertes publiques régulières.',
    note_en: 'Zurich drug checking service, regular public warnings.' },
  { nom: 'DIMS', pays: 'NL', type: 'analyse', url: 'https://www.drugs-test.nl',
    note_fr: 'Système national néerlandais de suivi du marché.',
    note_en: 'Dutch national drug market monitoring system.' },
  { nom: 'The Loop', pays: 'GB', type: 'analyse', url: 'https://wearetheloop.org',
    note_fr: 'Drug checking en festival et en centre-ville.',
    note_en: 'Drug checking at festivals and in city centres.' },
  { nom: 'Échele Cabeza', pays: 'CO', type: 'analyse', url: 'https://www.echelecabeza.com',
    note_fr: 'Analyse et gestion des plaisirs — registre sans équivalent francophone.',
    note_en: 'Analysis and pleasure management — a register with no French-language equivalent.' },
  { nom: 'Modus Vivendi', pays: 'BE', type: 'analyse', url: 'https://www.modusvivendi-be.org',
    note_fr: 'RDR belge, projet TRIP et système d’alerte précoce.',
    note_en: 'Belgian harm reduction, TRIP project and early warning system.' },

  /* ---------- Milieu festif ---------- */
  { nom: 'DanceSafe', pays: 'US', type: 'festif', url: 'https://dancesafe.org',
    note_fr: 'Kits de test, information en milieu festif. « Ni cautionner ni condamner. »',
    note_en: 'Test kits and nightlife information. “Neither condone nor condemn.”' },
  { nom: 'Techno+', pays: 'FR', type: 'festif', url: 'https://www.technoplus.org',
    note_fr: 'Association d’usagers en milieu festif, une des plus anciennes en France.',
    note_en: 'User-led nightlife harm reduction, one of France’s oldest.' },
  { nom: 'Fêtez Clairs', pays: 'FR', type: 'festif', url: 'https://www.fetez-clairs.org',
    note_fr: 'Prévention en milieu festif francilien, dont les risques auditifs.',
    note_en: 'Nightlife prevention in the Paris region, including hearing risks.' },
  { nom: 'Rave It Safe', pays: 'CH', type: 'festif', url: 'https://www.raveitsafe.ch',
    note_fr: 'Berne — accueil sans condition d’âge.',
    note_en: 'Bern — no age requirement for access.' },
  { nom: 'Kosmicare', pays: 'PT', type: 'festif', url: 'https://kosmicare.org',
    note_fr: 'Accompagnement des crises psychédéliques. « Your trip. Our support. »',
    note_en: 'Psychedelic crisis support. “Your trip. Our support.”' },
  { nom: 'DanceWize', pays: 'AU', type: 'festif', url: 'https://dancewize.org.au',
    note_fr: 'RDR festive australienne, modèle par les pairs.',
    note_en: 'Australian nightlife harm reduction, peer-based model.' },
  { nom: 'Crew', pays: 'GB', type: 'festif', url: 'https://www.crew.scot',
    note_fr: 'Écosse — information festive et accueil.',
    note_en: 'Scotland — nightlife information and drop-in.' },

  /* ---------- Bas seuil / rue / précarité ---------- */
  { nom: 'Mainline', pays: 'NL', type: 'bas_seuil', url: 'https://mainline.nl',
    note_fr: 'Trente-cinq ans d’usages marginalisés. « Arrêter n’est jamais un préalable. »',
    note_en: 'Thirty-five years on marginalised use. “Stopping is never a prerequisite.”' },
  { nom: 'Transit', pays: 'BE', type: 'bas_seuil', url: 'https://www.transitasbl.be',
    note_fr: 'Bruxelles — accueil sans rendez-vous. « Personne n’a à arriver avec un plan. »',
    note_en: 'Brussels — walk-in. “People are under no obligation to arrive with a plan.”' },
  { nom: 'DUNE', pays: 'BE', type: 'bas_seuil', url: 'https://www.dune-asbl.be',
    note_fr: 'Travail de rue et échange de matériel, Bruxelles.',
    note_en: 'Street work and supply exchange, Brussels.' },
  { nom: 'Fixpunkt', pays: 'DE', type: 'bas_seuil', url: 'https://fixpunkt-berlin.de',
    note_fr: 'Berlin — travail de rue, salles de consommation.',
    note_en: 'Berlin — street work, consumption rooms.' },
  { nom: 'Metzineres', pays: 'ES', type: 'bas_seuil', url: 'https://metzineres.net',
    note_fr: 'Barcelone — premier programme d’Europe exclusivement pour les femmes et les personnes de genre non conforme. 100 % survivantes de violences.',
    note_en: 'Barcelona — Europe’s first harm reduction programme exclusively for women and gender non-conforming people. All are survivors of violence.' },
  { nom: 'NEXT Harm Reduction', pays: 'US', type: 'bas_seuil', url: 'https://nextdistro.org',
    note_fr: 'Naloxone et matériel stérile envoyés par la poste, partout aux États-Unis.',
    note_en: 'Naloxone and sterile supplies sent by mail, nationwide in the US.' },
  { nom: 'Never Use Alone', pays: 'US', type: 'bas_seuil', url: 'https://neverusealone.com',
    note_fr: 'Accompagnement téléphonique pendant la consommation, sans jugement.',
    note_en: 'Someone on the phone while you use, without judgment.' },

  /* ---------- Auto-support / pairs ---------- */
  { nom: 'ASUD', pays: 'FR', type: 'pairs', url: 'https://www.asud.org',
    note_fr: 'Auto-support des usagers de drogues. Journal, plaidoyer, savoir expérientiel.',
    note_en: 'Self-organised drug user group. Magazine, advocacy, experiential knowledge.' },
  { nom: 'Psychoactif', pays: 'FR', type: 'pairs', url: 'https://www.psychoactif.org',
    note_fr: 'Forum et PsychoWiki. « Ni encourager ni décourager. »',
    note_en: 'Forum and PsychoWiki. “Neither encourage nor discourage.”' },
  { nom: 'INPUD', pays: null, type: 'pairs', url: 'https://inpud.net',
    note_fr: 'Réseau international des personnes qui utilisent des drogues.',
    note_en: 'International Network of People who Use Drugs.' },
  { nom: 'JES', pays: 'DE', type: 'pairs', url: 'https://jes-bundesverband.de',
    note_fr: 'Réseau allemand d’auto-support.',
    note_en: 'German self-organised drug user network.' },
  { nom: 'akzept e.V.', pays: 'DE', type: 'pairs', url: 'https://www.akzept.eu',
    note_fr: 'Fédération allemande de RDR. Origine du principe « zieloffen ».',
    note_en: 'German harm reduction federation. Origin of the “zieloffen” principle.' },

  /* ---------- Chemsex ---------- */
  { nom: 'chemsex.be', pays: 'BE', type: 'info', url: 'https://www.chemsex.be',
    note_fr: 'Information et orientation chemsex, Belgique.',
    note_en: 'Chemsex information and referral, Belgium.' },
  { nom: 'chemsex.nl (Mainline)', pays: 'NL', type: 'info', url: 'https://www.chemsex.nl',
    note_fr: 'Information neutre pour les personnes concernées et leur entourage.',
    note_en: 'Neutral information for people involved and those close to them.' },

  /* ---------- Information et documentation ---------- */
  { nom: 'TripSit', pays: null, type: 'info', url: 'https://tripsit.me',
    note_fr: 'Tableau des interactions, accompagnement en ligne, données ouvertes.',
    note_en: 'Combination chart, live support, open data.' },
  { nom: 'EUDA', pays: null, type: 'info', url: 'https://www.euda.europa.eu',
    note_fr: 'Agence européenne sur les drogues. Signalements et données ouvertes.',
    note_en: 'European Union Drugs Agency. Alerts and open data.' },

  /* ---------- Observation / plaidoyer — ne reçoit pas de public ---------- */
  { nom: 'Eurotox', pays: 'BE', type: 'plaidoyer', url: 'https://eurotox.org',
    note_fr: 'Observatoire wallon et bruxellois. Système d’alerte précoce.',
    note_en: 'Walloon and Brussels observatory. Early warning system.' },
  { nom: 'Harm Reduction International', pays: null, type: 'plaidoyer', url: 'https://hri.global',
    note_fr: 'Plaidoyer international, rapport « Global State of Harm Reduction ».',
    note_en: 'International advocacy, “Global State of Harm Reduction” report.' },
  { nom: 'C-EHRN', pays: null, type: 'plaidoyer', url: 'https://www.correlation-net.org',
    note_fr: 'Réseau européen. Rapport « Full Spectrum Harm Reduction in Europe ».',
    note_en: 'European network. “Full Spectrum Harm Reduction in Europe” report.' },
  { nom: 'IDPC', pays: null, type: 'plaidoyer', url: 'https://idpc.net',
    note_fr: 'Consortium international sur les politiques des drogues.',
    note_en: 'International Drug Policy Consortium.' }

];
