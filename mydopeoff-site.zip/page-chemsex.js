/* MyDope Off — page-chemsex.js
   Dossier chemsex. Le seul besoin de la page est MDCore.init() : sans lui elle reste en
   français quelle que soit la langue choisie (piège 4 du protocole 36, vérifié par rendu). */
(function () {
  function start() {
    try { MDCore.init({ page: 'chemsex', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
