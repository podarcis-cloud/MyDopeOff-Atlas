/* MyDope Off — page-mentions.js
   Initialisation de mentions-legales.html. La page est statique : son seul besoin est
   MDCore.init(), qui applique le thème, la langue (data-i18n / data-i18n-html) et la
   navigation. Sans lui, la page reste en français quelle que soit la langue choisie —
   piège 4 du protocole 36, vérifié par rendu avant correction. */
(function () {
  function start() {
    try { MDCore.init({ page: 'mentions', section: 'securite' }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
