/* MyDope Off — page-recherche.js
   Page dédiée aux résultats. Le champ d'accueil ne rend rien sur place : il redirige
   ici avec le terme en paramètre d'URL, et c'est ici que le résultat s'affiche —
   jamais une liste qui pousse le reste de l'accueil vers le bas. */
(function () {
  function start() {
    try { MDCore.init({ page: 'recherche', section: 'securite' }); } catch (e) {}
    var champ = document.getElementById('recherche-champ');
    var res = document.getElementById('recherche-res');
    var q = new URLSearchParams(location.search).get('q') || '';
    if (champ) { champ.value = q; }
    if (window.MDRecherche && res) MDRecherche.rendre(q, res);
    if (champ) champ.addEventListener('input', function () {
      if (window.MDRecherche && res) MDRecherche.rendre(champ.value, res);
      var url = new URL(location.href);
      if (champ.value) url.searchParams.set('q', champ.value); else url.searchParams.delete('q');
      history.replaceState(null, '', url);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
