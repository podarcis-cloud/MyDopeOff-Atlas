/* MyDope Off — page-virage.js
   Logique de virage, extraite du script inline de virage.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }
  var L = lang();
  var BLEU='#69889A', OCRE='#D5A84A', TERRA='#C7765C', SAUGE='#7A8F72';
  var TRIALS=24;
  var body=document.getElementById('vg-body');
  var trial=0, correct=0, rts=[], swErr=0, rule='couleur', prevRule='couleur', card=null, tStart=0, t0=0, locked=false, nextSwitch=4, sinceSwitch=0;

  var T = {
    sort_by_color:{fr:'Trie par couleur',en:'Sort by colour'},
    sort_by_shape:{fr:'Trie par forme',en:'Sort by shape'},
    ok_count:{fr:'Justes : ',en:'Correct: '},
    check:{fr:'\u2713',en:'\u2713'},
    back_to_rule:{fr:'\u21ba la règle',en:'\u21ba the rule'},
    title:{fr:'Virage',en:'Switch'},
    stat_acc:{fr:'justesse',en:'accuracy'},
    stat_switch_err:{fr:'erreurs post-virage',en:'post-switch errors'},
    stat_flex:{fr:'flexibilité',en:'flexibility'},
    replay:{fr:'Rejouer',en:'Replay'},
    back_labo:{fr:'Retour au labo',en:'Back to Lab'},
    rules_l1:{fr:'Une forme colorée apparaît. Trie-la selon la règle affichée en haut.',en:'A coloured shape appears. Sort it according to the rule shown at the top.'},
    rules_l2:{fr:'Parfois par couleur (bleu / ocre), parfois par forme (rond / carré).',en:'Sometimes by colour (blue / ochre), sometimes by shape (circle / square).'},
    rules_l3:{fr:'La règle change sans prévenir : suis le virage, ne reste pas sur l\u2019ancien réflexe.',en:'The rule changes without warning: follow the switch, don\u2019t stay on the old reflex.'},
    rules_why:{fr:'Passer d\u2019une règle à l\u2019autre entraîne la flexibilité cognitive. La rigidité mentale nourrit les rituels et les automatismes de conso ; savoir changer de cap aide à en sortir.',
      en:'Switching from one rule to another trains cognitive flexibility. Mental rigidity feeds rituals and habitual use patterns; knowing how to change course helps you break free of them.'}
  };
  function t(k){ var e=T[k]; return e ? (L==='en'?e.en:e.fr) : k; }
  var RULE_LABEL = { couleur: t('sort_by_color'), forme: t('sort_by_shape') };

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'virage.title':    { fr: 'Virage', en: 'Switch' },
    'virage.subtitle': { fr: 'Changer de règle sans se laisser piéger par l\u2019habitude.', en: 'Changing the rule without getting trapped by habit.' },
    'virage.game_sub': { fr: "Trie la forme selon la règle affichée. Parfois c'est la <b>couleur</b>, parfois la <b>forme</b>. La règle change sans prévenir : à toi de suivre, sans rester sur l'ancien réflexe.",
      en: "Sort the shape according to the rule shown. Sometimes it's <b>colour</b>, sometimes it's <b>shape</b>. The rule changes without warning: keep up, don't stay on the old reflex." }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function shapeSVG(shape,color,size){ size=size||88;
    if(shape==='rond') return '<svg class="vg-shape" viewBox="0 0 100 100" width="'+size+'" height="'+size+'"><circle cx="50" cy="50" r="42" fill="'+color+'"/></svg>';
    return '<svg class="vg-shape" viewBox="0 0 100 100" width="'+size+'" height="'+size+'"><rect x="10" y="10" width="80" height="80" rx="12" fill="'+color+'"/></svg>';
  }

  function render(){
    var rc = rule==='couleur' ? 'background:'+SAUGE+'22;color:'+SAUGE : 'background:'+TERRA+'22;color:'+TERRA;
    var padA, padB;
    if(rule==='couleur'){ padA='<span class="vg-sw" style="background:'+BLEU+'"></span>'; padB='<span class="vg-sw" style="background:'+OCRE+'"></span>'; }
    else { padA=shapeSVG('rond','#8a8a8a',30); padB=shapeSVG('carré','#8a8a8a',30); }
    body.innerHTML='<span class="vg-rule" id="vg-rule" style="'+rc+'">'+RULE_LABEL[rule]+'</span>'+
      '<p class="game-step">'+(trial+1)+' / '+TRIALS+'</p>'+
      '<div class="vg-stage" id="vg-stage"></div>'+
      '<div class="vg-pads"><button class="vg-pad" data-k="A">'+padA+'</button><button class="vg-pad" data-k="B">'+padB+'</button></div>'+
      '<div class="game-hud"><span>'+t('ok_count')+'<b id="vg-ok">'+correct+'</b></span><span id="vg-fb">&nbsp;</span></div>'+
      '<div class="game-bar"><span id="vg-fill"></span></div>';
    body.querySelectorAll('[data-k]').forEach(function(b){ b.addEventListener('click',function(){ answer(b.getAttribute('data-k')); }); });
    next();
  }

  function next(){
    locked=false;
    // gérer le changement de règle
    if(sinceSwitch>=nextSwitch){ prevRule=rule; rule = rule==='couleur'?'forme':'couleur'; sinceSwitch=0; nextSwitch=3+Math.floor(Math.random()*3);
      // re-render pads/rule pour la nouvelle règle
      var rc = rule==='couleur' ? 'background:'+SAUGE+'22;color:'+SAUGE : 'background:'+TERRA+'22;color:'+TERRA;
      var ru=document.getElementById('vg-rule'); if(ru){ ru.textContent=RULE_LABEL[rule]; ru.setAttribute('style',rc); ru.classList.remove('flash'); void ru.offsetWidth; ru.classList.add('flash'); }
      var pads=document.querySelectorAll('.vg-pad');
      if(rule==='couleur'){ pads[0].innerHTML='<span class="vg-sw" style="background:'+BLEU+'"></span>'; pads[1].innerHTML='<span class="vg-sw" style="background:'+OCRE+'"></span>'; }
      else { pads[0].innerHTML=shapeSVG('rond','#8a8a8a',30); pads[1].innerHTML=shapeSVG('carré','#8a8a8a',30); }
    } else { prevRule=rule; }
    card={ color:Math.random()<0.5?'bleu':'ocre', shape:Math.random()<0.5?'rond':'carré' };
    document.getElementById('vg-stage').innerHTML=shapeSVG(card.shape, card.color==='bleu'?BLEU:OCRE);
    document.getElementById('vg-fill').style.width=Math.round(trial/TRIALS*100)+'%';
    tStart=Date.now();
  }

  function answer(k){
    if(locked) return; locked=true;
    var good;
    if(rule==='couleur') good = (card.color==='bleu') ? 'A':'B';
    else good = (card.shape==='rond') ? 'A':'B';
    var ok = k===good;
    var fb=document.getElementById('vg-fb');
    var isSwitch = sinceSwitch===0;
    if(ok){ correct++; rts.push(Date.now()-tStart); document.getElementById('vg-ok').textContent=correct; fb.textContent=t('check'); fb.style.color=SAUGE; }
    else { if(isSwitch) swErr++; fb.textContent=t('back_to_rule'); fb.style.color=TERRA; }
    sinceSwitch++; trial++;
    setTimeout(function(){ if(trial>=TRIALS) finish(); else next(); var f=document.getElementById('vg-fb'); if(f)f.innerHTML='&nbsp;'; }, ok?240:600);
  }

  function finish(){
    var acc=Math.round(correct/TRIALS*100);
    var avgRt=rts.length?Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length):0;
    var idx=Math.max(0,Math.min(100, acc - swErr*4));
    var d=store(); d.virage=d.virage||{best:0,parties:0}; d.virage.parties++; if(idx>d.virage.best)d.virage.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('virage',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{justesse:acc,rtMoyen:avgRt,erreursVirage:swErr,indice:idx},
        title:t('title'), stats:[{label:t('stat_acc'),value:acc+'%'},{label:t('stat_switch_err'),value:swErr},{label:t('stat_flex'),value:idx+'/100'}],
        nav:{ primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose:function(){ window.__mdAvant=null; trial=0;correct=0;rts=[];swErr=0;sinceSwitch=0;nextSwitch=4;rule='couleur';t0=Date.now();render(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('virage',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ justesse:acc, rtMoyen:avgRt, erreursVirage:swErr, indice:idx } }); }
  }

  function begin(){
    trial=0;correct=0;rts=[];swErr=0;sinceSwitch=0;nextSwitch=4;rule='couleur';t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  try{ MDCore.init({page:'virage',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
