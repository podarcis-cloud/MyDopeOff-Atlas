/* MyDope Off — page-virage.js
   Logique de virage, extraite du script inline de virage.html pour permettre une CSP
   stricte (script-src 'self'). Contenu inchangé, simplement déplacé. */

(function(){
  'use strict';
  var BLEU='#69889A', OCRE='#D5A84A', TERRA='#C7765C', SAUGE='#7A8F72';
  var TRIALS=24;
  var body=document.getElementById('vg-body');
  var trial=0, correct=0, rts=[], swErr=0, rule='couleur', prevRule='couleur', card=null, tStart=0, t0=0, locked=false, nextSwitch=4, sinceSwitch=0;

  function store(){ try{return (window.MDData&&MDData.read&&MDData.read())||{};}catch(e){return {};} }
  function save(d){ try{ if(window.MDData&&MDData.write) MDData.write(d); }catch(e){} }
  function shapeSVG(shape,color,size){ size=size||88;
    if(shape==='rond') return '<svg class="vg-shape" viewBox="0 0 100 100" width="'+size+'" height="'+size+'"><circle cx="50" cy="50" r="42" fill="'+color+'"/></svg>';
    return '<svg class="vg-shape" viewBox="0 0 100 100" width="'+size+'" height="'+size+'"><rect x="10" y="10" width="80" height="80" rx="12" fill="'+color+'"/></svg>';
  }

  function render(){
    var rc = rule==='couleur' ? 'background:'+SAUGE+'22;color:'+SAUGE : 'background:'+TERRA+'22;color:'+TERRA;
    var padA, padB;
    if(rule==='couleur'){ padA='<span class="vg-sw" style="background:'+BLEU+'"></span>'; padB='<span class="vg-sw" style="background:'+OCRE+'"></span>'; }
    else { padA=shapeSVG('rond','#8a8a8a',30); padB=shapeSVG('carré','#8a8a8a',30); }
    body.innerHTML='<span class="vg-rule" id="vg-rule" style="'+rc+'">Trie par '+rule+'</span>'+
      '<p class="game-step">'+(trial+1)+' / '+TRIALS+'</p>'+
      '<div class="vg-stage" id="vg-stage"></div>'+
      '<div class="vg-pads"><button class="vg-pad" data-k="A">'+padA+'</button><button class="vg-pad" data-k="B">'+padB+'</button></div>'+
      '<div class="game-hud"><span>Justes : <b id="vg-ok">'+correct+'</b></span><span id="vg-fb">&nbsp;</span></div>'+
      '<div class="game-bar"><span id="vg-fill"></span></div>';
    body.querySelectorAll('[data-k]').forEach(function(b){ b.addEventListener('click',function(){ answer(b.getAttribute('data-k')); }); });
    next();
  }

  function next(){
    locked=false;
    // gérer le changement de règle
    if(sinceSwitch>=nextSwitch){ prevRule=rule; rule = rule==='couleur'?'forme':'couleur'; sinceSwitch=0; nextSwitch=3+Math.floor(Math.random()*3);
      // re-render pads/rule pour la nouvelle règle
      var rc = rule==='couleur' ? 'background:'+SAUGE+'22;color:'+SAUGE : 'background:'+TERRA+'22;color:'+TERRA;
      var ru=document.getElementById('vg-rule'); if(ru){ ru.textContent='Trie par '+rule; ru.setAttribute('style',rc); ru.classList.remove('flash'); void ru.offsetWidth; ru.classList.add('flash'); }
      var pads=document.querySelectorAll('.vg-pad');
      if(rule==='couleur'){ pads[0].innerHTML='<span class="vg-sw" style="background:'+BLEU+'"></span>'; pads[1].innerHTML='<span class="vg-sw" style="background:'+OCRE+'"></span>'; }
      else { pads[0].innerHTML=shapeSVG('rond','#8a8a8a',30); pads[1].innerHTML=shapeSVG('carré','#8a8a8a',30); }
    } else { prevRule=rule; }
    card={ color:Math.random()<0.5?'bleu':'ocre', shape:Math.random()<0.5?'rond':'carré' };
    document.getElementById('vg-stage').innerHTML=shapeSVG(card.shape, card.color==='bleu'?BLEU:OCRE);
    document.getElementById('vg-fill').style.width=Math.round(trial/TRIALS*100)+'%';
    tStart=Date.now();
  }

  function answer(k){
    if(locked) return; locked=true;
    var good;
    if(rule==='couleur') good = (card.color==='bleu') ? 'A':'B';
    else good = (card.shape==='rond') ? 'A':'B';
    var ok = k===good;
    var fb=document.getElementById('vg-fb');
    var isSwitch = sinceSwitch===0;
    if(ok){ correct++; rts.push(Date.now()-tStart); document.getElementById('vg-ok').textContent=correct; fb.textContent='✓'; fb.style.color=SAUGE; }
    else { if(isSwitch) swErr++; fb.textContent='↺ la règle'; fb.style.color=TERRA; }
    sinceSwitch++; trial++;
    setTimeout(function(){ if(trial>=TRIALS) finish(); else next(); var f=document.getElementById('vg-fb'); if(f)f.innerHTML='&nbsp;'; }, ok?240:600);
  }

  function finish(){
    var acc=Math.round(correct/TRIALS*100);
    var avgRt=rts.length?Math.round(rts.reduce(function(a,b){return a+b;},0)/rts.length):0;
    var idx=Math.max(0,Math.min(100, acc - swErr*4));
    var d=store(); d.virage=d.virage||{best:0,parties:0}; d.virage.parties++; if(idx>d.virage.best)d.virage.best=idx; save(d);
    if(window.MDExercise){
      MDExercise.after('virage',{avant:window.__mdAvant, dureeSec:Math.round((Date.now()-t0)/1000), meta:{justesse:acc,rtMoyen:avgRt,erreursVirage:swErr,indice:idx},
        title:'Virage', stats:[{label:'justesse',value:acc+'%'},{label:'erreurs post-virage',value:swErr},{label:'flexibilité',value:idx+'/100'}],
        nav:{ primary:{label:'Rejouer'}, secondary:{label:'Retour au labo'} },
        onClose:function(){ window.__mdAvant=null; trial=0;correct=0;rts=[];swErr=0;sinceSwitch=0;nextSwitch=4;rule='couleur';t0=Date.now();render(); }});
    } else if(window.MDData&&MDData.logSession){ MDData.logSession('virage',{ dureeSec:Math.round((Date.now()-t0)/1000), meta:{ justesse:acc, rtMoyen:avgRt, erreursVirage:swErr, indice:idx } }); }
  }

  function begin(){
    trial=0;correct=0;rts=[];swErr=0;sinceSwitch=0;nextSwitch=4;rule='couleur';t0=Date.now();
    if(window.MDJeuHero){
      MDJeuHero.rules({ mood:'concentration', title:'Virage',
        lines:['Une forme colorée apparaît. Trie-la selon la règle affichée en haut.',
               'Parfois par couleur (bleu / ocre), parfois par forme (rond / carré).',
               'La règle change sans prévenir : suis le virage, ne reste pas sur l\u2019ancien réflexe.'],
        why:'Passer d\u2019une règle \u00e0 l\u2019autre entra\u00eene la flexibilit\u00e9 cognitive. La rigidit\u00e9 mentale nourrit les rituels et les automatismes de conso ; savoir changer de cap aide \u00e0 en sortir.',
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  try{ MDCore.init({page:'virage',section:'equilibre'}); }catch(e){}
  begin(); // écran unique (tutoriel + jauge) affiché dès l'arrivée sur la page
})();
