/* MyDope Off — page-recadrage.js
   Jeu de restructuration cognitive (TCC) : une pensée automatique liée au craving/à la
   rechute apparaît, avec 3 réactions possibles — une reformulation ancrée (ni déni ni
   dramatisation), et deux réactions courantes mais peu aidantes (rumination/catastrophisme,
   déni/minimisation). Choix jamais jugé « faux » : chaque tour se referme par une note
   informative sur le mécanisme, pas par un verdict.
   Nourrit l'axe « résilience émotionnelle » du parcours (voir parcours.js sessionScores) —
   jusqu'ici alimenté uniquement par la respiration et les bilans, aucun exercice cognitif
   dédié n'existait pour cet axe. 100% local. */
(function(){
  'use strict';
  function lang(){ try{ return (window.LUCIDE && LUCIDE.lang) ? LUCIDE.lang() : 'fr'; }catch(e){ return 'fr'; } }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'recadrage.title': { fr: 'Recadrage', en: 'Reframe' },
    'recadrage.subtitle': { fr: "Une pensée n'est pas un fait.", en: 'A thought is not a fact.' },
    'recadrage.game_q': { fr: 'Regarder une pensée autrement', en: 'Looking at a thought differently' },
    'recadrage.game_sub': { fr: "Une pensée automatique apparaît — le genre qui traverse l'esprit sans qu'on l'ait choisie. Choisis la réaction qui te semble la plus <b>juste</b>, pas la plus positive. Il n'y a pas de bonne réponse à deviner, juste des angles différents.",
      en: "An automatic thought appears — the kind that crosses your mind without being chosen. Pick the reaction that feels most <b>accurate</b> to you, not the most positive one. There's no right answer to guess, just different angles." }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  var T = {
    round_x_of_y: {fr:function(x,y){return x+' / '+y;}, en:function(x,y){return x+' / '+y;}},
    balanced_pick: {fr:'C\u2019est aussi la lecture la plus ancr\u00e9e.', en:'That\u2019s also the most grounded reading.'},
    other_pick: {fr:'Une autre lecture, plus ancr\u00e9e, existe aussi \u2014 la voici :', en:'Another, more grounded reading exists too \u2014 here it is:'},
    next: {fr:'Suivant', en:'Next'},
    title: {fr:'Recadrage', en:'Reframe'},
    stat_balanced: {fr:'lectures ancr\u00e9es', en:'grounded reads'},
    stat_rounds: {fr:'pens\u00e9es travers\u00e9es', en:'thoughts examined'},
    replay: {fr:'Rejouer', en:'Replay'},
    back_labo: {fr:'Retour au labo', en:'Back to Lab'},
    rules_l1: {fr:'Une pens\u00e9e automatique appara\u00eet \u2014 le genre qui surgit sans permission.', en:'An automatic thought appears \u2014 the kind that shows up uninvited.'},
    rules_l2: {fr:'Trois r\u00e9actions possibles. Choisis celle qui te semble la plus juste.', en:'Three possible reactions. Pick the one that feels most accurate.'},
    rules_l3: {fr:'Huit tours. Aucune r\u00e9ponse n\u2019est \u00ab fausse \u00bb \u2014 chacune dit juste quelque chose de diff\u00e9rent.', en:'Eight rounds. No answer is "wrong" \u2014 each one just says something different.'},
    rules_why: {fr:'Une pens\u00e9e n\u2019est pas un fait, et elle n\u2019a pas besoin d\u2019\u00eatre ni ni\u00e9e ni crue sur parole. S\u2019entra\u00eener \u00e0 la regarder sous un angle plus ancr\u00e9 \u2014 sans dramatiser ni minimiser \u2014 est une des techniques les mieux \u00e9tudi\u00e9es pour tenir face \u00e0 une envie.',
      en:'A thought is not a fact, and it doesn\u2019t need to be denied or taken at face value. Practising a more grounded angle on it \u2014 without dramatising or minimising \u2014 is one of the best-studied techniques for holding steady against an urge.'}
  };
  function t(k, a, b){ var e=T[k]; if(!e) return k; var v=lang()==='en'?e.en:e.fr; return (typeof v==='function')?v(a,b):v; }

  /* Banque : 16 pensées automatiques, chacune avec 3 réactions dont UNE ancrée (bal:true) —
     jamais présentée en premier ni marquée, l'ordre est mélangé à l'affichage. */
  var BANK_FR = [
    { thought:'Je craque, autant craquer \u00e0 fond.',
      opts:[ {t:'Un faux pas n\u2019efface pas tout ce que j\u2019ai d\u00e9j\u00e0 tenu. Je peux m\u2019arr\u00eater l\u00e0, maintenant.', bal:true},
             {t:'C\u2019est fichu de toute fa\u00e7on, plus rien \u00e0 perdre.'},
             {t:'En fait \u00e7a ne compte pas vraiment, je g\u00e8re tr\u00e8s bien.'} ] },
    { thought:'Cette envie ne va jamais s\u2019arr\u00eater.',
      opts:[ {t:'Les envies montent, culminent, puis redescendent \u2014 m\u00eame celle-ci, m\u00eame si \u00e7a n\u2019en a pas l\u2019air maintenant.', bal:true},
             {t:'Je ne vais pas survivre \u00e0 \u00e7a, il faut que \u00e7a cesse tout de suite.'},
             {t:'Ce n\u2019est rien, je n\u2019y pense m\u00eame pas.'} ] },
    { thought:'Je suis nul\u00b7le, je n\u2019y arriverai jamais.',
      opts:[ {t:'Un jour difficile ne dit rien sur qui je suis en g\u00e9n\u00e9ral.', bal:true},
             {t:'C\u2019est vrai, je n\u2019ai jamais \u00e9t\u00e9 capable de rien.'},
             {t:'Ce n\u2019est pas grave du tout, aucune importance.'} ] },
    { thought:'Tout le monde va me juger.',
      opts:[ {t:'Je ne sais pas vraiment ce que les autres pensent \u2014 et ce que j\u2019imagine est souvent pire que la r\u00e9alit\u00e9.', bal:true},
             {t:'C\u2019est certain, ils pensent tous la m\u00eame chose de moi.'},
             {t:'Je m\u2019en fiche compl\u00e8tement de ce qu\u2019ils pensent.'} ] },
    { thought:'Je ne supporte pas cette sensation.',
      opts:[ {t:'C\u2019est inconfortable, pas dangereux. \u00c7a va passer, m\u00eame si \u00e7a prend un moment.', bal:true},
             {t:'Il faut que \u00e7a s\u2019arr\u00eate maintenant, je ne peux vraiment pas tenir.'},
             {t:'Je ne ressens rien du tout en fait.'} ] },
    { thought:'Une seule fois, \u00e7a ne changera rien.',
      opts:[ {t:'Chaque fois compte, dans un sens ou dans l\u2019autre \u2014 m\u00eame si \u00e7a ne se voit pas tout de suite.', bal:true},
             {t:'De toute fa\u00e7on rien de ce que je fais ne compte vraiment.'},
             {t:'Une fois c\u2019est du sabotage total, je ne devrais m\u00eame pas y penser.'} ] },
    { thought:'Si je n\u2019avais pas ce probl\u00e8me, ma vie serait parfaite.',
      opts:[ {t:'\u00c7a r\u00e9glerait une chose, pas tout \u2014 et \u00e7a, c\u2019est d\u00e9j\u00e0 beaucoup.', bal:true},
             {t:'Rien n\u2019ira jamais mieux tant que \u00e7a durera.'},
             {t:'\u00c7a n\u2019a aucun impact sur le reste de ma vie.'} ] },
    { thought:'Je dois avoir consomm\u00e9 pour me d\u00e9tendre apr\u00e8s cette journ\u00e9e.',
      opts:[ {t:'J\u2019ai besoin de me d\u00e9tendre, c\u2019est vrai \u2014 il existe plusieurs fa\u00e7ons d\u2019y arriver.', bal:true},
             {t:'Sans \u00e7a, je ne me d\u00e9tendrai jamais.'},
             {t:'Je n\u2019ai pas vraiment besoin de me d\u00e9tendre.'} ] },
    { thought:'Je suis en train de perdre le contr\u00f4le.',
      opts:[ {t:'Ce moment est difficile \u00e0 tenir, ce qui n\u2019est pas la m\u00eame chose que perdre le contr\u00f4le.', bal:true},
             {t:'C\u2019est fini, je ne contr\u00f4le plus rien du tout.'},
             {t:'Je contr\u00f4le parfaitement, aucun souci.'} ] },
    { thought:'Personne ne comprend ce que je traverse.',
      opts:[ {t:'Peu de gens comprennent exactement \u2014 mais certains comprennent en partie, et \u00e7a compte.', bal:true},
             {t:'Je suis compl\u00e8tement seul\u00b7e avec \u00e7a, personne ne peut m\u2019aider.'},
             {t:'Tout le monde vit la m\u00eame chose, ce n\u2019est rien de sp\u00e9cial.'} ] },
    { thought:'J\u2019ai d\u00e9j\u00e0 rechut\u00e9 une fois, je vais forc\u00e9ment recommencer.',
      opts:[ {t:'Le pass\u00e9 donne des informations, pas une pr\u00e9diction garantie du futur.', bal:true},
             {t:'C\u2019est \u00e9crit, je vais forc\u00e9ment recommencer un jour.'},
             {t:'Le pass\u00e9 n\u2019a strictement aucun rapport avec maintenant.'} ] },
    { thought:'Je devrais d\u00e9j\u00e0 \u00eatre gu\u00e9ri\u00b7e \u00e0 ce stade.',
      opts:[ {t:'Il n\u2019y a pas de calendrier universel pour \u00e7a \u2014 mon rythme est le mien.', bal:true},
             {t:'Je suis en retard sur tout le monde, quelque chose ne va pas chez moi.'},
             {t:'Le temps n\u2019a aucune importance de toute fa\u00e7on.'} ] },
    { thought:'Si je craque, je vais d\u00e9cevoir tout le monde.',
      opts:[ {t:'Les gens qui comptent pour moi pr\u00e9f\u00e8rent probablement m\u2019entendre en parler plut\u00f4t que me voir dispara\u00eetre.', bal:true},
             {t:'Ils seront tous d\u00e9\u00e7us et je perdrai leur confiance pour toujours.'},
             {t:'\u00c7a ne les regarde absolument pas de toute fa\u00e7on.'} ] },
    { thought:'Je n\u2019ai aucune bonne raison de me sentir mal aujourd\u2019hui.',
      opts:[ {t:'Une \u00e9motion n\u2019a pas besoin d\u2019une raison parfaite pour \u00eatre r\u00e9elle et l\u00e9gitime.', bal:true},
             {t:'Je n\u2019ai pas le droit de me sentir comme \u00e7a, c\u2019est ridicule.'},
             {t:'En fait je ne me sens pas mal du tout.'} ] },
    { thought:'Je suis faible d\u2019avoir cette envie.',
      opts:[ {t:'Avoir une envie est une r\u00e9ponse biologique, pas un jugement sur ma force de caract\u00e8re.', bal:true},
             {t:'Une personne forte n\u2019aurait jamais cette envie.'},
             {t:'Ce n\u2019est rien, \u00e7a ne veut absolument rien dire.'} ] },
    { thought:'\u00c7a a toujours \u00e9t\u00e9 comme \u00e7a, \u00e7a sera toujours comme \u00e7a.',
      opts:[ {t:'Le pass\u00e9 fa\u00e7onne le pr\u00e9sent, il ne le condamne pas.', bal:true},
             {t:'Rien ne changera jamais vraiment, pourquoi essayer.'},
             {t:'Tout peut changer du jour au lendemain sans effort.'} ] }
  ];
  var BANK_EN = [
    { thought:'I\u2019m slipping, might as well go all the way.',
      opts:[ {t:'One slip doesn\u2019t erase everything I\u2019ve already held onto. I can stop right here, now.', bal:true},
             {t:'It\u2019s ruined anyway, nothing left to lose.'},
             {t:'Actually it doesn\u2019t really count, I\u2019ve got this under control.'} ] },
    { thought:'This urge is never going to stop.',
      opts:[ {t:'Urges rise, peak, then fall again \u2014 even this one, even if it doesn\u2019t feel that way right now.', bal:true},
             {t:'I won\u2019t survive this, it needs to stop right now.'},
             {t:'It\u2019s nothing, I\u2019m not even thinking about it.'} ] },
    { thought:'I\u2019m useless, I\u2019m never going to manage this.',
      opts:[ {t:'A hard day says nothing about who I am in general.', bal:true},
             {t:'It\u2019s true, I\u2019ve never been capable of anything.'},
             {t:'It doesn\u2019t matter at all, no big deal.'} ] },
    { thought:'Everyone is going to judge me.',
      opts:[ {t:'I don\u2019t actually know what other people think \u2014 and what I imagine is usually worse than reality.', bal:true},
             {t:'For sure, they all think the same thing about me.'},
             {t:'I couldn\u2019t care less what they think.'} ] },
    { thought:'I can\u2019t stand this feeling.',
      opts:[ {t:'It\u2019s uncomfortable, not dangerous. It will pass, even if it takes a moment.', bal:true},
             {t:'This has to stop right now, I really can\u2019t hold on.'},
             {t:'I don\u2019t actually feel anything.'} ] },
    { thought:'Just this once won\u2019t change anything.',
      opts:[ {t:'Every time counts, one way or the other \u2014 even if it doesn\u2019t show right away.', bal:true},
             {t:'Nothing I do really counts anyway.'},
             {t:'Just once is total sabotage, I shouldn\u2019t even think about it.'} ] },
    { thought:'If I didn\u2019t have this problem, my life would be perfect.',
      opts:[ {t:'It would fix one thing, not everything \u2014 and that\u2019s already a lot.', bal:true},
             {t:'Nothing will ever get better as long as this lasts.'},
             {t:'It has no impact on the rest of my life at all.'} ] },
    { thought:'I need to have used to unwind after a day like this.',
      opts:[ {t:'I do need to unwind, that\u2019s true \u2014 there are several ways to get there.', bal:true},
             {t:'Without it, I\u2019ll never actually relax.'},
             {t:'I don\u2019t really need to unwind.'} ] },
    { thought:'I\u2019m losing control.',
      opts:[ {t:'This moment is hard to hold onto, which isn\u2019t the same as losing control.', bal:true},
             {t:'It\u2019s over, I don\u2019t control anything anymore.'},
             {t:'I\u2019m in perfect control, no issue at all.'} ] },
    { thought:'Nobody understands what I\u2019m going through.',
      opts:[ {t:'Few people understand exactly \u2014 but some understand part of it, and that counts.', bal:true},
             {t:'I\u2019m completely alone with this, no one can help me.'},
             {t:'Everyone goes through the same thing, it\u2019s nothing special.'} ] },
    { thought:'I\u2019ve relapsed once before, so I\u2019m bound to do it again.',
      opts:[ {t:'The past gives information, not a guaranteed prediction of the future.', bal:true},
             {t:'It\u2019s written, I\u2019m bound to relapse again someday.'},
             {t:'The past has absolutely nothing to do with now.'} ] },
    { thought:'I should already be over this by now.',
      opts:[ {t:'There\u2019s no universal timeline for this \u2014 my pace is my own.', bal:true},
             {t:'I\u2019m behind everyone else, something\u2019s wrong with me.'},
             {t:'Time doesn\u2019t matter at all anyway.'} ] },
    { thought:'If I slip, I\u2019m going to disappoint everyone.',
      opts:[ {t:'The people who matter to me probably\u2019d rather hear about it than watch me disappear.', bal:true},
             {t:'They\u2019ll all be disappointed and I\u2019ll lose their trust forever.'},
             {t:'It\u2019s absolutely none of their business anyway.'} ] },
    { thought:'I have no good reason to feel bad today.',
      opts:[ {t:'An emotion doesn\u2019t need a perfect reason to be real and legitimate.', bal:true},
             {t:'I have no right to feel like this, it\u2019s ridiculous.'},
             {t:'Actually I don\u2019t feel bad at all.'} ] },
    { thought:'I\u2019m weak for having this urge.',
      opts:[ {t:'Having an urge is a biological response, not a verdict on my character.', bal:true},
             {t:'A strong person would never have this urge.'},
             {t:'It\u2019s nothing, it doesn\u2019t mean anything at all.'} ] },
    { thought:'It\u2019s always been this way, it will always be this way.',
      opts:[ {t:'The past shapes the present, it doesn\u2019t sentence it.', bal:true},
             {t:'Nothing will ever really change, why even try.'},
             {t:'Everything can change overnight with no effort.'} ] }
  ];
  function BANK(){ return lang()==='en' ? BANK_EN : BANK_FR; }

  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var x=a[i];a[i]=a[j];a[j]=x;} return a; }

  var ROUNDS=8, round=0, balancedCount=0, t0=0, order=[], body;

  function render(){
    var q = order[round];
    var opts = shuffle(q.opts.map(function(o,i){ return {t:o.t, bal:!!o.bal}; }));
    var html = '<p class="game-step">'+t('round_x_of_y', round+1, ROUNDS)+'</p>'+
      '<div class="rc-thought" id="rc-thought"></div>'+
      '<div class="rc-opts" id="rc-opts"></div>'+
      '<div class="rc-fb" id="rc-fb"></div>'+
      '<div class="game-bar"><span id="rc-fill"></span></div>';
    body.innerHTML = html;
    document.getElementById('rc-thought').textContent = q.thought;
    document.getElementById('rc-fill').style.width = Math.round(round/ROUNDS*100)+'%';
    var wrap = document.getElementById('rc-opts');
    opts.forEach(function(o){
      var b = document.createElement('button');
      b.className='rc-opt'; b.type='button'; b.textContent=o.t;
      b.addEventListener('click', function(){ pick(o, opts, wrap); });
      wrap.appendChild(b);
    });
  }

  function pick(chosen, opts, wrap){
    Array.prototype.forEach.call(wrap.children, function(btn, i){
      btn.setAttribute('disabled','');
      if (opts[i].t === chosen.t) btn.classList.add('picked');
    });
    if (chosen.bal) balancedCount++;
    var fb = document.getElementById('rc-fb');
    fb.className = 'rc-fb show';
    if (chosen.bal) {
      fb.textContent = t('balanced_pick');
    } else {
      var balancedOpt = opts.filter(function(o){ return o.bal; })[0];
      fb.textContent = t('other_pick') + ' ' + (balancedOpt ? balancedOpt.t : '');
    }
    var nextBtn = document.createElement('button');
    nextBtn.type='button'; nextBtn.className='btn btn-primary rc-next'; nextBtn.style.marginTop='6px';
    nextBtn.textContent = t('next');
    nextBtn.addEventListener('click', function(){ round++; if (round>=ROUNDS) finish(); else render(); });
    document.getElementById('rc-body').appendChild(nextBtn);
  }

  function finish(){
    var idx = Math.round(balancedCount/ROUNDS*100);
    if (window.MDExercise){
      MDExercise.after('recadrage', { avant: window.__mdAvant, perf: balancedCount/ROUNDS, dureeSec: Math.round((Date.now()-t0)/1000),
        meta: { balanced: balancedCount, rounds: ROUNDS, indice: idx },
        title: t('title'),
        stats: [ {label:t('stat_balanced'), value: balancedCount+'/'+ROUNDS}, {label:t('stat_rounds'), value: ROUNDS} ],
        nav: { primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose: function(){ window.__mdAvant=null; begin(); } });
    } else if (window.MDData && MDData.logSession){
      MDData.logSession('recadrage', { dureeSec: Math.round((Date.now()-t0)/1000), meta:{ balanced: balancedCount, rounds: ROUNDS, indice: idx } });
    }
  }

  function begin(){
    round=0; balancedCount=0; t0=Date.now();
    order = shuffle(BANK()).slice(0, ROUNDS);
    body = document.getElementById('rc-body');
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'reflexion', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  try{ MDCore.init({page:'recadrage',section:'equilibre'}); }catch(e){}
  begin();
})();
