/* MyDope Off — page-recadrage.js
   Jeu de restructuration cognitive (TCC) : une pensée automatique liée au craving/à la
   rechute apparaît, avec 3 réactions possibles — une reformulation ancrée (ni déni ni
   dramatisation), et deux réactions courantes mais peu aidantes (rumination/catastrophisme,
   déni/minimisation). Choix jamais jugé « faux » : chaque tour se referme par une note
   informative sur le mécanisme, pas par un verdict.
   Nourrit l'axe « résilience émotionnelle » du parcours (voir parcours.js sessionScores) —
   jusqu'ici alimenté uniquement par la respiration et les bilans, aucun exercice cognitif
   dédié n'existait pour cet axe. 100% local. */
(function(){
  'use strict';
  function lang(){ try{ return (window.MDCore && MDCore.lang) ? MDCore.lang() : 'fr'; }catch(e){ return 'fr'; } }

  var STATIC_T = {
    'game.back_labo': { fr: 'Retour au Labo', en: 'Back to Lab' },
    'game.labo_badge': { fr: 'Labo', en: 'Lab' },
    'recadrage.title': { fr: 'Recadrage', en: 'Reframe' },
    'recadrage.subtitle': { fr: "Une pensée n'est pas un fait.", en: 'A thought is not a fact.' },
    'recadrage.game_q': { fr: 'Regarder une pensée autrement', en: 'Looking at a thought differently' },
    'recadrage.game_sub': { fr: "Une pensée automatique apparaît — le genre qui traverse l'esprit sans qu'on l'ait choisie. Choisis la réaction qui te semble la plus <b>juste</b>, pas la plus positive. Il n'y a pas de bonne réponse à deviner, juste des angles différents.",
      en: "An automatic thought appears — the kind that crosses your mind without being chosen. Pick the reaction that feels most <b>accurate</b> to you, not the most positive one. There's no right answer to guess, just different angles." }
  };
  window.MD_DICT = window.MD_DICT || {};
  Object.keys(STATIC_T).forEach(function(k){ if(!window.MD_DICT[k]) window.MD_DICT[k] = STATIC_T[k]; });

  var T = {
    round_x_of_y: {fr:function(x,y){return x+' / '+y;}, en:function(x,y){return x+' / '+y;}},
    balanced_pick: {fr:'C\u2019est aussi la lecture la plus ancr\u00e9e.', en:'That\u2019s also the most grounded reading.'},
    other_pick: {fr:'Une autre lecture, plus ancr\u00e9e, existe aussi \u2014 la voici :', en:'Another, more grounded reading exists too \u2014 here it is:'},
    next: {fr:'Suivant', en:'Next'},
    title: {fr:'Recadrage', en:'Reframe'},
    stat_balanced: {fr:'lectures ancr\u00e9es', en:'grounded reads'},
    stat_rounds: {fr:'pens\u00e9es travers\u00e9es', en:'thoughts examined'},
    replay: {fr:'Rejouer', en:'Replay'},
    back_labo: {fr:'Retour au labo', en:'Back to Lab'},
    rules_l1: {fr:'Une pens\u00e9e automatique appara\u00eet \u2014 le genre qui surgit sans permission.', en:'An automatic thought appears \u2014 the kind that shows up uninvited.'},
    rules_l2: {fr:'Trois r\u00e9actions possibles. Choisis celle qui te semble la plus juste.', en:'Three possible reactions. Pick the one that feels most accurate.'},
    rules_l3: {fr:'Huit tours. Aucune r\u00e9ponse n\u2019est \u00ab fausse \u00bb \u2014 chacune dit juste quelque chose de diff\u00e9rent.', en:'Eight rounds. No answer is "wrong" \u2014 each one just says something different.'},
    rules_why: {fr:'Une pens\u00e9e n\u2019est pas un fait, et elle n\u2019a pas besoin d\u2019\u00eatre ni ni\u00e9e ni crue sur parole. S\u2019entra\u00eener \u00e0 la regarder sous un angle plus ancr\u00e9 \u2014 sans dramatiser ni minimiser \u2014 est une des techniques les mieux \u00e9tudi\u00e9es pour tenir face \u00e0 une envie.',
      en:'A thought is not a fact, and it doesn\u2019t need to be denied or taken at face value. Practising a more grounded angle on it \u2014 without dramatising or minimising \u2014 is one of the best-studied techniques for holding steady against an urge.'}
  };
  function t(k, a, b){ var e=T[k]; if(!e) return k; var v=lang()==='en'?e.en:e.fr; return (typeof v==='function')?v(a,b):v; }

  /* Banque : 16 pensées automatiques, chacune avec 3 réactions dont UNE ancrée (bal:true) —
     jamais présentée en premier ni marquée, l'ordre est mélangé à l'affichage. */
  var BANK_FR = [
    { id:'t01', thought:'Je craque, autant craquer à fond.',
      opts:[ {t:'Un faux pas n\'efface pas tout ce que j\'ai déjà tenu. Je peux m\'arrêter là, maintenant.', bal:true},
             {t:'C\'est fichu de toute façon, plus rien à perdre.'},
             {t:'En fait ça ne compte pas vraiment, je gère très bien.'} ] },
    { id:'t02', thought:'Cette envie ne va jamais s\'arrêter.',
      opts:[ {t:'Les envies montent, culminent, puis redescendent — même celle-ci, même si ça n\'en a pas l\'air maintenant.', bal:true},
             {t:'Je ne vais pas survivre à ça, il faut que ça cesse tout de suite.'},
             {t:'Ce n\'est rien, je n\'y pense même pas.'} ] },
    { id:'t03', thought:'Je suis nul·le, je n\'y arriverai jamais.',
      opts:[ {t:'Un jour difficile ne dit rien sur qui je suis en général.', bal:true},
             {t:'C\'est vrai, je n\'ai jamais été capable de rien.'},
             {t:'Ce n\'est pas grave du tout, aucune importance.'} ] },
    { id:'t04', thought:'Tout le monde va me juger.',
      opts:[ {t:'Je ne sais pas vraiment ce que les autres pensent — et ce que j\'imagine est souvent pire que la réalité.', bal:true},
             {t:'C\'est certain, ils pensent tous la même chose de moi.'},
             {t:'Je m\'en fiche complètement de ce qu\'ils pensent.'} ] },
    { id:'t05', thought:'Je ne supporte pas cette sensation.',
      opts:[ {t:'C\'est inconfortable, pas dangereux. Ça va passer, même si ça prend un moment.', bal:true},
             {t:'Il faut que ça s\'arrête maintenant, je ne peux vraiment pas tenir.'},
             {t:'Je ne ressens rien du tout en fait.'} ] },
    { id:'t06', thought:'Une seule fois, ça ne changera rien.',
      opts:[ {t:'Chaque fois compte, dans un sens ou dans l\'autre — même si ça ne se voit pas tout de suite.', bal:true},
             {t:'De toute façon rien de ce que je fais ne compte vraiment.'},
             {t:'Une fois c\'est du sabotage total, je ne devrais même pas y penser.'} ] },
    { id:'t07', thought:'Si je n\'avais pas ce problème, ma vie serait parfaite.',
      opts:[ {t:'Ça réglerait une chose, pas tout — et ça, c\'est déjà beaucoup.', bal:true},
             {t:'Rien n\'ira jamais mieux tant que ça durera.'},
             {t:'Ça n\'a aucun impact sur le reste de ma vie.'} ] },
    { id:'t08', thought:'Je dois avoir consommé pour me détendre après cette journée.',
      opts:[ {t:'J\'ai besoin de me détendre, c\'est vrai — il existe plusieurs façons d\'y arriver.', bal:true},
             {t:'Sans ça, je ne me détendrai jamais.'},
             {t:'Je n\'ai pas vraiment besoin de me détendre.'} ] },
    { id:'t09', thought:'Je suis en train de perdre le contrôle.',
      opts:[ {t:'Ce moment est difficile à tenir, ce qui n\'est pas la même chose que perdre le contrôle.', bal:true},
             {t:'C\'est fini, je ne contrôle plus rien du tout.'},
             {t:'Je contrôle parfaitement, aucun souci.'} ] },
    { id:'t10', thought:'Personne ne comprend ce que je traverse.',
      opts:[ {t:'Peu de gens comprennent exactement — mais certains comprennent en partie, et ça compte.', bal:true},
             {t:'Je suis complètement seul·e avec ça, personne ne peut m\'aider.'},
             {t:'Tout le monde vit la même chose, ce n\'est rien de spécial.'} ] },
    { id:'t11', thought:'J\'ai déjà rechuté une fois, je vais forcément recommencer.',
      opts:[ {t:'Le passé donne des informations, pas une prédiction garantie du futur.', bal:true},
             {t:'C\'est écrit, je vais forcément recommencer un jour.'},
             {t:'Le passé n\'a strictement aucun rapport avec maintenant.'} ] },
    { id:'t12', thought:'Je devrais déjà être guéri·e à ce stade.',
      opts:[ {t:'Il n\'y a pas de calendrier universel pour ça — mon rythme est le mien.', bal:true},
             {t:'Je suis en retard sur tout le monde, quelque chose ne va pas chez moi.'},
             {t:'Le temps n\'a aucune importance de toute façon.'} ] },
    { id:'t13', thought:'Si je craque, je vais décevoir tout le monde.',
      opts:[ {t:'Les gens qui comptent pour moi préfèrent probablement m\'entendre en parler plutôt que me voir disparaître.', bal:true},
             {t:'Ils seront tous déçus et je perdrai leur confiance pour toujours.'},
             {t:'Ça ne les regarde absolument pas de toute façon.'} ] },
    { id:'t14', thought:'Je n\'ai aucune bonne raison de me sentir mal aujourd\'hui.',
      opts:[ {t:'Une émotion n\'a pas besoin d\'une raison parfaite pour être réelle et légitime.', bal:true},
             {t:'Je n\'ai pas le droit de me sentir comme ça, c\'est ridicule.'},
             {t:'En fait je ne me sens pas mal du tout.'} ] },
    { id:'t15', thought:'Je suis faible d\'avoir cette envie.',
      opts:[ {t:'Avoir une envie est une réponse biologique, pas un jugement sur ma force de caractère.', bal:true},
             {t:'Une personne forte n\'aurait jamais cette envie.'},
             {t:'Ce n\'est rien, ça ne veut absolument rien dire.'} ] },
    { id:'t16', thought:'Ça a toujours été comme ça, ça sera toujours comme ça.',
      opts:[ {t:'Le passé façonne le présent, il ne le condamne pas.', bal:true},
             {t:'Rien ne changera jamais vraiment, pourquoi essayer.'},
             {t:'Tout peut changer du jour au lendemain sans effort.'} ] },
    { id:'t17', thought:'Je devrais pouvoir gérer ça tout seul·e.',
      opts:[ {t:'Demander un coup de main n\'annule pas ce que j\'ai déjà fait par moi-même.', bal:true},
             {t:'Si j\'ai besoin d\'aide, c\'est que j\'ai vraiment échoué.'},
             {t:'Je n\'ai jamais besoin de personne, jamais.'} ] },
    { id:'t18', thought:'Si je craque une fois, plus rien ne compte.',
      opts:[ {t:'Un seul moment ne peut pas effacer tout un chemin déjà parcouru.', bal:true},
             {t:'Autant tout arrêter, ça n\'aura plus aucun sens.'},
             {t:'Rien de tout ça n\'a jamais compté de toute façon.'} ] },
    { id:'t19', thought:'Les autres y arrivent, pourquoi pas moi ?',
      opts:[ {t:'Je ne vois qu\'un aperçu du chemin des autres, jamais tout ce qu\'il leur a coûté.', bal:true},
             {t:'C\'est la preuve que je suis moins capable que les autres.'},
             {t:'Les autres n\'ont jamais eu à se battre pour rien.'} ] },
    { id:'t20', thought:'Ça fait trop longtemps que j\'essaie, à quoi bon continuer.',
      opts:[ {t:'La durée d\'un effort ne dit rien sur sa valeur — certains chemins sont juste plus longs.', bal:true},
             {t:'Si ça prend autant de temps, c\'est que ça ne marchera jamais.'},
             {t:'Un peu plus ou un peu moins de temps, ça ne change rien.'} ] },
    { id:'t21', thought:'Je me sens différent·e de tout le monde à cause de ça.',
      opts:[ {t:'Beaucoup de gens portent quelque chose d\'invisible — la différence est juste moins visible chez eux.', bal:true},
             {t:'Je suis vraiment à part, personne d\'autre ne vit ça.'},
             {t:'Ce n\'est rien, tout le monde est exactement pareil.'} ] },
    { id:'t22', thought:'Je n\'ai pas assez de volonté.',
      opts:[ {t:'La volonté n\'est pas une réserve fixe — elle se reconstitue, elle se renforce, elle se ménage aussi.', bal:true},
             {t:'C\'est vrai, je n\'ai jamais eu assez de volonté pour rien.'},
             {t:'La volonté n\'existe pas vraiment, ça ne sert à rien d\'y penser.'} ] },
    { id:'t23', thought:'Personne ne remarquerait si je craquais.',
      opts:[ {t:'Le fait que ça ne se voie pas de l\'extérieur ne change rien à ce que ça représenterait pour moi.', bal:true},
             {t:'C\'est vrai, ça ne changerait rien pour personne.'},
             {t:'Tout le monde le remarquerait immédiatement et me jugerait.'} ] },
    { id:'t24', thought:'Je gâche tout ce que j\'ai construit.',
      opts:[ {t:'Un moment difficile fait partie de la construction, il ne la démolit pas à lui seul.', bal:true},
             {t:'C\'est vrai, tout ce que j\'ai construit ne vaut plus rien maintenant.'},
             {t:'Je n\'ai jamais rien construit de toute façon.'} ] },
    { id:'t25', thought:'C\'est trop dur, je ne suis pas fait·e pour ça.',
      opts:[ {t:'Trouver ça dur ne veut pas dire que ce n\'est pas pour moi — ça veut juste dire que c\'est dur, pour l\'instant.', bal:true},
             {t:'C\'est vrai, certaines personnes n\'y arrivent tout simplement pas, et je suis probablement de celles-là.'},
             {t:'En fait ce n\'est pas dur du tout.'} ] },
    { id:'t26', thought:'Si je n\'avais pas autant de stress, je n\'aurais pas cette envie.',
      opts:[ {t:'Le stress joue un vrai rôle, sans être la seule explication ni une excuse à tout.', bal:true},
             {t:'Ce n\'est pas ma faute du tout, c\'est entièrement à cause du stress.'},
             {t:'Le stress n\'a rien à voir avec ça.'} ] },
    { id:'t27', thought:'Je devrais être plus loin dans mon parcours à ce stade.',
      opts:[ {t:'Il n\'existe pas de « bon rythme » universel à atteindre — seulement le mien, tel qu\'il est.', bal:true},
             {t:'C\'est vrai, je suis clairement à la traîne par rapport à où je devrais être.'},
             {t:'Le rythme n\'a aucune importance, peu importe où j\'en suis.'} ] },
    { id:'t28', thought:'Je ne mérite pas d\'aller mieux.',
      opts:[ {t:'Aller mieux n\'est pas une récompense à mériter — c\'est quelque chose que je peux choisir, point.', bal:true},
             {t:'C\'est vrai, je ne mérite vraiment pas que ça s\'améliore pour moi.'},
             {t:'Le mérite n\'a rien à voir là-dedans, ça n\'a aucun sens d\'y penser.'} ] },
    { id:'t29', thought:'Une fois que j\'aurai craqué, je pourrai recommencer à zéro demain.',
      opts:[ {t:'Demain n\'efface pas aujourd\'hui — mais aujourd\'hui n\'est pas non plus toute l\'histoire.', bal:true},
             {t:'Oui, autant craquer maintenant puisque demain rattrapera tout.'},
             {t:'Ça n\'a aucune importance, demain ou pas.'} ] },
    { id:'t30', thought:'Les bons moments ne durent jamais longtemps de toute façon.',
      opts:[ {t:'Un bon moment garde sa valeur même s\'il ne dure pas éternellement — rien n\'est censé durer toujours.', bal:true},
             {t:'C\'est vrai, à quoi bon apprécier quelque chose qui va forcément se terminer.'},
             {t:'Les bons moments durent toujours, en fait, rien à en dire.'} ] },
    { id:'t31', thought:'Si je ressens ça, c\'est que je n\'ai pas vraiment changé.',
      opts:[ {t:'Ressentir une envie ne défait pas un changement — le changement, c\'est justement de savoir quoi en faire.', bal:true},
             {t:'C\'est vrai, tout ce travail n\'a servi à rien puisque je ressens encore ça.'},
             {t:'Ressentir quelque chose ou non, ça n\'a aucun rapport avec le changement.'} ] },
    { id:'t32', thought:'Je devrais avoir plus de contrôle sur mes pensées.',
      opts:[ {t:'Les pensées arrivent sans permission — ce qui compte, c\'est ce que j\'en fais, pas si elles surgissent.', bal:true},
             {t:'C\'est vrai, une personne saine d\'esprit n\'aurait pas ce genre de pensées.'},
             {t:'Le contrôle des pensées n\'existe pas, ça ne sert à rien d\'y penser.'} ] },
    { id:'t33', thought:'Ça ne sert à rien d\'essayer si je risque de recraquer un jour.',
      opts:[ {t:'Le risque de rechute ne rend pas l\'effort d\'aujourd\'hui inutile — il le rend juste réel, comme pour tout le monde.', bal:true},
             {t:'C\'est vrai, à quoi bon essayer si l\'échec est de toute façon probable.'},
             {t:'Il n\'y a jamais de risque de rechute, aucun souci à se faire.'} ] },
    { id:'t34', thought:'Je suis en train de perdre du temps avec tout ça.',
      opts:[ {t:'Le temps passé à comprendre et à tenir n\'est jamais du temps perdu, même quand ça ne se voit pas encore.', bal:true},
             {t:'C\'est vrai, tout ce temps aurait pu servir à autre chose de plus utile.'},
             {t:'Le temps n\'a aucune importance, ça ne sert à rien d\'y penser.'} ] },
    { id:'t35', thought:'Les gens qui n\'ont jamais eu ce problème ne peuvent pas comprendre à quel point c\'est dur.',
      opts:[ {t:'Comprendre entièrement n\'est pas nécessaire pour offrir un vrai soutien — beaucoup de gens en sont capables sans avoir vécu la même chose.', bal:true},
             {t:'C\'est vrai, personne qui n\'a pas vécu ça ne peut m\'être d\'aucune aide.'},
             {t:'Tout le monde comprend exactement de la même façon, ça n\'a pas d\'importance.'} ] },
    { id:'t36', thought:'Je devrais ressentir de la gratitude, pas du craving.',
      opts:[ {t:'Deux ressentis peuvent coexister sans s\'annuler — être reconnaissant·e et avoir une envie ne sont pas incompatibles.', bal:true},
             {t:'C\'est vrai, ressentir du craving prouve que je ne suis pas assez reconnaissant·e pour ce que j\'ai.'},
             {t:'La gratitude et le craving n\'ont rigoureusement aucun rapport.'} ] },
    { id:'t37', thought:'J\'ai raté ma chance de faire les choses bien.',
      opts:[ {t:'Une occasion ratée n\'épuise pas toutes les autres — il en reste, même si celle-ci est passée.', bal:true},
             {t:'C\'est vrai, cette chance-là ne reviendra jamais, c\'était la seule.'},
             {t:'Les chances n\'ont aucune importance, ça ne sert à rien d\'y penser.'} ] },
    { id:'t38', thought:'Ce moment va définir le reste de ma semaine.',
      opts:[ {t:'Un moment donné a du poids, mais il n\'écrit pas à lui seul tout ce qui suit.', bal:true},
             {t:'C\'est vrai, si ce moment se passe mal, toute la semaine sera fichue.'},
             {t:'Ce moment n\'a strictement aucune influence sur la suite.'} ] },
    { id:'t39', thought:'Personne ne va croire que j\'ai vraiment envie de changer.',
      opts:[ {t:'Ce que les autres croient ne détermine pas si mon envie de changer est réelle — elle m\'appartient, quoi qu\'ils en pensent.', bal:true},
             {t:'C\'est vrai, personne ne me croira jamais sincère là-dessus.'},
             {t:'Ce que les autres pensent de mes intentions n\'a strictement aucune importance.'} ] },
    { id:'t40', thought:'Si j\'avais plus de discipline, je ne serais pas dans cette situation.',
      opts:[ {t:'La discipline n\'est qu\'un facteur parmi d\'autres — biologie, contexte, histoire personnelle jouent aussi un vrai rôle.', bal:true},
             {t:'C\'est vrai, tout ça est entièrement de ma faute, à cause d\'un manque de discipline.'},
             {t:'La discipline n\'a strictement rien à voir avec cette situation.'} ] },
    { id:'t41', thought:'Je dois prouver que je suis capable, sinon ça ne compte pas.',
      opts:[ {t:'Un progrès garde sa valeur même sans avoir besoin d\'être prouvé à qui que ce soit, moi y compris.', bal:true},
             {t:'C\'est vrai, si je ne le prouve pas clairement, ça ne compte pour rien.'},
             {t:'Prouver quoi que ce soit n\'a jamais eu la moindre importance.'} ] },
    { id:'t42', thought:'Ça devient plus facile pour tout le monde sauf moi.',
      opts:[ {t:'Je ne vois presque jamais la difficulté réelle du chemin des autres — seulement ce qu\'ils choisissent de montrer.', bal:true},
             {t:'C\'est vrai, tout le monde avance sauf moi, qui reste coincé·e.'},
             {t:'Ça devient facile pour tout le monde exactement au même rythme, aucune différence.'} ] },
    { id:'t43', thought:'Je ne devrais même pas avoir besoin de cette appli.',
      opts:[ {t:'Utiliser un outil qui aide n\'est pas un aveu d\'échec — c\'est une façon parmi d\'autres de prendre soin de soi.', bal:true},
             {t:'C\'est vrai, avoir besoin de ça prouve que je suis plus faible que les autres.'},
             {t:'Cette appli n\'a jamais servi à rien, autant l\'oublier.'} ] },
    { id:'t44', thought:'Un bon jour ne veut rien dire si demain est mauvais.',
      opts:[ {t:'Un bon jour compte pour ce qu\'il est, indépendamment de ce que sera demain.', bal:true},
             {t:'C\'est vrai, ça ne sert à rien de se réjouir d\'un bon jour puisque ça ne va pas durer.'},
             {t:'Les jours n\'ont jamais aucune valeur en eux-mêmes, ni bons ni mauvais.'} ] },
    { id:'t45', thought:'Je suis fatigué·e de me battre contre moi-même.',
      opts:[ {t:'Cette fatigue est réelle et légitime — elle mérite du repos, pas d\'être ignorée ni de servir d\'excuse pour arrêter d\'essayer.', bal:true},
             {t:'C\'est vrai, autant abandonner puisque je suis épuisé·e de toute façon.'},
             {t:'En fait je ne suis pas fatigué·e du tout, aucun souci.'} ] },
    { id:'t46', thought:'Ce n\'est probablement qu\'une question de temps avant que je craque.',
      opts:[ {t:'Le futur n\'est pas écrit d\'avance — chaque moment tenu est une preuve contraire à cette pensée, pas juste un sursis.', bal:true},
             {t:'C\'est vrai, c\'est inévitable, ce n\'est qu\'une question de temps.'},
             {t:'Il n\'y a strictement aucun risque, jamais, à aucun moment.'} ] },
    { id:'t47', thought:'Je ne peux pas faire confiance à mon propre jugement en ce moment.',
      opts:[ {t:'L\'inconfort du moment ne rend pas tout mon jugement invalide — je peux encore m\'appuyer sur ce que je sais être vrai.', bal:true},
             {t:'C\'est vrai, mieux vaut ne faire confiance à rien de ce que je pense en ce moment.'},
             {t:'Mon jugement est parfaitement fiable à 100 %, aucun doute possible.'} ] },
    { id:'t48', thought:'Si ça devait marcher, ce serait déjà plus facile.',
      opts:[ {t:'La difficulté d\'un moment ne prédit pas l\'issue de tout le chemin — beaucoup de choses qui finissent par marcher restent difficiles longtemps.', bal:true},
             {t:'C\'est vrai, si c\'était censé marcher pour moi, ça se saurait déjà.'},
             {t:'La facilité n\'a jamais eu le moindre rapport avec la réussite de quoi que ce soit.'} ] }
  ];
  var BANK_EN = [
    { id:'t01', thought:'I\'m slipping, might as well go all the way.',
      opts:[ {t:'One slip doesn\'t erase everything I\'ve already held onto. I can stop right here, now.', bal:true},
             {t:'It\'s ruined anyway, nothing left to lose.'},
             {t:'Actually it doesn\'t really count, I\'ve got this under control.'} ] },
    { id:'t02', thought:'This urge is never going to stop.',
      opts:[ {t:'Urges rise, peak, then fall again — even this one, even if it doesn\'t feel that way right now.', bal:true},
             {t:'I won\'t survive this, it needs to stop right now.'},
             {t:'It\'s nothing, I\'m not even thinking about it.'} ] },
    { id:'t03', thought:'I\'m useless, I\'m never going to manage this.',
      opts:[ {t:'A hard day says nothing about who I am in general.', bal:true},
             {t:'It\'s true, I\'ve never been capable of anything.'},
             {t:'It doesn\'t matter at all, no big deal.'} ] },
    { id:'t04', thought:'Everyone is going to judge me.',
      opts:[ {t:'I don\'t actually know what other people think — and what I imagine is usually worse than reality.', bal:true},
             {t:'For sure, they all think the same thing about me.'},
             {t:'I couldn\'t care less what they think.'} ] },
    { id:'t05', thought:'I can\'t stand this feeling.',
      opts:[ {t:'It\'s uncomfortable, not dangerous. It will pass, even if it takes a moment.', bal:true},
             {t:'This has to stop right now, I really can\'t hold on.'},
             {t:'I don\'t actually feel anything.'} ] },
    { id:'t06', thought:'Just this once won\'t change anything.',
      opts:[ {t:'Every time counts, one way or the other — even if it doesn\'t show right away.', bal:true},
             {t:'Nothing I do really counts anyway.'},
             {t:'Just once is total sabotage, I shouldn\'t even think about it.'} ] },
    { id:'t07', thought:'If I didn\'t have this problem, my life would be perfect.',
      opts:[ {t:'It would fix one thing, not everything — and that\'s already a lot.', bal:true},
             {t:'Nothing will ever get better as long as this lasts.'},
             {t:'It has no impact on the rest of my life at all.'} ] },
    { id:'t08', thought:'I need to have used to unwind after a day like this.',
      opts:[ {t:'I do need to unwind, that\'s true — there are several ways to get there.', bal:true},
             {t:'Without it, I\'ll never actually relax.'},
             {t:'I don\'t really need to unwind.'} ] },
    { id:'t09', thought:'I\'m losing control.',
      opts:[ {t:'This moment is hard to hold onto, which isn\'t the same as losing control.', bal:true},
             {t:'It\'s over, I don\'t control anything anymore.'},
             {t:'I\'m in perfect control, no issue at all.'} ] },
    { id:'t10', thought:'Nobody understands what I\'m going through.',
      opts:[ {t:'Few people understand exactly — but some understand part of it, and that counts.', bal:true},
             {t:'I\'m completely alone with this, no one can help me.'},
             {t:'Everyone goes through the same thing, it\'s nothing special.'} ] },
    { id:'t11', thought:'I\'ve relapsed once before, so I\'m bound to do it again.',
      opts:[ {t:'The past gives information, not a guaranteed prediction of the future.', bal:true},
             {t:'It\'s written, I\'m bound to relapse again someday.'},
             {t:'The past has absolutely nothing to do with now.'} ] },
    { id:'t12', thought:'I should already be over this by now.',
      opts:[ {t:'There\'s no universal timeline for this — my pace is my own.', bal:true},
             {t:'I\'m behind everyone else, something\'s wrong with me.'},
             {t:'Time doesn\'t matter at all anyway.'} ] },
    { id:'t13', thought:'If I slip, I\'m going to disappoint everyone.',
      opts:[ {t:'The people who matter to me probably\'d rather hear about it than watch me disappear.', bal:true},
             {t:'They\'ll all be disappointed and I\'ll lose their trust forever.'},
             {t:'It\'s absolutely none of their business anyway.'} ] },
    { id:'t14', thought:'I have no good reason to feel bad today.',
      opts:[ {t:'An emotion doesn\'t need a perfect reason to be real and legitimate.', bal:true},
             {t:'I have no right to feel like this, it\'s ridiculous.'},
             {t:'Actually I don\'t feel bad at all.'} ] },
    { id:'t15', thought:'I\'m weak for having this urge.',
      opts:[ {t:'Having an urge is a biological response, not a verdict on my character.', bal:true},
             {t:'A strong person would never have this urge.'},
             {t:'It\'s nothing, it doesn\'t mean anything at all.'} ] },
    { id:'t16', thought:'It\'s always been this way, it will always be this way.',
      opts:[ {t:'The past shapes the present, it doesn\'t sentence it.', bal:true},
             {t:'Nothing will ever really change, why even try.'},
             {t:'Everything can change overnight with no effort.'} ] },
    { id:'t17', thought:'I should be able to handle this on my own.',
      opts:[ {t:'Asking for a hand doesn\'t cancel out what I\'ve already done by myself.', bal:true},
             {t:'If I need help, it means I\'ve truly failed.'},
             {t:'I never need anyone, ever.'} ] },
    { id:'t18', thought:'If I slip once, nothing counts anymore.',
      opts:[ {t:'A single moment can\'t erase a whole path already walked.', bal:true},
             {t:'Might as well stop everything, it won\'t make sense anymore.'},
             {t:'None of it ever counted anyway.'} ] },
    { id:'t19', thought:'Other people manage it, why can\'t I?',
      opts:[ {t:'I only see a glimpse of other people\'s path, never everything it cost them.', bal:true},
             {t:'It proves I\'m less capable than everyone else.'},
             {t:'Other people never had to fight for anything.'} ] },
    { id:'t20', thought:'I\'ve been trying for too long, what\'s the point of continuing.',
      opts:[ {t:'How long an effort takes says nothing about its worth — some paths are just longer.', bal:true},
             {t:'If it\'s taking this long, it means it\'ll never work.'},
             {t:'A bit more or a bit less time changes nothing.'} ] },
    { id:'t21', thought:'I feel different from everyone else because of this.',
      opts:[ {t:'A lot of people carry something invisible — the difference is just less visible in them.', bal:true},
             {t:'I really am set apart, no one else lives this.'},
             {t:'It\'s nothing, everyone is exactly the same.'} ] },
    { id:'t22', thought:'I don\'t have enough willpower.',
      opts:[ {t:'Willpower isn\'t a fixed reserve — it refills, it strengthens, it also needs pacing.', bal:true},
             {t:'It\'s true, I\'ve never had enough willpower for anything.'},
             {t:'Willpower doesn\'t really exist, no point thinking about it.'} ] },
    { id:'t23', thought:'No one would notice if I slipped.',
      opts:[ {t:'The fact that it wouldn\'t show from the outside changes nothing about what it would mean to me.', bal:true},
             {t:'It\'s true, it wouldn\'t change anything for anyone.'},
             {t:'Everyone would notice immediately and judge me.'} ] },
    { id:'t24', thought:'I\'m ruining everything I\'ve built.',
      opts:[ {t:'A hard moment is part of the building, it doesn\'t demolish it on its own.', bal:true},
             {t:'It\'s true, everything I\'ve built is worthless now.'},
             {t:'I never built anything anyway.'} ] },
    { id:'t25', thought:'This is too hard, I\'m not cut out for this.',
      opts:[ {t:'Finding it hard doesn\'t mean it\'s not for me — it just means it\'s hard, for now.', bal:true},
             {t:'It\'s true, some people simply can\'t do it, and I\'m probably one of them.'},
             {t:'Actually this isn\'t hard at all.'} ] },
    { id:'t26', thought:'If I didn\'t have so much stress, I wouldn\'t have this urge.',
      opts:[ {t:'Stress plays a real role, without being the only explanation or an excuse for everything.', bal:true},
             {t:'It\'s not my fault at all, it\'s entirely because of stress.'},
             {t:'Stress has nothing to do with this.'} ] },
    { id:'t27', thought:'I should be further along in my journey by now.',
      opts:[ {t:'There\'s no universal "right pace" to reach — only my own, as it is.', bal:true},
             {t:'It\'s true, I\'m clearly lagging behind where I should be.'},
             {t:'Pace doesn\'t matter at all, no matter where I am.'} ] },
    { id:'t28', thought:'I don\'t deserve to get better.',
      opts:[ {t:'Getting better isn\'t a reward to earn — it\'s something I can choose, full stop.', bal:true},
             {t:'It\'s true, I really don\'t deserve things to improve for me.'},
             {t:'Deserving has nothing to do with it, no point thinking about it.'} ] },
    { id:'t29', thought:'Once I\'ve slipped, I can start fresh tomorrow.',
      opts:[ {t:'Tomorrow doesn\'t erase today — but today isn\'t the whole story either.', bal:true},
             {t:'Yes, might as well slip now since tomorrow will make up for it.'},
             {t:'It doesn\'t matter at all, tomorrow or not.'} ] },
    { id:'t30', thought:'Good moments never last long anyway.',
      opts:[ {t:'A good moment keeps its value even if it doesn\'t last forever — nothing is meant to last forever.', bal:true},
             {t:'It\'s true, what\'s the point enjoying something that\'s bound to end.'},
             {t:'Good moments actually always last, nothing to say about it.'} ] },
    { id:'t31', thought:'If I\'m feeling this, it means I haven\'t really changed.',
      opts:[ {t:'Feeling an urge doesn\'t undo change — change is precisely knowing what to do with it.', bal:true},
             {t:'It\'s true, all that work was for nothing since I still feel this.'},
             {t:'Feeling something or not has nothing to do with change.'} ] },
    { id:'t32', thought:'I should have more control over my thoughts.',
      opts:[ {t:'Thoughts show up without permission — what matters is what I do with them, not whether they appear.', bal:true},
             {t:'It\'s true, a healthy-minded person wouldn\'t have these kinds of thoughts.'},
             {t:'Controlling thoughts doesn\'t exist, no point thinking about it.'} ] },
    { id:'t33', thought:'There\'s no point trying if I might relapse someday.',
      opts:[ {t:'The risk of relapse doesn\'t make today\'s effort pointless — it just makes it real, like for everyone.', bal:true},
             {t:'It\'s true, what\'s the point trying if failure is likely anyway.'},
             {t:'There\'s never any relapse risk, nothing to worry about.'} ] },
    { id:'t34', thought:'I\'m wasting my time with all this.',
      opts:[ {t:'Time spent understanding and holding steady is never wasted, even when it doesn\'t show yet.', bal:true},
             {t:'It\'s true, all that time could have gone to something more useful.'},
             {t:'Time doesn\'t matter at all, no point thinking about it.'} ] },
    { id:'t35', thought:'People who\'ve never had this problem can\'t understand how hard it is.',
      opts:[ {t:'Fully understanding isn\'t necessary to offer real support — many people are capable of that without having lived the same thing.', bal:true},
             {t:'It\'s true, no one who hasn\'t lived this can be of any help to me.'},
             {t:'Everyone understands in exactly the same way, it doesn\'t matter.'} ] },
    { id:'t36', thought:'I should be feeling grateful, not craving.',
      opts:[ {t:'Two feelings can coexist without cancelling each other out — being grateful and having an urge aren\'t incompatible.', bal:true},
             {t:'It\'s true, feeling craving proves I\'m not grateful enough for what I have.'},
             {t:'Gratitude and craving have absolutely nothing to do with each other.'} ] },
    { id:'t37', thought:'I missed my chance to get this right.',
      opts:[ {t:'A missed chance doesn\'t use up all the others — there are more, even if this one has passed.', bal:true},
             {t:'It\'s true, that chance will never come back, it was the only one.'},
             {t:'Chances don\'t matter at all, no point thinking about it.'} ] },
    { id:'t38', thought:'This moment is going to define the rest of my week.',
      opts:[ {t:'A given moment carries weight, but it doesn\'t write everything that follows on its own.', bal:true},
             {t:'It\'s true, if this moment goes badly, the whole week is ruined.'},
             {t:'This moment has absolutely no influence on what follows.'} ] },
    { id:'t39', thought:'No one is going to believe I really want to change.',
      opts:[ {t:'What others believe doesn\'t determine whether my wish to change is real — it\'s mine, whatever they think.', bal:true},
             {t:'It\'s true, no one will ever believe I\'m sincere about this.'},
             {t:'What others think of my intentions doesn\'t matter at all.'} ] },
    { id:'t40', thought:'If I had more discipline, I wouldn\'t be in this situation.',
      opts:[ {t:'Discipline is just one factor among others — biology, context, personal history also play a real role.', bal:true},
             {t:'It\'s true, this is entirely my fault, because of a lack of discipline.'},
             {t:'Discipline has absolutely nothing to do with this situation.'} ] },
    { id:'t41', thought:'I have to prove I\'m capable, or it doesn\'t count.',
      opts:[ {t:'Progress keeps its value even without needing to be proven to anyone, myself included.', bal:true},
             {t:'It\'s true, if I don\'t clearly prove it, it counts for nothing.'},
             {t:'Proving anything has never mattered at all.'} ] },
    { id:'t42', thought:'It\'s getting easier for everyone except me.',
      opts:[ {t:'I almost never see the real difficulty of other people\'s path — only what they choose to show.', bal:true},
             {t:'It\'s true, everyone is moving forward except me, stuck where I am.'},
             {t:'It gets easy for everyone at exactly the same pace, no difference at all.'} ] },
    { id:'t43', thought:'I shouldn\'t even need this app.',
      opts:[ {t:'Using a tool that helps isn\'t an admission of failure — it\'s one way among others to take care of yourself.', bal:true},
             {t:'It\'s true, needing this proves I\'m weaker than everyone else.'},
             {t:'This app has never been any use, might as well forget it.'} ] },
    { id:'t44', thought:'A good day means nothing if tomorrow is bad.',
      opts:[ {t:'A good day counts for what it is, independent of what tomorrow will be.', bal:true},
             {t:'It\'s true, no point being glad about a good day since it won\'t last.'},
             {t:'Days never have any value in themselves, good or bad.'} ] },
    { id:'t45', thought:'I\'m tired of fighting against myself.',
      opts:[ {t:'This tiredness is real and legitimate — it deserves rest, not to be ignored or used as a reason to stop trying.', bal:true},
             {t:'It\'s true, might as well give up since I\'m exhausted anyway.'},
             {t:'Actually I\'m not tired at all, no issue.'} ] },
    { id:'t46', thought:'It\'s probably just a matter of time before I slip.',
      opts:[ {t:'The future isn\'t written in advance — every moment held is evidence against this thought, not just a delay.', bal:true},
             {t:'It\'s true, it\'s inevitable, it\'s just a matter of time.'},
             {t:'There\'s absolutely no risk, ever, at any point.'} ] },
    { id:'t47', thought:'I can\'t trust my own judgment right now.',
      opts:[ {t:'This moment\'s discomfort doesn\'t invalidate all my judgment — I can still lean on what I know to be true.', bal:true},
             {t:'It\'s true, better not trust anything I think right now.'},
             {t:'My judgment is 100% perfectly reliable, no doubt possible.'} ] },
    { id:'t48', thought:'If this was going to work, it would already be easier.',
      opts:[ {t:'The difficulty of a moment doesn\'t predict the outcome of the whole path — many things that end up working stay hard for a long time.', bal:true},
             {t:'It\'s true, if it was meant to work for me, it would already show.'},
             {t:'Ease has never had anything to do with whether something succeeds.'} ] }
  ];
  function BANK(){ return lang()==='en' ? BANK_EN : BANK_FR; }

  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var x=a[i];a[i]=a[j];a[j]=x;} return a; }

  var ROUNDS=8, round=0, balancedCount=0, t0=0, order=[], body;

  /* Mémoire glissante des pensées déjà tirées (par id), pour éviter de retomber tout de suite
     sur les mêmes huit sur plusieurs parties — bornée à la taille totale de la banque, jamais
     davantage : dès qu'une pensée ressort du sac, elle redevient éligible plus tard. */
  function loadSeen(){ try{ var d=(window.MDData&&MDData.read&&MDData.read())||{}; return Array.isArray(d.recadrageSeen)?d.recadrageSeen:[]; }catch(e){ return []; } }
  function saveSeen(ids){ try{ if(window.MDData&&MDData.write){ var d=MDData.read()||{}; d.recadrageSeen=ids; MDData.write(d); } }catch(e){} }

  function render(){
    var q = order[round];
    var opts = shuffle(q.opts.map(function(o,i){ return {t:o.t, bal:!!o.bal}; }));
    var html = '<p class="game-step">'+t('round_x_of_y', round+1, ROUNDS)+'</p>'+
      '<div class="rc-thought" id="rc-thought"></div>'+
      '<div class="rc-opts" id="rc-opts"></div>'+
      '<div class="rc-fb" id="rc-fb"></div>'+
      '<div class="game-bar"><span id="rc-fill"></span></div>';
    body.innerHTML = html;
    document.getElementById('rc-thought').textContent = q.thought;
    document.getElementById('rc-fill').style.width = Math.round(round/ROUNDS*100)+'%';
    var wrap = document.getElementById('rc-opts');
    opts.forEach(function(o){
      var b = document.createElement('button');
      b.className='rc-opt'; b.type='button'; b.textContent=o.t;
      b.addEventListener('click', function(){ pick(o, opts, wrap); });
      wrap.appendChild(b);
    });
  }

  function pick(chosen, opts, wrap){
    Array.prototype.forEach.call(wrap.children, function(btn, i){
      btn.setAttribute('disabled','');
      if (opts[i].t === chosen.t) btn.classList.add('picked');
    });
    if (chosen.bal) balancedCount++;
    var fb = document.getElementById('rc-fb');
    fb.className = 'rc-fb show';
    if (chosen.bal) {
      fb.textContent = t('balanced_pick');
    } else {
      var balancedOpt = opts.filter(function(o){ return o.bal; })[0];
      fb.textContent = t('other_pick') + ' ' + (balancedOpt ? balancedOpt.t : '');
    }
    var nextBtn = document.createElement('button');
    nextBtn.type='button'; nextBtn.className='btn btn-primary rc-next'; nextBtn.style.marginTop='6px';
    nextBtn.textContent = t('next');
    nextBtn.addEventListener('click', function(){ round++; if (round>=ROUNDS) finish(); else render(); });
    document.getElementById('rc-body').appendChild(nextBtn);
  }

  function finish(){
    var idx = Math.round(balancedCount/ROUNDS*100);
    if (window.MDExercise){
      MDExercise.after('recadrage', { avant: window.__mdAvant, perf: balancedCount/ROUNDS, dureeSec: Math.round((Date.now()-t0)/1000),
        meta: { balanced: balancedCount, rounds: ROUNDS, indice: idx },
        title: t('title'),
        stats: [ {label:t('stat_balanced'), value: balancedCount+'/'+ROUNDS}, {label:t('stat_rounds'), value: ROUNDS} ],
        nav: { primary:{label:t('replay')}, secondary:{label:t('back_labo')} },
        onClose: function(){ window.__mdAvant=null; begin(); } });
    } else if (window.MDData && MDData.logSession){
      MDData.logSession('recadrage', { dureeSec: Math.round((Date.now()-t0)/1000), meta:{ balanced: balancedCount, rounds: ROUNDS, indice: idx } });
    }
  }

  function begin(){
    round=0; balancedCount=0; t0=Date.now();
    var bank = BANK();
    var seen = loadSeen();
    var unseen = bank.filter(function(q){ return seen.indexOf(q.id) < 0; });
    var pool = unseen.length >= ROUNDS ? unseen : bank; // presque tout vu récemment -> retire depuis toute la banque
    order = shuffle(pool).slice(0, ROUNDS);
    var newSeen = seen.concat(order.map(function(q){ return q.id; }));
    if (newSeen.length > bank.length) newSeen = newSeen.slice(newSeen.length - bank.length);
    saveSeen(newSeen);
    body = document.getElementById('rc-body');
    if (window.MDJeuHero){
      MDJeuHero.rules({ mood:'reflexion', title:t('title'),
        lines:[t('rules_l1'), t('rules_l2'), t('rules_l3')],
        why:t('rules_why'),
        onStart:function(avant){ window.__mdAvant=avant; render(); } });
    } else { render(); }
  }
  try{ MDCore.init({page:'recadrage',section:'equilibre'}); }catch(e){}
  begin();
})();
