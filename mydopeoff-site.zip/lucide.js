/* MyDope Off — socle commun (nav, profil, logo, i18n) */
window.LUCIDE = (function () {

  const KEY = 'ctc_v6';
  const LANG_KEY = 'mydopeoff_lang';
  const LANGS = ['fr', 'en'];
  const LANG_NAMES = { fr: 'Français', en: 'English' };

  /* ============================================================
     I18N — dictionnaire du "cadre" (UI partagée).
     Pour traduire le contenu (fiches) plus tard : remplir
     window.LUCIDE_FICHES_I18N (voir docs en bas) — aucune
     modification d'architecture nécessaire.
     ============================================================ */
  const DICT = {
    // Navigation
    'nav.home':        { fr: 'Accueil',      en: 'Home' },
    'nav.tracking':    { fr: 'Progression', en: 'Progress' },
    'nav.substances':  { fr: 'Substances',   en: 'Substances' },
    'nav.protocols':   { fr: 'Équilibre',   en: 'Balance' },
    'nav.rdr':         { fr: 'Sécurité',    en: 'Safety' },
    // Commun
    'common.back':     { fr: 'Accueil',      en: 'Home' },
    'common.back_prev':{ fr: 'Retour',       en: 'Back' },
    'common.close':    { fr: 'Fermer',       en: 'Close' },
    'common.save':     { fr: 'Enregistrer',  en: 'Save' },
    'common.cancel':   { fr: 'Annuler',      en: 'Cancel' },
    'common.add':      { fr: 'Ajouter',      en: 'Add' },
    'common.delete':   { fr: 'Supprimer',    en: 'Delete' },
    'common.search':   { fr: 'Rechercher…',  en: 'Search…' },
    'common.language': { fr: 'Langue',       en: 'Language' },
    // Accueil
    'home.intro':      { fr: "Ici, tu n'es pas un dossier : tu gardes les commandes. MyDope Off t'aide à comprendre les substances, mesurer ta consommation et couper la boucle quand tu le décides — sans jugement, sans compte, tout reste sur ton appareil.",
                         en: "Here you're not a case file — you stay in control. MyDope Off helps you understand substances, track your use and break the loop when you decide — no judgement, no account, everything stays on your device." },
    'home.spaces':     { fr: 'Les 5 espaces', en: 'The 5 spaces' },
    'home.welcome':    { fr: 'Bienvenue',    en: 'Welcome' },
    'home.welcome_sub':{ fr: 'Commence par tenir ton journal dans Suivi conso.',
                         en: 'Start by keeping your journal in Tracking.' },
    'home.tile_track': { fr: 'Journal, coûts, détection, objectifs',
                         en: 'Journal, costs, detection, goals' },
    'home.tile_subs':  { fr: '270 fiches, interactions, risques',
                         en: '270 substances, interactions, risks' },
    'home.tile_proto': { fr: 'Exercices et jeux anti-craving',
                         en: 'Anti-craving exercises and games' },
    'home.tile_rdr':   { fr: 'Urgences, centres, conseils',
                         en: 'Emergencies, centres, advice' },
    'home.edit_info':  { fr: 'Modifier mes infos', en: 'Edit my info' },
    'home.support':    { fr: 'Soutenir le projet', en: 'Support the project' },
    'home.guide_link': { fr: 'Guide d\'utilisation', en: 'User guide' },
    'home.hello': { fr: 'Salut', en: 'Hi' },
    'home.settings_help': { fr: 'Réglages et aide', en: 'Settings & help' },
    'home.guide_sub': { fr: 'Comment se servir de MyDope Off', en: 'How to use MyDope Off' },
    'home.edit_sub': { fr: 'Prénom, âge, région', en: 'First name, age, region' },
    'home.bilan': { fr: 'Bilan', en: 'Assessment' },
    'home.bilan_sub': { fr: 'Questionnaires d\'auto-évaluation (craving, AUDIT-C…)', en: 'Self-assessment questionnaires (craving, AUDIT-C…)' },
    'home.support_sec': { fr: 'Soutenir', en: 'Support' },
    'home.support_title': { fr: 'Soutenir le projet', en: 'Support the project' },
    'home.support_sub': { fr: 'MyDope Off est gratuit et le restera', en: 'MyDope Off is free and always will be' },
    'home.disclaimer_strong': { fr: 'MyDope Off', en: 'MyDope Off' },
    'home.disclaimer': { fr: '— outil de monitoring et de réduction des risques. Information scientifique · ne remplace pas un avis médical.', en: '— a monitoring and harm-reduction tool. Scientific information · not a substitute for medical advice.' },
    'sout.back': { fr: '← Retour', en: '← Back' },
    'sout.topbar': { fr: 'Soutenir MyDope Off', en: 'Support MyDope Off' },
    'sout.hero_title': { fr: 'MyDope Off reste <span class="accent">gratuit</span><br>grâce à toi.', en: 'MyDope Off stays <span class="accent">free</span><br>thanks to you.' },
    'sout.hero_sub': { fr: 'Aucune pub. Aucune donnée vendue. Aucune inscription. Juste un outil de réduction des risques, construit avec soin.', en: 'No ads. No data sold. No sign-up. Just a harm-reduction tool, built with care.' },
    'sout.impact1': { fr: 'substances documentées', en: 'documented substances' },
    'sout.impact2': { fr: 'interactions vérifiées', en: 'verified interactions' },
    'sout.impact3': { fr: 'exercices neuroscience', en: 'neuroscience exercises' },
    'sout.impact4': { fr: 'gratuit & open source', en: 'free & open source' },
    'sout.fin_label': { fr: 'Soutenir financièrement', en: 'Support financially' },
    'sout.kofi_desc': { fr: '100% des dons financent le développement, l\'API IA, et l\'hébergement. Aucune commission. Aucun frais de gestion. Reçu disponible sur Ko-fi.', en: '100% of donations fund development, the AI API and hosting. No commission. No management fees. Receipt available on Ko-fi.' },
    'sout.kofi_note': { fr: 'Paiement sécurisé via Ko-fi · Carte bancaire, PayPal ou Stripe', en: 'Secure payment via Ko-fi · Card, PayPal or Stripe' },
    'sout.kofi_badge': { fr: 'Mensuel disponible sur Ko-fi', en: 'Monthly available on Ko-fi' },
    'sout.amt_coffee': { fr: 'Un café', en: 'A coffee' },
    'sout.amt_server': { fr: 'Serveur', en: 'Server' },
    'sout.amt_api': { fr: 'API IA', en: 'AI API' },
    'sout.amt_module': { fr: 'Module', en: 'Module' },
    'sout.amt_sprint': { fr: 'Dev sprint', en: 'Dev sprint' },
    'sout.amt_free': { fr: 'Je choisis', en: 'My choice' },
    'sout.amt_free_label': { fr: 'Libre', en: 'Custom' },
    'sout.kofi_btn': { fr: 'Soutenir · 5€ sur Ko-fi', en: 'Support · €5 on Ko-fi' },
    'sout.feat_label': { fr: 'Ce que contient MyDope Off', en: 'What\'s inside MyDope Off' },
    'sout.feat1': { fr: 'Oxford 2015 — 3 min réduisent le craving de 24%', en: 'Oxford 2015 — 3 min cut craving by 24%' },
    'sout.feat2': { fr: 'Gyroscope · 12 niveaux · Cervelet & Pariétal', en: 'Gyroscope · 12 levels · Cerebellum & Parietal' },
    'sout.feat3': { fr: '270 substances · 165+ interactions documentées', en: '270 substances · 165+ documented interactions' },
    'sout.feat4': { fr: 'Protocoles validés — craving, plasticité, quotidien', en: 'Validated protocols — craving, plasticity, daily' },
    'sout.feat5': { fr: 'BE · FR · CH · CA · LU — numéros cliquables', en: 'BE · FR · CH · CA · LU — tappable numbers' },
    'sout.feat6': { fr: 'Streak · Coûts · Test salivaire scientifique', en: 'Streak · Costs · Scientific saliva test' },
    'sout.feat7': { fr: '6 évaluations validées · Radar Canvas', en: '6 validated assessments · Radar canvas' },
    'sout.feat_n1': { fr: 'Tetris Anti-Craving', en: 'Anti-craving Tetris' },
    'sout.feat_n2': { fr: 'Gyro Labyrinthe', en: 'Gyro maze' },
    'sout.feat_n3': { fr: 'PSYCHOchecker', en: 'PSYCHOchecker' },
    'sout.feat_n4': { fr: '20 Exercices Neuroscience', en: '20 neuroscience exercises' },
    'sout.feat_n5': { fr: 'RDR & Urgences', en: 'Harm reduction & emergencies' },
    'sout.feat_n6': { fr: 'Journal de Suivi', en: 'Tracking journal' },
    'sout.feat_n7': { fr: 'Profil Neurologique', en: 'Neurological profile' },
    'sout.road_label': { fr: 'Roadmap', en: 'Roadmap' },
    'sout.road_done': { fr: '✓', en: '✓' },
    'sout.road_wip': { fr: 'En cours', en: 'In progress' },
    'sout.road_planned': { fr: 'Planifié', en: 'Planned' },
    'sout.road1': { fr: 'Base de données + interactions', en: 'Database + interactions' },
    'sout.road2': { fr: 'Addictologue · Psychologue · Assistant social', en: 'Addiction specialist · Psychologist · Social worker' },
    'sout.road3': { fr: 'Suivi · DAST-10 · Radar neuro', en: 'Tracking · DAST-10 · Neuro radar' },
    'sout.road4': { fr: 'Bottom nav · Design system cohérent', en: 'Bottom nav · Consistent design system' },
    'sout.road5': { fr: 'iOS + Android · Push notifications craving', en: 'iOS + Android · Craving push notifications' },
    'sout.road6': { fr: 'IA fonctionnelle sans config technique', en: 'Working AI with no technical setup' },
    'sout.road7': { fr: 'Prise de RDV directe avec addictologues', en: 'Direct appointments with addiction specialists' },
    'sout.road8': { fr: 'Couverture internationale', en: 'International coverage' },
    'sout.road_n1': { fr: 'PSYCHOchecker 172 substances', en: 'PSYCHOchecker 172 substances' },
    'sout.road_n2': { fr: 'Agent IA Dr. Alex', en: 'AI agent Dr. Alex' },
    'sout.road_n3': { fr: 'Journal + Profil neurologique', en: 'Journal + neurological profile' },
    'sout.road_n4': { fr: 'Redesign MyDope Off + Nav globale', en: 'MyDope Off redesign + global nav' },
    'sout.road_n5': { fr: 'App mobile native', en: 'Native mobile app' },
    'sout.road_n6': { fr: 'Dr. Alex hébergé', en: 'Hosted Dr. Alex' },
    'sout.road_n7': { fr: 'Annuaire centres RDR étendu', en: 'Extended harm-reduction directory' },
    'sout.road_n8': { fr: 'Traductions EN · NL · DE', en: 'EN · NL · DE translations' },
    'sout.alt_label': { fr: 'Autres façons d\'aider', en: 'Other ways to help' },
    'sout.alt1': { fr: 'Star sur GitHub', en: 'Star on GitHub' },
    'sout.alt1_d': { fr: 'Aide la visibilité du projet — gratuit', en: 'Boost the project visibility — free' },
    'sout.alt2': { fr: 'Partager l\'application', en: 'Share the app' },
    'sout.alt2_d': { fr: 'Envoie le lien à quelqu\'un qui en a besoin', en: 'Send the link to someone who needs it' },
    'sout.alt3': { fr: 'Donner ton avis', en: 'Give feedback' },
    'sout.alt3_d': { fr: 'Bugs · idées · témoignages', en: 'Bugs · ideas · testimonials' },
    'sout.alt4': { fr: 'Contribuer au code', en: 'Contribute to the code' },
    'sout.alt4_d': { fr: 'Pull requests bienvenues sur GitHub', en: 'Pull requests welcome on GitHub' },
    'sout.legal_strong': { fr: 'Transparence', en: 'Transparency' },
    'sout.legal': { fr: '— MyDope Off est un projet indépendant à but non lucratif. Les informations médicales sont fournies à titre éducatif uniquement. Les dons sont traités par Ko-fi. Aucune donnée personnelle n\'est transmise à des tiers.', en: '— MyDope Off is an independent non-profit project. Medical information is provided for educational purposes only. Donations are processed by Ko-fi. No personal data is shared with third parties.' },
    'sout.ty_title': { fr: 'Merci du fond du cœur !', en: 'Thank you from the bottom of our heart!' },
    'sout.ty_sub': { fr: 'Ton soutien permet à MyDope Off de continuer à exister gratuitement. Tu fais partie de la solution.', en: 'Your support keeps MyDope Off free. You are part of the solution.' },
    // Suivi
    'track.title':     { fr: 'Suivi conso',  en: 'Tracking' },
    'track.tab_board': { fr: 'Tableau',      en: 'Board' },
    'track.tab_journal':{ fr: 'Journal',     en: 'Journal' },
    'track.tab_costs': { fr: 'Coûts',        en: 'Costs' },
    'track.tab_goals': { fr: 'Objectifs',    en: 'Goals' },
    // RDR / interactions génériques
    'inter.title':     { fr: "Vérificateur d'interactions", en: 'Interaction checker' },
    'inter.analyze':   { fr: 'Analyser les interactions', en: 'Check interactions' },
    // Inscription (1er lancement)
    'reg.sub':         { fr: "Ici, tu gardes les commandes. Comprendre, mesurer, couper la boucle — tes données restent sur ton appareil.",
                         en: "Here, you stay in control. Understand, track, break the loop — your data stays on your device." },
    'reg.name':        { fr: 'Prénom ou pseudo', en: 'First name or nickname' },
    'reg.name_ph':     { fr: 'Ton prénom', en: 'Your name' },
    'reg.age':         { fr: 'Âge', en: 'Age' },
    'reg.region':      { fr: 'Région', en: 'Region' },
    'reg.enter':       { fr: 'Entrer', en: 'Enter' },
    'reg.back_home':   { fr: "← Revenir à l'accueil", en: '← Back to home' },
    'reg.note':        { fr: 'Aucun compte · aucune inscription en ligne · 100 % local',
                         en: 'No account · no online sign-up · 100% local' },
    'reg.choose_lang': { fr: 'Choisis ta langue', en: 'Choose your language' },
    // Consentement
    'consent.title':   { fr: 'Avant de commencer', en: 'Before you start' },
    'consent.p1':      { fr: "MyDope Off est un outil de <b>réduction des risques</b> à visée éducative. Il ne remplace ni un avis médical, ni un traitement, ni un service d'urgence.",
                         en: "MyDope Off is an educational <b>harm-reduction</b> tool. It does not replace medical advice, treatment, or emergency services." },
    'consent.p2':      { fr: "Les informations sur les substances, interactions et durées de détection sont des <b>estimations</b> qui varient selon chaque personne. En cas d'urgence, appelle le 112.",
                         en: "Information on substances, interactions and detection times are <b>estimates</b> that vary from person to person. In an emergency, call 112." },
    'consent.p3':      { fr: "Tes données restent uniquement sur cet appareil. Si tu vides le cache, elles disparaissent.",
                         en: "Your data stays only on this device. If you clear the cache, it's gone." },
    'consent.ok':      { fr: "J'ai compris", en: 'I understand' },
    // Suivi conso — détail
    'tr.day':          { fr: 'Journée', en: 'Day' },
    'tr.edit_entry':   { fr: "Modifier l'entrée", en: 'Edit entry' },
    'tr.date':         { fr: 'Date', en: 'Date' },
    'tr.substance':    { fr: 'Substance', en: 'Substance' },
    'tr.substance_search': { fr: 'Substance (recherche dans les fiches)', en: 'Substance (search the database)' },
    'tr.intensity':    { fr: 'Intensité', en: 'Intensity' },
    'tr.note':         { fr: 'Note', en: 'Note' },
    'tr.note_ph':      { fr: 'Contexte, ressenti…', en: 'Context, feelings…' },
    'tr.cost':         { fr: 'Coût (€)', en: 'Cost (€)' },
    'tr.sober':        { fr: 'Sobre', en: 'Sober' },
    'tr.light':        { fr: 'Léger', en: 'Light' },
    'tr.moderate':     { fr: 'Modéré', en: 'Moderate' },
    'tr.intense':      { fr: 'Intensif', en: 'Intense' },
    'tr.add_entry':    { fr: 'Ajouter une entrée', en: 'Add entry' },
    'tr.add_to_day':   { fr: 'Ajouter à ce jour', en: 'Add to this day' },
    'tr.add_entry_btn':{ fr: "Ajouter l'entrée", en: 'Add the entry' },
    'tr.day_sober':    { fr: 'Journée sobre', en: 'Sober day' },
    'tr.sobers':       { fr: 'Sobres', en: 'Sober' },
    'tr.logged':       { fr: 'Journalisés', en: 'Logged' },
    'tr.intenses':     { fr: 'Intenses', en: 'Intense' },
    'tr.cal_hint':     { fr: "30 derniers jours · touche un jour pour l'éditer", en: 'Last 30 days · tap a day to edit' },
    'tr.new_goal':     { fr: 'Nouvel objectif', en: 'New goal' },
    'tr.create_goal':  { fr: "Créer l'objectif", en: 'Create goal' },
    'tr.goal_type':    { fr: "Type d'objectif", en: 'Goal type' },
    'tr.goal_reduce':  { fr: "Réduction d'une substance", en: 'Reduce a substance' },
    'tr.goal_streak':  { fr: 'Jours consécutifs sobres', en: 'Consecutive sober days' },
    'tr.goal_max_week':{ fr: 'Maximum de prises / semaine (toutes substances)', en: 'Max uses / week (all substances)' },
    'tr.goal_no_heavy':{ fr: 'Aucune séance intensive', en: 'No intense sessions' },
    'tr.per_day':      { fr: 'par jour', en: 'per day' },
    'tr.per_week':     { fr: 'par semaine', en: 'per week' },
    'tr.per_month':    { fr: 'par mois', en: 'per month' },
    'tr.per_sub':      { fr: 'Par substance · 30 jours', en: 'Per substance · 30 days' },
    'tr.lottery':      { fr: 'Ta cagnotte potentielle', en: 'Reverse lottery' },
    'tr.lottery_sub':  { fr: 'Ce que ça représente autrement. Pas pour culpabiliser — juste pour voir ce que tu pourrais récupérer.', en: "What it could be instead. Not to guilt-trip — just to see what you could get back." },
    'tr.proj_annual':  { fr: 'Projection annuelle', en: 'Annual projection' },
    'tr.cost_empty':   { fr: 'Renseigne un coût dans tes entrées pour voir les projections.', en: 'Add a cost to your entries to see projections.' },
    'tr.cost_note':    { fr: 'Seules les entrées avec un coût renseigné sont comptabilisées.', en: 'Only entries with a cost are counted.' },
    'tr.record':       { fr: 'Record', en: 'Record' },
    'tr.del_confirm':  { fr: 'Supprimer cette entrée ?', en: 'Delete this entry?' },
    'tr.max':          { fr: 'maximum', en: 'maximum' },
    'tr.empty':        { fr: 'Vide', en: 'Empty' },
    'tr.cons_8w':      { fr: 'Consommations · 8 semaines', en: 'Use · 8 weeks' },
    'tr.subs_30d':     { fr: 'Substances · 30 jours', en: 'Substances · 30 days' },
    'tr.mark_sober':   { fr: "Marquer aujourd'hui sobre", en: 'Mark today sober' },
    'tr.history':      { fr: 'Historique', en: 'History' },
    'tr.limit_set':    { fr: 'Limite que tu te fixes', en: 'Limit you set' },
    'tr.target_num':   { fr: 'Cible (nombre)', en: 'Target (number)' },
    'tr.sub_ph':       { fr: 'ex. Tabac, Alcool, Cannabis…', en: 'e.g. Tobacco, Alcohol, Cannabis…' },
    // Guide
    'gd.title':        { fr: 'Bien utiliser MyDope Off', en: 'Getting the most from MyDope Off' },
    'gd.intro':        { fr: "MyDope Off rassemble des informations scientifiques et des outils pour comprendre les substances et réduire les risques. Tout fonctionne hors-ligne et reste sur ton téléphone.",
                         en: "MyDope Off gathers scientific information and tools to understand substances and reduce risks. Everything works offline and stays on your phone." },
    'gd.spaces':       { fr: 'Les cinq espaces', en: 'The five spaces' },
    'gd.subs_desc':    { fr: "270 fiches détaillées et le vérificateur d'interactions. Cherche une substance pour voir risques, durée et précautions.",
                         en: "270 detailed entries and the interaction checker. Search a substance to see risks, duration and precautions." },
    'gd.ex_desc':      { fr: "Des tâches visuelles courtes (labyrinthe, etc.) qui aident à faire retomber une envie pressante en quelques minutes.",
                         en: "Short visual tasks (maze, etc.) that help a pressing urge subside within minutes." },
    'gd.track_desc':   { fr: "Ton journal, tes coûts, tes objectifs, et la durée de détection estimée par test.",
                         en: "Your journal, your costs, your goals, and the estimated detection time per test." },
    'gd.rdr_desc':     { fr: "Réduction des risques : numéros d'urgence, centres et bonnes pratiques.",
                         en: "Harm reduction: emergency numbers, centres and best practices." },
    'gd.journal_title':{ fr: 'Tenir ton journal en 3 gestes', en: 'Keep your journal in 3 steps' },
    'gd.j1_t':         { fr: 'Ajouter une entrée', en: 'Add an entry' },
    'gd.j1_d':         { fr: 'Suivi › Journal', en: 'Tracking › Journal' },
    'gd.j2_t':         { fr: 'Plusieurs entrées le même jour', en: 'Several entries the same day' },
    'gd.j2_d':         { fr: "Sur une journée déjà présente, touche « Ajouter à ce jour ». Tu peux empiler autant d'entrées que nécessaire sur la même date.",
                         en: "On a day already logged, tap \"Add to this day\". You can stack as many entries as needed on the same date." },
    'gd.j3_t':         { fr: 'Modifier ou supprimer', en: 'Edit or delete' },
    'gd.j3_d':         { fr: "Touche une entrée pour la rouvrir et la corriger, ou la croix pour la supprimer. Depuis le calendrier, touche un jour pour l'éditer directement.",
                         en: "Tap an entry to reopen and fix it, or the cross to delete it. From the calendar, tap a day to edit it directly." },
    'gd.detect_title': { fr: 'Comprendre la détection', en: 'Understanding detection' },
    'gd.detect_intro': { fr: "Quand tu choisis une substance, MyDope Off estime la fenêtre de détection selon trois types de test :",
                         en: "When you pick a substance, MyDope Off estimates the detection window for three test types:" },
    'gd.saliva':       { fr: 'Salive', en: 'Saliva' },
    'gd.saliva_d':     { fr: "Test oral rapide — fenêtre courte, reflète l'usage récent.", en: "Quick oral test — short window, reflects recent use." },
    'gd.urine':        { fr: 'Urine', en: 'Urine' },
    'gd.urine_d':      { fr: "Le plus répandu — fenêtre la plus longue, surtout en usage régulier.", en: "Most common — longest window, especially with regular use." },
    'gd.blood':        { fr: 'Sang', en: 'Blood' },
    'gd.blood_d':      { fr: "Fenêtre la plus courte — mais la plus précise sur le moment.", en: "Shortest window — but the most accurate in the moment." },
    'gd.ctrl_title':   { fr: 'Contrôles routiers', en: 'Roadside checks' },
    'gd.ctrl_desc':    { fr: "Une page dédiée explique comment se déroulent les contrôles alcool et stupéfiants au volant, les seuils légaux, et pourquoi la seule façon fiable de les passer est de ne pas conduire après avoir consommé.",
                         en: "A dedicated page explains how alcohol and drug roadside checks work, the legal limits, and why the only reliable way to pass them is not to drive after using." },
    'gd.ctrl_link_t':  { fr: 'Alcool, stupéfiants et conduite', en: 'Alcohol, drugs and driving' },
    'gd.ctrl_link_d':  { fr: "Déroulé, seuils, sanctions, comment vraiment l'éviter", en: "Process, limits, penalties, how to really avoid it" },
    'gd.lex_title':    { fr: 'Lexique réduction des risques', en: 'Harm-reduction glossary' },
    'gd.lex_intro':    { fr: "Les termes scientifiques et le jargon que tu croises dans l'app et autour du sujet, expliqués simplement. Touche un mot pour dérouler.",
                         en: "The scientific terms and jargon you meet in the app and around the topic, explained simply. Tap a word to expand." },
    'gd.lex_note':     { fr: "Ce lexique est pédagogique et simplifié. Il ne remplace pas un avis médical.", en: "This glossary is educational and simplified. It does not replace medical advice." },
    'gd.data_title':   { fr: 'Tes données', en: 'Your data' },
    'gd.support':      { fr: 'Soutenir le projet', en: 'Support the project' },
    'gd.lex_search':   { fr: 'Rechercher un terme…', en: 'Search a term…' },
    'gd.lex_empty':    { fr: 'Aucun terme ne correspond.', en: 'No matching term.' },
    // Page Substances (psychochecker) — interface
    'ps.subtag':       { fr: '270 substances', en: '270 substances' },
    'ps.checker_intro':{ fr: 'Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Enter 2 or 3 substances — every pair will be analysed.' },
    'ps.checker_title': { fr: 'Vérificateur d\'<span>interactions</span>', en: 'Interaction <span>checker</span>' },
    'ps.checker_warn': { fr: 'Outil préventif pour les personnes qui consomment déjà.', en: 'A prevention tool for people who already use.' },
    'ps.checker_warn2': { fr: 'N\'encourage aucun usage. Vise à réduire les dommages avec une information fiable. Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Encourages no use. Aims to reduce harm with reliable information. Enter 2 or 3 substances — all pairs will be analysed.' },
    'ps.recognized':   { fr: 'Noms reconnus : Valium, Xanax, Coke, MDMA, Éthanol…', en: 'Recognised names: Valium, Xanax, Coke, MDMA, Ethanol…' },
    'ps.sub1':         { fr: 'Substance 1', en: 'Substance 1' },
    'ps.sub2':         { fr: 'Substance 2', en: 'Substance 2' },
    'ps.sub3':         { fr: 'Substance 3 (optionnel)', en: 'Substance 3 (optional)' },
    'ps.analyze':      { fr: 'Analyser les interactions', en: 'Check interactions' },
    'ps.result_empty': { fr: 'Saisir au moins 2 substances pour voir les interactions documentées.', en: 'Enter at least 2 substances to see documented interactions.' },
    'ps.tab_classic':  { fr: 'Substances classiques', en: 'Classic substances' },
    'ps.tab_canna':    { fr: 'Cannabinoïdes', en: 'Cannabinoids' },
    'ps.search':       { fr: 'Rechercher…', en: 'Search…' },
    'ps.all_classes':  { fr: 'Toutes classes', en: 'All classes' },
    'ps.cl_stimulant': { fr: 'Stimulant', en: 'Stimulant' },
    'ps.cl_depressant':{ fr: 'Dépresseur', en: 'Depressant' },
    'ps.cl_opioid':    { fr: 'Opioïde', en: 'Opioid' },
    'ps.cl_psyche':    { fr: 'Psychédélique', en: 'Psychedelic' },
    'ps.cl_dissoc':    { fr: 'Dissociatif', en: 'Dissociative' },
    'ps.cl_enta':      { fr: 'Entactogène', en: 'Entactogen' },
    'ps.addiction':    { fr: 'Addiction', en: 'Addiction' },
    'ps.effects':      { fr: 'Effets', en: 'Effects' },
    'ps.dose':         { fr: 'Dosage', en: 'Dosage' },
    'ps.duration':     { fr: 'Durée', en: 'Duration' },
    'ps.dose_low':     { fr: 'Faible', en: 'Low' },
    'ps.dose_mod':     { fr: 'Modéré', en: 'Moderate' },
    'ps.dose_high':    { fr: 'Fort', en: 'Strong' },
    'ps.danger_label': { fr: 'Danger', en: 'Risk' },
    'ps.no_result':    { fr: 'Aucun résultat', en: 'No results' },
    'ps.count_subs':   { fr: '{n} substances', en: '{n} substances' },
    'ps.testimony':    { fr: 'Témoignage', en: 'Report' },
    'ps.info':         { fr: 'Info', en: 'Info' },
    'ps.none_found':   { fr: 'Aucune substance trouvée.', en: 'No substance found.' },
    'ps.footer':       { fr: 'Réduction des risques', en: 'Harm reduction' },
    // Jeux (maze + tetris)
    'gm.back':         { fr: 'Retour', en: 'Back' },
    'gm.maze_title':   { fr: 'Labyrinthe', en: 'Maze' },
    'gm.maze_intro':   { fr: "12 niveaux · Incline le téléphone pour déplacer la bille jusqu'à la cible.", en: "12 levels · Tilt your phone to roll the ball to the target." },
    'gm.ready_round':  { fr: 'Prêt pour la manche ?', en: 'Ready for the round?' },
    'gm.maze_ready_d': { fr: 'La bille apparaît en haut à gauche. La cible rouge est en bas à droite.', en: 'The ball starts top-left. The red target is bottom-right.' },
    'gm.gyro_wait':    { fr: 'Gyro en attente…', en: 'Gyro waiting…' },
    'gm.give_up':      { fr: 'Abandonner', en: 'Give up' },
    'gm.level':        { fr: 'Niveau', en: 'Level' },
    'gm.time':         { fr: 'Temps', en: 'Time' },
    'gm.penalties':    { fr: 'Pénalités', en: 'Penalties' },
    'gm.score':        { fr: 'Score', en: 'Score' },
    'gm.gyro_on':      { fr: 'Gyro actif', en: 'Gyro on' },
    'gm.hold_move':    { fr: 'Maintiens pour déplacer la bille', en: 'Hold to move the ball' },
    'gm.round':        { fr: 'Manche', en: 'Round' },
    'gm.next_level':   { fr: 'Niveau suivant →', en: 'Next level →' },
    'gm.restart':      { fr: 'Recommencer depuis le début', en: 'Restart from the beginning' },
    'gm.maze_done':    { fr: 'Labyrinthe complété !', en: 'Maze completed!' },
    'gm.maze_done_d':  { fr: 'Tu as activé cervelet, cortex pariétal et système vestibulaire.', en: 'You activated the cerebellum, parietal cortex and vestibular system.' },
    'gm.replay':       { fr: 'Rejouer', en: 'Play again' },
    'gm.home':         { fr: "Retour à l'accueil", en: 'Back to home' },
    'gm.maze_h1': { fr: 'Gyro<br><span>Labyrinthe</span>', en: 'Gyro<br><span>Maze</span>' },
    'gm.maze_rules': { fr: '• Incline le téléphone = la bille bouge<br> • Touche un mur = <strong style="color:var(--red);">+1 seconde de pénalité</strong><br> • Atteins la cible rouge le plus vite possible<br> • Score max : 5/5 par niveau', en: '• Tilt the phone = the ball moves<br> • Touch a wall = <strong style="color:var(--red);">+1 second penalty</strong><br> • Reach the red target as fast as possible<br> • Max score: 5/5 per level' },
    'gm.maze_sci': { fr: '— Coordonner l\'équilibre physique et la navigation spatiale active des circuits cognitifs distincts du circuit de la récompense. Idéal pour couper un craving.', en: '— Coordinating physical balance and spatial navigation activates cognitive circuits distinct from the reward circuit. Ideal to cut a craving.' },
    'gm.sci_label': { fr: 'Cervelet & Pariétal', en: 'Cerebellum & Parietal' },
    'gm.rule1': { fr: '• Incline le téléphone = la bille bouge', en: '• Tilt the phone = the ball moves' },
    'gm.rule2': { fr: '• Touche un mur =', en: '• Touch a wall =' },
    'gm.rule2b': { fr: '+1 seconde de pénalité', en: '+1 second penalty' },
    'gm.rule3': { fr: '• Atteins la cible rouge le plus vite possible', en: '• Reach the red target as fast as possible' },
    'gm.rule4': { fr: '• Score max : 5/5 par niveau', en: '• Max score: 5/5 per level' },
    'gm.perm_err': { fr: 'Permission gyroscope refusée. Utilise les flèches à la place.', en: 'Gyroscope permission denied. Use the arrows instead.' },
    'gm.enable_gyro': { fr: 'Activer le gyroscope', en: 'Enable the gyroscope' },
    'gm.use_arrows': { fr: 'Utiliser les flèches', en: 'Use the arrows' },
    'gm.start_round': { fr: 'Démarrer la manche', en: 'Start the round' },
    'gm.give_up_x': { fr: '✕ Abandonner', en: '✕ Give up' },
    'gm.start':        { fr: 'Commencer', en: 'Start' },
    'gm.ready':        { fr: 'Prêt ?', en: 'Ready?' },
    'gm.tetris_title': { fr: 'Tetris anti-craving', en: 'Anti-craving Tetris' },
    'gm.tetris_intro': { fr: "Complète des lignes pendant 3 minutes. Chaque palier de 10 lignes accélère la chute. L'objectif n'est pas le score : c'est d'occuper ton esprit.", en: "Clear lines for 3 minutes. Every 10 lines speeds up the fall. The goal isn't the score — it's to occupy your mind." },
    'gm.lines':        { fr: 'Lignes', en: 'Lines' },
    'gm.urge':         { fr: "Intensité de l'envie", en: 'Urge intensity' },
    'gm.tetris_ctrl':  { fr: 'Glisse sur la grille : ← → déplacer · tap = pivoter · ↓ chute rapide', en: 'Swipe on the grid: ← → move · tap = rotate · ↓ fast drop' }
  };

  function lang() {
    let l = null;
    try { l = localStorage.getItem(LANG_KEY); } catch (e) {}
    if (l && LANGS.indexOf(l) !== -1) return l;
    const nav = (navigator.language || 'fr').slice(0, 2).toLowerCase();
    return LANGS.indexOf(nav) !== -1 ? nav : 'fr';
  }

  function setLang(l) {
    if (LANGS.indexOf(l) === -1) return;
    try { localStorage.setItem(LANG_KEY, l); } catch (e) {}
    applyI18n(); if(window.MDTranslateDOM){try{window.MDTranslateDOM((typeof lang==='function'?lang():'fr')==='en');}catch(e){}}
    document.documentElement.setAttribute('lang', l);
    // notifier les pages qui ont du contenu dynamique à re-rendre
    document.dispatchEvent(new CustomEvent('langchange', { detail: { lang: l } }));
  }

  function t(keyOrObj, vars) {
    const l = lang();
    let s;
    if (keyOrObj && typeof keyOrObj === 'object') {
      // objet {fr,en,es,de} fourni directement
      s = keyOrObj[l] || keyOrObj.fr || '';
    } else {
      const entry = DICT[keyOrObj];
      s = entry ? (entry[l] || entry.fr) : keyOrObj;
    }
    if (vars) Object.keys(vars).forEach(k => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }

  /* Traduit tous les éléments porteurs d'attributs i18n */
  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      if (DICT[k]) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const k = el.getAttribute('data-i18n-html');
      if (DICT[k]) el.innerHTML = t(k);
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const k = el.getAttribute('data-i18n-ph');
      if (DICT[k]) el.setAttribute('placeholder', t(k));
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const k = el.getAttribute('data-i18n-aria');
      if (DICT[k]) el.setAttribute('aria-label', t(k));
    });
    // re-render nav (libellés traduits)
    const navEl = document.querySelector('.bottom-nav');
    if (navEl && navEl.getAttribute('data-page') !== null) {
      navEl.outerHTML = renderNav(navEl.getAttribute('data-page') || '');
    }
  }

  /* Sélecteur de langue : remplit tout [data-langselect] */
  function renderLangSelect() {
    document.querySelectorAll('[data-langselect]').forEach(host => {
      const cur = lang();
      host.innerHTML = '<div class="lang-select" style="display:inline-flex;gap:4px;background:var(--soft,#FBF8F1);padding:4px;border-radius:11px;">' +
        LANGS.map(l => '<button type="button" data-setlang="' + l + '" style="border:none;cursor:pointer;font-family:var(--disp,Inter,sans-serif);font-weight:700;font-size:12px;padding:6px 11px;border-radius:8px;background:' +
          (l === cur ? '#fff' : 'transparent') + ';color:' + (l === cur ? '#C7765C' : '#58635E') +
          (l === cur ? ';box-shadow:0 1px 3px rgba(31,43,37,.08)' : '') + ';">' + l.toUpperCase() + '</button>').join('') +
        '</div>';
      host.querySelectorAll('[data-setlang]').forEach(b => {
        b.addEventListener('click', () => { setLang(b.getAttribute('data-setlang')); renderLangSelect(); });
      });
    });
  }

  function user() {
    try { return (JSON.parse(localStorage.getItem(KEY)) || {}).user || null; }
    catch (e) { return null; }
  }

  function qs() {
    const u = user();
    if (!u || !u.name) return '';
    return '?name=' + encodeURIComponent(u.name) + '&region=' + (u.region || 'BE') + (u.age ? '&age=' + u.age : '');
  }

  function link(href) {
    const q = qs();
    if (!q) return href;
    const i = href.indexOf('#');
    return i === -1 ? href + q : href.slice(0, i) + q + href.slice(i);
  }

  function logoSVG(size, mono) {
    size = size || 32;
    const c1 = mono ? '#fff' : '#33463E', c2 = mono ? '#fff' : '#69889A', sun = mono ? '#fff' : '#C7765C';
    return '<svg viewBox="0 0 32 32" width="' + size + '" height="' + size + '" aria-label="MyDope Off">' +
      '<circle cx="23.5" cy="9" r="3.4" fill="' + sun + '"' + (mono ? ' opacity="0.9"' : '') + '/>' +
      '<path d="M1 26 L9 14 L14 21 L20 11 L31 26 Z" fill="' + c2 + '"' + (mono ? ' opacity="0.55"' : '') + '/>' +
      '<path d="M1 26 L11 17 L17 23 L23 16 L31 26 Z" fill="' + c1 + '"/></svg>';
  }

  function appIcon(size) {
    size = size || 56;
    return '<span style="display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;border-radius:' + Math.round(size * .28) + 'px;background:#F5F2EA;border:1px solid #E2DCD0;">' +
      logoSVG(Math.round(size * .56), true) + '</span>';
  }

  function wordmark() {
    return '<span style="font-family:var(--disp,Inter,sans-serif);font-weight:800;letter-spacing:-.02em;color:#1F2B25;white-space:nowrap;">MyDope <b style="color:#C7765C;font-weight:800;">Off</b></span>';
  }

  /* Navigation — libellés via clés i18n */
  const NAV = [
    { k: 'index', href: 'index.html', tkey: 'nav.home',
      icon: '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { k: 'suivi', href: 'suivi.html', tkey: 'nav.tracking',
      icon: '<path d="M22 7L13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>' },
    { k: 'psychochecker', href: 'psychochecker.html', tkey: 'nav.substances',
      icon: '<path d="M11 11m-8 0a8 8 0 1 0 16 0 8 8 0 1 0-16 0"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' },
    { k: 'fiches', href: 'fiches.html', tkey: 'nav.protocols',
      icon: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
    { k: 'rdr', href: 'rdr.html', tkey: 'nav.rdr',
      icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
  ];

  function renderNav(active) {
    return '<nav class="bottom-nav" data-page="' + (active || '') + '">' + NAV.map(n =>
      '<a class="bn-item' + (n.k === active ? ' active on' : '') + '" href="' + link(n.href) + '">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">' + n.icon + '</svg>' +
      '<span>' + t(n.tkey) + '</span></a>').join('') + '</nav>';
  }

  function init(opts) {
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());

    document.querySelectorAll('[data-logo]').forEach(el => {
      el.innerHTML = logoSVG(parseInt(el.getAttribute('data-logo')) || 32, el.hasAttribute('data-mono'));
    });
    document.querySelectorAll('[data-appicon]').forEach(el => {
      el.innerHTML = appIcon(parseInt(el.getAttribute('data-appicon')) || 56);
    });
    document.querySelectorAll('[data-wordmark]').forEach(el => { el.innerHTML = wordmark(); });

    const nav = document.querySelector('[data-nav]');
    if (nav) nav.outerHTML = renderNav(opts.page || '');

    document.querySelectorAll('[data-go]').forEach(a => {
      a.setAttribute('href', link(a.getAttribute('data-go')));
    });

    document.querySelectorAll('[data-back]').forEach(b => {
      b.addEventListener('click', () => {
        if (window.history.length > 1 && document.referrer && document.referrer.indexOf(location.origin) === 0) {
          window.history.back();
        } else {
          location.href = link('index.html');
        }
      });
    });

    applyI18n(); if(window.MDTranslateDOM){try{window.MDTranslateDOM((typeof lang==='function'?lang():'fr')==='en');}catch(e){}}
    renderLangSelect();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  return { user, qs, link, logoSVG, appIcon, wordmark, renderNav, init,
           t, lang, setLang, applyI18n, renderLangSelect, LANGS, LANG_NAMES, DICT };
})();
