/* MyDope Off — socle commun (nav, profil, logo, i18n) */
window.LUCIDE = (function () {

  const KEY = 'ctc_v6';
  const LANG_KEY = 'mydopeoff_lang';
  const LANGS = ['fr', 'en', 'es', 'de'];
  const LANG_NAMES = { fr: 'Français', en: 'English', es: 'Español', de: 'Deutsch' };

  /* ============================================================
     I18N — dictionnaire du "cadre" (UI partagée).
     Pour traduire le contenu (fiches) plus tard : remplir
     window.LUCIDE_FICHES_I18N (voir docs en bas) — aucune
     modification d'architecture nécessaire.
     ============================================================ */
  const DICT = {
    // Navigation
    'nav.home':        { fr: 'Accueil',      en: 'Home',        es: 'Inicio',       de: 'Start' },
    'nav.tracking':    { fr: 'Progression', en: 'Progress',    es: 'Progreso',     de: 'Verlauf' },
    'nav.substances':  { fr: 'Substances',   en: 'Substances',  es: 'Sustancias',   de: 'Substanzen' },
    'nav.protocols':   { fr: 'Équilibre',   en: 'Balance',     es: 'Equilibrio',   de: 'Balance' },
    'nav.rdr':         { fr: 'Sécurité',    en: 'Safety',      es: 'Seguridad',    de: 'Sicherheit' },
    // Commun
    'common.back':     { fr: 'Accueil',      en: 'Home',        es: 'Inicio',       de: 'Start' },
    'common.back_prev':{ fr: 'Retour',       en: 'Back',        es: 'Atrás',        de: 'Zurück' },
    'common.close':    { fr: 'Fermer',       en: 'Close',       es: 'Cerrar',       de: 'Schließen' },
    'common.save':     { fr: 'Enregistrer',  en: 'Save',        es: 'Guardar',      de: 'Speichern' },
    'common.cancel':   { fr: 'Annuler',      en: 'Cancel',      es: 'Cancelar',     de: 'Abbrechen' },
    'common.add':      { fr: 'Ajouter',      en: 'Add',         es: 'Añadir',       de: 'Hinzufügen' },
    'common.delete':   { fr: 'Supprimer',    en: 'Delete',      es: 'Eliminar',     de: 'Löschen' },
    'common.search':   { fr: 'Rechercher…',  en: 'Search…',     es: 'Buscar…',      de: 'Suchen…' },
    'common.language': { fr: 'Langue',       en: 'Language',    es: 'Idioma',       de: 'Sprache' },
    // Accueil
    'home.intro':      { fr: "Ici, tu n'es pas un dossier : tu gardes les commandes. MyDope Off t'aide à comprendre les substances, mesurer ta consommation et couper la boucle quand tu le décides — sans jugement, sans compte, tout reste sur ton appareil.",
                         en: "Here you're not a case file — you stay in control. MyDope Off helps you understand substances, track your use and break the loop when you decide — no judgement, no account, everything stays on your device.",
                         es: "Aquí no eres un expediente: tú tienes el control. MyDope Off te ayuda a entender las sustancias, medir tu consumo y romper el ciclo cuando tú decidas — sin juicios, sin cuenta, todo se queda en tu dispositivo.",
                         de: "Hier bist du keine Akte — du behältst die Kontrolle. MyDope Off hilft dir, Substanzen zu verstehen, deinen Konsum zu erfassen und den Kreislauf zu durchbrechen, wenn du willst — ohne Urteil, ohne Konto, alles bleibt auf deinem Gerät." },
    'home.spaces':     { fr: 'Les 5 espaces', en: 'The 5 spaces', es: 'Los 5 espacios', de: 'Die 5 Bereiche' },
    'home.welcome':    { fr: 'Bienvenue',    en: 'Welcome',     es: 'Bienvenido',   de: 'Willkommen' },
    'home.welcome_sub':{ fr: 'Commence par tenir ton journal dans Suivi conso.',
                         en: 'Start by keeping your journal in Tracking.',
                         es: 'Empieza llevando tu diario en Seguimiento.',
                         de: 'Beginne mit deinem Tagebuch im Tracking.' },
    'home.tile_track': { fr: 'Journal, coûts, détection, objectifs',
                         en: 'Journal, costs, detection, goals',
                         es: 'Diario, costes, detección, objetivos',
                         de: 'Tagebuch, Kosten, Nachweis, Ziele' },
    'home.tile_subs':  { fr: '270 fiches, interactions, risques',
                         en: '270 substances, interactions, risks',
                         es: '270 fichas, interacciones, riesgos',
                         de: '270 Substanzen, Wechselwirkungen, Risiken' },
    'home.tile_proto': { fr: 'Exercices et jeux anti-craving',
                         en: 'Anti-craving exercises and games',
                         es: 'Ejercicios y juegos anti-craving',
                         de: 'Anti-Craving-Übungen und -Spiele' },
    'home.tile_rdr':   { fr: 'Urgences, centres, conseils',
                         en: 'Emergencies, centres, advice',
                         es: 'Urgencias, centros, consejos',
                         de: 'Notfälle, Zentren, Ratschläge' },
    'home.edit_info':  { fr: 'Modifier mes infos', en: 'Edit my info', es: 'Editar mis datos', de: 'Meine Daten ändern' },
    'home.support':    { fr: 'Soutenir le projet', en: 'Support the project', es: 'Apoyar el proyecto', de: 'Projekt unterstützen' },
    'home.guide_link': { fr: 'Guide d\'utilisation', en: 'User guide', es: 'Guía de uso', de: 'Anleitung' },
    'home.hello': { fr: 'Salut', en: 'Hi', es: 'Hola', de: 'Hallo' },
    'home.settings_help': { fr: 'Réglages et aide', en: 'Settings & help', es: 'Ajustes y ayuda', de: 'Einstellungen & Hilfe' },
    'home.guide_sub': { fr: 'Comment se servir de MyDope Off', en: 'How to use MyDope Off', es: 'Cómo usar MyDope Off', de: 'So nutzt du MyDope Off' },
    'home.edit_sub': { fr: 'Prénom, âge, région', en: 'First name, age, region', es: 'Nombre, edad, región', de: 'Vorname, Alter, Region' },
    'home.bilan': { fr: 'Bilan', en: 'Assessment', es: 'Evaluación', de: 'Bilanz' },
    'home.bilan_sub': { fr: 'Questionnaires d\'auto-évaluation (craving, AUDIT-C…)', en: 'Self-assessment questionnaires (craving, AUDIT-C…)', es: 'Cuestionarios de autoevaluación (craving, AUDIT-C…)', de: 'Selbsttest-Fragebögen (Craving, AUDIT-C…)' },
    'home.support_sec': { fr: 'Soutenir', en: 'Support', es: 'Apoyar', de: 'Unterstützen' },
    'home.support_title': { fr: 'Soutenir le projet', en: 'Support the project', es: 'Apoyar el proyecto', de: 'Das Projekt unterstützen' },
    'home.support_sub': { fr: 'MyDope Off est gratuit et le restera', en: 'MyDope Off is free and always will be', es: 'MyDope Off es gratis y siempre lo será', de: 'MyDope Off ist und bleibt kostenlos' },
    'home.disclaimer_strong': { fr: 'MyDope Off', en: 'MyDope Off', es: 'MyDope Off', de: 'MyDope Off' },
    'home.disclaimer': { fr: '— outil de monitoring et de réduction des risques. Information scientifique · ne remplace pas un avis médical.', en: '— a monitoring and harm-reduction tool. Scientific information · not a substitute for medical advice.', es: '— herramienta de monitoreo y reducción de riesgos. Información científica · no sustituye el consejo médico.', de: '— ein Monitoring- und Risikominderungs-Tool. Wissenschaftliche Information · ersetzt keine ärztliche Beratung.' },
    'sout.back': { fr: '← Retour', en: '← Back', es: '← Atrás', de: '← Zurück' },
    'sout.topbar': { fr: 'Soutenir MyDope Off', en: 'Support MyDope Off', es: 'Apoyar MyDope Off', de: 'MyDope Off unterstützen' },
    'sout.hero_title': { fr: 'MyDope Off reste <span class="accent">gratuit</span><br>grâce à toi.', en: 'MyDope Off stays <span class="accent">free</span><br>thanks to you.', es: 'MyDope Off sigue <span class="accent">gratis</span><br>gracias a ti.', de: 'MyDope Off bleibt <span class="accent">kostenlos</span><br>dank dir.' },
    'sout.hero_sub': { fr: 'Aucune pub. Aucune donnée vendue. Aucune inscription. Juste un outil de réduction des risques, construit avec soin.', en: 'No ads. No data sold. No sign-up. Just a harm-reduction tool, built with care.', es: 'Sin anuncios. Sin venta de datos. Sin registro. Solo una herramienta de reducción de riesgos, hecha con cuidado.', de: 'Keine Werbung. Kein Datenverkauf. Keine Anmeldung. Nur ein sorgfältig gebautes Risikominderungs-Tool.' },
    'sout.impact1': { fr: 'substances documentées', en: 'documented substances', es: 'sustancias documentadas', de: 'dokumentierte Substanzen' },
    'sout.impact2': { fr: 'interactions vérifiées', en: 'verified interactions', es: 'interacciones verificadas', de: 'geprüfte Wechselwirkungen' },
    'sout.impact3': { fr: 'exercices neuroscience', en: 'neuroscience exercises', es: 'ejercicios de neurociencia', de: 'Neurowissenschafts-Übungen' },
    'sout.impact4': { fr: 'gratuit & open source', en: 'free & open source', es: 'gratis y código abierto', de: 'kostenlos & Open Source' },
    'sout.fin_label': { fr: 'Soutenir financièrement', en: 'Support financially', es: 'Apoyar económicamente', de: 'Finanziell unterstützen' },
    'sout.kofi_desc': { fr: '100% des dons financent le développement, l\'API IA, et l\'hébergement. Aucune commission. Aucun frais de gestion. Reçu disponible sur Ko-fi.', en: '100% of donations fund development, the AI API and hosting. No commission. No management fees. Receipt available on Ko-fi.', es: 'El 100% de las donaciones financia el desarrollo, la API de IA y el alojamiento. Sin comisión. Sin gastos de gestión. Recibo disponible en Ko-fi.', de: '100% der Spenden finanzieren Entwicklung, KI-API und Hosting. Keine Provision. Keine Verwaltungsgebühren. Beleg auf Ko-fi verfügbar.' },
    'sout.kofi_note': { fr: 'Paiement sécurisé via Ko-fi · Carte bancaire, PayPal ou Stripe', en: 'Secure payment via Ko-fi · Card, PayPal or Stripe', es: 'Pago seguro vía Ko-fi · Tarjeta, PayPal o Stripe', de: 'Sichere Zahlung über Ko-fi · Karte, PayPal oder Stripe' },
    'sout.kofi_badge': { fr: 'Mensuel disponible sur Ko-fi', en: 'Monthly available on Ko-fi', es: 'Mensual disponible en Ko-fi', de: 'Monatlich auf Ko-fi verfügbar' },
    'sout.amt_coffee': { fr: 'Un café', en: 'A coffee', es: 'Un café', de: 'Ein Kaffee' },
    'sout.amt_server': { fr: 'Serveur', en: 'Server', es: 'Servidor', de: 'Server' },
    'sout.amt_api': { fr: 'API IA', en: 'AI API', es: 'API IA', de: 'KI-API' },
    'sout.amt_module': { fr: 'Module', en: 'Module', es: 'Módulo', de: 'Modul' },
    'sout.amt_sprint': { fr: 'Dev sprint', en: 'Dev sprint', es: 'Sprint dev', de: 'Dev-Sprint' },
    'sout.amt_free': { fr: 'Je choisis', en: 'My choice', es: 'Yo elijo', de: 'Ich wähle' },
    'sout.amt_free_label': { fr: 'Libre', en: 'Custom', es: 'Libre', de: 'Frei' },
    'sout.kofi_btn': { fr: 'Soutenir · 5€ sur Ko-fi', en: 'Support · €5 on Ko-fi', es: 'Apoyar · 5€ en Ko-fi', de: 'Unterstützen · 5€ auf Ko-fi' },
    'sout.feat_label': { fr: 'Ce que contient MyDope Off', en: 'What\'s inside MyDope Off', es: 'Qué contiene MyDope Off', de: 'Was in MyDope Off steckt' },
    'sout.feat1': { fr: 'Oxford 2015 — 3 min réduisent le craving de 24%', en: 'Oxford 2015 — 3 min cut craving by 24%', es: 'Oxford 2015 — 3 min reducen el craving un 24%', de: 'Oxford 2015 — 3 Min senken das Verlangen um 24%' },
    'sout.feat2': { fr: 'Gyroscope · 12 niveaux · Cervelet & Pariétal', en: 'Gyroscope · 12 levels · Cerebellum & Parietal', es: 'Giroscopio · 12 niveles · Cerebelo y Parietal', de: 'Gyroskop · 12 Level · Kleinhirn & Parietal' },
    'sout.feat3': { fr: '270 substances · 165+ interactions documentées', en: '270 substances · 165+ documented interactions', es: '270 sustancias · 165+ interacciones documentadas', de: '270 Substanzen · 165+ dokumentierte Wechselwirkungen' },
    'sout.feat4': { fr: 'Protocoles validés — craving, plasticité, quotidien', en: 'Validated protocols — craving, plasticity, daily', es: 'Protocolos validados — craving, plasticidad, diario', de: 'Validierte Protokolle — Craving, Plastizität, Alltag' },
    'sout.feat5': { fr: 'BE · FR · CH · CA · LU — numéros cliquables', en: 'BE · FR · CH · CA · LU — tappable numbers', es: 'BE · FR · CH · CA · LU — números pulsables', de: 'BE · FR · CH · CA · LU — anklickbare Nummern' },
    'sout.feat6': { fr: 'Streak · Coûts · Test salivaire scientifique', en: 'Streak · Costs · Scientific saliva test', es: 'Racha · Costes · Test salival científico', de: 'Streak · Kosten · Wissenschaftlicher Speicheltest' },
    'sout.feat7': { fr: '6 évaluations validées · Radar Canvas', en: '6 validated assessments · Radar canvas', es: '6 evaluaciones validadas · Radar Canvas', de: '6 validierte Bewertungen · Radar-Canvas' },
    'sout.feat_n1': { fr: 'Tetris Anti-Craving', en: 'Anti-craving Tetris', es: 'Tetris anti-craving', de: 'Anti-Craving-Tetris' },
    'sout.feat_n2': { fr: 'Gyro Labyrinthe', en: 'Gyro maze', es: 'Laberinto giroscopio', de: 'Gyro-Labyrinth' },
    'sout.feat_n3': { fr: 'PSYCHOchecker', en: 'PSYCHOchecker', es: 'PSYCHOchecker', de: 'PSYCHOchecker' },
    'sout.feat_n4': { fr: '20 Exercices Neuroscience', en: '20 neuroscience exercises', es: '20 ejercicios de neurociencia', de: '20 Neurowissenschafts-Übungen' },
    'sout.feat_n5': { fr: 'RDR & Urgences', en: 'Harm reduction & emergencies', es: 'RdD y urgencias', de: 'Risikominderung & Notfälle' },
    'sout.feat_n6': { fr: 'Journal de Suivi', en: 'Tracking journal', es: 'Diario de seguimiento', de: 'Tracking-Tagebuch' },
    'sout.feat_n7': { fr: 'Profil Neurologique', en: 'Neurological profile', es: 'Perfil neurológico', de: 'Neurologisches Profil' },
    'sout.road_label': { fr: 'Roadmap', en: 'Roadmap', es: 'Hoja de ruta', de: 'Roadmap' },
    'sout.road_done': { fr: '✓', en: '✓', es: '✓', de: '✓' },
    'sout.road_wip': { fr: 'En cours', en: 'In progress', es: 'En curso', de: 'Läuft' },
    'sout.road_planned': { fr: 'Planifié', en: 'Planned', es: 'Planeado', de: 'Geplant' },
    'sout.road1': { fr: 'Base de données + interactions', en: 'Database + interactions', es: 'Base de datos + interacciones', de: 'Datenbank + Wechselwirkungen' },
    'sout.road2': { fr: 'Addictologue · Psychologue · Assistant social', en: 'Addiction specialist · Psychologist · Social worker', es: 'Adictólogo · Psicólogo · Trabajador social', de: 'Suchtmediziner · Psychologe · Sozialarbeiter' },
    'sout.road3': { fr: 'Suivi · DAST-10 · Radar neuro', en: 'Tracking · DAST-10 · Neuro radar', es: 'Seguimiento · DAST-10 · Radar neuro', de: 'Tracking · DAST-10 · Neuro-Radar' },
    'sout.road4': { fr: 'Bottom nav · Design system cohérent', en: 'Bottom nav · Consistent design system', es: 'Nav inferior · Sistema de diseño coherente', de: 'Bottom-Nav · Konsistentes Design-System' },
    'sout.road5': { fr: 'iOS + Android · Push notifications craving', en: 'iOS + Android · Craving push notifications', es: 'iOS + Android · Notificaciones push de craving', de: 'iOS + Android · Craving-Push-Benachrichtigungen' },
    'sout.road6': { fr: 'IA fonctionnelle sans config technique', en: 'Working AI with no technical setup', es: 'IA funcional sin configuración técnica', de: 'Funktionierende KI ohne technische Einrichtung' },
    'sout.road7': { fr: 'Prise de RDV directe avec addictologues', en: 'Direct appointments with addiction specialists', es: 'Citas directas con adictólogos', de: 'Direkte Termine mit Suchtmedizinern' },
    'sout.road8': { fr: 'Couverture internationale', en: 'International coverage', es: 'Cobertura internacional', de: 'Internationale Abdeckung' },
    'sout.road_n1': { fr: 'PSYCHOchecker 172 substances', en: 'PSYCHOchecker 172 substances', es: 'PSYCHOchecker 172 sustancias', de: 'PSYCHOchecker 172 Substanzen' },
    'sout.road_n2': { fr: 'Agent IA Dr. Alex', en: 'AI agent Dr. Alex', es: 'Agente IA Dr. Alex', de: 'KI-Agent Dr. Alex' },
    'sout.road_n3': { fr: 'Journal + Profil neurologique', en: 'Journal + neurological profile', es: 'Diario + perfil neurológico', de: 'Tagebuch + neurologisches Profil' },
    'sout.road_n4': { fr: 'Redesign MyDope Off + Nav globale', en: 'MyDope Off redesign + global nav', es: 'Rediseño MyDope Off + nav global', de: 'MyDope-Off-Redesign + globale Nav' },
    'sout.road_n5': { fr: 'App mobile native', en: 'Native mobile app', es: 'App móvil nativa', de: 'Native Mobile-App' },
    'sout.road_n6': { fr: 'Dr. Alex hébergé', en: 'Hosted Dr. Alex', es: 'Dr. Alex alojado', de: 'Gehosteter Dr. Alex' },
    'sout.road_n7': { fr: 'Annuaire centres RDR étendu', en: 'Extended harm-reduction directory', es: 'Directorio RdD ampliado', de: 'Erweitertes Risikominderungs-Verzeichnis' },
    'sout.road_n8': { fr: 'Traductions EN · NL · DE', en: 'EN · NL · DE translations', es: 'Traducciones EN · NL · DE', de: 'Übersetzungen EN · NL · DE' },
    'sout.alt_label': { fr: 'Autres façons d\'aider', en: 'Other ways to help', es: 'Otras formas de ayudar', de: 'Andere Wege zu helfen' },
    'sout.alt1': { fr: 'Star sur GitHub', en: 'Star on GitHub', es: 'Estrella en GitHub', de: 'Stern auf GitHub' },
    'sout.alt1_d': { fr: 'Aide la visibilité du projet — gratuit', en: 'Boost the project visibility — free', es: 'Ayuda a la visibilidad del proyecto — gratis', de: 'Hilft der Sichtbarkeit des Projekts — kostenlos' },
    'sout.alt2': { fr: 'Partager l\'application', en: 'Share the app', es: 'Compartir la app', de: 'Die App teilen' },
    'sout.alt2_d': { fr: 'Envoie le lien à quelqu\'un qui en a besoin', en: 'Send the link to someone who needs it', es: 'Envía el enlace a quien lo necesite', de: 'Sende den Link an jemanden, der ihn braucht' },
    'sout.alt3': { fr: 'Donner ton avis', en: 'Give feedback', es: 'Dar tu opinión', de: 'Feedback geben' },
    'sout.alt3_d': { fr: 'Bugs · idées · témoignages', en: 'Bugs · ideas · testimonials', es: 'Errores · ideas · testimonios', de: 'Bugs · Ideen · Erfahrungsberichte' },
    'sout.alt4': { fr: 'Contribuer au code', en: 'Contribute to the code', es: 'Contribuir al código', de: 'Zum Code beitragen' },
    'sout.alt4_d': { fr: 'Pull requests bienvenues sur GitHub', en: 'Pull requests welcome on GitHub', es: 'Pull requests bienvenidas en GitHub', de: 'Pull Requests auf GitHub willkommen' },
    'sout.legal_strong': { fr: 'Transparence', en: 'Transparency', es: 'Transparencia', de: 'Transparenz' },
    'sout.legal': { fr: '— MyDope Off est un projet indépendant à but non lucratif. Les informations médicales sont fournies à titre éducatif uniquement. Les dons sont traités par Ko-fi. Aucune donnée personnelle n\'est transmise à des tiers.', en: '— MyDope Off is an independent non-profit project. Medical information is provided for educational purposes only. Donations are processed by Ko-fi. No personal data is shared with third parties.', es: '— MyDope Off es un proyecto independiente sin ánimo de lucro. La información médica es solo educativa. Las donaciones las procesa Ko-fi. No se comparten datos personales con terceros.', de: '— MyDope Off ist ein unabhängiges, gemeinnütziges Projekt. Medizinische Informationen dienen nur Bildungszwecken. Spenden werden von Ko-fi abgewickelt. Keine personenbezogenen Daten an Dritte.' },
    'sout.ty_title': { fr: 'Merci du fond du cœur !', en: 'Thank you from the bottom of our heart!', es: '¡Gracias de todo corazón!', de: 'Danke von Herzen!' },
    'sout.ty_sub': { fr: 'Ton soutien permet à MyDope Off de continuer à exister gratuitement. Tu fais partie de la solution.', en: 'Your support keeps MyDope Off free. You are part of the solution.', es: 'Tu apoyo permite que MyDope Off siga siendo gratis. Eres parte de la solución.', de: 'Deine Unterstützung hält MyDope Off kostenlos. Du bist Teil der Lösung.' },
    // Suivi
    'track.title':     { fr: 'Suivi conso',  en: 'Tracking',    es: 'Seguimiento',  de: 'Tracking' },
    'track.tab_board': { fr: 'Tableau',      en: 'Board',       es: 'Tablero',      de: 'Übersicht' },
    'track.tab_journal':{ fr: 'Journal',     en: 'Journal',     es: 'Diario',       de: 'Tagebuch' },
    'track.tab_costs': { fr: 'Coûts',        en: 'Costs',       es: 'Costes',       de: 'Kosten' },
    'track.tab_goals': { fr: 'Objectifs',    en: 'Goals',       es: 'Objetivos',    de: 'Ziele' },
    // RDR / interactions génériques
    'inter.title':     { fr: "Vérificateur d'interactions", en: 'Interaction checker', es: 'Verificador de interacciones', de: 'Wechselwirkungs-Check' },
    'inter.analyze':   { fr: 'Analyser les interactions', en: 'Check interactions', es: 'Analizar interacciones', de: 'Wechselwirkungen prüfen' },
    // Inscription (1er lancement)
    'reg.sub':         { fr: "Ici, tu gardes les commandes. Comprendre, mesurer, couper la boucle — tes données restent sur ton appareil.",
                         en: "Here, you stay in control. Understand, track, break the loop — your data stays on your device.",
                         es: "Aquí tú tienes el control. Entender, medir, romper el ciclo — tus datos se quedan en tu dispositivo.",
                         de: "Hier behältst du die Kontrolle. Verstehen, erfassen, den Kreislauf durchbrechen — deine Daten bleiben auf deinem Gerät." },
    'reg.name':        { fr: 'Prénom ou pseudo', en: 'First name or nickname', es: 'Nombre o apodo', de: 'Vorname oder Spitzname' },
    'reg.name_ph':     { fr: 'Ton prénom', en: 'Your name', es: 'Tu nombre', de: 'Dein Name' },
    'reg.age':         { fr: 'Âge', en: 'Age', es: 'Edad', de: 'Alter' },
    'reg.region':      { fr: 'Région', en: 'Region', es: 'Región', de: 'Region' },
    'reg.enter':       { fr: 'Entrer', en: 'Enter', es: 'Entrar', de: 'Eintreten' },
    'reg.back_home':   { fr: "← Revenir à l'accueil", en: '← Back to home', es: '← Volver al inicio', de: '← Zurück zur Startseite' },
    'reg.note':        { fr: 'Aucun compte · aucune inscription en ligne · 100 % local',
                         en: 'No account · no online sign-up · 100% local',
                         es: 'Sin cuenta · sin registro en línea · 100 % local',
                         de: 'Kein Konto · keine Online-Anmeldung · 100 % lokal' },
    'reg.choose_lang': { fr: 'Choisis ta langue', en: 'Choose your language', es: 'Elige tu idioma', de: 'Wähle deine Sprache' },
    // Consentement
    'consent.title':   { fr: 'Avant de commencer', en: 'Before you start', es: 'Antes de empezar', de: 'Bevor du beginnst' },
    'consent.p1':      { fr: "MyDope Off est un outil de <b>réduction des risques</b> à visée éducative. Il ne remplace ni un avis médical, ni un traitement, ni un service d'urgence.",
                         en: "MyDope Off is an educational <b>harm-reduction</b> tool. It does not replace medical advice, treatment, or emergency services.",
                         es: "MyDope Off es una herramienta educativa de <b>reducción de riesgos</b>. No sustituye el consejo médico, un tratamiento ni los servicios de urgencia.",
                         de: "MyDope Off ist ein edukatives Werkzeug zur <b>Risikominderung</b>. Es ersetzt weder ärztlichen Rat noch Behandlung oder Notdienste." },
    'consent.p2':      { fr: "Les informations sur les substances, interactions et durées de détection sont des <b>estimations</b> qui varient selon chaque personne. En cas d'urgence, appelle le 112.",
                         en: "Information on substances, interactions and detection times are <b>estimates</b> that vary from person to person. In an emergency, call 112.",
                         es: "La información sobre sustancias, interacciones y tiempos de detección son <b>estimaciones</b> que varían según cada persona. En una emergencia, llama al 112.",
                         de: "Angaben zu Substanzen, Wechselwirkungen und Nachweiszeiten sind <b>Schätzungen</b>, die individuell variieren. Im Notfall wähle 112." },
    'consent.p3':      { fr: "Tes données restent uniquement sur cet appareil. Si tu vides le cache, elles disparaissent.",
                         en: "Your data stays only on this device. If you clear the cache, it's gone.",
                         es: "Tus datos se quedan solo en este dispositivo. Si borras la caché, desaparecen.",
                         de: "Deine Daten bleiben nur auf diesem Gerät. Wenn du den Cache leerst, sind sie weg." },
    'consent.ok':      { fr: "J'ai compris", en: 'I understand', es: 'Entendido', de: 'Verstanden' },
    // Suivi conso — détail
    'tr.day':          { fr: 'Journée', en: 'Day', es: 'Día', de: 'Tag' },
    'tr.edit_entry':   { fr: "Modifier l'entrée", en: 'Edit entry', es: 'Editar registro', de: 'Eintrag bearbeiten' },
    'tr.date':         { fr: 'Date', en: 'Date', es: 'Fecha', de: 'Datum' },
    'tr.substance':    { fr: 'Substance', en: 'Substance', es: 'Sustancia', de: 'Substanz' },
    'tr.substance_search': { fr: 'Substance (recherche dans les fiches)', en: 'Substance (search the database)', es: 'Sustancia (buscar en las fichas)', de: 'Substanz (in der Datenbank suchen)' },
    'tr.intensity':    { fr: 'Intensité', en: 'Intensity', es: 'Intensidad', de: 'Intensität' },
    'tr.note':         { fr: 'Note', en: 'Note', es: 'Nota', de: 'Notiz' },
    'tr.note_ph':      { fr: 'Contexte, ressenti…', en: 'Context, feelings…', es: 'Contexto, sensación…', de: 'Kontext, Gefühl…' },
    'tr.cost':         { fr: 'Coût (€)', en: 'Cost (€)', es: 'Coste (€)', de: 'Kosten (€)' },
    'tr.sober':        { fr: 'Sobre', en: 'Sober', es: 'Sobrio', de: 'Nüchtern' },
    'tr.light':        { fr: 'Léger', en: 'Light', es: 'Leve', de: 'Leicht' },
    'tr.moderate':     { fr: 'Modéré', en: 'Moderate', es: 'Moderado', de: 'Mäßig' },
    'tr.intense':      { fr: 'Intensif', en: 'Intense', es: 'Intenso', de: 'Intensiv' },
    'tr.add_entry':    { fr: 'Ajouter une entrée', en: 'Add entry', es: 'Añadir registro', de: 'Eintrag hinzufügen' },
    'tr.add_to_day':   { fr: 'Ajouter à ce jour', en: 'Add to this day', es: 'Añadir a este día', de: 'Zu diesem Tag' },
    'tr.add_entry_btn':{ fr: "Ajouter l'entrée", en: 'Add the entry', es: 'Añadir el registro', de: 'Eintrag speichern' },
    'tr.day_sober':    { fr: 'Journée sobre', en: 'Sober day', es: 'Día sobrio', de: 'Nüchterner Tag' },
    'tr.sobers':       { fr: 'Sobres', en: 'Sober', es: 'Sobrios', de: 'Nüchtern' },
    'tr.logged':       { fr: 'Journalisés', en: 'Logged', es: 'Registrados', de: 'Erfasst' },
    'tr.intenses':     { fr: 'Intenses', en: 'Intense', es: 'Intensos', de: 'Intensiv' },
    'tr.cal_hint':     { fr: "30 derniers jours · touche un jour pour l'éditer", en: 'Last 30 days · tap a day to edit', es: 'Últimos 30 días · toca un día para editar', de: 'Letzte 30 Tage · tippe einen Tag zum Bearbeiten' },
    'tr.new_goal':     { fr: 'Nouvel objectif', en: 'New goal', es: 'Nuevo objetivo', de: 'Neues Ziel' },
    'tr.create_goal':  { fr: "Créer l'objectif", en: 'Create goal', es: 'Crear objetivo', de: 'Ziel erstellen' },
    'tr.goal_type':    { fr: "Type d'objectif", en: 'Goal type', es: 'Tipo de objetivo', de: 'Zielart' },
    'tr.goal_reduce':  { fr: "Réduction d'une substance", en: 'Reduce a substance', es: 'Reducir una sustancia', de: 'Eine Substanz reduzieren' },
    'tr.goal_streak':  { fr: 'Jours consécutifs sobres', en: 'Consecutive sober days', es: 'Días sobrios seguidos', de: 'Aufeinanderfolgende nüchterne Tage' },
    'tr.goal_max_week':{ fr: 'Maximum de prises / semaine (toutes substances)', en: 'Max uses / week (all substances)', es: 'Máximo de tomas / semana (todas)', de: 'Max. Konsum / Woche (alle)' },
    'tr.goal_no_heavy':{ fr: 'Aucune séance intensive', en: 'No intense sessions', es: 'Sin sesiones intensas', de: 'Keine intensiven Sessions' },
    'tr.per_day':      { fr: 'par jour', en: 'per day', es: 'por día', de: 'pro Tag' },
    'tr.per_week':     { fr: 'par semaine', en: 'per week', es: 'por semana', de: 'pro Woche' },
    'tr.per_month':    { fr: 'par mois', en: 'per month', es: 'por mes', de: 'pro Monat' },
    'tr.per_sub':      { fr: 'Par substance · 30 jours', en: 'Per substance · 30 days', es: 'Por sustancia · 30 días', de: 'Pro Substanz · 30 Tage' },
    'tr.lottery':      { fr: 'Loterie inversée', en: 'Reverse lottery', es: 'Lotería invertida', de: 'Umgekehrte Lotterie' },
    'tr.lottery_sub':  { fr: 'Ce que ça représente autrement. Pas pour culpabiliser — juste pour voir ce que tu pourrais récupérer.', en: "What it could be instead. Not to guilt-trip — just to see what you could get back.", es: 'Lo que representa de otro modo. No para culpar — solo para ver lo que podrías recuperar.', de: 'Was es auch sein könnte. Kein Schuldgefühl — nur, um zu sehen, was du zurückbekommen könntest.' },
    'tr.proj_annual':  { fr: 'Projection annuelle', en: 'Annual projection', es: 'Proyección anual', de: 'Jahresprojektion' },
    'tr.cost_empty':   { fr: 'Renseigne un coût dans tes entrées pour voir les projections.', en: 'Add a cost to your entries to see projections.', es: 'Indica un coste en tus registros para ver proyecciones.', de: 'Gib Kosten in deinen Einträgen an, um Projektionen zu sehen.' },
    'tr.cost_note':    { fr: 'Seules les entrées avec un coût renseigné sont comptabilisées.', en: 'Only entries with a cost are counted.', es: 'Solo se cuentan los registros con coste.', de: 'Nur Einträge mit Kosten werden gezählt.' },
    'tr.record':       { fr: 'Record', en: 'Record', es: 'Récord', de: 'Rekord' },
    'tr.del_confirm':  { fr: 'Supprimer cette entrée ?', en: 'Delete this entry?', es: '¿Eliminar este registro?', de: 'Diesen Eintrag löschen?' },
    'tr.max':          { fr: 'maximum', en: 'maximum', es: 'máximo', de: 'maximal' },
    'tr.empty':        { fr: 'Vide', en: 'Empty', es: 'Vacío', de: 'Leer' },
    'tr.cons_8w':      { fr: 'Consommations · 8 semaines', en: 'Use · 8 weeks', es: 'Consumos · 8 semanas', de: 'Konsum · 8 Wochen' },
    'tr.subs_30d':     { fr: 'Substances · 30 jours', en: 'Substances · 30 days', es: 'Sustancias · 30 días', de: 'Substanzen · 30 Tage' },
    'tr.mark_sober':   { fr: "Marquer aujourd'hui sobre", en: 'Mark today sober', es: 'Marcar hoy sobrio', de: 'Heute als nüchtern markieren' },
    'tr.history':      { fr: 'Historique', en: 'History', es: 'Historial', de: 'Verlauf' },
    'tr.limit_set':    { fr: 'Limite que tu te fixes', en: 'Limit you set', es: 'Límite que te fijas', de: 'Selbst gesetztes Limit' },
    'tr.target_num':   { fr: 'Cible (nombre)', en: 'Target (number)', es: 'Objetivo (número)', de: 'Ziel (Zahl)' },
    'tr.sub_ph':       { fr: 'ex. Tabac, Alcool, Cannabis…', en: 'e.g. Tobacco, Alcohol, Cannabis…', es: 'ej. Tabaco, Alcohol, Cannabis…', de: 'z. B. Tabak, Alkohol, Cannabis…' },
    // Guide
    'gd.title':        { fr: 'Bien utiliser MyDope Off', en: 'Getting the most from MyDope Off', es: 'Sacar partido a MyDope Off', de: 'MyDope Off optimal nutzen' },
    'gd.intro':        { fr: "MyDope Off rassemble des informations scientifiques et des outils pour comprendre les substances et réduire les risques. Tout fonctionne hors-ligne et reste sur ton téléphone.",
                         en: "MyDope Off gathers scientific information and tools to understand substances and reduce risks. Everything works offline and stays on your phone.",
                         es: "MyDope Off reúne información científica y herramientas para entender las sustancias y reducir riesgos. Todo funciona sin conexión y se queda en tu teléfono.",
                         de: "MyDope Off bündelt wissenschaftliche Infos und Werkzeuge, um Substanzen zu verstehen und Risiken zu senken. Alles funktioniert offline und bleibt auf deinem Handy." },
    'gd.spaces':       { fr: 'Les cinq espaces', en: 'The five spaces', es: 'Los cinco espacios', de: 'Die fünf Bereiche' },
    'gd.subs_desc':    { fr: "270 fiches détaillées et le vérificateur d'interactions. Cherche une substance pour voir risques, durée et précautions.",
                         en: "270 detailed entries and the interaction checker. Search a substance to see risks, duration and precautions.",
                         es: "270 fichas detalladas y el verificador de interacciones. Busca una sustancia para ver riesgos, duración y precauciones.",
                         de: "270 detaillierte Einträge und der Wechselwirkungs-Check. Suche eine Substanz für Risiken, Dauer und Vorsichtsmaßnahmen." },
    'gd.ex_desc':      { fr: "Des tâches visuelles courtes (labyrinthe, etc.) qui aident à faire retomber une envie pressante en quelques minutes.",
                         en: "Short visual tasks (maze, etc.) that help a pressing urge subside within minutes.",
                         es: "Tareas visuales cortas (laberinto, etc.) que ayudan a que una ganas urgente baje en minutos.",
                         de: "Kurze visuelle Aufgaben (Labyrinth usw.), die ein drängendes Verlangen in Minuten abklingen lassen." },
    'gd.track_desc':   { fr: "Ton journal, tes coûts, tes objectifs, et la durée de détection estimée par test.",
                         en: "Your journal, your costs, your goals, and the estimated detection time per test.",
                         es: "Tu diario, tus costes, tus objetivos y el tiempo de detección estimado por prueba.",
                         de: "Dein Tagebuch, deine Kosten, deine Ziele und die geschätzte Nachweiszeit pro Test." },
    'gd.rdr_desc':     { fr: "Réduction des risques : numéros d'urgence, centres et bonnes pratiques.",
                         en: "Harm reduction: emergency numbers, centres and best practices.",
                         es: "Reducción de riesgos: números de urgencia, centros y buenas prácticas.",
                         de: "Risikominderung: Notrufnummern, Zentren und bewährte Praktiken." },
    'gd.journal_title':{ fr: 'Tenir ton journal en 3 gestes', en: 'Keep your journal in 3 steps', es: 'Lleva tu diario en 3 pasos', de: 'Dein Tagebuch in 3 Schritten' },
    'gd.j1_t':         { fr: 'Ajouter une entrée', en: 'Add an entry', es: 'Añadir un registro', de: 'Eintrag hinzufügen' },
    'gd.j1_d':         { fr: 'Suivi › Journal', en: 'Tracking › Journal', es: 'Seguimiento › Diario', de: 'Tracking › Tagebuch' },
    'gd.j2_t':         { fr: 'Plusieurs entrées le même jour', en: 'Several entries the same day', es: 'Varios registros el mismo día', de: 'Mehrere Einträge am selben Tag' },
    'gd.j2_d':         { fr: "Sur une journée déjà présente, touche « Ajouter à ce jour ». Tu peux empiler autant d'entrées que nécessaire sur la même date.",
                         en: "On a day already logged, tap \"Add to this day\". You can stack as many entries as needed on the same date.",
                         es: "En un día ya registrado, toca «Añadir a este día». Puedes apilar tantos registros como necesites en la misma fecha.",
                         de: "An einem bereits erfassten Tag auf « Zu diesem Tag » tippen. Du kannst beliebig viele Einträge am selben Datum stapeln." },
    'gd.j3_t':         { fr: 'Modifier ou supprimer', en: 'Edit or delete', es: 'Editar o eliminar', de: 'Bearbeiten oder löschen' },
    'gd.j3_d':         { fr: "Touche une entrée pour la rouvrir et la corriger, ou la croix pour la supprimer. Depuis le calendrier, touche un jour pour l'éditer directement.",
                         en: "Tap an entry to reopen and fix it, or the cross to delete it. From the calendar, tap a day to edit it directly.",
                         es: "Toca un registro para reabrirlo y corregirlo, o la cruz para eliminarlo. Desde el calendario, toca un día para editarlo directamente.",
                         de: "Tippe einen Eintrag an, um ihn zu öffnen und zu korrigieren, oder das Kreuz zum Löschen. Im Kalender tippst du einen Tag direkt zum Bearbeiten an." },
    'gd.detect_title': { fr: 'Comprendre la détection', en: 'Understanding detection', es: 'Entender la detección', de: 'Nachweis verstehen' },
    'gd.detect_intro': { fr: "Quand tu choisis une substance, MyDope Off estime la fenêtre de détection selon trois types de test :",
                         en: "When you pick a substance, MyDope Off estimates the detection window for three test types:",
                         es: "Cuando eliges una sustancia, MyDope Off estima la ventana de detección según tres tipos de prueba:",
                         de: "Wenn du eine Substanz wählst, schätzt MyDope Off das Nachweisfenster für drei Testarten:" },
    'gd.saliva':       { fr: 'Salive', en: 'Saliva', es: 'Saliva', de: 'Speichel' },
    'gd.saliva_d':     { fr: "Test oral rapide — fenêtre courte, reflète l'usage récent.", en: "Quick oral test — short window, reflects recent use.", es: "Prueba oral rápida — ventana corta, refleja el uso reciente.", de: "Schneller oraler Test — kurzes Fenster, zeigt den jüngsten Konsum." },
    'gd.urine':        { fr: 'Urine', en: 'Urine', es: 'Orina', de: 'Urin' },
    'gd.urine_d':      { fr: "Le plus répandu — fenêtre la plus longue, surtout en usage régulier.", en: "Most common — longest window, especially with regular use.", es: "La más común — ventana más larga, sobre todo en uso regular.", de: "Am verbreitetsten — längstes Fenster, vor allem bei regelmäßigem Konsum." },
    'gd.blood':        { fr: 'Sang', en: 'Blood', es: 'Sangre', de: 'Blut' },
    'gd.blood_d':      { fr: "Fenêtre la plus courte — mais la plus précise sur le moment.", en: "Shortest window — but the most accurate in the moment.", es: "Ventana más corta — pero la más precisa en el momento.", de: "Kürzestes Fenster — aber am genauesten im Moment." },
    'gd.ctrl_title':   { fr: 'Contrôles routiers', en: 'Roadside checks', es: 'Controles de tráfico', de: 'Verkehrskontrollen' },
    'gd.ctrl_desc':    { fr: "Une page dédiée explique comment se déroulent les contrôles alcool et stupéfiants au volant, les seuils légaux, et pourquoi la seule façon fiable de les passer est de ne pas conduire après avoir consommé.",
                         en: "A dedicated page explains how alcohol and drug roadside checks work, the legal limits, and why the only reliable way to pass them is not to drive after using.",
                         es: "Una página dedicada explica cómo se desarrollan los controles de alcohol y drogas al volante, los límites legales y por qué la única forma fiable de pasarlos es no conducir tras consumir.",
                         de: "Eine eigene Seite erklärt, wie Alkohol- und Drogenkontrollen ablaufen, die gesetzlichen Grenzwerte und warum man sie nur zuverlässig besteht, indem man nach dem Konsum nicht fährt." },
    'gd.ctrl_link_t':  { fr: 'Alcool, stupéfiants et conduite', en: 'Alcohol, drugs and driving', es: 'Alcohol, drogas y conducción', de: 'Alkohol, Drogen und Fahren' },
    'gd.ctrl_link_d':  { fr: "Déroulé, seuils, sanctions, comment vraiment l'éviter", en: "Process, limits, penalties, how to really avoid it", es: "Desarrollo, límites, sanciones, cómo evitarlo de verdad", de: "Ablauf, Grenzwerte, Sanktionen, echte Vermeidung" },
    'gd.lex_title':    { fr: 'Lexique réduction des risques', en: 'Harm-reduction glossary', es: 'Glosario de reducción de riesgos', de: 'Glossar Risikominderung' },
    'gd.lex_intro':    { fr: "Les termes scientifiques et le jargon que tu croises dans l'app et autour du sujet, expliqués simplement. Touche un mot pour dérouler.",
                         en: "The scientific terms and jargon you meet in the app and around the topic, explained simply. Tap a word to expand.",
                         es: "Los términos científicos y la jerga que encuentras en la app y en torno al tema, explicados de forma sencilla. Toca una palabra para desplegar.",
                         de: "Die Fachbegriffe und der Jargon, denen du in der App und rund um das Thema begegnest, einfach erklärt. Tippe ein Wort zum Aufklappen." },
    'gd.lex_note':     { fr: "Ce lexique est pédagogique et simplifié. Il ne remplace pas un avis médical.", en: "This glossary is educational and simplified. It does not replace medical advice.", es: "Este glosario es educativo y simplificado. No sustituye un consejo médico.", de: "Dieses Glossar ist didaktisch und vereinfacht. Es ersetzt keinen ärztlichen Rat." },
    'gd.data_title':   { fr: 'Tes données', en: 'Your data', es: 'Tus datos', de: 'Deine Daten' },
    'gd.support':      { fr: 'Soutenir le projet', en: 'Support the project', es: 'Apoyar el proyecto', de: 'Projekt unterstützen' },
    'gd.lex_search':   { fr: 'Rechercher un terme…', en: 'Search a term…', es: 'Buscar un término…', de: 'Begriff suchen…' },
    'gd.lex_empty':    { fr: 'Aucun terme ne correspond.', en: 'No matching term.', es: 'Ningún término coincide.', de: 'Kein passender Begriff.' },
    // Page Substances (psychochecker) — interface
    'ps.subtag':       { fr: '270 substances', en: '270 substances', es: '270 sustancias', de: '270 Substanzen' },
    'ps.checker_intro':{ fr: 'Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Enter 2 or 3 substances — every pair will be analysed.', es: 'Introduce 2 o 3 sustancias — se analizarán todos los pares.', de: 'Gib 2 oder 3 Substanzen ein — alle Paare werden analysiert.' },
    'ps.checker_title': { fr: 'Vérificateur d\'<span>interactions</span>', en: 'Interaction <span>checker</span>', es: 'Verificador de <span>interacciones</span>', de: 'Wechselwirkungs-<span>Checker</span>' },
    'ps.checker_warn': { fr: 'Outil préventif pour les personnes qui consomment déjà.', en: 'A prevention tool for people who already use.', es: 'Herramienta preventiva para quienes ya consumen.', de: 'Ein Präventionswerkzeug für Menschen, die bereits konsumieren.' },
    'ps.checker_warn2': { fr: 'N\'encourage aucun usage. Vise à réduire les dommages avec une information fiable. Saisir 2 ou 3 substances — toutes les paires seront analysées.', en: 'Encourages no use. Aims to reduce harm with reliable information. Enter 2 or 3 substances — all pairs will be analysed.', es: 'No fomenta ningún consumo. Busca reducir daños con información fiable. Introduce 2 o 3 sustancias — se analizarán todos los pares.', de: 'Ermutigt zu keinem Konsum. Zielt auf Schadensminderung mit verlässlicher Information. Gib 2 oder 3 Substanzen ein — alle Paare werden analysiert.' },
    'ps.recognized':   { fr: 'Noms reconnus : Valium, Xanax, Coke, MDMA, Éthanol…', en: 'Recognised names: Valium, Xanax, Coke, MDMA, Ethanol…', es: 'Nombres reconocidos: Valium, Xanax, Coca, MDMA, Etanol…', de: 'Erkannte Namen: Valium, Xanax, Koks, MDMA, Ethanol…' },
    'ps.sub1':         { fr: 'Substance 1', en: 'Substance 1', es: 'Sustancia 1', de: 'Substanz 1' },
    'ps.sub2':         { fr: 'Substance 2', en: 'Substance 2', es: 'Sustancia 2', de: 'Substanz 2' },
    'ps.sub3':         { fr: 'Substance 3 (optionnel)', en: 'Substance 3 (optional)', es: 'Sustancia 3 (opcional)', de: 'Substanz 3 (optional)' },
    'ps.analyze':      { fr: 'Analyser les interactions', en: 'Check interactions', es: 'Analizar interacciones', de: 'Wechselwirkungen prüfen' },
    'ps.result_empty': { fr: 'Saisir au moins 2 substances pour voir les interactions documentées.', en: 'Enter at least 2 substances to see documented interactions.', es: 'Introduce al menos 2 sustancias para ver las interacciones documentadas.', de: 'Gib mindestens 2 Substanzen ein, um dokumentierte Wechselwirkungen zu sehen.' },
    'ps.tab_classic':  { fr: 'Substances classiques', en: 'Classic substances', es: 'Sustancias clásicas', de: 'Klassische Substanzen' },
    'ps.tab_canna':    { fr: 'Cannabinoïdes', en: 'Cannabinoids', es: 'Cannabinoides', de: 'Cannabinoide' },
    'ps.search':       { fr: 'Rechercher…', en: 'Search…', es: 'Buscar…', de: 'Suchen…' },
    'ps.all_classes':  { fr: 'Toutes classes', en: 'All classes', es: 'Todas las clases', de: 'Alle Klassen' },
    'ps.cl_stimulant': { fr: 'Stimulant', en: 'Stimulant', es: 'Estimulante', de: 'Stimulans' },
    'ps.cl_depressant':{ fr: 'Dépresseur', en: 'Depressant', es: 'Depresor', de: 'Dämpfer' },
    'ps.cl_opioid':    { fr: 'Opioïde', en: 'Opioid', es: 'Opioide', de: 'Opioid' },
    'ps.cl_psyche':    { fr: 'Psychédélique', en: 'Psychedelic', es: 'Psicodélico', de: 'Psychedelikum' },
    'ps.cl_dissoc':    { fr: 'Dissociatif', en: 'Dissociative', es: 'Disociativo', de: 'Dissoziativum' },
    'ps.cl_enta':      { fr: 'Entactogène', en: 'Entactogen', es: 'Entactógeno', de: 'Entaktogen' },
    'ps.addiction':    { fr: 'Addiction', en: 'Addiction', es: 'Adicción', de: 'Suchtpotenzial' },
    'ps.effects':      { fr: 'Effets', en: 'Effects', es: 'Efectos', de: 'Wirkungen' },
    'ps.dose':         { fr: 'Dosage', en: 'Dosage', es: 'Dosis', de: 'Dosierung' },
    'ps.duration':     { fr: 'Durée', en: 'Duration', es: 'Duración', de: 'Dauer' },
    'ps.dose_low':     { fr: 'Faible', en: 'Low', es: 'Baja', de: 'Niedrig' },
    'ps.dose_mod':     { fr: 'Modéré', en: 'Moderate', es: 'Moderada', de: 'Mäßig' },
    'ps.dose_high':    { fr: 'Fort', en: 'Strong', es: 'Fuerte', de: 'Stark' },
    'ps.danger_label': { fr: 'Danger', en: 'Risk', es: 'Peligro', de: 'Gefahr' },
    'ps.no_result':    { fr: 'Aucun résultat', en: 'No results', es: 'Sin resultados', de: 'Keine Ergebnisse' },
    'ps.count_subs':   { fr: '{n} substances', en: '{n} substances', es: '{n} sustancias', de: '{n} Substanzen' },
    'ps.testimony':    { fr: 'Témoignage', en: 'Report', es: 'Testimonio', de: 'Erfahrungsbericht' },
    'ps.info':         { fr: 'Info', en: 'Info', es: 'Info', de: 'Info' },
    'ps.none_found':   { fr: 'Aucune substance trouvée.', en: 'No substance found.', es: 'Ninguna sustancia encontrada.', de: 'Keine Substanz gefunden.' },
    'ps.footer':       { fr: 'Réduction des risques', en: 'Harm reduction', es: 'Reducción de riesgos', de: 'Risikominderung' },
    // Jeux (maze + tetris)
    'gm.back':         { fr: 'Retour', en: 'Back', es: 'Atrás', de: 'Zurück' },
    'gm.maze_title':   { fr: 'Labyrinthe', en: 'Maze', es: 'Laberinto', de: 'Labyrinth' },
    'gm.maze_intro':   { fr: "12 niveaux · Incline le téléphone pour déplacer la bille jusqu'à la cible.", en: "12 levels · Tilt your phone to roll the ball to the target.", es: "12 niveles · Inclina el teléfono para llevar la bola al objetivo.", de: "12 Level · Neige dein Handy, um die Kugel zum Ziel zu rollen." },
    'gm.ready_round':  { fr: 'Prêt pour la manche ?', en: 'Ready for the round?', es: '¿Listo para la ronda?', de: 'Bereit für die Runde?' },
    'gm.maze_ready_d': { fr: 'La bille apparaît en haut à gauche. La cible rouge est en bas à droite.', en: 'The ball starts top-left. The red target is bottom-right.', es: 'La bola sale arriba a la izquierda. El objetivo rojo está abajo a la derecha.', de: 'Die Kugel startet oben links. Das rote Ziel ist unten rechts.' },
    'gm.gyro_wait':    { fr: 'Gyro en attente…', en: 'Gyro waiting…', es: 'Giroscopio en espera…', de: 'Gyro wartet…' },
    'gm.give_up':      { fr: 'Abandonner', en: 'Give up', es: 'Abandonar', de: 'Aufgeben' },
    'gm.level':        { fr: 'Niveau', en: 'Level', es: 'Nivel', de: 'Level' },
    'gm.time':         { fr: 'Temps', en: 'Time', es: 'Tiempo', de: 'Zeit' },
    'gm.penalties':    { fr: 'Pénalités', en: 'Penalties', es: 'Penalizaciones', de: 'Strafen' },
    'gm.score':        { fr: 'Score', en: 'Score', es: 'Puntuación', de: 'Punkte' },
    'gm.gyro_on':      { fr: 'Gyro actif', en: 'Gyro on', es: 'Giroscopio activo', de: 'Gyro aktiv' },
    'gm.hold_move':    { fr: 'Maintiens pour déplacer la bille', en: 'Hold to move the ball', es: 'Mantén para mover la bola', de: 'Halten, um die Kugel zu bewegen' },
    'gm.round':        { fr: 'Manche', en: 'Round', es: 'Ronda', de: 'Runde' },
    'gm.next_level':   { fr: 'Niveau suivant →', en: 'Next level →', es: 'Siguiente nivel →', de: 'Nächstes Level →' },
    'gm.restart':      { fr: 'Recommencer depuis le début', en: 'Restart from the beginning', es: 'Reiniciar desde el principio', de: 'Von vorn beginnen' },
    'gm.maze_done':    { fr: 'Labyrinthe complété !', en: 'Maze completed!', es: '¡Laberinto completado!', de: 'Labyrinth geschafft!' },
    'gm.maze_done_d':  { fr: 'Tu as activé cervelet, cortex pariétal et système vestibulaire.', en: 'You activated the cerebellum, parietal cortex and vestibular system.', es: 'Has activado el cerebelo, la corteza parietal y el sistema vestibular.', de: 'Du hast Kleinhirn, parietalen Kortex und Gleichgewichtssystem aktiviert.' },
    'gm.replay':       { fr: 'Rejouer', en: 'Play again', es: 'Volver a jugar', de: 'Nochmal spielen' },
    'gm.home':         { fr: "Retour à l'accueil", en: 'Back to home', es: 'Volver al inicio', de: 'Zur Startseite' },
    'gm.maze_h1': { fr: 'Gyro<br><span>Labyrinthe</span>', en: 'Gyro<br><span>Maze</span>', es: 'Giro<br><span>Laberinto</span>', de: 'Gyro<br><span>Labyrinth</span>' },
    'gm.maze_rules': { fr: '• Incline le téléphone = la bille bouge<br> • Touche un mur = <strong style="color:var(--red);">+1 seconde de pénalité</strong><br> • Atteins la cible rouge le plus vite possible<br> • Score max : 5/5 par niveau', en: '• Tilt the phone = the ball moves<br> • Touch a wall = <strong style="color:var(--red);">+1 second penalty</strong><br> • Reach the red target as fast as possible<br> • Max score: 5/5 per level', es: '• Inclina el teléfono = la bola se mueve<br> • Tocas una pared = <strong style="color:var(--red);">+1 segundo de penalización</strong><br> • Alcanza el objetivo rojo lo más rápido posible<br> • Puntuación máx: 5/5 por nivel', de: '• Neige das Handy = die Kugel bewegt sich<br> • Wand berührt = <strong style="color:var(--red);">+1 Sekunde Strafe</strong><br> • Erreiche das rote Ziel so schnell wie möglich<br> • Höchstpunktzahl: 5/5 pro Level' },
    'gm.maze_sci': { fr: '— Coordonner l\'équilibre physique et la navigation spatiale active des circuits cognitifs distincts du circuit de la récompense. Idéal pour couper un craving.', en: '— Coordinating physical balance and spatial navigation activates cognitive circuits distinct from the reward circuit. Ideal to cut a craving.', es: '— Coordinar el equilibrio físico y la navegación espacial activa circuitos cognitivos distintos del circuito de recompensa. Ideal para cortar un craving.', de: '— Die Koordination von körperlichem Gleichgewicht und räumlicher Navigation aktiviert kognitive Schaltkreise abseits des Belohnungssystems. Ideal, um ein Verlangen zu unterbrechen.' },
    'gm.sci_label': { fr: 'Cervelet & Pariétal', en: 'Cerebellum & Parietal', es: 'Cerebelo y Parietal', de: 'Kleinhirn & Parietal' },
    'gm.rule1': { fr: '• Incline le téléphone = la bille bouge', en: '• Tilt the phone = the ball moves', es: '• Inclina el teléfono = la bola se mueve', de: '• Neige das Handy = die Kugel bewegt sich' },
    'gm.rule2': { fr: '• Touche un mur =', en: '• Touch a wall =', es: '• Tocas una pared =', de: '• Wand berührt =' },
    'gm.rule2b': { fr: '+1 seconde de pénalité', en: '+1 second penalty', es: '+1 segundo de penalización', de: '+1 Sekunde Strafe' },
    'gm.rule3': { fr: '• Atteins la cible rouge le plus vite possible', en: '• Reach the red target as fast as possible', es: '• Alcanza el objetivo rojo lo más rápido posible', de: '• Erreiche das rote Ziel so schnell wie möglich' },
    'gm.rule4': { fr: '• Score max : 5/5 par niveau', en: '• Max score: 5/5 per level', es: '• Puntuación máx: 5/5 por nivel', de: '• Höchstpunktzahl: 5/5 pro Level' },
    'gm.perm_err': { fr: 'Permission gyroscope refusée. Utilise les flèches à la place.', en: 'Gyroscope permission denied. Use the arrows instead.', es: 'Permiso de giroscopio denegado. Usa las flechas.', de: 'Gyroskop-Berechtigung verweigert. Nutze stattdessen die Pfeile.' },
    'gm.enable_gyro': { fr: 'Activer le gyroscope', en: 'Enable the gyroscope', es: 'Activar el giroscopio', de: 'Gyroskop aktivieren' },
    'gm.use_arrows': { fr: 'Utiliser les flèches', en: 'Use the arrows', es: 'Usar las flechas', de: 'Pfeile verwenden' },
    'gm.start_round': { fr: 'Démarrer la manche', en: 'Start the round', es: 'Empezar la ronda', de: 'Runde starten' },
    'gm.give_up_x': { fr: '✕ Abandonner', en: '✕ Give up', es: '✕ Abandonar', de: '✕ Aufgeben' },
    'gm.start':        { fr: 'Commencer', en: 'Start', es: 'Empezar', de: 'Starten' },
    'gm.ready':        { fr: 'Prêt ?', en: 'Ready?', es: '¿Listo?', de: 'Bereit?' },
    'gm.tetris_title': { fr: 'Tetris anti-craving', en: 'Anti-craving Tetris', es: 'Tetris anti-craving', de: 'Anti-Craving-Tetris' },
    'gm.tetris_intro': { fr: "Complète des lignes pendant 3 minutes. Chaque palier de 10 lignes accélère la chute. L'objectif n'est pas le score : c'est d'occuper ton esprit.", en: "Clear lines for 3 minutes. Every 10 lines speeds up the fall. The goal isn't the score — it's to occupy your mind.", es: "Completa líneas durante 3 minutos. Cada 10 líneas se acelera la caída. El objetivo no es la puntuación: es ocupar tu mente.", de: "Räume 3 Minuten lang Reihen ab. Alle 10 Reihen fällt es schneller. Es geht nicht um Punkte — sondern darum, deinen Geist zu beschäftigen." },
    'gm.lines':        { fr: 'Lignes', en: 'Lines', es: 'Líneas', de: 'Reihen' },
    'gm.urge':         { fr: "Intensité de l'envie", en: 'Urge intensity', es: 'Intensidad del deseo', de: 'Stärke des Verlangens' },
    'gm.tetris_ctrl':  { fr: 'Glisse sur la grille : ← → déplacer · tap = pivoter · ↓ chute rapide', en: 'Swipe on the grid: ← → move · tap = rotate · ↓ fast drop', es: 'Desliza en la cuadrícula: ← → mover · toca = girar · ↓ caída rápida', de: 'Wisch übers Feld: ← → bewegen · tippen = drehen · ↓ schneller Fall' }
  };

  function lang() {
    let l = null;
    try { l = localStorage.getItem(LANG_KEY); } catch (e) {}
    if (l && LANGS.indexOf(l) !== -1) return l;
    const nav = (navigator.language || 'fr').slice(0, 2).toLowerCase();
    return LANGS.indexOf(nav) !== -1 ? nav : 'fr';
  }

  function setLang(l) {
    if (LANGS.indexOf(l) === -1) return;
    try { localStorage.setItem(LANG_KEY, l); } catch (e) {}
    applyI18n();
    document.documentElement.setAttribute('lang', l);
    // notifier les pages qui ont du contenu dynamique à re-rendre
    document.dispatchEvent(new CustomEvent('langchange', { detail: { lang: l } }));
  }

  function t(keyOrObj, vars) {
    const l = lang();
    let s;
    if (keyOrObj && typeof keyOrObj === 'object') {
      // objet {fr,en,es,de} fourni directement
      s = keyOrObj[l] || keyOrObj.fr || '';
    } else {
      const entry = DICT[keyOrObj];
      s = entry ? (entry[l] || entry.fr) : keyOrObj;
    }
    if (vars) Object.keys(vars).forEach(k => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }

  /* Traduit tous les éléments porteurs d'attributs i18n */
  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      if (DICT[k]) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const k = el.getAttribute('data-i18n-html');
      if (DICT[k]) el.innerHTML = t(k);
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const k = el.getAttribute('data-i18n-ph');
      if (DICT[k]) el.setAttribute('placeholder', t(k));
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const k = el.getAttribute('data-i18n-aria');
      if (DICT[k]) el.setAttribute('aria-label', t(k));
    });
    // re-render nav (libellés traduits)
    const navEl = document.querySelector('.bottom-nav');
    if (navEl && navEl.getAttribute('data-page') !== null) {
      navEl.outerHTML = renderNav(navEl.getAttribute('data-page') || '');
    }
  }

  /* Sélecteur de langue : remplit tout [data-langselect] */
  function renderLangSelect() {
    document.querySelectorAll('[data-langselect]').forEach(host => {
      const cur = lang();
      host.innerHTML = '<div class="lang-select" style="display:inline-flex;gap:4px;background:var(--soft,#F1F5F9);padding:4px;border-radius:11px;">' +
        LANGS.map(l => '<button type="button" data-setlang="' + l + '" style="border:none;cursor:pointer;font-family:var(--disp,Manrope,sans-serif);font-weight:700;font-size:12px;padding:6px 11px;border-radius:8px;background:' +
          (l === cur ? '#fff' : 'transparent') + ';color:' + (l === cur ? '#2563EB' : '#64748B') +
          (l === cur ? ';box-shadow:0 1px 3px rgba(15,23,42,.08)' : '') + ';">' + l.toUpperCase() + '</button>').join('') +
        '</div>';
      host.querySelectorAll('[data-setlang]').forEach(b => {
        b.addEventListener('click', () => { setLang(b.getAttribute('data-setlang')); renderLangSelect(); });
      });
    });
  }

  function user() {
    try { return (JSON.parse(localStorage.getItem(KEY)) || {}).user || null; }
    catch (e) { return null; }
  }

  function qs() {
    const u = user();
    if (!u || !u.name) return '';
    return '?name=' + encodeURIComponent(u.name) + '&region=' + (u.region || 'BE') + (u.age ? '&age=' + u.age : '');
  }

  function link(href) {
    const q = qs();
    if (!q) return href;
    const i = href.indexOf('#');
    return i === -1 ? href + q : href.slice(0, i) + q + href.slice(i);
  }

  function logoSVG(size, mono) {
    size = size || 32;
    const c1 = mono ? '#fff' : '#33463E', c2 = mono ? '#fff' : '#69889A', sun = mono ? '#fff' : '#C7765C';
    return '<svg viewBox="0 0 32 32" width="' + size + '" height="' + size + '" aria-label="MyDope Off">' +
      '<circle cx="23.5" cy="9" r="3.4" fill="' + sun + '"' + (mono ? ' opacity="0.9"' : '') + '/>' +
      '<path d="M1 26 L9 14 L14 21 L20 11 L31 26 Z" fill="' + c2 + '"' + (mono ? ' opacity="0.55"' : '') + '/>' +
      '<path d="M1 26 L11 17 L17 23 L23 16 L31 26 Z" fill="' + c1 + '"/></svg>';
  }

  function appIcon(size) {
    size = size || 56;
    return '<span style="display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;border-radius:' + Math.round(size * .28) + 'px;background:#F5F2EA;border:1px solid #E2DCD0;">' +
      logoSVG(Math.round(size * .56), true) + '</span>';
  }

  function wordmark() {
    return '<span style="font-family:var(--disp,Manrope,sans-serif);font-weight:800;letter-spacing:-.02em;color:#0F172A;white-space:nowrap;">MyDope <b style="color:#2563EB;font-weight:800;">Off</b></span>';
  }

  /* Navigation — libellés via clés i18n */
  const NAV = [
    { k: 'index', href: 'index.html', tkey: 'nav.home',
      icon: '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { k: 'suivi', href: 'suivi.html', tkey: 'nav.tracking',
      icon: '<path d="M22 7L13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>' },
    { k: 'psychochecker', href: 'psychochecker.html', tkey: 'nav.substances',
      icon: '<path d="M11 11m-8 0a8 8 0 1 0 16 0 8 8 0 1 0-16 0"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' },
    { k: 'fiches', href: 'fiches.html', tkey: 'nav.protocols',
      icon: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
    { k: 'rdr', href: 'rdr.html', tkey: 'nav.rdr',
      icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' }
  ];

  function renderNav(active) {
    return '<nav class="bottom-nav" data-page="' + (active || '') + '">' + NAV.map(n =>
      '<a class="bn-item' + (n.k === active ? ' active on' : '') + '" href="' + link(n.href) + '">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">' + n.icon + '</svg>' +
      '<span>' + t(n.tkey) + '</span></a>').join('') + '</nav>';
  }

  function init(opts) {
    opts = opts || {};
    document.documentElement.setAttribute('lang', lang());

    document.querySelectorAll('[data-logo]').forEach(el => {
      el.innerHTML = logoSVG(parseInt(el.getAttribute('data-logo')) || 32, el.hasAttribute('data-mono'));
    });
    document.querySelectorAll('[data-appicon]').forEach(el => {
      el.innerHTML = appIcon(parseInt(el.getAttribute('data-appicon')) || 56);
    });
    document.querySelectorAll('[data-wordmark]').forEach(el => { el.innerHTML = wordmark(); });

    const nav = document.querySelector('[data-nav]');
    if (nav) nav.outerHTML = renderNav(opts.page || '');

    document.querySelectorAll('[data-go]').forEach(a => {
      a.setAttribute('href', link(a.getAttribute('data-go')));
    });

    document.querySelectorAll('[data-back]').forEach(b => {
      b.addEventListener('click', () => {
        if (window.history.length > 1 && document.referrer && document.referrer.indexOf(location.origin) === 0) {
          window.history.back();
        } else {
          location.href = link('index.html');
        }
      });
    });

    applyI18n();
    renderLangSelect();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  return { user, qs, link, logoSVG, appIcon, wordmark, renderNav, init,
           t, lang, setLang, applyI18n, renderLangSelect, LANGS, LANG_NAMES, DICT };
})();
